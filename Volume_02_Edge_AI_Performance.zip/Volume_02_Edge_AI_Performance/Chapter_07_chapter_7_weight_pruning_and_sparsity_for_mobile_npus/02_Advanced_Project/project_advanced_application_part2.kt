
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.sparsity

import android.content.Context
import android.os.PowerManager
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import dagger.hilt.components.SingletonComponent
import dagger.hilt. Installation
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Defines the operational mode based on pruning strategy.
 */
enum class InferenceMode {
    PRECISION, // Use Dense Model (High Accuracy, High Power)
    PERFORMANCE // Use Pruned/Sparse Model (Lower Accuracy, NPU Optimized)
}

/**
 * Repository responsible for hardware-aware model orchestration.
 * It manages the lifecycle of TFLite interpreters and delegates.
 */
@Singleton
class SparsityAwareInferenceRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val powerManager: PowerManager
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null
    private var currentMode: InferenceMode? = null

    // Use a Mutex to ensure thread-safe model swapping during inference
    private val modelLock = kotlinx.coroutines.sync.Mutex()

    /**
     * Switches the underlying model and hardware delegate based on the mode.
     * This is the core of the "Advanced Application" of pruning.
     */
    suspend fun updateInferenceMode(mode: InferenceMode) = modelLock.withLock {
        if (currentMode == mode) return@withLock
        
        Log.d("SparsityRepo", "Switching to mode: $mode")
        
        // Clean up existing resources to prevent memory leaks in NPU/GPU memory
        interpreter?.close()
        if (currentDelegate is GpuDelegate) (currentDelegate as GpuDelegate).close()
        if (currentDelegate is NnApiDelegate) (currentDelegate as NnApiDelegate).close()

        val options = Interpreter.Options().apply {
            when (mode) {
                InferenceMode.PERFORMANCE -> {
                    // NPUs are designed to exploit sparsity via NNAPI.
                    // We enable the NnApiDelegate which allows the hardware to skip zero-weights.
                    this.addDelegate(NnApiDelegate())
                    this.setNumThreads(4)
                }
                InferenceMode.PRECISION -> {
                    // For dense models, GPU acceleration is often more stable for high-precision FP32/FP16.
                    this.addDelegate(GpuDelegate())
                    this.setNumThreads(2)
                }
            }
        }

        // Load the corresponding model file (.tflite)
        // In a real app, these would be assets: 'model_dense.tflite' vs 'model_sparse.tflite'
        val modelFile = if (mode == InferenceMode.PERFORMANCE) "model_sparse.tflite" else "model_dense.tflite"
        interpreter = Interpreter(loadModelFile(modelFile), options)
        currentMode = mode
    }

    /**
     * Executes inference on the current active model.
     * Uses Dispatchers.Default to ensure the NPU/GPU call doesn't block the UI.
     */
    suspend fun runInference(inputBuffer: ByteBuffer): FloatArray = withContext(Dispatchers.Default) {
        modelLock.withLock {
            val currentInterpreter = interpreter ?: throw IllegalStateException("Interpreter not initialized")
            
            // Output tensor allocation based on model metadata
            val output = Array(1) { FloatArray(1000) } 
            
            // The actual hardware call. If the model is sparse and NnApiDelegate is active,
            // the NPU will perform zero-skipping at the hardware level.
            currentInterpreter.run(inputBuffer, output)
            
            output[0]
        }
    }

    private fun loadModelFile(fileName: String): ByteBuffer {
        return context.assets.open(fileName).use { inputStream ->
            val bytes = inputStream.readBytes()
            ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
                rewind()
            }
        }
    }
}

/**
 * ViewModel that orchestrates the state between the UI and the Hardware Repository.
 */
@HiltViewModel
class SparsityViewModel @Inject constructor(
    private val repository: SparsityAwareInferenceRepository,
    private val powerManager: PowerManager
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(SparsityUiState())
    val uiState: StateFlow<SparsityUiState> = _uiState.asStateFlow()

    init {
        monitorHardwareConstraints()
    }

    private fun monitorHardwareConstraints() {
        viewModelScope.launch {
            // Poll thermal state or battery to decide on sparsity mode
            while (isActive) {
                val mode = determineOptimalMode()
                repository.updateInferenceMode(mode)
                _uiState.update { it.copy(currentMode = mode) }
                delay(5000) // Check every 5 seconds
            }
        }
    }

    private fun determineOptimalMode(): InferenceMode {
        // Logic: If device is overheating or battery is low, force the Pruned/Sparse model
        return if (powerManager.isPowerSaveMode || isDeviceOverheating()) {
            InferenceMode.PERFORMANCE
        } else {
            InferenceMode.PRECISION
        }
    }

    private fun isDeviceOverheating(): Boolean {
        // Simplified thermal check
        return false 
    }

    fun processFrame(buffer: ByteBuffer) {
        viewModelScope.launch {
            try {
                val results = repository.runInference(buffer)
                _uiState.update { it.copy(inferenceResults = results) }
            } catch (e: Exception) {
                Log.e("SparsityVM", "Inference failed", e)
            }
        }
    }
}

data class SparsityUiState(
    val currentMode: InferenceMode = InferenceMode.PRECISION,
    val inferenceResults: FloatArray = floatArrayOf(),
    val isProcessing: Boolean = false
)

/**
 * Hilt Module for Dependency Injection.
 */
@Module
@InstallIn(SingletonComponent::class)
object SparsityModule {
    @Provides
    @Singleton
    fun providePowerManager(@ApplicationContext context: Context): PowerManager {
        return context.getSystemService(Context.POWER_SERVICE) as PowerManager
    }
}
