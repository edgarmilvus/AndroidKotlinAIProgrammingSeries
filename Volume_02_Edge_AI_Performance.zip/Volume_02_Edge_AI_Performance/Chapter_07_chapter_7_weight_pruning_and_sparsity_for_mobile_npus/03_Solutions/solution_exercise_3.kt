
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import android.os.PowerManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

enum class ModelMode { HIGH_FIDELITY, PERFORMANCE }

@Singleton
class ModelManager @Inject constructor(private val context: Context) {
    private var activeInterpreter: Interpreter? = null
    private var currentMode = ModelMode.HIGH_FIDELITY

    fun switchModel(mode: ModelMode) {
        if (currentMode == mode) return
        
        // Close old interpreter to release NPU memory immediately
        activeInterpreter?.close()
        
        activeInterpreter = if (mode == ModelMode.HIGH_FIDELITY) {
            Interpreter(loadModel("dense.tflite"))
        } else {
            Interpreter(loadModel("pruned.tflite"))
        }
        currentMode = mode
    }

    fun runInference(input: Any, output: Any) {
        activeInterpreter?.run(input, output)
    }
    
    private fun loadModel(name: String) = ByteBuffer.allocateDirect(0) // Mock
}

@AndroidEntryPoint
class ThermalViewModel @Inject constructor(
    private val modelManager: ModelManager,
    private val powerManager: PowerManager
) : ViewModel() {

    private val _currentMode = MutableStateFlow(ModelMode.HIGH_FIDELITY)
    val currentMode: StateFlow<ModelMode> = _currentMode

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        when (status) {
            PowerManager.THERMAL_STATUS_MODERATE, 
            PowerManager.THERMAL_STATUS_SEVERE -> {
                updateModelMode(ModelMode.PERFORMANCE)
            }
            PowerManager.THERMAL_STATUS_NONE, 
            PowerManager.THERMAL_STATUS_SLIGHT -> {
                updateModelMode(ModelMode.HIGH_FIDELITY)
            }
        }
    }

    init {
        powerManager.addThermalStatusListener(thermalListener)
    }

    private fun updateModelMode(mode: ModelMode) {
        viewModelScope.launch(Dispatchers.Default) {
            modelManager.switchModel(mode)
            _currentMode.value = mode
        }
    }

    override fun onCleared() {
        powerManager.removeThermalStatusListener(thermalListener)
        super.onCleared()
    }
}
