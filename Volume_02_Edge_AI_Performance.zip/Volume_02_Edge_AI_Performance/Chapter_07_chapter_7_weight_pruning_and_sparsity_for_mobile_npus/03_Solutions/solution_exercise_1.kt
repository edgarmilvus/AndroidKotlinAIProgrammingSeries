
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.graphics.Color
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder

// Data class to hold analysis results
data class SparsityMetrics(
    val sparsityPercentage: Float = 0f,
    val weightMatrix: FloatArray = floatArrayOf(),
    val rows: Int = 0,
    val cols: Int = 0,
    val histogram: Map<Int, Int> = emptyMap()
)

class SparsityViewModel : ViewModel() {
    private val _metrics = MutableStateFlow(SparsityMetrics())
    val metrics: StateFlow<SparsityMetrics> = _metrics

    fun analyzeModelWeights(buffer: ByteBuffer, rows: Int, cols: Int) {
        viewModelScope.launch(Dispatchers.Default) {
            buffer.rewind()
            buffer.order(ByteOrder.nativeOrder())
            
            val totalElements = rows * cols
            val weights = FloatArray(totalElements)
            var zeroCount = 0
            val distribution = mutableMapOf<Int, Int>()

            for (i in 0 until totalElements) {
                val weight = buffer.float
                weights[i] = weight
                
                if (weight == 0f) {
                    zeroCount++
                }
                
                // Histogram: Group by magnitude (rounded to 2 decimal places)
                val bucket = (Math.abs(weight) * 100).toInt()
                distribution[bucket] = distribution.getOrDefault(bucket, 0) + 1
            }

            _metrics.value = SparsityMetrics(
                sparsityPercentage = (zeroCount.toFloat() / totalElements) * 100f,
                weightMatrix = weights,
                rows = rows,
                cols = cols,
                histogram = distribution
            )
        }
    }
}

@Composable
fun SparsityVisualizer(viewModel: SparsityViewModel) {
    val metrics by viewModel.metrics.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Sparsity: ${"%.2f".format(metrics.sparsityPercentage)}%")
        
        Spacer(modifier = Modifier.height(16.dp))

        // Use Canvas for high-performance drawing of the weight matrix
        Canvas(modifier = Modifier.fillMaxSize().aspectRatio(1f)) {
            if (metrics.rows == 0) return@Canvas

            val cellWidth = size.width / metrics.cols
            val cellHeight = size.height / metrics.rows

            for (r in 0 until metrics.rows) {
                for (c in 0 until metrics.cols) {
                    val weight = metrics.weightMatrix[r * metrics.cols + c]
                    val color = if (weight == 0f) ComposeColor.White else ComposeColor.Blue
                    
                    drawRect(
                        color = color,
                        topLeft = Offset(c * cellWidth, r * cellHeight),
                        size = Size(cellWidth, cellHeight)
                    )
                }
            }
        }
    }
}
