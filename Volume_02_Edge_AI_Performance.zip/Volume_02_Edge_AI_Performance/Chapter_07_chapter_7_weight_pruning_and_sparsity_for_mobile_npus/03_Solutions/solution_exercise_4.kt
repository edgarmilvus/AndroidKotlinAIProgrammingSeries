
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import java.nio.ByteBuffer
import java.nio.ByteOrder

class SparseBufferManager {
    
    data class CSRBuffer(
        val values: ByteBuffer,
        val colIndices: ByteBuffer,
        val rowPtr: ByteBuffer
    )

    fun packDenseToCSR(denseMatrix: FloatArray, rows: Int, cols: Int): CSRBuffer {
        val nonZeroValues = mutableListOf<Float>()
        val colIndices = mutableListOf<Int>()
        val rowPtr = IntArray(rows + 1)

        var count = 0
        for (r in 0 until rows) {
            rowPtr[r] = count
            for (c in 0 until cols) {
                val value = denseMatrix[r * cols + c]
                if (value != 0f) {
                    nonZeroValues.add(value)
                    colIndices.add(c)
                    count++
                }
            }
        }
        rowPtr[rows] = count

        return CSRBuffer(
            values = allocateAlignedBuffer(nonZeroValues.size * 4),
            colIndices = allocateAlignedBuffer(colIndices.size * 4),
            rowPtr = allocateAlignedBuffer(rowPtr.size * 4)
        ).apply {
            // Fill buffers
            values.asFloatBuffer().put(nonZeroValues.toFloatArray())
            colIndices.asIntBuffer().put(colIndices.toIntArray())
            rowPtr.asIntBuffer().put(rowPtr)
        }
    }

    private fun allocateAlignedBuffer(size: Int): ByteBuffer {
        // To ensure 64-byte alignment, we allocate extra space 
        // and slice the buffer to the first 64-byte boundary.
        val alignment = 64
        val rawBuffer = ByteBuffer.allocateDirect(size + alignment)
        rawBuffer.order(ByteOrder.nativeOrder())
        
        val address = (rawBuffer as sun.nio.ch.DirectBuffer).address()
        val offset = (alignment - (address % alignment).toInt()) % alignment
        
        rawBuffer.position(offset)
        return rawBuffer.slice().limit(size) as ByteBuffer
    }
}

// Usage and Benchmarking
fun benchmarkPacking(manager: SparseBufferManager, denseData: FloatArray) {
    val start = System.nanoTime()
    val csr = manager.packDenseToCSR(denseData, 224, 224)
    val end = System.nanoTime()
    println("Packing Overhead: ${(end - start) / 1_000_000.0} ms")
}
