
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.os.Debug
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.util.concurrent.Executors
import kotlin.system.measureNanoTime

@Singleton
class ModelBenchmarkEngine @Inject constructor() {
    private val executor = Executors.newFixedThreadPool(1)

    fun runBenchmark(
        modelPath: String, 
        iterations: Int = 50, 
        warmup: Int = 10,
        onResult: (BenchmarkResult) -> Unit
    ) {
        executor.execute {
            // 1. Configure NPU via NnApiDelegate
            val options = Interpreter.Options().apply {
                addDelegate(NnApiDelegate())
            }
            
            val interpreter = Interpreter(loadModelFile(modelPath), options)
            val input = Array(1) { Array(224) { FloatArray(224) } }
            val output = Array(1) { FloatArray(1000) }

            // 2. Warm-up Phase: Trigger NPU power-state transition & JIT
            repeat(warmup) {
                interpreter.run(input, output)
            }

            // 3. Latency Measurement
            val latencies = mutableListOf<Long>()
            repeat(iterations) {
                val time = measureNanoTime {
                    interpreter.run(input, output)
                }
                latencies.add(time)
                // Cooldown to prevent thermal throttling
                Thread.sleep(10) 
            }

            // 4. Memory Profiling
            val memInfo = Debug.MemoryInfo()
            Debug.getMemoryInfo(memInfo)
            val heapUsed = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()

            val sortedLatencies = latencies.sorted()
            val result = BenchmarkResult(
                mean = sortedLatencies.average() / 1_000_000.0,
                median = sortedLatencies[iterations / 2] / 1_000_000.0,
                p99 = sortedLatencies[(iterations * 0.99).toInt()] / 1_000_000.0,
                memoryMb = heapUsed / (1024 * 1024).toLong()
            )
            
            interpreter.close()
            onResult(result)
        }
    }

    private fun loadModelFile(path: String): ByteBuffer {
        // Implementation for loading file into direct ByteBuffer
        return ByteBuffer.allocateDirect(0) // Mock
    }
}

data class BenchmarkResult(val mean: Double, val median: Double, val p99: Double, val memoryMb: Long)
