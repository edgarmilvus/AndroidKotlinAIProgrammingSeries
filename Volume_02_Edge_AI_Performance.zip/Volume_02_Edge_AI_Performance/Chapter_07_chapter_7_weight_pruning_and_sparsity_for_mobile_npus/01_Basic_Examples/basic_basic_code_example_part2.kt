
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.sparsity

import android.content.Context
import android.os.Build
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * InferenceEngine manages the TFLite Interpreter.
 * It is designed to be agnostic of whether the model is dense or pruned,
 * allowing us to compare both side-by-side.
 */
class SparsityInferenceEngine(
    private val context: Context,
    private val modelPath: String,
    useNpu: Boolean = true
) : AutoCloseable {

    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        setupInterpreter(useNpu)
    }

    private fun setupInterpreter(useNpu: Boolean) {
        val options = Interpreter.Options().apply {
            if (useNpu && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // NNAPI is the gateway to the NPU on Android.
                // Pruned models benefit from NNAPI's ability to delegate 
                // sparse operations to the hardware accelerator.
                nnApiDelegate = NnApiDelegate()
                addDelegate(nnApiDelegate)
            }
            setNumThreads(4) // Optimize for quad-core mobile CPUs
        }
        
        interpreter = Interpreter(loadModelFile(), options)
    }

    private fun loadModelFile(): MappedByteBuffer {
        val file = context.assets.openFd(modelPath)
        val inputStream = FileInputStream(file.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = file.startOffset
        val declaredLength = file.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    /**
     * Performs inference on the provided input buffer.
     * @param inputBuffer The pre-processed image data.
     * @return The output tensor as a FloatArray.
     */
    fun runInference(inputBuffer: ByteBuffer): FloatArray {
        val output = Array(1) { FloatArray(1000) } // Assuming ImageNet 1000 classes
        interpreter?.run(inputBuffer, output)
        return output[0]
    }

    override fun close() {
        interpreter?.close()
        nnApiDelegate?.close()
    }
}
