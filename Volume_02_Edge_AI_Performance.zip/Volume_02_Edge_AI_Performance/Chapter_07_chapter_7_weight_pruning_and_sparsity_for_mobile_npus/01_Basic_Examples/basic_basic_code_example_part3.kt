
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.sparsity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.measureNanoTime

data class SparsityMetrics(
    val denseLatencyMs: Double = 0.0,
    val prunedLatencyMs: Double = 0.0,
    val speedup: Double = 0.0,
    val isProcessing: Boolean = false
)

class PruningViewModel(
    private val denseEngine: SparsityInferenceEngine,
    private val prunedEngine: SparsityInferenceEngine
) : ViewModel() {

    private val _metrics = MutableStateFlow(SparsityMetrics())
    val metrics: StateFlow<SparsityMetrics> = _metrics.asStateFlow()

    /**
     * Processes a frame from CameraX.
     * We run both models on the same frame to ensure a fair comparison.
     */
    fun analyzeFrame(bitmapBuffer: ByteBuffer) {
        viewModelScope.launch {
            _metrics.value = _metrics.value.copy(isProcessing = true)

            // Switch to Default dispatcher for CPU/NPU intensive work
            val result = withContext(Dispatchers.Default) {
                // 1. Measure Dense Model
                val denseTime = measureNanoTime {
                    denseEngine.runInference(bitmapBuffer)
                }

                // 2. Measure Pruned Model
                val prunedTime = measureNanoTime {
                    prunedEngine.runInference(bitmapBuffer)
                }

                val denseMs = denseTime / 1_000_000.0
                val prunedMs = prunedTime / 1_000_000.0
                val speedup = denseMs / prunedMs

                SparsityMetrics(
                    denseLatencyMs = denseMs,
                    prunedLatencyMs = prunedMs,
                    speedup = speedup,
                    isProcessing = false
                )
            }
            _metrics.value = result
        }
    }

    override fun onCleared() {
        super.onCleared()
        denseEngine.close()
        prunedEngine.close()
    }
}
