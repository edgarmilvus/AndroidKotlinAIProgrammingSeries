
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.ndk

import android.content.Context
import android.nio.ByteBuffer
import android.nio.ByteOrder
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as InjectHilt
import javax.inject.Singleton
import javax.inject.Scope

/**
 * MVI State representing the AI Processing Pipeline status.
 */
data class EdgeAIState(
    val isProcessing: Boolean = false,
    val inferenceResult: String = "Idle",
    val hardwareAccelerator: AcceleratorType = AcceleratorType.CPU,
    val latencyMs: Long = 0
)

enum class AcceleratorType { CPU, GPU, NPU }

/**
 * JNI Bridge: This class interfaces directly with the C++ NDK layer.
 * It uses DirectByteBuffers to avoid the JNI array-copy overhead.
 */
class NativeSignalProcessor {
    init {
        System.loadLibrary("edge_ai_ops")
    }

    // Native method to perform custom SIMD pre-processing and NPU inference
    // Returns the processing time in nanoseconds
    external fun processFrameNative(
        inputBuffer: ByteBuffer, 
        outputBuffer: ByteBuffer, 
        accelerator: Int
    ): Long

    companion object {
        const val ACCEL_CPU = 0
        const val ACCEL_GPU = 1
        const val ACCEL_NPU = 2
    }
}

/**
 * Repository: Orchestrates the flow between the JVM data source and the NDK.
 * Implements hardware-aware selection logic.
 */
@Singleton
class HardwareAccelerationRepository @InjectHilt constructor(
    @ApplicationContext private val context: Context
) {
    private val nativeProcessor = NativeSignalProcessor()
    
    // Pre-allocate DirectByteBuffers to prevent GC pressure during real-time loops.
    // 224x224x3 float32 tensor = 602,112 bytes
    private val inputBuffer: ByteBuffer = ByteBuffer.allocateDirect(224 * 224 * 3 * 4)
        .order(ByteOrder.nativeOrder())
    private val outputBuffer: ByteBuffer = ByteBuffer.allocateDirect(1000 * 4)
        .order(ByteOrder.nativeOrder())

    suspend fun executeInference(
        imageData: ByteArray, 
        preferredAccel: AcceleratorType
    ): Pair<String, Long> = withContext(Dispatchers.Default) {
        // 1. Load data into the direct buffer (Zero-copy target)
        inputBuffer.clear()
        inputBuffer.put(imageData)
        inputBuffer.flip()

        // 2. Map the enum to the native integer constant
        val accelInt = when (preferredAccel) {
            AcceleratorType.CPU -> NativeSignalProcessor.ACCEL_CPU
            AcceleratorType.GPU -> NativeSignalProcessor.ACCEL_GPU
            AcceleratorType.NPU -> NativeSignalProcessor.ACCEL_NPU
        }

        // 3. Execute the NDK operation
        val startTime = System.nanoTime()
        val nativeLatency = nativeProcessor.processFrameNative(inputBuffer, outputBuffer, accelInt)
        val endTime = System.nanoTime()

        // 4. Extract result from the output buffer without creating new objects
        outputBuffer.rewind()
        val result = "Class: ${outputBuffer.getInt()} Conf: ${outputBuffer.getFloat()}"
        
        return@withContext result to (nativeLatency / 1_000_000)
    }
}

/**
 * ViewModel: Manages the UI state and triggers the AI pipeline.
 * Uses Structured Concurrency to ensure native calls are cancelled if the VM is cleared.
 */
@HiltViewModel
@AndroidEntryPoint
class EdgeAIViewModel @InjectHilt constructor(
    private val repository: HardwareAccelerationRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(EdgeAIState())
    val uiState: StateFlow<EdgeAIState> = _uiState.asStateFlow()

    private var processingJob: Job? = null

    fun onFrameReceived(data: ByteArray) {
        // Avoid overlapping inference calls to prevent NPU buffer congestion
        if (_uiState.value.isProcessing) return

        processingJob = viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            
            try {
                // Hardware-aware orchestration: Try NPU first, fallback to GPU
                val resultPair = repository.executeInference(data, AcceleratorType.NPU)
                
                _uiState.update { 
                    it.copy(
                        isProcessing = false, 
                        inferenceResult = resultPair.first, 
                        latencyMs = resultPair.second,
                        hardwareAccelerator = AcceleratorType.NPU
                    ) 
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessing = false, inferenceResult = "Error: ${e.message}") }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        processingJob?.cancel() // Ensure native threads are signaled to stop
    }
}
