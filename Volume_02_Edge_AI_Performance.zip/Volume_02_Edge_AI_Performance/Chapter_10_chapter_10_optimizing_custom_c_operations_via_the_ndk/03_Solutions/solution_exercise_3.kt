
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.util.Log
import javax.inject.Inject
import kotlin.random.Random

class NativeEngine @Inject constructor() {
    init {
        System.loadLibrary("native-ai-ops")
    }
    external fun dotProductScalar(a: FloatArray, b: FloatArray): Float
    external fun dotProductNeon(a: FloatArray, b: FloatArray): Float
}

class PerformanceTester @Inject constructor(private val nativeEngine: NativeEngine) {
    fun runBenchmark(size: Int = 1024 * 1024) {
        val arrayA = FloatArray(size) { Random.nextFloat() }
        val arrayB = FloatArray(size) { Random.nextFloat() }

        // Warm up the JVM and Native side
        nativeEngine.dotProductScalar(arrayA, arrayB)
        nativeEngine.dotProductNeon(arrayA, arrayB)

        val startScalar = System.nanoTime()
        val res1 = nativeEngine.dotProductScalar(arrayA, arrayB)
        val endScalar = System.nanoTime()

        val startNeon = System.nanoTime()
        val res2 = nativeEngine.dotProductNeon(arrayA, arrayB)
        val endNeon = System.nanoTime()

        Log.d("AI_PERF", "Size: $size | Scalar: ${endScalar - startScalar}ns | NEON: ${endNeon - startNeon}ns")
        Log.d("AI_PERF", "Verification: Scalar=$res1, NEON=$res2")
    }
}

/* 
C++ Implementation (native-lib.cpp):
#include <arm_neon.h>

JNIEXPORT jfloat JNICALL Java_com_example_app_NativeEngine_dotProductScalar(
    JNIEnv* env, jobject thiz, jfloatArray a, jfloatArray b) {
    jfloat* ptrA = env->GetFloatArrayElements(a, 0);
    jfloat* ptrB = env->GetFloatArrayElements(b, 0);
    int len = env->GetArrayLength(a);
    float sum = 0;
    for(int i=0; i<len; i++) sum += ptrA[i] * ptrB[i];
    env->ReleaseFloatArrayElements(a, ptrA, JNI_ABORT);
    env->ReleaseFloatArrayElements(b, ptrB, JNI_ABORT);
    return sum;
}

JNIEXPORT jfloat JNICALL Java_com_example_app_NativeEngine_dotProductNeon(
    JNIEnv* env, jobject thiz, jfloatArray a, jfloatArray b) {
    jfloat* ptrA = env->GetFloatArrayElements(a, 0);
    jfloat* ptrB = env->GetFloatArrayElements(b, 0);
    int len = env->GetArrayLength(a);
    
    float32x4_t acc = vdupq_n_f32(0.0f); // Initialize accumulator with 0s
    int i = 0;
    for (; i <= len - 4; i += 4) {
        float32x4_t va = vld1q_f32(&ptrA[i]); // Load 4 floats
        float32x4_t vb = vld1q_f32(&ptrB[i]); // Load 4 floats
        acc = vmlaq_f32(acc, va, vb);         // Multiply-Accumulate
    }
    
    // Horizontal add: sum the 4 lanes of the accumulator
    float sum = vgetq_lane_f32(acc, 0) + vgetq_lane_f32(acc, 1) + 
                vgetq_lane_f32(acc, 2) + vgetq_lane_f32(acc, 3);
                
    // Tail handling
    for (; i < len; i++) sum += ptrA[i] * ptrB[i];

    env->ReleaseFloatArrayElements(a, ptrA, JNI_ABORT);
    env->ReleaseFloatArrayElements(b, ptrB, JNI_ABORT);
    return sum;
}
*/
