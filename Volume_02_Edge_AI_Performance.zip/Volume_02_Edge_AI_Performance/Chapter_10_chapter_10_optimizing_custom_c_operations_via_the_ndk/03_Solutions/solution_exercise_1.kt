
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import javax.inject.Inject
import javax.inject.Singleton
import androidx.compose.runtime.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Singleton
class NativeActivationEngine @Inject constructor() {
    init {
        System.loadLibrary("native-ai-ops")
    }

    /**
     * Applies the Swish activation function to the input tensor.
     * C++ implementation uses fast-math and potential SIMD vectorization.
     */
    external fun applySwish(input: FloatArray, beta: Float): FloatArray
}

@Composable
fun SwishActivationScreen(engine: NativeActivationEngine) {
    var inputString by remember { mutableStateOf("1.0, -2.0, 0.5, 3.0") }
    var results by remember { mutableStateOf(listOf<Float>()) }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = inputString,
            onValueChange = { inputString = it },
            label = { Text("Input Floats (comma separated)") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Button(
            onClick = {
                val input = inputString.split(",").map { it.trim().toFloat() }.toFloatArray()
                results = engine.applySwish(input, 1.0f).toList()
            },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Process with Native Swish")
        }

        LazyColumn {
            items(results) { res ->
                Text(text = "Result: ${"%.4f".format(res)}", modifier = Modifier.padding(4.dp))
            }
        }
    }
}

/* 
C++ Implementation (native-lib.cpp):
JNIEXPORT jfloatArray JNICALL Java_com_example_app_NativeActivationEngine_applySwish(
    JNIEnv* env, jobject thiz, jfloatArray input, jfloat beta) {
    
    jsize len = env->GetArrayLength(input);
    // GetPrimitiveArrayCritical blocks GC but avoids copying for better performance
    jfloat* body = (jfloat*)env->GetPrimitiveArrayCritical(input, nullptr);
    jfloat* result = (jfloat*)env->NewFloatArray(len); // Simplified for example
    
    // In a real scenario, we'd allocate a C++ array and then convert to jfloatArray
    float* out = new float[len];
    for (int i = 0; i < len; i++) {
        out[i] = body[i] * (1.0f / (1.0f + expf(-beta * body[i])));
    }
    
    env->ReleasePrimitiveArrayCritical(input, body, JNI_ABORT);
    jfloatArray jOut = env->NewFloatArray(len);
    env->SetFloatArrayRegion(jOut, 0, len, out);
    delete[] out;
    return jOut;
}
*/
