
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*
import java.nio.ByteBuffer
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

interface NativeCallback {
    fun onComplete(result: FloatArray)
    fun onError(error: String)
}

@Singleton
class AsyncNativePipeline @Inject constructor() {
    init {
        System.loadLibrary("native-ai-ops")
    }

    suspend fun processFrameAsync(buffer: ByteBuffer): FloatArray = suspendCancellableCoroutine { continuation ->
        val callback = object : NativeCallback {
            override fun onComplete(result: FloatArray) {
                // Resume the coroutine on the original dispatcher
                continuation.resume(result)
            }
            override fun onError(error: String) {
                continuation.resumeWithException(RuntimeException(error))
            }
        }
        
        try {
            nativeSubmitTask(buffer, callback)
        } catch (e: Exception) {
            continuation.resumeWithException(e)
        }
        
        continuation.invokeOnCancellation {
            nativeCancelTask(buffer)
        }
    }

    private external fun nativeSubmitTask(buffer: ByteBuffer, callback: NativeCallback)
    private external fun nativeCancelTask(buffer: ByteBuffer)
}

/* 
C++ Implementation (native-lib.cpp):
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>

JavaVM* g_jvm; // Initialized in JNI_OnLoad

struct Task {
    jobject buffer;
    jobject callbackObj;
};

std::queue<Task> taskQueue;
std::mutex queueMtx;
std::condition_variable cv;

void workerThreadLoop() {
    while (true) {
        Task task;
        {
            std::unique_lock<std::mutex> lock(queueMtx);
            cv.wait(lock, [] { return !taskQueue.empty(); });
            task = taskQueue.front();
            taskQueue.pop();
        }

        // 1. Perform heavy AI computation...
        float* data = (float*)env->GetDirectBufferAddress(task.buffer);
        // ... processing ...

        // 2. Attach this native thread to the JVM to call the callback
        JNIEnv* env;
        g_jvm->AttachCurrentThread(&env, nullptr);
        
        jclass cbClass = env->GetObjectClass(task.callbackObj);
        jmethodID mid = env->GetMethodID(cbClass, "onComplete", "([F)V");
        
        jfloatArray result = env->NewFloatArray(10); // Example size
        env->CallVoidMethod(task.callbackObj, mid, result);
        
        g_jvm->DetachCurrentThread(); // CRITICAL: Prevent memory leak
    }
}
*/
