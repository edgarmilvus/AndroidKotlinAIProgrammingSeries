
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.graphics.Bitmap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NativeImageProcessor @Inject constructor() {
    init {
        System.loadLibrary("native-ai-ops")
    }

    /**
     * Normalizes a bitmap for AI inference.
     * Directly passes the Bitmap object to C++ to access raw memory.
     */
    external fun normalizeBitmap(bitmap: Bitmap, mean: Float, std: Float): FloatArray
}

/* 
C++ Implementation (native-lib.cpp):
#include <android/bitmap.h>

JNIEXPORT jfloatArray JNICALL Java_com_example_app_NativeImageProcessor_normalizeBitmap(
    JNIEnv* env, jobject thiz, jobject bitmap, jfloat mean, jfloat std) {
    
    AndroidBitmapInfo info;
    void* pixels;

    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) return nullptr;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) return nullptr;

    int numPixels = info.width * info.height;
    float* normalizedData = new float[numPixels * 3]; // RGB
    uint32_t* rgbaPixels = (uint32_t*)pixels;

    for (int i = 0; i < numPixels; i++) {
        uint32_t pixel = rgbaPixels[i];
        // Extract channels (assuming RGBA_8888)
        float r = (float)(pixel & 0xFF);
        float g = (float)((pixel >> 8) & 0xFF);
        float b = (float)((pixel >> 16) & 0xFF);

        normalizedData[i * 3] = (r - mean) / std;
        normalizedData[i * 3 + 1] = (g - mean) / std;
        normalizedData[i * 3 + 2] = (b - mean) / std;
    }

    AndroidBitmap_unlockPixels(env, bitmap);

    jfloatArray result = env->NewFloatArray(numPixels * 3);
    env->SetFloatArrayRegion(result, 0, numPixels * 3, normalizedData);
    delete[] normalizedData;
    return result;
}
*/
