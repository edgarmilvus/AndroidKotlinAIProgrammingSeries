
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

class TensorBufferManager {
    fun createTensor(size: Int): ByteBuffer {
        // Allocate memory outside the JVM heap (off-heap)
        // 4 bytes per float
        return ByteBuffer.allocateDirect(size * 4)
            .order(ByteOrder.nativeOrder()) 
    }
}

@Singleton
class NativeTensorEngine @Inject constructor() {
    init {
        System.loadLibrary("native-ai-ops")
    }

    /**
     * Multiplies the tensor in-place by a scalar.
     * The ByteBuffer is modified directly in C++, no return value needed.
     */
    external fun scaleTensorInPlace(buffer: ByteBuffer, scalar: Float)
}

/* 
C++ Implementation (native-lib.cpp):
JNIEXPORT void JNICALL Java_com_example_app_NativeTensorEngine_scaleTensorInPlace(
    JNIEnv* env, jobject thiz, jobject buffer, jfloat scalar) {
    
    // Get the raw pointer to the direct buffer. 
    // This is O(1) and does NOT copy the data.
    float* data = (float*)env->GetDirectBufferAddress(buffer);
    if (data == nullptr) return;

    // We need to know the size. In production, pass size as an argument.
    jlong capacity = env->GetDirectBufferCapacity(buffer);
    int elementCount = capacity / sizeof(float);

    for (int i = 0; i < elementCount; i++) {
        data[i] *= scalar;
    }
}
*/
