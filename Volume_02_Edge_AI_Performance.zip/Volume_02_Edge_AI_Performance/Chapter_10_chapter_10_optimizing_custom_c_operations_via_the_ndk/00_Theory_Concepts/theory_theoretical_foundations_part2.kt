
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Configuration for the Custom C++ Op.
 * Serialized and passed to NDK to avoid JNI argument overhead.
 */
@Serializable
data class OpConfig(
    val precision: Precision = Precision.FP16,
    val useNpuAcceleration: Boolean = true,
    val threadCount: Int = 4
)

enum class Precision { FP32, FP16, INT8 }

/**
 * The Native Bridge handles the low-level JNI interactions.
 * It uses DirectByteBuffers to achieve zero-copy memory access.
 */
@Singleton
class NativeAiBridge @Inject constructor() {
    
    init {
        System.loadLibrary("edge_ai_ops")
    }

    // Native method declarations
    private external fun nativeExecuteCustomOp(
        inputBuffer: ByteBuffer, 
        outputBuffer: ByteBuffer, 
        configJson: String
    ): Int

    /**
     * Executes the custom C++ operation.
     * @return Result code from the native layer.
     */
    fun executeOp(input: ByteBuffer, output: ByteBuffer, config: OpConfig): Int {
        val configJson = Json.encodeToString(config)
        return nativeExecuteCustomOp(input, output, configJson)
    }
}

/**
 * Context Receiver for AI Operations.
 * This ensures that any function using the AI Context has access to the Bridge.
 */
interface AiContext {
    val bridge: NativeAiBridge
    val scope: CoroutineScope
}

/**
 * High-level AI Service that exposes the native operation as a Flow.
 * This is where we connect the blocking NDK call to the reactive Kotlin world.
 */
@Singleton
class EdgeAiService @Inject constructor(
    private val bridge: NativeAiBridge
) : AiContext {
    override val bridge: NativeAiBridge = bridge
    override val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * Process AI inference as a stream.
     * Just like with CameraX, we abstract the hardware complexity 
     * and provide a simple stream of results.
     */
    fun runInferenceStream(
        inputData: FloatArray, 
        config: OpConfig
    ): Flow<FloatArray> = callbackFlow {
        
        // 1. Allocate Direct ByteBuffers (Off-Heap)
        // This is critical for zero-copy NDK access.
        val inputBuffer = ByteBuffer.allocateDirect(inputData.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(inputData)
            .flip()
            .let { it.rewind(); it } // Simplified for brevity

        val outputBuffer = ByteBuffer.allocateDirect(inputData.size * 4)
            .order(ByteOrder.nativeOrder())

        // 2. Execute the blocking native call on a background thread
        scope.launch {
            try {
                val result = bridge.executeOp(
                    inputBuffer as ByteBuffer, 
                    outputBuffer, 
                    config
                )
                
                if (result == 0) {
                    // Convert output buffer back to Kotlin array
                    val outputFloatBuffer = outputBuffer.asFloatBuffer()
                    val resultData = FloatArray(inputData.size)
                    outputFloatBuffer.get(resultData)
                    
                    trySend(resultData)
                } else {
                    close(RuntimeException("Native Op failed with code: $result"))
                }
            } catch (e: Exception) {
                close(e)
            } finally {
                channel.close()
            }
        }
        
        awaitClose { /* Cleanup native resources if necessary */ }
    }
}

/**
 * Example of using Context Receivers to create a domain-specific AI language.
 * This function can only be called when an AiContext is available.
 */
context(AiContext)
fun performAdvancedOptimization(data: FloatArray) {
    // We have direct access to 'bridge' and 'scope' because of the context receiver
    scope.launch {
        val config = OpConfig(precision = Precision.INT8)
        bridge.executeOp(
            ByteBuffer.allocateDirect(0), // Dummy
            ByteBuffer.allocateDirect(0), // Dummy
            config
        )
    }
}
