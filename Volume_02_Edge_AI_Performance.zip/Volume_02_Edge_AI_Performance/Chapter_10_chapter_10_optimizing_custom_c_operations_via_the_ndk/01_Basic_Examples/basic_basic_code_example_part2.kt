
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.edgeai

import android.os.Build
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. NativeAiEngine: The JNI Wrapper
 * This class acts as the direct interface to the C++ binary.
 * We mark functions as 'external' to tell Kotlin the implementation is in C++.
 */
@Singleton
class NativeAiEngine @Inject constructor() {
    init {
        // Load the native library compiled by CMake
        System.loadLibrary("native-lib")
    }

    // The signature must match the C++ function: Java_package_class_method
    external fun processTensor(input: FloatArray, size: Int): FloatArray
}

/**
 * 2. AiRepository: The Domain Layer
 * Handles the business logic of AI execution. It abstracts the NDK calls
 * and ensures they happen on the correct thread.
 */
@Singleton
class AiRepository @Inject constructor(
    private val nativeEngine: NativeAiEngine
) {
    suspend fun runInference(data: FloatArray): Result<FloatArray> = withContext(Dispatchers.Default) {
        try {
            Log.d("AI_REPO", "Starting native processing on ${Thread.currentThread().name}")
            // Call the native C++ function
            val result = nativeEngine.processTensor(data, data.size)
            Result.success(result)
        } catch (e: Exception) {
            Log.e("AI_REPO", "Native crash or error: ${e.message}")
            Result.failure(e)
        }
    }
}

/**
 * 3. AiViewModel: The State Holder
 * Manages the UI state and triggers the AI pipeline using Coroutines.
 */
class AiViewModel @Inject constructor(
    private val repository: AiRepository
) : ViewModel() {

    // Use StateFlow for reactive UI updates in Compose
    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    fun processData() {
        viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            
            // Dummy input tensor: 1000 floats
            val inputTensor = FloatArray(1000) { it.toFloat() }
            
            val result = repository.runInference(inputTensor)
            
            _uiState.value = result.fold(
                onSuccess = { AiUiState.Success(it.take(5).toList()) }, // Return first 5 for display
                onFailure = { AiUiState.Error("Native Operation Failed") }
            )
        }
    }
}

// UI State representation
sealed class AiUiState {
    object Idle : AiUiState()
    object Loading : AiUiState()
    data class Success(val data: List<Float>) : AiUiState()
    data class Error(val message: String) : AiUiState()
}

/**
 * 4. AiScreen: The Jetpack Compose UI
 * A modern, declarative UI that observes the ViewModel state.
 */
@Composable
fun AiScreen(viewModel: AiViewModel = ViewModelProvider(ViewModelProvider.AndroidViewModelFactory.getInstance()).get(AiViewModel::class.java)) {
    // collectAsStateWithLifecycle is the lifecycle-aware way to consume flows in Compose
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Edge AI NDK Optimizer", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        when (state) {
            is AiUiState.Idle -> Text("Ready to process tensor...")
            is AiUiState.Loading -> CircularProgressIndicator()
            is AiUiState.Success -> {
                val results = (state as AiUiState.Success).data
                Text("Native Result (First 5): ${results.joinToString(", ")}")
            }
            is AiUiState.Error -> {
                Text("Error: ${(state as AiUiState.Error).message}", color = MaterialTheme.colorScheme.error)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { viewModel.processData() },
            enabled = state !is AiUiState.Loading
        ) {
            Text("Run Native Operation")
        }
    }
}
