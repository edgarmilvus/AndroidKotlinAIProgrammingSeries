
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import kotlin.math.pow
import kotlin.math.sqrt

data class BenchmarkMetrics(
    val median: Double,
    val p90: Double,
    val p99: Double,
    val stdDev: Double,
    val sampleSize: Int
)

// Interface to abstract the model execution
interface ModelRunner {
    fun runInference()
}

class LatencyProfiler(private val modelRunner: ModelRunner) {
    suspend fun profile(iterations: Int = 100, warmUp: Int = 10): BenchmarkMetrics = withContext(Dispatchers.Default) {
        // 1. Warm-up Phase: Discard initial runs to account for JIT and GPU shader compilation
        repeat(warmUp) { modelRunner.runInference() }

        val latencies = mutableListOf<Long>()

        // 2. Execution Loop: High-precision timing
        repeat(iterations) {
            val start = System.nanoTime()
            modelRunner.runInference()
            val end = System.nanoTime()
            latencies.add(end - start)
        }

        // 3. Statistical Analysis
        latencies.sort() // Sorting is required for percentile calculation
        
        val median = latencies[iterations / 2].toDouble() / 1_000_000.0
        val p90 = latencies[(iterations * 0.9).toInt()].toDouble() / 1_000_000.0
        val p99 = latencies[(iterations * 0.99).toInt()].toDouble() / 1_000_000.0
        
        val mean = latencies.average()
        val variance = latencies.map { (it - mean).pow(2) }.average()
        val stdDev = sqrt(variance) / 1_000_000.0

        BenchmarkMetrics(median, p90, p99, stdDev, iterations)
    }
}

@Composable
fun LatencyProfilerScreen(profiler: LatencyProfiler) {
    var metrics by remember { mutableStateOf<BenchmarkMetrics?>(null) }
    var isRunning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        Button(
            onClick = {
                scope.launch {
                    isRunning = true
                    metrics = profiler.profile()
                    isRunning = false
                }
            },
            enabled = !isRunning
        ) {
            Text(if (isRunning) "Profiling..." else "Run Benchmark")
        }

        Spacer(modifier = Modifier.height(16.dp))

        metrics?.let {
            Text("Results (ms):", style = MaterialTheme.typography.headlineSmall)
            Text("P50 (Median): ${"%.2f".format(it.median)}")
            Text("P90: ${"%.2f".format(it.p90)}")
            Text("P99 (Tail): ${"%.2f".format(it.p99)}")
            Text("Std Dev: ${"%.2f".format(it.stdDev)}")
            Text("Samples: ${it.sampleSize}")
        }
    }
}
