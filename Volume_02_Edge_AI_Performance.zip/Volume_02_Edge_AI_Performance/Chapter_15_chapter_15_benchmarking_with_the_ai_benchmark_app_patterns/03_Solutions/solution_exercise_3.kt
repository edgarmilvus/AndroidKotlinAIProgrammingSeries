
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import org.tensorflow.lite.Interpreter
import kotlin.math.abs

data class ModelVariant(val name: String, val fileAsset: String, val precision: String)
data class QuantizationResult(val variant: ModelVariant, val accuracy: Double, val medianLatency: Double, val efficiencyScore: Double)
data class GoldenSample(val input: FloatArray, val label: Int)

class QuantizationAnalyzer(private val context: Context, private val profilerFactory: (ModelRunner) -> LatencyProfiler) {
    private fun loadGoldenDataset(): List<GoldenSample> {
        // Mock dataset: In real world, load from assets/JSON
        return List(50) { GoldenSample(FloatArray(224 * 224 * 3), (0..9).random()) }
    }

    fun analyze(variants: List<ModelVariant>): List<QuantizationResult> {
        val dataset = loadGoldenDataset()
        val results = mutableListOf<QuantizationResult>()
        var fp32BaselineLatency = 0.0
        var fp32BaselineAccuracy = 0.0

        variants.forEach { variant ->
            val interpreter = Interpreter(loadModelFile(variant.fileAsset))
            
            // 1. Measure Latency
            val runner = object : ModelRunner {
                override fun runInference() { 
                    val output = Array(1) { FloatArray(10) }
                    interpreter.run(dataset.first().input, output) 
                }
            }
            val metrics = profilerFactory(runner).profile(iterations = 50)
            val latency = metrics.median

            // 2. Measure Top-1 Accuracy
            var correct = 0
            dataset.forEach { sample ->
                val output = Array(1) { FloatArray(10) }
                interpreter.run(sample.input, output)
                val predictedClass = output[0].indices.maxByOrNull { output[0][it] } ?: -1
                if (predictedClass == sample.label) correct++
            }
            val accuracy = correct.toDouble() / dataset.size

            if (variant.precision == "FP32") {
                fp32BaselineLatency = latency
                fp32BaselineAccuracy = accuracy
            }

            results.add(QuantizationResult(variant, accuracy, latency, 0.0)) // Efficiency calculated later
            interpreter.close()
        }

        // 3. Calculate Efficiency Score relative to FP32
        return results.map { res ->
            val speedup = fp32BaselineLatency / res.medianLatency
            val accLoss = abs(fp32BaselineAccuracy - res.accuracy)
            // Prevent division by zero; if accLoss is 0, score is effectively infinite (perfect)
            val score = if (accLoss > 0) speedup / accLoss else speedup * 100.0 
            res.copy(efficiencyScore = score)
        }
    }
    
    private fun loadModelFile(asset: String): java.nio.MappedByteBuffer { 
        /* Load logic */ 
        throw NotImplementedError() 
    }
}
