
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate

enum class AiBackend { CPU, GPU, NNAPI }

class ModelProvider(private val context: Context) {
    fun getInterpreter(backend: AiBackend): Interpreter {
        val options = Interpreter.Options()
        return try {
            when (backend) {
                AiBackend.CPU -> options.setNumThreads(4)
                AiBackend.GPU -> options.addDelegate(GpuDelegate())
                AiBackend.NNAPI -> options.addDelegate(NnApiDelegate())
            }
            // Load model from assets (simplified)
            Interpreter(loadModelFile(), options)
        } catch (e: Exception) {
            // Fallback to CPU if GPU/NNAPI fails
            if (backend != AiBackend.CPU) {
                println("Delegate ${backend.name} failed, falling back to CPU: ${e.message}")
                getInterpreter(AiBackend.CPU)
            } else throw e
        }
    }
    
    private fun loadModelFile(): java.nio.MappedByteBuffer { 
        /* Implementation to load .tflite file */ 
        throw NotImplementedError() 
    }
}

class ModelViewModel(private val modelProvider: ModelProvider, private val profilerFactory: (ModelRunner) -> LatencyProfiler) : ViewModel() {
    var currentBackend by mutableStateOf(AiBackend.CPU)
    var benchmarkResult by mutableStateOf<BenchmarkMetrics?>(null)
    var previousResult by mutableStateOf<Pair<AiBackend, Double>?>(null)

    fun runBenchmark() {
        viewModelScope.launch(Dispatchers.Default) {
            val interpreter = modelProvider.getInterpreter(currentBackend)
            val runner = object : ModelRunner {
                override fun runInference() {
                    // interpreter.run(...)
                }
            }
            val profiler = profilerFactory(runner)
            val result = profiler.profile()
            
            benchmarkResult = result
            interpreter.close()
        }
    }
}

@Composable
fun BackendComparisonScreen(viewModel: ModelViewModel) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Select Hardware Backend", style = MaterialTheme.typography.titleMedium)
        Row {
            AiBackend.values().forEach { backend ->
                FilterChip(
                    selected = viewModel.currentBackend == backend,
                    onClick = { viewModel.currentBackend = backend },
                    label = { Text(backend.name) },
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Button(onClick = { viewModel.runBenchmark() }, modifier = Modifier.padding(vertical = 16.dp)) {
            Text("Benchmark Current Backend")
        }

        viewModel.benchmarkResult?.let {
            Text("Current (${viewModel.currentBackend}): ${"%.2f".format(it.median)} ms")
            
            viewModel.previousResult?.let { prev ->
                val speedup = prev.second / it.median
                Text("Comparison: ${viewModel.currentBackend} is ${"%.2f".format(speedup)}x ${if(speedup > 1) "faster" else "slower"} than ${prev.first}")
            }
        }
    }
}
