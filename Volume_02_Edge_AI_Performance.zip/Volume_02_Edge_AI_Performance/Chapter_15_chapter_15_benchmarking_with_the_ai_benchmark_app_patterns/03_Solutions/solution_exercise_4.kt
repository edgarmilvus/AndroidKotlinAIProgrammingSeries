
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class StabilityTester(private val modelRunner: ModelRunner, private val context: Context) {
    private val latencyHistory = mutableListOf<Pair<Long, Double>>()

    suspend fun startStressTest(durationMinutes: Int, onUpdate: (List<Pair<Long, Double>>, Boolean) -> Unit) {
        val startTime = System.currentTimeMillis()
        val endTime = startTime + (durationMinutes * 60 * 1000)
        var baselineLatency = 0.0

        while (System.currentTimeMillis() < endTime) {
            val batchLatency = measureBatch(100)
            val timestamp = System.currentTimeMillis() - startTime
            
            if (baselineLatency == 0.0) baselineLatency = batchLatency
            
            latencyHistory.add(timestamp to batchLatency)
            
            // Throttling Detection: Latency increase > 20%
            val isThrottling = batchLatency > (baselineLatency * 1.2)
            
            onUpdate(latencyHistory, isThrottling)
            delay(1000) // Allow SoC to breathe and OS to update thermal stats
        }
    }

    private fun measureBatch(count: Int): Double {
        val start = System.nanoTime()
        repeat(count) { modelRunner.runInference() }
        val end = System.nanoTime()
        return (end - start).toDouble() / (count * 1_000_000.0)
    }

    fun getDeviceTemperature(): Float {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)!!.toFloat() / 10.0f
    }
}

@Composable
fun StabilityGraph(history: List<Pair<Long, Double>>, isThrottling: Boolean) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Stability Curve", style = MaterialTheme.typography.titleLarge)
        if (isThrottling) {
            Text("⚠️ THERMAL THROTTLING DETECTED", color = Color.Red)
        }
        
        Canvas(modifier = Modifier.fillMaxWidth().height(200.dp)) {
            if (history.isEmpty()) return@Canvas
            
            val maxLatency = history.maxOf { it.second }.toFloat()
            val maxTime = history.last().first.toFloat()
            
            val points = history.map { (time, latency) ->
                Offset(
                    x = (time.toFloat() / maxTime) * size.width,
                    y = size.height - ((latency.toFloat() / maxLatency) * size.height)
                )
            }
            
            for (i in 0 until points.size - 1) {
                drawLine(Color.Blue, points[i], points[i+1], strokeWidth = 2f)
            }
        }
    }
}
