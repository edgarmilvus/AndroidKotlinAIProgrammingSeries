
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.benchmark.performance

import android.content.Context
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as javaxInject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.measureNanoTime

/**
 * Represents the targeted hardware acceleration backend.
 */
enum class HardwareBackend(val displayName: String) {
    CPU("Central Processing Unit"),
    GPU("Graphics Processing Unit"),
    NPU("Neural Processing Unit (NNAPI)")
}

/**
 * Data model for a single benchmark run result.
 */
data class BenchmarkMetric(
    val backend: HardwareBackend,
    val averageLatencyMs: Double,
    val p99LatencyMs: Double,
    val throughputFps: Double,
    val isSuccessful: Boolean,
    val errorMessage: String? = null
)

/**
 * State representation for the Benchmark UI (MVI Pattern).
 */
data class BenchmarkUiState(
    val isRunning: Boolean = false,
    val currentBackend: HardwareBackend? = null,
    val results: List<BenchmarkMetric> = emptyList(),
    val progress: Float = 0f
)

/**
 * Repository responsible for the low-level orchestration of TFLite Interpreters
 * across different hardware delegates.
 */
@Singleton
class AIHardwareBenchmarkRepository @javaxInject constructor(
    @ApplicationContext private val context: Context
) {
    private val TAG = "AIHardwareRepo"

    suspend fun runBenchmark(
        modelPath: String, 
        backend: HardwareBackend, 
        iterations: Int = 50
    ): BenchmarkMetric = withContext(Dispatchers.Default) {
        var interpreter: Interpreter? = null
        try {
            val options = Interpreter.Options().apply {
                when (backend) {
                    HardwareBackend.CPU -> setNumThreads(4)
                    HardwareBackend.GPU -> addDelegate(GpuDelegate())
                    HardwareBackend.NPU -> addDelegate(NnApiDelegate())
                }
            }

            // Load model into memory
            val modelBuffer = context.assets.open(modelPath).use { 
                it.readBytes().let { bytes ->
                    ByteBuffer.allocateDirect(bytes.size).apply {
                        order(ByteOrder.nativeOrder())
                        put(bytes)
                        rewind()
                    }
                }
            }

            interpreter = Interpreter(modelBuffer, options)
            
            // 1. Warm-up Phase: Crucial for GPU/NPU to compile kernels
            val dummyInput = createDummyInput(interpreter!!.getInputTensor(0))
            val dummyOutput = createDummyOutput(interpreter!!.getOutputTensor(0))
            
            repeat(5) { interpreter!!.run(dummyInput, dummyOutput) }

            // 2. Measurement Phase
            val latencies = mutableListOf<Long>()
            repeat(iterations) {
                val time = measureNanoTime {
                    interpreter!!.run(dummyInput, dummyOutput)
                }
                latencies.add(time)
            }

            // 3. Statistical Analysis
            val sortedLatencies = latencies.sorted()
            val avgLatency = sortedLatencies.average() / 1_000_000.0
            val p99Latency = sortedLatencies[(iterations * 0.99).toInt()] / 1_000_000.0
            val fps = 1000.0 / avgLatency

            BenchmarkMetric(backend, avgLatency, p99Latency, fps, true)
        } catch (e: Exception) {
            Log.e(TAG, "Benchmark failed for ${backend.displayName}: ${e.message}")
            BenchmarkMetric(backend, 0.0, 0.0, 0.0, false, e.localizedMessage)
        } finally {
            interpreter?.close()
        }
    }

    private fun createDummyInput(tensor: org.tensorflow.lite.Tensor): ByteBuffer {
        val shape = tensor.shape()
        val size = shape.reduce { acc, i -> acc * i } * 4 // Assuming Float32
        return ByteBuffer.allocateDirect(size).apply {
            order(ByteOrder.nativeOrder())
        }
    }

    private fun createDummyOutput(tensor: org.tensorflow.lite.Tensor): ByteBuffer {
        val shape = tensor.shape()
        val size = shape.reduce { acc, i -> acc * i } * 4
        return ByteBuffer.allocateDirect(size).apply {
            order(ByteOrder.nativeOrder())
        }
    }
}

/**
 * ViewModel orchestrating the benchmark flow using Structured Concurrency.
 */
@HiltViewModel
@AndroidEntryPoint
class BenchmarkViewModel @javaxInject constructor(
    private val repository: AIHardwareBenchmarkRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(BenchmarkUiState())
    val uiState: StateFlow<BenchmarkUiState> = _uiState.asStateFlow()

    fun startFullHardwareSuite(modelPath: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, results = emptyList()) }
            
            val backends = HardwareBackend.values()
            backends.forEachIndexed { index, backend ->
                _uiState.update { it.copy(currentBackend = backend, progress = index / backends.size.toFloat()) }
                
                // Execute benchmark on Dispatchers.Default via Repository
                val result = repository.runBenchmark(modelPath, backend)
                
                _uiState.update { state ->
                    state.copy(results = state.results + result)
                }
            }
            
            _uiState.update { it.copy(isRunning = false, currentBackend = null, progress = 1.0f) }
        }
    }
}
