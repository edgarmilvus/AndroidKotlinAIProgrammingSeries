
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.benchmark.data

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The PerformanceBenchmarkRepository handles the low-level TFLite 
 * interpreter lifecycle and the timing logic.
 */
@Singleton
class PerformanceBenchmarkRepository @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    /**
     * Initializes the interpreter with a specific acceleration strategy.
     * @param useGpu Whether to use the GPU delegate or stick to CPU.
     */
    fun initializeInterpreter(useGpu: Boolean) {
        // Close existing interpreter to free memory
        closeInterpreter()

        val options = Interpreter.Options().apply {
            if (useGpu) {
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
                Log.d("AI_BENCH", "Initializing with GPU Delegate")
            } else {
                setNumThreads(4) // Standard for most mobile CPUs
                Log.d("AI_BENCH", "Initializing with CPU (4 threads)")
            }
        }

        // In a real app, load the .tflite file from assets
        // For this basic example, we assume a model is loaded
        // interpreter = Interpreter(loadModelFile(), options)
        
        // MOCK: Simulating interpreter initialization for code completeness
        interpreter = Interpreter() 
    }

    /**
     * Executes the benchmarking loop.
     * 
     * The pattern:
     * 1. Warm-up: Run 5-10 iterations to trigger JIT and cache loading.
     * 2. Measurement: Run N iterations and record precise timestamps.
     * 3. Averaging: Calculate the mean latency.
     */
    fun runBenchmark(iterations: Int = 100): BenchmarkResult {
        val interpreterRef = interpreter ?: throw IllegalStateException("Interpreter not initialized")
        
        // Create dummy input and output tensors to simulate a real model
        // Assuming a model with input [1, 224, 224, 3] and output [1, 1000]
        val input = ByteBuffer.allocateDirect(1 * 224 * 224 * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        val output = Array(1) { FloatArray(1000) }

        // --- PHASE 1: WARM-UP ---
        // We do not measure this phase. It ensures the hardware is "awake".
        repeat(10) {
            interpreterRef.run(input, output)
        }

        // --- PHASE 2: MEASUREMENT ---
        val latencies = mutableListOf<Long>()
        
        repeat(iterations) {
            val startTime = System.nanoTime()
            interpreterRef.run(input, output)
            val endTime = System.nanoTime()
            latencies.add(endTime - startTime)
        }

        // Calculate statistics
        val averageLatencyNs = latencies.average()
        val minLatencyNs = latencies.minOrNull() ?: 0L
        val maxLatencyNs = latencies.maxOrNull() ?: 0L
        
        return BenchmarkResult(
            avgMs = averageLatencyNs / 1_000_000.0,
            minMs = minLatencyNs / 1_000_000.0,
            maxMs = maxLatencyNs / 1_000_000.0,
            ips = 1000.0 / (averageLatencyNs / 1_000_000.0)
        )
    }

    fun closeInterpreter() {
        interpreter?.close()
        gpuDelegate?.close()
        interpreter = null
        gpuDelegate = null
    }
}

data class BenchmarkResult(
    val avgMs: Double,
    val minMs: Double,
    val maxMs: Double,
    val ips: Double
)
