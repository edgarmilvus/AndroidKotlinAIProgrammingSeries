
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.benchmark.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun BenchmarkScreen(vm: BenchmarkViewModel = viewModel()) {
    val uiState by vm.uiState.collectAsStateWithLifecycle()
    var useGpu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "AI Performance Benchmarker", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = useGpu, onCheckedChange = { useGpu = it })
            Text(text = "Enable GPU Acceleration")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { vm.startBenchmark(useGpu) },
            enabled = uiState !is BenchmarkUiState.Running
        ) {
            Text(if (uiState is BenchmarkUiState.Running) "Benchmarking..." else "Run Benchmark")
        }

        Spacer(modifier = Modifier.height(32.dp))

        when (val state = uiState) {
            is BenchmarkUiState.Success -> ResultDisplay(state.result)
            is BenchmarkUiState.Error -> Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
            is BenchmarkUiState.Running -> CircularProgressIndicator()
            else -> Text("Select hardware and press Run")
        }
    }
}

@Composable
fun ResultDisplay(result: com.edgeai.benchmark.data.BenchmarkResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Average Latency: ${"%.2f".format(result.avgMs)} ms", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Min Latency: ${"%.2f".format(result.minMs)} ms", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Max Latency: ${"%.2f".format(result.maxMs)} ms", style = MaterialTheme.typography.bodyMedium)
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text(text = "Throughput: ${"%.2f".format(result.ips)} IPS", style = MaterialTheme.typography.headlineSmall)
        }
    }
}
