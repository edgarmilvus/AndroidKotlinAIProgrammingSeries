
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.exp
import kotlin.math.ln

/**
 * Processor to handle the "softening" of model outputs.
 */
class LogitsProcessor {
    /**
     * Applies temperature scaling to raw logits.
     * Formula: q_i = exp(z_i / T) / sum(exp(z_j / T))
     */
    fun applyTemperature(logits: FloatArray, temperature: Float): FloatArray {
        if (temperature <= 0f) throw IllegalArgumentException("Temperature must be positive")
        
        // 1. Numerical Stability: Subtract max logit to prevent exp() overflow (Infinity)
        val maxLogit = logits.maxOrNull() ?: 0f
        val scaledLogits = FloatArray(logits.size) { i -> 
            (logits[i] - maxLogit) / temperature 
        }

        // 2. Compute exponents and sum
        var sumExp = 0f
        val exps = FloatArray(scaledLogits.size) { i ->
            val e = exp(scaledLogits[i].toDouble()).toFloat()
            sumExp += e
            e
        }

        // 3. Normalize to create a probability distribution
        return FloatArray(exps.size) { i -> exps[i] / sumExp }
    }
}

@Composable
fun TemperatureScalingScreen(logits: FloatArray, classNames: List<String>) {
    val processor = remember { LogitsProcessor() }
    var temperature by remember { mutableFloatStateOf(1.0f) }
    
    // Recalculate probabilities whenever temperature changes
    val probabilities = remember(temperature) {
        processor.applyTemperature(logits, temperature)
    }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Text(text = "Temperature: ${"%.2f".format(temperature)}", style = MaterialTheme.typography.headlineSmall)
        
        Slider(
            value = temperature,
            onValueChange = { temperature = it },
            valueRange = 0.1f..10.0f,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            itemsIndexed(probabilities) { index, prob ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = classNames.getOrElse(index) { "Class $index" })
                    Text(text = "${"%.4f".format(prob)}")
                }
                LinearProgressIndicator(
                    progress = { prob },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
            }
        }
    }
}
