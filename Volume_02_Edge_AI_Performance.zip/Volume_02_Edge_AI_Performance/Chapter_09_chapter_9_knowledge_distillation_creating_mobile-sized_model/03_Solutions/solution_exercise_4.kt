
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.room.*
import androidx.work.*
import retrofit2.http.*
import kotlin.math.log

// --- Data Layer ---
@Entity(tableName = "distillation_dataset")
data class KnowledgePair(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val imageUri: String,
    val teacherSoftTargets: String, // JSON array of probabilities
    val studentEntropy: Double
)

@Dao
interface KnowledgeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPair(pair: KnowledgePair)
}

// --- Networking ---
interface TeacherApi {
    @POST("/get_soft_targets")
    suspend fun getTeacherKnowledge(@Body imageBytes: ByteArray): List<Float>
}

// --- Logic ---
class UncertaintyBridge(
    private val api: TeacherApi,
    private val dao: KnowledgeDao,
    private val context: Context
) {
    private val ENTROPY_THRESHOLD = 1.5 // Tunable parameter

    suspend fun processInference(imageUri: String, studentProbs: FloatArray) {
        val entropy = calculateEntropy(studentProbs)
        
        if (entropy > ENTROPY_THRESHOLD) {
            Log.d("ActiveLearning", "Uncertainty detected (H=$entropy). Querying Teacher...")
            
            try {
                // 1. Privacy Layer: Basic cropping/downsampling before upload
                val processedImage = preprocessForPrivacy(imageUri)
                
                // 2. Query Cloud Teacher
                val softTargets = api.getTeacherKnowledge(processedImage)
                
                // 3. Local Storage for future distillation
                dao.insertPair(KnowledgePair(
                    imageUri = imageUri,
                    teacherSoftTargets = softTargets.joinToString(","),
                    studentEntropy = entropy
                ))
                
                // 4. Schedule background upload of the pair to server
                scheduleKnowledgeUpload()
            } catch (e: Exception) {
                Log.e("ActiveLearning", "Teacher query failed", e)
            }
        }
    }

    private fun calculateEntropy(probs: FloatArray): Double {
        var entropy = 0.0
        for (p in probs) {
            if (p > 0) {
                entropy -= p * log(p.toDouble(), Math.E)
            }
        }
        return entropy
    }

    private fun preprocessForPrivacy(uri: String): ByteArray {
        // Mock: In production, crop faces or remove EXIF data
        return "processed_image_data".toByteArray()
    }

    private fun scheduleKnowledgeUpload() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.UNMETERED)
            .setRequiresCharging(true)
            .build()

        val uploadRequest = OneTimeWorkRequestBuilder<KnowledgeUploadWorker>()
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueue(uploadRequest)
    }
}

class KnowledgeUploadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        // Implementation to upload Room DB entries to server
        return Result.success()
    }
}
