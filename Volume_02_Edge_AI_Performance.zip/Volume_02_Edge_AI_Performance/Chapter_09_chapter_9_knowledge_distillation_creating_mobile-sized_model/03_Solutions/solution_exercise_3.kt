
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import android.os.PowerManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate

enum class ModelMode { HIGH_FIDELITY, LOW_LATENCY }

class AdaptiveModelManager(private val context: Context) : ViewModel() {
    private val _currentMode = MutableStateFlow(ModelMode.HIGH_FIDELITY)
    val currentMode: StateFlow<ModelMode> = _currentMode

    private var activeInterpreter: Interpreter? = null
    private val aiDispatcher = Dispatchers.Default.limitedParallelism(1)

    init {
        setupThermalListener()
    }

    private fun setupThermalListener() {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusListener { status ->
                // Switch to Low Latency if device is overheating (Status >= THERMAL_STATUS_MODERATE)
                val targetMode = if (status >= PowerManager.THERMAL_STATUS_MODERATE) {
                    ModelMode.LOW_LATENCY
                } else {
                    ModelMode.HIGH_FIDELITY
                }
                if (targetMode != _currentMode.value) {
                    swapModel(targetMode)
                }
            }
        }
    }

    private fun swapModel(mode: ModelMode) {
        viewModelScope.launch(aiDispatcher) {
            Log.d("AI_MANAGER", "Swapping to $mode...")
            
            // 1. Prepare new interpreter options
            val options = Interpreter.Options().apply {
                if (mode == ModelMode.HIGH_FIDELITY) {
                    addDelegate(NnApiDelegate()) // NPU for high fidelity
                } else {
                    addDelegate(GpuDelegate())   // GPU for low latency
                }
            }

            // 2. Load and Warm-up
            val modelFile = if (mode == ModelMode.HIGH_FIDELITY) "model_hi.tflite" else "model_lo.tflite"
            val newInterpreter = Interpreter(loadModelFile(modelFile), options)
            
            // Warm-up: Run dummy inference to initialize GPU/NPU kernels
            val dummyInput = FloatArray(224 * 224 * 3)
            val dummyOutput = FloatArray(10)
            newInterpreter.run(dummyInput, dummyOutput)

            // 3. Graceful Swap
            val oldInterpreter = activeInterpreter
            activeInterpreter = newInterpreter
            _currentMode.value = mode
            
            // 4. Clean up native memory
            oldInterpreter?.close()
            Log.d("AI_MANAGER", "Swap complete: $mode active")
        }
    }

    private fun loadModelFile(name: String): java.nio.MappedByteBuffer {
        // Implementation using FileChannel.map() for memory efficiency
        return context.assets.openFd(name).use { fd ->
            java.nio.channels.FileChannel.open(
                java.io.File(context.filesDir, name).toPath()
            ).map(java.nio.channels.FileChannel.MapMode.READ_ONLY, 0, fd.length)
        }
    }
}
