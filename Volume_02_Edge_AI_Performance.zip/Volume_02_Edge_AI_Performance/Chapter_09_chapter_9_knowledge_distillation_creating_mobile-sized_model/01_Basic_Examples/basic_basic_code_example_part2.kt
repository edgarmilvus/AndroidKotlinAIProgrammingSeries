
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.distillation.example

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data class representing the result of an inference pass.
 * We track both the prediction and the time taken to demonstrate the 
 * efficiency of the distilled Student model.
 */
data class InferenceResult(
    val label: String,
    val confidence: Float,
    val latencyMs: Long,
    val modelType: ModelType
)

enum class ModelType { TEACHER, STUDENT }

/**
 * Interface for our AI models to ensure both Teacher and Student 
 * adhere to the same input/output contract.
 */
interface EdgeModel : AutoCloseable {
    fun predict(input: ByteBuffer): Pair<String, Float>
}

/**
 * Base implementation of a TFLite model wrapper.
 * Handles memory mapping and hardware acceleration.
 */
open class TFLiteModelWrapper(
    context: Context,
    modelPath: String,
    useGpu: Boolean = true
) : EdgeModel {
    protected val interpreter: Interpreter

    init {
        val options = Interpreter.Options().apply {
            if (useGpu) {
                // Leverage GPU acceleration for the Teacher model
                addDelegate(GpuDelegate())
            }
            setNumThreads(Runtime.getRuntime().availableProcessors())
        }
        interpreter = Interpreter(loadModelFile(context, modelPath), options)
    }

    private fun loadModelFile(context: Context, path: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.open(path))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    override fun close() {
        interpreter.close()
    }
}

/**
 * The Teacher Model: Large, high-accuracy, high-latency.
 * Example: ResNet-101 (approx 170MB)
 */
class TeacherModel(context: Context) : TFLiteModelWrapper(context, "teacher_resnet101.tflite") {
    override fun predict(input: ByteBuffer): Pair<String, Float> {
        val output = Array(1) { FloatArray(1000) } // Assuming ImageNet 1000 classes
        interpreter.run(input, output)
        val maxIdx = output[0].indices.maxByOrNull { output[0][it] } ?: 0
        return "Class $maxIdx" to output[0][maxIdx]
    }
}

/**
 * The Student Model: Distilled, low-latency, slightly lower accuracy.
 * Example: MobileNetV3-Small (approx 5MB)
 */
class StudentModel(context: Context) : TFLiteModelWrapper(context, "student_mobilenet.tflite", useGpu = false) {
    override fun predict(input: ByteBuffer): Pair<String, Float> {
        val output = Array(1) { FloatArray(1000) }
        interpreter.run(input, output)
        val maxIdx = output[0].indices.maxByOrNull { output[0][it] } ?: 0
        return "Class $maxIdx" to output[0][maxIdx]
    }
}

/**
 * Repository handling the orchestration of Teacher vs Student inference.
 */
@Singleton
class DistillationRepository @Inject constructor(private val context: Context) {
    private val teacher = TeacherModel(context)
    private val student = StudentModel(context)

    suspend fun runInference(input: ByteBuffer, type: ModelType): InferenceResult = withContext(Dispatchers.Default) {
        val model = if (type == ModelType.TEACHER) teacher else student
        
        val startTime = SystemClock.elapsedRealtime()
        val (label, confidence) = model.predict(input)
        val endTime = SystemClock.elapsedRealtime()
        
        InferenceResult(label, confidence, endTime - startTime, type)
    }

    fun release() {
        teacher.close()
        student.close()
    }
}

/**
 * ViewModel managing the state and ensuring AI work is offloaded from the Main Thread.
 */
@HiltViewModel
class DistillationViewModel @Inject constructor(
    private val repository: DistillationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<List<InferenceResult>>(emptyList())
    val uiState: StateFlow<List<InferenceResult>> = _uiState.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun compareModels(inputData: ByteBuffer) {
        viewModelScope.launch {
            _isProcessing.value = true
            
            // Run both inferences in parallel using async
            val teacherDeferred = async { repository.runInference(inputData, ModelType.TEACHER) }
            val studentDeferred = async { repository.runInference(inputData, ModelType.STUDENT) }
            
            val results = awaitAll(teacherDeferred, studentDeferred)
            _uiState.value = results
            
            _isProcessing.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.release()
    }
}

/**
 * Jetpack Compose UI for visualizing the Distillation impact.
 */
@Composable
fun DistillationScreen(viewModel: DistillationViewModel) {
    val results by viewModel.uiState.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    
    // Simulated input buffer (in a real app, this comes from CameraX/Bitmap)
    val dummyInput = remember {
        ByteBuffer.allocateDirect(224 * 224 * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
    }

    Column(modifier = androidx.compose.ui.Modifier.padding(16.dp)) {
        Text(text = "Knowledge Distillation Benchmarking", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = androidx.compose.ui.Modifier.height(16.dp))
        
        Button(
            onClick = { viewModel.compareModels(dummyInput) },
            enabled = !isProcessing
        ) {
            Text(if (isProcessing) "Analyzing..." else "Run Comparison")
        }

        Spacer(modifier = androidx.compose.ui.Modifier.height(24.dp))

        results.forEach { result ->
            ResultRow(result)
        }
    }
}

@Composable
fun ResultRow(result: InferenceResult) {
    Card(modifier = androidx.compose.ui.Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = androidx.compose.ui.Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(text = result.modelType.name, style = androidx.compose.material3.MaterialTheme.typography.labelLarge)
                Text(text = "Prediction: ${result.label}")
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(text = "Latency: ${result.latencyMs}ms", color = androidx.compose.ui.graphics.Color.Blue)
                Text(text = "Conf: ${"%.2f".format(result.confidence)}")
            }
        }
    }
}
