
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.distillation.segmentation

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Singleton
import javax.inject.Inject

/**
 * Represents the state of the AI Inference UI.
 */
data class SegmentationState(
    val isProcessing: Boolean = false,
    val segmentationMask: Bitmap? = null,
    val detectedClasses: List<String> = emptyList(),
    val hardwareAccelerator: String = "Detecting...",
    val error: String? = null
)

/**
 * Sealed class for MVI Intents.
 */
sealed class SegmentationIntent {
    data class ProcessFrame(val bitmap: Bitmap) : SegmentationIntent()
    object ResetState : SegmentationIntent()
}

/**
 * Hardware-aware Inference Engine.
 * This class encapsulates the logic of loading the distilled model 
 * and selecting the optimal hardware delegate.
 */
@Singleton
class DistilledInferenceEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    // The distilled model is typically smaller and quantized to INT8
    private val modelPath = "student_segmentation_quant.tflite"

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // Priority 1: NPU via NNAPI (Best for Quantized Distilled Models)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nnApiDelegate = NnApiDelegate()
                addDelegate(nnApiDelegate)
                Log.i("EdgeAI", "Using NPU Acceleration via NNAPI")
            } else {
                // Priority 2: GPU via OpenCL/OpenGL
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
                Log.i("EdgeAI", "Using GPU Acceleration")
            }
            
            // Optimization: Set number of threads for CPU fallback
            setNumThreads(Runtime.getRuntime().availableProcessors())
        }

        try {
            interpreter = Interpreter(loadModelFile(), options)
        } catch (e: Exception) {
            Log.e("EdgeAI", "Failed to initialize interpreter", e)
        }
    }

    private fun loadModelFile(): ByteBuffer {
        return context.assets.open(modelPath).use { inputStream ->
            val bytes = inputStream.readBytes()
            ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
                rewind()
            }
        }
    }

    fun runInference(bitmap: Bitmap): Pair<ByteBuffer, String> {
        val inputBuffer = preprocess(bitmap)
        val outputBuffer = ByteBuffer.allocateDirect(1 * 256 * 256 * 21) // Example: 21 classes
        outputBuffer.order(ByteOrder.nativeOrder())

        interpreter?.run(inputBuffer, outputBuffer)
        
        val accelerator = when {
            nnApiDelegate != null -> "NPU (NNAPI)"
            gpuDelegate != null -> "GPU (OpenGL)"
            else -> "CPU (XNNPACK)"
        }
        
        return Pair(outputBuffer, accelerator)
    }

    private fun preprocess(bitmap: Bitmap): ByteBuffer {
        // Distilled models often require specific normalization (e.g., -1 to 1)
        val inputBuffer = ByteBuffer.allocateDirect(1 * 256 * 256 * 3 * 4)
        inputBuffer.order(ByteOrder.nativeOrder())
        
        // Simplified normalization logic
        val pixels = IntArray(256 * 256)
        bitmap.getPixels(pixels, 0, 256, 0, 0, 256, 256)
        
        for (pixel in pixels) {
            inputBuffer.putFloat(((pixel shr 16 and 0xFF) - 127.5f) / 127.5f)
            inputBuffer.putFloat(((pixel shr 8 and 0xFF) - 127.5f) / 127.5f)
            inputBuffer.putFloat(((pixel and 0xFF) - 127.5f) / 127.5f)
        }
        inputBuffer.rewind()
        return inputBuffer
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * Repository layer to abstract the AI logic from the ViewModel.
 */
@Singleton
class SegmentationRepository @Inject constructor(
    private val engine: DistilledInferenceEngine
) {
    suspend fun analyzeImage(bitmap: Bitmap): Pair<ByteBuffer, String> = withContext(Dispatchers.Default) {
        // Use Dispatchers.Default for CPU-intensive tensor preparation
        engine.runInference(bitmap)
    }
}

/**
 * ViewModel implementing MVI pattern for state management.
 */
@HiltViewModel
@AndroidEntryPoint
class SegmentationViewModel @Inject constructor(
    private val repository: SegmentationRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SegmentationState())
    val state: StateFlow<SegmentationState> = _state.asStateFlow()

    private val intentChannel = MutableSharedFlow<SegmentationIntent>()

    init {
        handleIntents()
    }

    fun sendIntent(intent: SegmentationIntent) {
        viewModelScope.launch {
            intentChannel.emit(intent)
        }
    }

    private fun handleIntents() {
        viewModelScope.launch {
            intentChannel.collect { intent ->
                when (intent) {
                    is SegmentationIntent.ProcessFrame -> performInference(intent.bitmap)
                    is SegmentationIntent.ResetState -> _state.value = SegmentationState()
                }
            }
        }
    }

    private suspend fun performInference(bitmap: Bitmap) {
        _state.update { it.copy(isProcessing = true) }
        
        try {
            // Structured Concurrency: The inference runs on a background thread 
            // but is scoped to the ViewModel's lifecycle.
            val (resultBuffer, accelerator) = repository.analyzeImage(bitmap)
            
            // Post-processing (converting buffer to bitmap) is also heavy
            val mask = withContext(Dispatchers.Default) {
                processOutputBuffer(resultBuffer)
            }

            _state.update { 
                it.copy(
                    isProcessing = false, 
                    segmentationMask = mask, 
                    hardwareAccelerator = accelerator 
                ) 
            }
        } catch (e: Exception) {
            _state.update { it.copy(isProcessing = false, error = e.message) }
        }
    }

    private fun processOutputBuffer(buffer: ByteBuffer): Bitmap {
        // Logic to convert the Student model's output tensor into a visual mask
        val bitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        // ... (Pixel mapping logic based on argmax of the distilled output)
        return bitmap
    }
}
