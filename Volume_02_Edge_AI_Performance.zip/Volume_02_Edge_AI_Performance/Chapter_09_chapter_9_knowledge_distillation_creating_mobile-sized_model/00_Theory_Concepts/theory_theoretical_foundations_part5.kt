
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

// 1. Define the AI Provider interface to decouple from the specific system implementation
interface AiProvider {
    suspend fun predict(input: String, config: InferenceConfig): Flow<String>
}

// 2. The System Implementation (AICore / Gemini Nano)
class AICoreProvider @Inject constructor(
    private val context: Context
) : AiProvider {
    override suspend fun predict(input: String, config: InferenceConfig): Flow<String> = flow {
        // This is where the JNI call to the system's C++ AI service happens
        // Just like CameraX interacts with the Camera HAL
        val systemService = context.getSystemService(Context.AI_SERVICE) as? AiSystemService
        
        systemService?.runInference(input, config)?.collect { token ->
            emit(token)
        } ?: throw IllegalStateException("AICore not available on this device")
    }
}

// 3. Hilt Module for Dependency Injection
@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides
    @Singleton
    fun provideAiProvider(@ApplicationContext context: Context): AiProvider {
        return AICoreProvider(context)
    }
}

// 4. The ViewModel utilizing the distilled model
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val aiProvider: AiProvider
) : ViewModel() {
    
    private val _uiState = MutableStateFlow<ChatState>(ChatState.Idle)
    val uiState = _uiState.asStateFlow()

    fun sendMessage(text: String) {
        viewModelScope.launch {
            _uiState.value = ChatState.Typing
            
            val config = InferenceConfig(temperature = 0.8f)
            
            aiProvider.predict(text, config)
                .catch { e -> _uiState.value = ChatState.Error(e.message) }
                .collect { token ->
                    // Append token to the current response in the state
                    _uiState.value = ChatState.Responding(currentText = (_uiState.value as? ChatState.Responding)?.currentText ?: "" + token)
                }
        }
    }
}

sealed class ChatState {
    object Idle : ChatState()
    object Typing : ChatState()
    data class Responding(val currentText: String) : ChatState()
    data class Error(val message: String?) : ChatState()
}
