
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.inference

import android.content.Context
import android.os.Build
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Sealed class representing the state of the AI Inference process.
 * Following MVI patterns to ensure unidirectional data flow.
 */
sealed interface InferenceState {
    object Idle : InferenceState
    object Processing : InferenceState
    data class Success(val results: List<DetectionResult>) : InferenceState
    data class Error(val message: String) : InferenceState
}

data class DetectionResult(val label: String, val confidence: Float, val bbox: FloatArray)

/**
 * Hardware-aware engine that handles the complexity of TFLite delegates.
 * It prioritizes NPU (NNAPI) -> GPU -> CPU.
 */
@Singleton
class HardwareAcceleratedEngine @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    private val TAG = "EdgeAI_Engine"

    init {
        initializeInterpreter()
    }

    private fun initializeInterpreter() {
        try {
            val options = Interpreter.Options()
            val modelBuffer = loadModelFile("model_quantized.tflite")

            // 1. Attempt NNAPI (NPU/DSP)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Log.i(TAG, "Attempting NNAPI acceleration...")
                nnApiDelegate = NnApiDelegate()
                options.addDelegate(nnApiDelegate)
            }

            // 2. Fallback to GPU if NNAPI is unavailable or fails
            // In a real scenario, you might wrap this in a try-catch specifically for the delegate
            try {
                gpuDelegate = GpuDelegate()
                options.addDelegate(gpuDelegate)
                Log.i(TAG, "GPU Delegate initialized successfully.")
            } catch (e: Exception) {
                Log.w(TAG, "GPU Delegate failed, falling back to CPU: ${e.message}")
            }

            // Use XNNPACK for CPU optimization (enabled by default in newer TFLite versions)
            options.setNumThreads(Runtime.getRuntime().availableProcessors())
            
            interpreter = Interpreter(modelBuffer, options)
        } catch (e: Exception) {
            Log.e(TAG, "Critical failure initializing TFLite: ${e.message}")
        }
    }

    private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    /**
     * Performs inference on the provided ByteBuffer.
     * Uses a blocking call, intended to be wrapped in Dispatchers.Default.
     */
    fun runInference(inputBuffer: ByteBuffer): List<DetectionResult> {
        val outputBuffer = ByteBuffer.allocateDirect(1 * 10 * 6) // Example: 10 detections, 6 values each
            .order(ByteOrder.nativeOrder())

        interpreter?.run(inputBuffer, outputBuffer) ?: throw IllegalStateException("Interpreter not initialized")

        return parseResults(outputBuffer)
    }

    private fun parseResults(buffer: ByteBuffer): List<DetectionResult> {
        // Logic to convert raw ByteBuffer to a list of DetectionResult objects
        // This is a simplified mock for demonstration
        return listOf(DetectionResult("Object", 0.92f, floatArrayOf(0f, 0f, 100f, 100f)))
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * Repository layer to abstract hardware orchestration and data mapping.
 */
@Singleton
class InferenceRepository @Inject constructor(
    private val engine: HardwareAcceleratedEngine
) {
    suspend fun processImage(imageBuffer: ByteBuffer): Result<List<DetectionResult>> = withContext(Dispatchers.Default) {
        try {
            val results = engine.runInference(imageBuffer)
            Result.success(results)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * ViewModel implementing MVI pattern to handle UI state and hardware triggers.
 */
@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val repository: InferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<InferenceState>(InferenceState.Idle)
    val uiState: StateFlow<InferenceState> = _uiState.asStateFlow()

    /**
     * Triggered by the CameraX Analyzer.
     * Uses structured concurrency to ensure inference doesn't overlap and leaks.
     */
    private var inferenceJob: Job? = null

    fun onFrameReceived(buffer: ByteBuffer) {
        // Cancel previous job if a new frame arrives before the previous one finished
        // This prevents backpressure and UI lag (Frame Dropping Strategy)
        inferenceJob?.cancel()
        
        inferenceJob = viewModelScope.launch {
            _uiState.value = InferenceState.Processing
            
            repository.processImage(buffer)
                .onSuccess { results ->
                    _uiState.value = InferenceState.Success(results)
                }
                .onFailure { error ->
                    _uiState.value = InferenceState.Error(error.message ?: "Unknown Error")
                }
        }
    }
}

@Module
@InstallIn(SingletonComponent::class)
object InferenceModule {
    @Provides
    @Singleton
    fun provideEngine(@BindsInstance context: Context): HardwareAcceleratedEngine {
        return HardwareAcceleratedEngine(context)
    }
}
