
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp

fun preprocessImage(bitmap: android.graphics.Bitmap): ByteBuffer {
    // 1. Create a TensorImage object
    val tensorImage = TensorImage(org.tensorflow.lite.DataType.FLOAT32)
    tensorImage.load(bitmap)

    // 2. Define the preprocessing pipeline
    // Most models expect a specific size (e.g., 224x224)
    val imageProcessor = ImageProcessor.Builder()
        .add(ResizeOp(224, 224, org.tensorflow.lite.support.image.ops.ResizeOp.Method.BILINEAR))
        // Add normalization if the model expects values between -1 and 1
        // .add(NormalizeOp(127.5f, 127.5f)) 
        .build()

    // 3. Process the image
    val processedImage = imageProcessor.process(tensorImage)
    
    // 4. Return the underlying ByteBuffer
    return processedImage.buffer
}
