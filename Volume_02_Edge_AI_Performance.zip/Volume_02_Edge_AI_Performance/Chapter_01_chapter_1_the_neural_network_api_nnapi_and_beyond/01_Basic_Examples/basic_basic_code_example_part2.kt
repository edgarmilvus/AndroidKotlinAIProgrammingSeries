
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.data

import android.content.Context
import android.os.Build
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.support.common.FileUtil
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ModelRepository handles the loading of the TFLite model and 
 * configures the hardware acceleration via NNAPI.
 */
@Singleton
class ModelRepository @Inject constructor(
    private val context: Context
) : Closeable {

    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        try {
            // 1. Load the model file from the assets folder
            // Mmap (Memory Mapping) is used here by FileUtil to avoid loading 
            // the entire model into RAM, reducing memory pressure.
            val modelBuffer = FileUtil.loadMappedFile(context, "mobilenet_v2.tflite")

            // 2. Configure NNAPI Delegate
            // We only initialize NNAPI if the device API level is 28 (Android 9) or higher.
            val options = Interpreter.Options().apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    // Create the NNAPI delegate. 
                    // This tells TFLite to attempt to offload operations to the NPU/DSP.
                    nnApiDelegate = NnApiDelegate()
                    addDelegate(nnApiDelegate)
                }
                
                // Set the number of threads for the CPU fallback.
                // If NNAPI cannot handle a specific op, it falls back to the CPU.
                setNumThreads(4)
            }

            // 3. Initialize the Interpreter
            interpreter = Interpreter(modelBuffer, options)
        } catch (e: Exception) {
            e.printStackTrace()
            // In a real app, use a Result wrapper or a custom Exception handler
        }
    }

    /**
     * Performs inference on the provided input buffer.
     * @param inputBuffer A Direct ByteBuffer containing the normalized image data.
     * @return A float array containing the classification probabilities.
     */
    fun classify(inputBuffer: ByteBuffer): FloatArray {
        val output = Array(1) { FloatArray(1000) } // Assuming MobileNet (1000 classes)
        
        // The actual execution happens here. 
        // If the NNAPI delegate is active, this call triggers the HAL to use the NPU.
        interpreter?.run(inputBuffer, output)
        
        return output[0]
    }

    override fun close() {
        // CRITICAL: Always close the interpreter and delegate to prevent memory leaks
        // and release the hardware lock on the NPU/GPU.
        interpreter?.close()
        nnApiDelegate?.close()
    }
}
