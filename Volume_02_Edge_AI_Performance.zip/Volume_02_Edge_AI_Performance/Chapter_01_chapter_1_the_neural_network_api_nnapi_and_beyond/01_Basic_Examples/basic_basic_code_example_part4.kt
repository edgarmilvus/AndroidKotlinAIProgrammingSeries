
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import dagger.hilt.android.AndroidEntryPoint
import android.app.Activity
import androidx.compose.ui.platform.LocalContext
import java.nio.ByteBuffer
import java.nio.ByteOrder

@Composable
fun InferenceScreen(
    viewModel: InferenceViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (state) {
            is InferenceState.Idle -> {
                Text("Ready for Inference")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { 
                    // Simulate image data (224x224x3 float32)
                    val buffer = ByteBuffer.allocateDirect(224 * 224 * 3 * 4).apply {
                        order(ByteOrder.nativeOrder())
                    }
                    viewModel.runInference(buffer) 
                }) {
                    Text("Run Model")
                }
            }
            is InferenceState.Loading -> {
                CircularProgressIndicator()
                Text("NNAPI Computing...")
            }
            is InferenceState.Success -> {
                val success = state as InferenceState.Success
                Text(text = "Result: ${success.label}", style = MaterialTheme.typography.headlineMedium)
                Text(text = "Confidence: ${(success.confidence * 100).toInt()}%")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { /* Reset logic */ }) {
                    Text("Retry")
                }
            }
            is InferenceState.Error -> {
                Text(text = "Error: ${(state as InferenceState.Error).message}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
