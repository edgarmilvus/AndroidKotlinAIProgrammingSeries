
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

enum class ModelPrecision { FP32, FP16, INT8 }

data class BenchResult(val precision: ModelPrecision, val delegate: String, val avgLatency: Double, val memoryMb: Long)

class QuantizationLab(private val context: Context) {
    private val testInputs = List(100) { FloatArray(128) { Math.random().toFloat() } }

    suspend fun runMatrix(): List<BenchResult> = withContext(Dispatchers.Default) {
        val results = mutableListOf<BenchResult>()
        val precisions = ModelPrecision.values()
        val delegates = listOf("CPU", "NNAPI")

        for (precision in precisions) {
            for (delegateName in delegates) {
                val modelFile = "model_${precision.name.toLowerCase()}.tflite"
                val interpreter = loadInterpreter(modelFile, delegateName)
                
                // 1. Warm-up phase: Discard first 5 runs
                repeat(5) { interpreter.run(testInputs[0], Array(1) { FloatArray(3) }) }

                // 2. Benchmarking phase
                val latencies = mutableListOf<Long>()
                repeat(100) { i ->
                    val start = System.nanoTime()
                    interpreter.run(testInputs[i], Array(1) { FloatArray(3) })
                    latencies.add(System.nanoTime() - start)
                }

                // 3. Memory tracking
                val runtime = Runtime.getRuntime()
                val memoryUsed = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)

                results.add(BenchResult(
                    precision, 
                    delegateName, 
                    latencies.average() / 1_000_000.0, 
                    memoryUsed
                ))
                interpreter.close()
            }
        }
        results
    }

    private fun loadInterpreter(file: String, delegate: String): Interpreter {
        val options = Interpreter.Options().apply {
            if (delegate == "NNAPI") addDelegate(NnApiDelegate.create())
        }
        return Interpreter(context.assets.open(file).readBytes(), options)
    }
}
