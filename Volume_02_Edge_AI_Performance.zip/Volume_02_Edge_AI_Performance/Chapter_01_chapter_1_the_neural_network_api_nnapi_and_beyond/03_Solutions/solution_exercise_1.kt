
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

// 1. Inference Engine Implementation
@Singleton
class InferenceEngine @Inject constructor(
    @ApplicationContext private val context: Context
) : AutoCloseable {
    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // Configure NNAPI Delegate
            nnApiDelegate = NnApiDelegate.create()
            addDelegate(nnApiDelegate)
        }
        
        // Load model from assets
        val modelBuffer = context.assets.open("text_classifier.tflite").readBytes()
        interpreter = Interpreter(modelBuffer, options)
    }

    suspend fun classify(text: String): String = withContext(Dispatchers.Default) {
        // Mocking preprocessing: Convert text to float array
        val input = FloatArray(128) { 0f } 
        val output = Array(1) { FloatArray(3) } // 3 categories: Urgent, Social, Work

        interpreter?.run(input, output)
        
        val categories = listOf("Urgent", "Social", "Work")
        val maxIndex = output[0].indices.maxByOrNull { output[0][it] } ?: 0
        categories[maxIndex]
    }

    override fun close() {
        interpreter?.close()
        nnApiDelegate?.close()
    }
}

// 2. Hilt Module for Dependency Injection
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideInferenceEngine(@ApplicationContext context: Context): InferenceEngine {
        return InferenceEngine(context)
    }
}

// 3. ViewModel for UI State Management
@HiltViewModel
class ClassifierViewModel @Inject constructor(
    private val engine: InferenceEngine
) : ViewModel() {
    private val _prediction = MutableStateFlow("Enter text...")
    val prediction = _prediction.asStateFlow()

    fun onTextEntered(text: String) {
        viewModelScope.launch {
            _prediction.value = "Analyzing..."
            val result = engine.classify(text)
            _prediction.value = "Category: $result"
        }
    }
}

// 4. Compose UI
@AndroidEntryPoint
@Composable
fun ClassifierScreen(viewModel: ClassifierViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var text by remember { mutableStateOf("") }
    val prediction by viewModel.prediction.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = text,
            onValueChange = { 
                text = it
                viewModel.onTextEntered(it) 
            },
            label = { Text("Message") }
        )
        Text(text = prediction, style = MaterialTheme.typography.headlineSmall)
    }
}
