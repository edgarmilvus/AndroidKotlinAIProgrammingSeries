
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.graphics.HardwareBuffer
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp

class VisionPipeline(private val engine: InferenceEngine) : ImageAnalysis.Analyzer {
    
    // Pre-allocate TensorImage to avoid GC pressure in 30fps loop
    private val tensorImage = TensorImage(org.tensorflow.lite.DataType.FLOAT32)
    private val imageProcessor = ImageProcessor.Builder()
        .add(ResizeOp(224, 224, org.tensorflow.lite.support.image.ops.ResizeOp.Method.BILINEAR))
        .build()

    override fun analyze(imageProxy: ImageProxy) {
        val startTime = System.currentTimeMillis()

        // 1. Pre-processing (Using TFLite Support Library)
        val preProcessStart = System.currentTimeMillis()
        tensorImage.load(imageProxy) // Efficiently loads YUV/RGB
        val processedImage = imageProcessor.process(tensorImage)
        val preProcessEnd = System.currentTimeMillis()

        // 2. Inference (Zero-copy approach)
        val inferenceStart = System.currentTimeMillis()
        
        // For Android 10+, we check for HardwareBuffer support
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // CONCEPTUAL: In a real GPU delegate, we would use:
            // gpuDelegate.bindHardwareBuffer(imageProxy.hardwareBuffer)
        }
        
        val results = engine.runInference(processedImage.buffer)
        val inferenceEnd = System.currentTimeMillis()

        // 3. Post-processing
        val postProcessStart = System.currentTimeMillis()
        val finalResult = processResults(results)
        val postProcessEnd = System.currentTimeMillis()

        // 4. Telemetry
        updateTelemetry(
            pre = preProcessEnd - preProcessStart,
            inf = inferenceEnd - inferenceStart,
            post = postProcessEnd - postProcessStart,
            total = System.currentTimeMillis() - startTime
        )

        imageProxy.close()
    }

    private fun updateTelemetry(pre: Long, inf: Long, post: Long, total: Long) {
        // Push to StateFlow for Compose UI overlay
    }
}
