
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.*

sealed class AccelerationState {
    object Accelerated : AccelerationState() // NNAPI/GPU
    object Degraded : AccelerationState()    // CPU (Slow)
    object Fallback : AccelerationState()    // CPU (Safe mode)
}

class AdaptiveInferenceEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val mutex = Mutex()
    private var interpreter: Interpreter? = null
    private var currentStrategy: AccelerationStrategy = AccelerationStrategy.NnApiStrategy
    
    private val _state = MutableStateFlow<AccelerationState>(AccelerationState.Accelerated)
    val state = _state.asStateFlow()

    private val latencyHistory = mutableListOf<Long>()

    suspend fun predict(input: FloatArray): FloatArray = mutex.withLock {
        val start = System.currentTimeMillis()
        
        val result = try {
            val output = Array(1) { FloatArray(3) }
            interpreter?.run(input, output)
            output[0]
        } catch (e: Exception) {
            handleFailure()
            return@withLock floatArrayOf()
        }

        val duration = System.currentTimeMillis() - start
        monitorPerformance(duration)
        
        result
    }

    private suspend fun monitorPerformance(latency: Long) {
        latencyHistory.add(latency)
        if (latencyHistory.size > 10) latencyHistory.removeAt(0)

        val avgLatency = latencyHistory.average()
        if (avgLatency > 200 && currentStrategy != AccelerationStrategy.CpuStrategy) {
            // Thermal throttling or system load detected -> Switch to CPU
            switchStrategy(AccelerationStrategy.CpuStrategy, AccelerationState.Degraded)
        }
    }

    private suspend fun switchStrategy(strategy: AccelerationStrategy, newState: AccelerationState) {
        _state.value = newState
        currentStrategy = strategy
        
        // Cold Start: Reload model with new delegate
        interpreter?.close()
        val modelBuffer = context.assets.open("model.tflite").readBytes()
        val options = Interpreter.Options()
        if (strategy is AccelerationStrategy.NnApiStrategy) {
            options.addDelegate(NnApiDelegate.create())
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    private suspend fun handleFailure() {
        // Recursive Fallback Chain: NNAPI -> GPU -> CPU
        val nextStrategy = when (currentStrategy) {
            is AccelerationStrategy.NnApiStrategy -> AccelerationStrategy.GpuStrategy
            is AccelerationStrategy.GpuStrategy -> AccelerationStrategy.CpuStrategy
            else -> AccelerationStrategy.CpuStrategy
        }
        switchStrategy(nextStrategy, AccelerationState.Fallback)
    }
}
