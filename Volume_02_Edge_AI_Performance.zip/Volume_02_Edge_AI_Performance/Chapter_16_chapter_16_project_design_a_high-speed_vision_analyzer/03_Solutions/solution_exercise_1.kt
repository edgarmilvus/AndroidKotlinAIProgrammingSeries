
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

enum class AccelerationStrategy {
    PERFORMANCE,   // NPU -> GPU -> CPU
    EFFICIENCY,    // NPU -> CPU
    COMPATIBILITY  // CPU only
}

@Singleton
class InferenceEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null

    fun initialize(modelPath: String, strategy: AccelerationStrategy) {
        val options = Interpreter.Options()
        val modelBuffer = loadModelFile(modelPath)

        try {
            currentDelegate = when (strategy) {
                AccelerationStrategy.PERFORMANCE -> {
                    try {
                        NnApiDelegate().also { options.addDelegate(it) }
                    } catch (e: Exception) {
                        try {
                            GpuDelegate().also { options.addDelegate(it) }
                        } catch (e2: Exception) {
                            null // Fallback to CPU
                        }
                    }
                }
                AccelerationStrategy.EFFICIENCY -> {
                    try {
                        NnApiDelegate().also { options.addDelegate(it) }
                    } catch (e: Exception) {
                        null // Fallback to CPU
                    }
                }
                AccelerationStrategy.COMPATIBILITY -> null // Force CPU
            }
            
            interpreter = Interpreter(modelBuffer, options)
        } catch (e: Exception) {
            // Final fallback: Initialize with default CPU options if everything fails
            interpreter = Interpreter(modelBuffer, Interpreter.Options())
        }
    }

    private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    fun runInference(input: Any, output: Any) {
        interpreter?.run(input, output) ?: throw IllegalStateException("Engine not initialized")
    }

    fun close() {
        interpreter?.close()
        (currentDelegate as? GpuDelegate)?.close()
        (currentDelegate as? NnApiDelegate)?.close()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideInferenceEngine(@ApplicationContext context: Context): InferenceEngine {
        return InferenceEngine(context)
    }
}
