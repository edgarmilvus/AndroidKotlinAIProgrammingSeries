
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.graphics.Bitmap
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

class FrameHolder(val imageProxy: ImageProxy, val tensorImage: Bitmap) : AutoCloseable {
    override fun close() {
        imageProxy.close()
    }
}

class VisionProcessingPipeline(
    private val inferenceEngine: InferenceEngine,
    private val scope: CoroutineScope
) {
    // CONFLATED ensures we only keep the latest frame, discarding stale ones
    private val frameChannel = Channel<FrameHolder>(Channel.CONFLATED)
    private val _results = MutableSharedFlow<DetectionResult>(replay = 0)
    val results = _results.asSharedFlow()

    fun enqueueFrame(frame: FrameHolder) {
        val success = frameChannel.trySend(frame).isSuccess
        if (!success) {
            // If the channel was full/conflated, the old frame is replaced.
            // However, trySend doesn't give us the replaced element.
            // In a real scenario, we'd use a custom wrapper or a Mutex to track the current frame.
        }
    }

    fun startProcessing() {
        scope.launch(Dispatchers.Default) {
            for (frame in frameChannel) {
                try {
                    val result = inferenceEngine.analyze(frame.tensorImage)
                    _results.emit(result)
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    // CRITICAL: Always close the ImageProxy
                    frame.close()
                }
            }
        }
    }
}

// Implementation of the CameraX Analyzer
class VisionAnalyzer(private val pipeline: VisionProcessingPipeline) : androidx.camera.core.ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        val bitmap = image.toBitmap() // Extension function to convert ImageProxy to Bitmap
        val holder = FrameHolder(image, bitmap)
        
        // We use trySend because the Analyzer runs on a dedicated CameraX thread
        // and must not be blocked.
        val result = pipeline.enqueueFrame(holder)
        
        // Since the channel is conflated, we must handle the case where the 
        // frame was not accepted or was immediately replaced.
        // Note: In a production system, a more robust lifecycle tracker is needed.
    }
}
