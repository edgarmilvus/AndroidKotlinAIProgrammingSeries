
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.*
import java.util.*
import kotlin.math.roundToInt

data class PerformanceMetrics(
    val currentLatency: Long = 0,
    val averageLatency: Double = 0.0,
    val fps: Int = 0,
    val activeDelegate: String = "Unknown"
)

class PerformanceMonitor {
    private val latencyHistory = ArrayDeque<Long>(30)
    private val _metrics = MutableStateFlow(PerformanceMetrics())
    val metrics: StateFlow<PerformanceMetrics> = _metrics.asStateFlow()

    private var frameCount = 0
    private var lastFpsUpdate = System.currentTimeMillis()

    fun recordInference(latencyNs: Long, delegateName: String) {
        val latencyMs = latencyNs / 1_000_000
        
        // Update rolling average
        latencyHistory.addLast(latencyMs)
        if (latencyHistory.size > 30) latencyHistory.removeFirst()
        val avgLatency = latencyHistory.average()

        // Calculate FPS
        frameCount++
        val now = System.currentTimeMillis()
        val elapsed = now - lastFpsUpdate
        
        if (elapsed >= 1000) {
            val currentFps = (frameCount * 1000L / elapsed).toInt()
            _metrics.update { it.copy(
                currentLatency = latencyMs,
                averageLatency = avgLatency,
                fps = currentFps,
                activeDelegate = delegateName
            )}
            frameCount = 0
            lastFpsUpdate = now
        } else {
            // Update latency even if FPS isn't updated yet
            _metrics.update { it.copy(currentLatency = latencyMs, averageLatency = avgLatency, activeDelegate = delegateName) }
        }
    }
}

@Composable
fun PerformanceOverlay(monitor: PerformanceMonitor) {
    val metrics by monitor.metrics.collectAsStateWithLifecycle()
    
    // Optimization: Only trigger UI update if significant changes occur or every 500ms
    val displayMetrics by remember {
        derivedStateOf {
            metrics.copy(averageLatency = metrics.averageLatency.roundTo(2))
        }
    }

    androidx.compose.material3.Surface(
        color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.6f),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
    ) {
        androidx.compose.foundation.layout.Column(modifier = androidx.compose.ui.Modifier.padding(8.dp)) {
            androidx.compose.material3.Text("FPS: ${displayMetrics.fps}", color = androidx.compose.ui.graphics.Color.Green)
            androidx.compose.material3.Text("Latency: ${displayMetrics.currentLatency}ms", color = androidx.compose.ui.graphics.Color.White)
            androidx.compose.material3.Text("Avg (30f): ${displayMetrics.averageLatency}ms", color = androidx.compose.ui.graphics.Color.White)
            androidx.compose.material3.Text("HW: ${displayMetrics.activeDelegate}", color = androidx.compose.ui.graphics.Color.Cyan)
        }
    }
}

fun Double.roundTo(decimals: Int): Double {
    var multiplier = 1.0
    repeat(decimals) { multiplier *= 10 }
    return kotlin.math.round(this * multiplier) / multiplier
}
