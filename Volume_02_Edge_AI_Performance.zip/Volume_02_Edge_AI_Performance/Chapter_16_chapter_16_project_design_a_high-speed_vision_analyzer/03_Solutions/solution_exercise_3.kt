
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlin.math.pow

class HardwareBenchmarker(private val engine: InferenceEngine) {
    
    data class BenchResult(val delegateName: String, val medianLatency: Double, val variance: Double)

    fun benchmarkDevice(): String {
        val results = mutableListOf<BenchResult>()
        val delegates = listOf("NPU", "GPU", "CPU")

        for (delegate in delegates) {
            val latencies = mutableListOf<Long>()
            // 1. Warm-up and Measurement
            repeat(10) { i ->
                val start = System.nanoTime()
                engine.runDummyInference(delegate)
                val end = System.nanoTime()
                
                if (i >= 3) { // Discard first 3 frames (warm-up)
                    latencies.add((end - start) / 1_000_000)
                }
            }

            val sorted = latencies.sorted()
            val median = sorted[sorted.size / 2].toDouble()
            val avg = latencies.average()
            val variance = latencies.map { (it - avg).pow(2) }.average()
            
            results.add(BenchResult(delegate, median, variance))
        }

        // 2. Decision Matrix: Score = (1/Latency) * (1 / (1 + Variance))
        return results.maxByOrNull { 
            (1.0 / it.medianLatency) * (1.0 / (1.0 + it.variance)) 
        }?.delegateName ?: "CPU"
    }
}

class AdaptiveEngine(
    private val monitor: PerformanceMonitor,
    private val benchmarker: HardwareBenchmarker,
    private val engine: InferenceEngine
) {
    private var currentStrategy = AccelerationStrategy.PERFORMANCE
    private var baselineLatency = 0.0

    fun monitorThermalThrottling() {
        // Check every 10 seconds
        kotlinx.coroutines.GlobalScope.launch {
            while(true) {
                kotlinx.coroutines.delay(10000)
                val currentAvg = monitor.metrics.value.averageLatency
                
                if (baselineLatency == 0.0) {
                    baselineLatency = currentAvg
                } else if (currentAvg > baselineLatency * 1.3) {
                    // Thermal throttling detected (>30% increase)
                    switchToEfficiencyMode()
                }
            }
        }
    }

    private fun switchToEfficiencyMode() {
        currentStrategy = AccelerationStrategy.EFFICIENCY
        engine.initialize("model.tflite", currentStrategy)
    }
}
