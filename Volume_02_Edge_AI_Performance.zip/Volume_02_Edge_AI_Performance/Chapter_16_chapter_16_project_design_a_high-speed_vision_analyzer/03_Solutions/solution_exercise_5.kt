
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import org.tensorflow.lite.Interpreter

class QuantizationCalibrator(
    private val slope: Float = 1.0f, 
    private val intercept: Float = 0.0f
) {
    data class QuantParams(val scale: Float, val zeroPoint: Int)

    fun calibrate(
        rawOutput: ByteArray, 
        params: QuantParams, 
        hardwareType: String
    ): FloatArray {
        // 1. De-quantization: r = (q - Z) * S
        val dequantized = FloatArray(rawOutput.size) { i ->
            val q = rawOutput[i].toInt()
            (q - params.zeroPoint) * params.scale
        }

        // 2. Linear Regression Correction: Corrected = (val * slope) + intercept
        val calibrated = FloatArray(dequantized.size) { i ->
            (dequantized[i] * slope) + intercept
        }

        return calibrated
    }

    fun getDynamicThreshold(hardwareType: String): Float {
        return when (hardwareType) {
            "NPU" -> 0.42f // Lower threshold to compensate for INT8 precision loss
            "GPU" -> 0.50f
            else -> 0.55f   // CPU usually runs FP32, higher precision
        }
    }
}

// Usage within the Inference Engine
fun processOutput(interpreter: Interpreter, outputBuffer: ByteArray) {
    val tensor = interpreter.getOutputTensor(0)
    val quantizationParams = tensor.quantizationParams()
    
    val params = QuantizationCalibrator.QuantParams(
        scale = quantizationParams.scale(),
        zeroPoint = quantizationParams.zeroPoint()
    )
    
    val calibrator = QuantizationCalibrator(slope = 1.05f, intercept = -0.02f)
    val finalScores = calibrator.calibrate(outputBuffer, params, "NPU")
    val threshold = calibrator.getDynamicThreshold("NPU")
    
    val detections = finalScores.filter { it >= threshold }
}
