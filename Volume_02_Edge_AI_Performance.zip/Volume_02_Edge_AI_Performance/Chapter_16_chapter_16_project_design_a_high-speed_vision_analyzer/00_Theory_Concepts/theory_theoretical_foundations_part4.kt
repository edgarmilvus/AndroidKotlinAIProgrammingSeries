
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.kt
// Description: Theoretical Foundations
// ==========================================

import android.graphics.HardwareBuffer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.Serializable
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Metadata for the model, loaded via kotlinx.serialization.
 * This prevents hard-coding tensor dimensions.
 */
@Serializable
data class ModelConfig(
    val inputWidth: Int,
    val inputHeight: Int,
    val inputChannels: Int,
    val quantizationScale: Float,
    val zeroPoint: Int
)

/**
 * AIContext provides the environment for inference.
 * Used with Context Receivers to clean up business logic.
 */
interface AIContext {
    val accelerator: HardwareAccelerator
    val config: ModelConfig
}

/**
 * HardwareAccelerator abstracts the NPU/GPU/CPU routing.
 */
interface HardwareAccelerator {
    suspend fun runInference(buffer: HardwareBuffer): InferenceResult
}

data class InferenceResult(
    val label: String,
    val confidence: Float,
    val boundingBox: android.graphics.RectF? = null
)

/**
 * The VisionAnalyzer orchestrates the pipeline.
 * It mimics the CameraX analyzer pattern but adds Coroutine-based async processing.
 */
@Singleton
class HighSpeedVisionAnalyzer @Inject constructor(
    private val accelerator: HardwareAccelerator,
    private val config: ModelConfig
) : AIContext {
    
    override val accelerator: HardwareAccelerator = accelerator
    override val config: ModelConfig = config

    // A SharedFlow to stream frames from the camera
    private val _frameStream = MutableSharedFlow<HardwareBuffer>(extraBufferCapacity = 1)
    
    // The result stream that the UI consumes
    val analysisResult: StateFlow<InferenceResult?> = _frameStream
        .conflate() // CRITICAL: Drop frames if the NPU is slower than the camera
        .map { buffer ->
            // Using context(this) to access AIContext properties
            with(this) {
                processFrame(buffer)
            }
        }
        .flowOn(Dispatchers.Default) // Pre-processing on Default
        .stateIn(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Main),
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun onFrameReceived(buffer: HardwareBuffer) {
        _frameStream.tryEmit(buffer)
    }

    // Context receiver usage: This function requires an AIContext to be present
    context(AIContext)
    private suspend fun processFrame(buffer: HardwareBuffer): InferenceResult {
        return try {
            // The actual NPU call happens here
            accelerator.runInference(buffer)
        } catch (e: Exception) {
            InferenceResult("Error", 0f)
        }
    }
}

/**
 * Example of a concrete NPU implementation using a hypothetical AICore wrapper.
 */
class AICoreAccelerator @Inject constructor() : HardwareAccelerator {
    override suspend fun runInference(buffer: HardwareBuffer): InferenceResult = withContext(Dispatchers.Default) {
        // In a real scenario, this would call the JNI layer of AICore/TFLite
        // simulateNpuCall(buffer)
        delay(16) // Simulate 60fps inference latency
        InferenceResult("Object Detected", 0.92f)
    }
}
