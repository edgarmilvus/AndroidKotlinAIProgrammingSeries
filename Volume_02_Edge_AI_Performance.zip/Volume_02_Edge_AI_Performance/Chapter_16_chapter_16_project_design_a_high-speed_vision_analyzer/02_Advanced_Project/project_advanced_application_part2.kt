
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.vision.analyzer

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Singleton
import javax.inject.Inject

/**
 * Hardware Acceleration Strategy.
 * Determines which delegate to use based on model quantization and device capabilities.
 */
enum class AccelerationMode {
    NPU_INT8,   // Optimized for NNAPI/NPU
    GPU_FP16,   // Optimized for GPU/OpenCL
    CPU_XNNPACK // Fallback for maximum compatibility
}

/**
 * Data class representing the result of a high-speed vision analysis.
 */
data class AnalysisResult(
    val detections: List<Detection>,
    val inferenceTimeMs: Long,
    val accelerationMode: AccelerationMode
)

data class Detection(val label: String, val confidence: Float, val boundingBox: android.graphics.RectF)

/**
 * Repository responsible for the heavy lifting of AI inference.
 * Encapsulates TFLite Interpreter and Hardware Delegate management.
 */
@Singleton
class VisionAnalyzerRepository @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null
    private val inferenceDispatcher = Dispatchers.Default.limitedParallelism(1) 
    // We limit parallelism to 1 to prevent race conditions on the NPU/GPU hardware buffer

    /**
     * Initializes the TFLite interpreter with the specified acceleration mode.
     * This is a heavy operation and should be called during app startup or background loading.
     */
    fun initializeAnalyzer(mode: AccelerationMode, modelBuffer: ByteBuffer) {
        val options = Interpreter.Options().apply {
            when (mode) {
                AccelerationMode.NPU_INT8 -> {
                    // NNAPI is the gateway to the NPU on Android
                    currentDelegate = NnApiDelegate()
                    addDelegate(currentDelegate)
                }
                AccelerationMode.GPU_FP16 -> {
                    // GPU Delegate utilizes OpenCL or OpenGL
                    currentDelegate = GpuDelegate()
                    addDelegate(currentDelegate)
                }
                AccelerationMode.CPU_XNNPACK -> {
                    // XNNPACK is enabled by default in recent TFLite versions
                    setNumThreads(4)
                }
            }
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    /**
     * Executes inference on a provided image buffer.
     * Uses a zero-copy approach by passing a Direct ByteBuffer.
     */
    suspend fun analyzeFrame(inputBuffer: ByteBuffer): AnalysisResult = withContext(inferenceDispatcher) {
        val startTime = System.currentTimeMillis()
        
        // Pre-allocated output buffer to avoid GC pressure during high-speed analysis
        val outputBuffer = ByteBuffer.allocateDirect(10 * 6).apply { 
            order(ByteOrder.nativeOrder()) 
        }

        // Perform the actual hardware-accelerated inference
        interpreter?.run(inputBuffer, outputBuffer)

        val inferenceTime = System.currentTimeMillis() - startTime
        
        // Parse the outputBuffer into a domain-specific AnalysisResult
        // (Parsing logic omitted for brevity, typically involves iterating through the float array)
        AnalysisResult(
            detections = emptyList(), // Simplified for example
            inferenceTimeMs = inferenceTime,
            accelerationMode = determineCurrentMode()
        )
    }

    private fun determineCurrentMode(): AccelerationMode {
        return when (currentDelegate) {
            is NnApiDelegate -> AccelerationMode.NPU_INT8
            is GpuDelegate -> AccelerationMode.GPU_FP16
            else -> AccelerationMode.CPU_XNNPACK
        }
    }

    fun close() {
        interpreter?.close()
        (currentDelegate as? GpuDelegate)?.close()
        (currentDelegate as? NnApiDelegate)?.close()
    }
}

/**
 * ViewModel implementing MVI pattern to handle the vision stream.
 */
@HiltViewModel
@AndroidEntryPoint
class VisionAnalyzerViewModel @Inject constructor(
    private val repository: VisionAnalyzerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<VisionUiState>(VisionUiState.Idle)
    val uiState: StateFlow<VisionUiState> = _uiState.asStateFlow()

    sealed class VisionUiState {
        object Idle : VisionUiState()
        data class Analyzing(val result: AnalysisResult) : VisionUiState()
        data class Error(val message: String) : VisionUiState()
    }

    /**
     * Process a frame from CameraX. 
     * Uses structured concurrency to ensure that if the ViewModel is cleared, 
     * pending inference tasks are cancelled immediately.
     */
    fun onFrameReceived(buffer: ByteBuffer) {
        viewModelScope.launch {
            try {
                // Offload to the repository which handles hardware orchestration
                val result = repository.analyzeFrame(buffer)
                _uiState.value = VisionUiState.Analyzing(result)
            } catch (e: Exception) {
                _uiState.value = VisionUiState.Error(e.localizedMessage ?: "Inference Failed")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}
