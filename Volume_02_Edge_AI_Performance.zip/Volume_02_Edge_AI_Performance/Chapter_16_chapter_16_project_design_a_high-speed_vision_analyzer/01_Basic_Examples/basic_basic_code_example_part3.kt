
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.vision.analyzer

import android.graphics.Bitmap
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VisionAnalyzer @Inject constructor(
    private val tflite: Interpreter
) : ImageAnalysis.Analyzer {

    // Model input requirements (example: 224x224 RGB)
    private val inputSize = 224
    private val byteBuffer = ByteBuffer.allocateDirect(1 * inputSize * inputSize * 3 * 4).apply {
        order(ByteOrder.nativeOrder())
    }

    override fun analyze(image: ImageProxy) {
        // 1. Pre-processing: Convert ImageProxy (YUV) to Bitmap/ByteBuffer
        // Note: In a real-world scenario, use a specialized YUV to RGB converter
        val bitmap = image.toBitmap() 
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
        
        prepareByteBuffer(scaledBitmap)

        // 2. Inference: Run the model
        val output = Array(1) { FloatArray(10) } // Assuming 10 classes
        tflite.run(byteBuffer, output)

        // 3. Post-processing: Extract the result
        val result = output[0].indices.maxByOrNull { output[0][it] } ?: -1
        
        // We will pass this result to the ViewModel via a callback or flow
        // For this example, assume we use a result listener
        onInferenceComplete(result)

        // CRITICAL: Always close the image proxy to avoid blocking the camera pipeline
        image.close()
    }

    private fun prepareByteBuffer(bitmap: Bitmap) {
        byteBuffer.rewind()
        val intValues = IntArray(inputSize * inputSize)
        bitmap.getPixels(intValues, 0, inputSize, 0, 0, inputSize, inputSize)

        for (pixel in intValues) {
            // Normalize RGB values to [0, 1] or [-1, 1] depending on model quantization
            byteBuffer.putFloat(((pixel shr 16) and 0xFF) / 255.0f)
            byteBuffer.putFloat(((pixel shr 8) and 0xFF) / 255.0f)
            byteBuffer.putFloat((pixel and 0xFF) / 255.0f)
        }
    }

    private fun onInferenceComplete(result: Int) {
        // This would typically call a ViewModel function
    }
}

// Extension to convert ImageProxy to Bitmap (Simplified)
fun ImageProxy.toBitmap(): Bitmap {
    // CameraX provides a helper for this in newer versions, 
    // otherwise, manual YUV to RGB conversion is required.
    return this.toBitmap() 
}
