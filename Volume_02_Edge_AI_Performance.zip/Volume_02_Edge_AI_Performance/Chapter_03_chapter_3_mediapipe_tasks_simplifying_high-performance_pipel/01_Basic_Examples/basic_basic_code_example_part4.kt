
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.example.edgeai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import dagger.hilt.android.AndroidEntryPoint
import android.graphics.Bitmap
import android.graphics.BitmapFactory

@Composable
fun ImageClassifierScreen(vm: ImageClassifierViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Image Display
        selectedBitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = "Input Image",
                modifier = Modifier.size(300.dp)
            )
        } ?: Text("No image selected")

        Spacer(modifier = Modifier.height(24.dp))

        // Action Button
        Button(
            onClick = {
                // In a real app, use a PhotoPicker. Here we load a dummy from assets.
                val bitmap = loadBitmapFromAssets("test_image.jpg")
                selectedBitmap = bitmap
                vm.analyzeImage(bitmap)
            },
            enabled = !state.isProcessing
        ) {
            Text(if (state.isProcessing) "Analyzing..." else "Classify Image")
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Results List
        if (state.errorMessage != null) {
            Text(text = state.errorMessage!!, color = MaterialTheme.colorScheme.error)
        } else {
            LazyColumn {
                items(state.results) { result ->
                    ResultItem(result)
                }
            }
        }
    }
}

@Composable
fun ResultItem(result: ClassificationResult) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = result.label, style = MaterialTheme.typography.bodyLarge)
        Text(text = "${(result.score * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
    }
}

// Helper to load image from assets
fun loadBitmapFromAssets(fileName: String): Bitmap {
    val inputStream = android.app.Application().assets.open(fileName)
    return BitmapFactory.decodeStream(inputStream)
}
