
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.edgeai.data

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageClassifier
import com.google.mediapipe.tasks.vision.core.ImageClassifierResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ImageClassificationRepository abstracts the MediaPipe Task API.
 * It manages the native ImageClassifier instance and handles the conversion
 * of Android Bitmaps into MediaPipe-compatible MPImages.
 */
@Singleton
class ImageClassificationRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var imageClassifier: ImageClassifier? = null

    init {
        setupClassifier()
    }

    private fun setupClassifier() {
        // BaseOptions defines the hardware acceleration strategy.
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("image_classifier.tflite") // Model must be in assets folder
            .build()

        // ImageClassifier options define the behavior of the task.
        val options = ImageClassifier.ImageClassifierOptions.builder()
            .setBaseOptions(baseOptions)
            .setMaxResults(3) // Only return the top 3 most likely categories
            .setScoreThreshold(0.3f) // Ignore results with confidence < 30%
            .setRunningMode(ImageClassifier.RunningMode.IMAGE) // Static image mode
            .build()

        imageClassifier = ImageClassifier.createFromOptions(context, options)
    }

    /**
     * Performs inference on the provided bitmap.
     * This function is thread-safe and intended to be called from a background dispatcher.
     */
    fun classifyImage(bitmap: Bitmap): ImageClassifierResult {
        val classifier = imageClassifier ?: throw IllegalStateException("Classifier not initialized")

        // MPImage is the internal format MediaPipe uses. 
        // BitmapImageBuilder prevents unnecessary copies of the image data.
        val mpImage = BitmapImageBuilder(bitmap).build()

        // The 'classify' call is synchronous and blocks the current thread.
        return classifier.classify(mpImage)
    }

    /**
     * Crucial for Edge AI: Native resources must be explicitly released.
     */
    fun close() {
        imageClassifier?.close()
        imageClassifier = null
    }
}
