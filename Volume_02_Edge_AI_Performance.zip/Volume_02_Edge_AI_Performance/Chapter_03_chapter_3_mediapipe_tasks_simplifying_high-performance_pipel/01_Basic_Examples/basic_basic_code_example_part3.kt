
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.edgeai.ui

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.edgeai.data.ImageClassificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * ClassificationUiState represents the current state of the UI.
 */
data class ClassificationUiState(
    val results: List<ClassificationResult> = emptyList(),
    val isProcessing: Boolean = false,
    val errorMessage: String? = null
)

data class ClassificationResult(val label: String, val score: Float)

@HiltViewModel
class ImageClassifierViewModel @Inject constructor(
    private val repository: ImageClassificationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ClassificationUiState())
    val uiState: StateFlow<ClassificationUiState> = _uiState.asStateFlow()

    fun analyzeImage(bitmap: Bitmap) {
        viewModelScope.launch {
            // 1. Update UI to show loading state
            _uiState.value = _uiState.value.copy(isProcessing = true, errorMessage = null)

            try {
                // 2. Switch to Dispatchers.Default for CPU/NPU intensive work.
                // AI inference is a blocking call; running it on Main would freeze the UI.
                val result = withContext(Dispatchers.Default) {
                    repository.classifyImage(bitmap)
                }

                // 3. Map the MediaPipe result to our UI state
                val topCategories = result.classifications().firstOrNull()?.categories()
                    ?.map { ClassificationResult(it.categoryName(), it.score()) }
                    ?: emptyList()

                _uiState.value = _uiState.value.copy(
                    results = topCategories,
                    isProcessing = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    errorMessage = "Inference failed: ${e.localizedMessage}"
                )
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close() // Prevent native memory leaks
    }
}
