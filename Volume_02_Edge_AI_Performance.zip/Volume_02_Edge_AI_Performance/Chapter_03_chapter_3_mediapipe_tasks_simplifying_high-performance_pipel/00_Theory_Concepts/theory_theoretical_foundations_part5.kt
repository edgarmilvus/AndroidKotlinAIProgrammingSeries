
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VisionTaskProvider @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var detector: ObjectDetector? = null

    // Model loading is like a Room migration: expensive and must be handled carefully
    fun getObjectDetector(config: AIModelConfig): ObjectDetector {
        return detector ?: synchronized(this) {
            detector ?: ObjectDetector.createFromOptions(context, 
                ObjectDetector.ObjectDetectorOptions.builder()
                    .setBaseOptions(BaseOptions.builder()
                        .setModelAssetPath(config.modelPath)
                        .setDelegate(if (config.useGpu) BaseOptions.Delegate.GPU else BaseOptions.Delegate.CPU)
                        .build())
                    .setScoreThreshold(config.confidenceThreshold)
                    .setMaxResults(config.maxResults)
                    .setRunningMode(RunningMode.LIVE_STREAM) // Critical for CameraX integration
                    .setResultListener { result, _ -> 
                        // This callback is the bridge between MediaPipe's C++ core and Kotlin
                    }
                    .build()
            ).also { detector = it }
        }
    }

    fun close() {
        detector?.close()
        detector = null
    }
}
