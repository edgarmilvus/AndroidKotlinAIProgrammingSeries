
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.gesture

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Domain state representing the current detected gesture and system health.
 */
data class GestureUiState(
    val detectedGesture: String = "None",
    val confidence: Float = 0f,
    val isProcessing: Boolean = false,
    val hardwareDelegate: String = "Unknown"
)

/**
 * Repository responsible for managing the MediaPipe GestureRecognizer lifecycle.
 * It handles the hardware orchestration and the actual inference logic.
 */
@Singleton
class GestureRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var gestureRecognizer: GestureRecognizer? = null
    private val _gestureFlow = MutableSharedFlow<GestureRecognizerResult>(replay = 0)
    val gestureFlow = _gestureFlow.asSharedFlow()

    // Hardware-aware configuration
    init {
        setupRecognizer()
    }

    private fun setupRecognizer() {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("gesture_recognizer.tflite")
            // STRATEGY: Attempt GPU acceleration, fallback to CPU via MediaPipe internal logic
            // In a more advanced setup, we would probe the device for NNAPI support here.
            .setDelegate(Delegate.GPU) 
            .build()

        val options = GestureRecognizer.GestureRecognizerOptions.builder()
            .setBaseOptions(baseOptions)
            .setRunningMode(GestureRecognizer.RunningMode.LIVE_STREAM)
            .setResultListener { result, _ ->
                // Use a global scope or specific repository scope to emit results
                CoroutineScope(Dispatchers.Default).launch {
                    _gestureFlow.emit(result)
                }
            }
            .build()

        gestureRecognizer = GestureRecognizer.createFromOptions(context, options)
    }

    /**
     * Processes a camera frame. 
     * @param imageProxy The frame from CameraX.
     * @param timestamp The frame timestamp in milliseconds.
     */
    suspend fun analyzeFrame(imageProxy: ImageProxy, timestamp: Long) = withContext(Dispatchers.Default) {
        try {
            // Convert CameraX ImageProxy to MediaPipe compatible Bitmap
            val bitmap = imageProxy.toBitmap() 
            val mpImage = BitmapImageBuilder(bitmap).build()
            
            // Perform inference on the NPU/GPU
            gestureRecognizer?.recognizeAsync(mpImage, timestamp)
        } catch (e: Exception) {
            Log.e("GestureRepo", "Inference Error: ${e.message}")
        } finally {
            // CRITICAL: Always close the image proxy to avoid blocking the camera pipeline
            imageProxy.close()
        }
    }

    fun getDelegateName(): String = "GPU/NPU Accelerated"

    fun close() {
        gestureRecognizer?.close()
    }
}

/**
 * ViewModel implementing MVI patterns to manage the UI state of the AI pipeline.
 */
@HiltViewModel
@AndroidEntryPoint
class GestureViewModel @Inject constructor(
    private val repository: GestureRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GestureUiState())
    val uiState: StateFlow<GestureUiState> = _uiState.asStateFlow()

    init {
        observeGestures()
    }

    private fun observeGestures() {
        viewModelScope.launch {
            repository.gestureFlow
                .collect { result ->
                    val topGesture = result.gestures().firstOrNull()?.firstOrNull()
                    _uiState.update { it.copy(
                        detectedGesture = topGesture?.categoryName() ?: "None",
                        confidence = topGesture?.score() ?: 0f,
                        hardwareDelegate = repository.getDelegateName()
                    )}
                }
        }
    }

    fun processFrame(imageProxy: ImageProxy) {
        viewModelScope.launch {
            // Use the current system time as the timestamp for LIVE_STREAM mode
            repository.analyzeFrame(imageProxy, System.currentTimeMillis())
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}

/**
 * Extension function to handle the complex conversion from CameraX ImageProxy to Bitmap.
 * In a production app, this would use a more optimized YUV to RGB conversion.
 */
fun ImageProxy.toBitmap(): Bitmap {
    // Simplified for pedagogical purposes; production code would use 
    // ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888 to avoid manual conversion.
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    // ... (Implementation of buffer copying) ...
    return bitmap
}
