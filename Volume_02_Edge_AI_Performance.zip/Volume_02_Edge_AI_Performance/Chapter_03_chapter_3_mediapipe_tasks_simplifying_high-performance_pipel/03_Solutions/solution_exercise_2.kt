
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// State Machine for Gesture Filtering
class GestureStateMachine(private val windowSize: Int = 5, private val threshold: Int = 4) {
    private val history = ArrayDeque<String>()

    fun addGesture(gesture: String): String? {
        history.addLast(gesture)
        if (history.size > windowSize) history.removeFirst()

        val counts = history.groupingBy { it }.eachCount()
        val mostFrequent = counts.maxByOrNull { it.value }
        
        // Only confirm if the gesture appears in X of the last Y frames
        return if (mostFrequent != null && mostFrequent.value >= threshold) {
            mostFrequent.key
        } else null
    }
}

@HiltViewModel
class AccessibilityViewModel @Inject constructor(
    private val gestureRecognizer: GestureRecognizer
) : ViewModel() {

    private val stateMachine = GestureStateMachine()
    private val _confirmedAction = MutableSharedFlow<String>()
    val confirmedAction = _confirmedAction.asSharedFlow()

    fun analyzeFrame(imageProxy: ImageProxy) {
        val mpImage = BitmapImageBuilder(imageProxy.toBitmap()).build()
        
        // Synchronous detection for simplicity in this specific pipeline
        val result = gestureRecognizer.recognize(mpImage)
        val topGesture = result.gestures().firstOrNull()?.firstOrNull()?.categoryName() ?: "NONE"

        viewModelScope.launch(Dispatchers.Default) {
            val confirmed = stateMachine.addGesture(topGesture)
            if (confirmed != null) {
                _confirmedAction.emit(confirmed)
            }
        }
    }
}

// Hilt Module configuring GPU Delegate
@Module
@InstallIn(SingletonComponent::class)
object GestureModule {
    @Provides
    @Singleton
    fun provideGestureRecognizer(@ApplicationContext context: Context): GestureRecognizer {
        return GestureRecognizer.createFromOptions(context, 
            GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(BaseOptions.builder()
                    .setModelAssetPath("gesture_recognizer.tflite")
                    .setDelegate(Delegate.GPU) // Lower latency for accessibility
                    .build())
                .build())
    }
}
