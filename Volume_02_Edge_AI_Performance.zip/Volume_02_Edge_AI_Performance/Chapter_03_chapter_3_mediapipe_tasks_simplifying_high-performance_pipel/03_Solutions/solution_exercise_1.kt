
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// Hilt Module for MediaPipe Dependency Injection
@Module
@InstallIn(SingletonComponent::class)
object VisionModule {
    @Provides
    @Singleton
    fun provideObjectDetector(@ApplicationContext context: Context): ObjectDetector {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("object_detector.tflite")
            .build()

        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(baseOptions)
            .setRunningMode(RunningMode.LIVE_STREAM) // Non-blocking mode
            .setScoreThreshold(0.5f)
            .setResultListener { result, _ -> 
                // Results are handled via a callback in LIVE_STREAM mode
            }
            .build()

        return ObjectDetector.createFromOptions(context, options)
    }
}

// ViewModel to manage detection state and coordinate mapping
@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val objectDetector: ObjectDetector
) : ViewModel() {

    private val _detections = MutableStateFlow<List<Detection>>(emptyList())
    val detections = _detections.asStateFlow()

    fun processImage(imageProxy: ImageProxy) {
        val mpImage = BitmapImageBuilder(imageProxy.toBitmap()).build()
        val timestamp = System.currentTimeMillis()

        // Set the listener dynamically to update the StateFlow
        objectDetector.setResultListener { result, _ ->
            _detections.value = result.detections()
        }
        
        objectDetector.detectAsync(mpImage, timestamp)
    }

    override fun onCleared() {
        objectDetector.close()
        super.onCleared()
    }
}

// Compose UI Layer
@Composable
fun ScannerScreen(viewModel: InventoryViewModel = hiltViewModel()) {
    val detections by viewModel.detections.collectAsStateWithLifecycle()
    var viewSize by remember { mutableStateOf(IntSize.Zero) }

    Box(modifier = Modifier.fillMaxSize().onGloballyPositioned { viewSize = it.size }) {
        CameraPreview() // Implementation of CameraX PreviewView

        Canvas(modifier = Modifier.fillMaxSize()) {
            detections.forEach { detection ->
                val box = detection.boundingBox()
                
                // Coordinate Mapping: Normalized (0-1) -> Pixel
                val left = box.left() * size.width
                val top = box.top() * size.height
                val right = box.right() * size.width
                val bottom = box.bottom() * size.height

                drawRect(
                    color = Color.Green,
                    topLeft = Offset(left, top),
                    size = Size(right - left, bottom - top),
                    style = Stroke(width = 4f)
                )
            }
        }
    }
}
