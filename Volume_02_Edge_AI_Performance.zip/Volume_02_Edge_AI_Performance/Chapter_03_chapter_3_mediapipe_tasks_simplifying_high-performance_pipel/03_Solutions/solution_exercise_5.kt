
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

enum class PerformanceMode(val delegate: Delegate, val samplingRate: Int) {
    HIGH_PERF(Delegate.GPU, 1),    // Every frame
    POWER_SAVER(Delegate.CPU, 30), // 1 frame per second
    CRITICAL(Delegate.CPU, 120)    // 1 frame every 4 seconds
}

class AdaptivePipelineManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var currentDetector: ObjectDetector? = null
    private var currentMode = PerformanceMode.HIGH_PERF

    fun updateMode(batteryLevel: Int, isThermalThrottled: Boolean) {
        val newMode = when {
            isThermalThrottled || batteryLevel < 15 -> PerformanceMode.CRITICAL
            batteryLevel < 30 -> PerformanceMode.POWER_SAVER
            else -> PerformanceMode.HIGH_PERF
        }

        if (newMode != currentMode) {
            currentMode = newMode
            reinitializePipeline()
        }
    }

    private fun reinitializePipeline() {
        currentDetector?.close()
        
        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                .setModelAssetPath(if (currentMode == PerformanceMode.HIGH_PERF) 
                    "model_fp32.tflite" else "model_int8.tflite")
                .setDelegate(currentMode.delegate)
                .build())
            .build()
        
        currentDetector = ObjectDetector.createFromOptions(context, options)
    }

    fun getSamplingRate() = currentMode.samplingRate
}

// Battery Receiver
class BatteryReceiver(private val manager: AdaptivePipelineManager) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        manager.updateMode(level, false)
    }
}
