
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.segmentation.core

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Hardware-aware Inference Engine for Real-time Segmentation.
 * Handles the lifecycle of TFLite delegates and the interpreter.
 */
@Singleton
class SegmentationEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    // Model configuration: 256x256 is common for real-time segmentation
    private val inputSize = 256
    private val byteBuffer = ByteBuffer.allocateDirect(inputSize * inputSize * 3 * 4).apply {
        order(ByteOrder.nativeOrder())
    }

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // Priority 1: NPU via NNAPI
            try {
                nnApiDelegate = NnApiDelegate()
                addDelegate(nnApiDelegate)
            } catch (e: Exception) {
                // Priority 2: GPU via GPU Delegate
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
            }
            setNumThreads(4) // Fallback CPU threads
        }
        
        // Load model from assets
        val modelBuffer = context.assets.open("segmentation_quant.tflite").readBytes().let {
            ByteBuffer.allocateDirect(it.size).apply {
                put(it)
                rewind()
            }
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    fun segment(bitmap: Bitmap): ByteBuffer {
        // Pre-processing: Normalize and scale bitmap to ByteBuffer
        // In production, use a RenderScript or Vulkan shader for this step
        preprocess(bitmap)
        
        val outputBuffer = ByteBuffer.allocateDirect(inputSize * inputSize * 1 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        
        interpreter?.run(byteBuffer, outputBuffer)
        return outputBuffer.apply { rewind() }
    }

    private fun preprocess(bitmap: Bitmap) {
        byteBuffer.rewind()
        // Simplified normalization: (pixel - 127.5) / 127.5
        // This loop is a bottleneck; in 60FPS apps, this is moved to GPU/C++
        val pixels = IntArray(inputSize * inputSize)
        bitmap.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        for (pixel in pixels) {
            byteBuffer.putFloat(((pixel shr 16 and 0xFF) - 127.5f) / 127.5f)
            byteBuffer.putFloat(((pixel shr 8 and 0xFF) - 127.5f) / 127.5f)
            byteBuffer.putFloat(((pixel and 0xFF) - 127.5f) / 127.5f)
        }
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * Repository acting as the bridge between the CameraX stream and the AI Engine.
 */
@Singleton
class SegmentationRepository @Inject constructor(
    private val engine: SegmentationEngine
) {
    private val _segmentationFlow = MutableSharedFlow<ByteBuffer>(replay = 0)
    val segmentationFlow = _segmentationFlow.asSharedFlow()

    suspend fun processFrame(imageProxy: ImageProxy) {
        withContext(Dispatchers.Default) {
            val bitmap = imageProxy.toBitmap() // Extension function for YUV to RGB
            val mask = engine.segment(bitmap)
            _segmentationFlow.emit(mask)
            imageProxy.close()
        }
    }
}

/**
 * ViewModel managing the MVI state and coordinating the analysis loop.
 */
@HiltViewModel
class SegmentationViewModel @Inject constructor(
    private val repository: SegmentationRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(SegmentationUiState())
    val uiState = _uiState.asStateFlow()

    private val viewModelScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    init {
        viewModelScope.launch {
            repository.segmentationFlow.collect { mask ->
                _uiState.update { it.copy(currentMask = mask, isProcessing = false) }
            }
        }
    }

    fun onFrameCaptured(imageProxy: ImageProxy) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.update { it.copy(isProcessing = true) }
            repository.processFrame(imageProxy)
        }
    }
}

data class SegmentationUiState(
    val currentMask: ByteBuffer? = null,
    val isProcessing: Boolean = false
)

/**
 * CameraX Analyzer implementing the real-time bridge.
 */
class SegmentationAnalyzer @Inject constructor(
    private val viewModel: SegmentationViewModel
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        // We delegate the image to the ViewModel to ensure structured concurrency
        viewModel.onFrameCaptured(image)
    }
}

// Hilt Module for providing the Analyzer
@Module
@InstallIn(SingletonComponent::class)
object SegmentationModule {
    @Provides
    @Singleton
    fun provideEngine(@ApplicationContext context: Context) = SegmentationEngine(context)

    @Provides
    @Singleton
    fun provideRepository(engine: SegmentationEngine) = SegmentationRepository(engine)
}
