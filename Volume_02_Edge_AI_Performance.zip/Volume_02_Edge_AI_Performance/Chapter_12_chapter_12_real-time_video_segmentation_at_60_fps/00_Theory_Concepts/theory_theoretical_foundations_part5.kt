
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * AIContext provides the hardware acceleration handles.
 * In a real scenario, this would be managed by AICore.
 */
interface AIContext {
    val npuSession: NpuSession
    val isQuantized: Boolean
}

class NpuSession {
    fun runInference(data: java.nio.ByteBuffer): FloatArray {
        // Simulated NPU execution
        return FloatArray(256 * 256) { 0.5f } 
    }
}

@Singleton
class SegmentationOrchestrator @Inject constructor(
    private val aiContext: AIContext
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    // Use a SharedFlow to broadcast segmentation masks to multiple UI components
    private val _maskFlow = MutableSharedFlow<SegmentationMask>(replay = 0)
    val maskFlow = _maskFlow.asSharedFlow()

    // Dedicated thread for NPU communication to prevent UI jank
    private val npuDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    fun analyzeFrame(imageProxy: ImageProxy) {
        scope.launch {
            try {
                // 1. Preprocessing (CPU/GPU)
                val tensor = preprocess(imageProxy)
                
                // 2. Inference (NPU) - Switch to dedicated dispatcher
                val result = withContext(npuDispatcher) {
                    executeInference(tensor)
                }
                
                // 3. Post-processing
                val mask = postprocess(result)
                
                _maskFlow.emit(mask)
            } catch (e: Exception) {
                Log.e("AI_CORE", "Inference failed", e)
            } finally {
                // CRITICAL: Always close ImageProxy to avoid CameraX deadlock
                imageProxy.close()
            }
        }
    }

    // Using context receiver to ensure this logic has access to NPU handles
    context(AIContext)
    private suspend fun executeInference(tensor: java.nio.ByteBuffer): FloatArray {
        return npuSession.runInference(tensor)
    }

    private fun preprocess(image: ImageProxy): java.nio.ByteBuffer {
        // In production, use a YUV to RGB conversion via RenderScript or Vulkan
        // For this theory, we simulate the buffer allocation
        return java.nio.ByteBuffer.allocateDirect(128 * 128 * 3 * 4)
    }

    private fun postprocess(rawOutput: FloatArray): SegmentationMask {
        // Convert probability map to binary mask
        return SegmentationMask(rawOutput)
    }
}

data class SegmentationMask(val data: FloatArray)
