
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.segmentation.camera

import android.graphics.Bitmap
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.edgeai.segmentation.ui.SegmentationViewModel

class SegmentationAnalyzer(
    private val viewModel: SegmentationViewModel
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        // 1. Convert ImageProxy (YUV) to Bitmap (RGB)
        // Note: In a production app, use a more efficient YUV-to-RGB converter
        val bitmap = image.toBitmap() 
        
        // 2. Send the bitmap to the ViewModel for processing
        viewModel.onFrameReceived(bitmap)
        
        // 3. IMPORTANT: Close the image proxy to signal CameraX that we are ready for the next frame
        image.close()
    }

    // Helper extension to convert ImageProxy to Bitmap
    private fun ImageProxy.toBitmap(): Bitmap {
        // Implementation of YUV to RGB conversion...
        // (Simplified for brevity: use androidx.camera.core.ImageProxy.toBitmap() in API 34+)
        return this.toBitmap() 
    }
}
