
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.segmentation.ai

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Manages the TFLite Interpreter and GPU acceleration.
 * Designed to be a singleton via Hilt to avoid reloading the model.
 */
class SegmentationModel(context: Context) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    init {
        setupInterpreter(context)
    }

    private fun setupInterpreter(context: Context) {
        // 1. Configure GPU Delegate for hardware acceleration
        // This is the key to hitting 60 FPS.
        gpuDelegate = GpuDelegate().apply {
            // Optional: Configure precision (FP16) to increase speed on mobile GPUs
            // setPrecisionLossAllowed(true) 
        }

        val options = Interpreter.Options().apply {
            addDelegate(gpuDelegate)
            setNumThreads(4) // Fallback for CPU operations
        }

        // 2. Load the .tflite model from assets
        val modelBuffer = loadModelFile(context, "segmentation_model.tflite")
        interpreter = Interpreter(modelBuffer, options)
    }

    private fun loadModelFile(context: Context, modelPath: String): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd(modelPath)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.startOffset, fileDescriptor.declaredLength)
    }

    /**
     * Performs the actual segmentation inference.
     * @param bitmap The input frame from CameraX.
     * @return A ByteBuffer containing the segmentation mask.
     */
    fun segment(bitmap: Bitmap): ByteBuffer {
        val inputImage = TensorImage.fromBitmap(bitmap)
        
        // Pre-processing: Resize to model dimensions (e.g., 256x256) and normalize
        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(256, 256, ResizeOp.Method.BILINEAR))
            .add(NormalizeOp(0f, 255f)) 
            .build()
        
        val processedImage = imageProcessor.process(inputImage)
        
        // Prepare output tensor (assuming output is 256x256)
        val outputBuffer = ByteBuffer.allocateDirect(256 * 256 * 1) // Single channel mask
        
        interpreter?.run(processedImage.buffer, outputBuffer)
        
        return outputBuffer
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
    }
}
