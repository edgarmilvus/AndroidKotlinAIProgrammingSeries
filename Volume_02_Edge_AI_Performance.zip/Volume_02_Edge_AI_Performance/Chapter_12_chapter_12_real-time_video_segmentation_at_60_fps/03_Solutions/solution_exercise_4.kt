
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class SegmentationRenderer : GLSurfaceView.Renderer {

    private var cameraTextureId = -1
    private var maskTextureId = -1
    
    // The GLSL Fragment Shader
    private val fragmentShaderCode = """
        precision mediump float;
        varying vec2 vTextureCoord;
        uniform sampler2D uCameraTexture;
        uniform sampler2D uMaskTexture;
        uniform vec4 uBackgroundColor;

        void main() {
            vec4 cameraColor = texture2D(uCameraTexture, vTextureCoord);
            // Sample the red channel of the mask texture (mask is 0.0 to 1.0)
            float maskValue = texture2D(uMaskTexture, vTextureCoord).r;
            
            // Smoothstep creates a soft edge, preventing pixelation
            float alpha = smoothstep(0.4, 0.6, maskValue);
            
            // Mix: if alpha is 1.0, result is cameraColor. If 0.0, result is uBackgroundColor.
            gl_FragColor = mix(uBackgroundColor, cameraColor, alpha);
        }
    """.trimIndent()

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        
        // 1. Bind the camera texture (Texture 0)
        // 2. Bind the mask texture (Texture 1)
        // 3. Draw the quad (the screen)
        drawScene()
    }

    /**
     * This is called from the Inference thread to upload the new mask.
     * This is the "Zero-Copy" bridge.
     */
    fun updateMaskTexture(maskData: ByteBuffer, width: Int, height: Int) {
        // In a real implementation, this would be synchronized with the GL thread
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, maskTextureId)
        // We use GL_LUMINANCE because the mask is a single-channel grayscale image
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE,
            width, height, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, maskData
        )
    }

    private fun drawScene() {
        // Standard OpenGL draw calls (glUseProgram, glBindBuffer, glDrawArrays)
        // would go here to render the quad using the fragmentShaderCode.
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) { /* Setup textures/shaders */ }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { /* Set viewport */ }
}
