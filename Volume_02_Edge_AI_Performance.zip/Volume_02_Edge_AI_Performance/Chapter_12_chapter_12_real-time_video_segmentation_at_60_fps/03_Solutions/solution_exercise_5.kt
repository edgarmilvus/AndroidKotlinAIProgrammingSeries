
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

/**
 * Technical Analysis Report (Simulated)
 * 
 * TEST RESULTS:
 * Model: Dense (10MB) | Latency: 14.2ms | Memory Bandwidth: High
 * Model: Pruned (5MB) | Latency: 13.8ms | Memory Bandwidth: Medium
 * 
 * OBSERVATION:
 * Despite the Pruned model being 50% smaller on disk, the latency reduction 
 * was negligible (only 0.4ms). 
 * 
 * ANALYSIS:
 * 1. The bottleneck is NOT Compute (ALU). If it were, latency would have 
 *    dropped significantly.
 * 2. The bottleneck is likely Memory Bandwidth or Unstructured Pruning limits.
 *    Because the pruning was 'unstructured' (random weights set to zero), 
 *    the TFLite runtime still performs the multiplication (x * 0). 
 *    The tensor shapes remain identical, so the number of memory fetches 
 *    remains the same.
 * 
 * RECOMMENDATION:
 * Use 'Structured Pruning' (removing entire channels) to actually reduce 
 * the tensor dimensions, which will lower memory bandwidth and latency.
 */

class PruningAnalyzer(private val context: Context) {
    
    fun runComparativeBenchmark() {
        val denseModel = loadModelFromAssets("dense_model.tflite")
        val prunedModel = loadModelFromAssets("pruned_model.tflite")

        val denseTime = measureInference(denseModel)
        val prunedTime = measureInference(prunedModel)

        Log.i("BENCHMARK", "Dense: $denseTime ms | Pruned: $prunedTime ms")
    }

    private fun measureInference(buffer: ByteBuffer): Double {
        val interpreter = Interpreter(buffer)
        val input = ByteBuffer.allocateDirect(256 * 256 * 3 * 4)
        val output = ByteBuffer.allocateDirect(256 * 256 * 4)
        
        // Warm up
        repeat(5) { interpreter.run(input, output) }

        val start = System.nanoTime()
        repeat(50) {
            interpreter.run(input, output)
        }
        val end = System.nanoTime()
        
        return (end - start).toDouble() / 50.0 / 1_000_000.0
    }
}
