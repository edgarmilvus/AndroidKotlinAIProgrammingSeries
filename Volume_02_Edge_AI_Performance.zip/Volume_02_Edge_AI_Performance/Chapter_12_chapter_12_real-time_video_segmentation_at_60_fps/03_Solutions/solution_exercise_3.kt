
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate

class AccelerationOrchestrator(private val context: Context) {

    private val TAG = "AI_OPT"

    fun createInterpreter(modelBuffer: ByteBuffer): Interpreter {
        val options = Interpreter.Options()
        
        // Strategy: Try highest performance first, fallback on failure
        val delegate = try {
            val nnapi = NnApiDelegate()
            options.addDelegate(nnapi)
            Log.d(TAG, "NPU (NNAPI) Acceleration Enabled")
            nnapi
        } catch (e: Exception) {
            Log.w(TAG, "NNAPI failed, trying GPU")
            try {
                val gpu = GpuDelegate()
                options.addDelegate(gpu)
                Log.d(TAG, "GPU Acceleration Enabled")
                gpu
            } catch (e2: Exception) {
                Log.w(TAG, "GPU failed, falling back to CPU (XNNPACK)")
                options.setUseXNNPACK(true)
                null // No delegate added
            }
        }

        val interpreter = Interpreter(modelBuffer, options)
        
        // WARM-UP SEQUENCE
        // Essential to prevent the "First Frame Stutter"
        warmUp(interpreter)
        
        return interpreter
    }

    private fun warmUp(interpreter: Interpreter) {
        Log.d(TAG, "Starting Warm-up sequence...")
        val dummyInput = ByteBuffer.allocateDirect(256 * 256 * 3 * 4).order(ByteOrder.nativeOrder())
        val dummyOutput = ByteBuffer.allocateDirect(256 * 256 * 4).order(ByteOrder.nativeOrder())
        
        // Run 5 dummy inferences to trigger shader compilation and memory allocation
        repeat(5) {
            interpreter.run(dummyInput, dummyOutput)
        }
        Log.d(TAG, "Warm-up complete.")
    }
}
