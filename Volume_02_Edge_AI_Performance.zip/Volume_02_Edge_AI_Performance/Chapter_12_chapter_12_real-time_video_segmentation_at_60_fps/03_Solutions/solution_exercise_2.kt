
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

class ModelManager(private val context: Context) {
    private var interpreter: Interpreter? = null
    private var currentModelType: ModelType = ModelType.FP32

    enum class ModelType { FP32, INT8 }

    fun loadModel(type: ModelType) {
        interpreter?.close()
        val modelPath = if (type == ModelType.FP32) "model_fp32.tflite" else "model_int8.tflite"
        val assetFileDescriptor = context.assets.openFd(modelPath)
        val mappedByteBuffer = assetFileDescriptor.createMappedByteBuffer(
            assetFileDescriptor.startOffset,
            assetFileDescriptor.length
        )
        interpreter = Interpreter(mappedByteBuffer)
        currentModelType = type
    }

    /**
     * Runs inference and returns the raw output.
     * For INT8, it applies de-quantization: real_value = (quantized_value - zero_point) * scale
     */
    fun runInference(input: ByteBuffer): FloatArray {
        val outputBuffer = if (currentModelType == ModelType.FP32) {
            ByteBuffer.allocateDirect(256 * 256 * 4).order(ByteOrder.nativeOrder())
        } else {
            // INT8 output requires a byte buffer
            ByteBuffer.allocateDirect(256 * 256) 
        }

        val startTime = System.nanoTime()
        interpreter?.run(input, outputBuffer)
        val durationMs = (System.nanoTime() - startTime) / 1_000_000.0

        return if (currentModelType == ModelType.FP32) {
            outputBuffer.asFloatBuffer().let { floatArray ->
                val arr = FloatArray(256 * 256)
                floatArray.get(arr)
                arr
            }
        } else {
            // DE-QUANTIZATION LOGIC
            // These parameters are extracted from the TFLite model metadata
            val scale = 0.00392156f 
            val zeroPoint = -128
            val arr = FloatArray(256 * 256)
            outputBuffer.rewind()
            for (i in 0 until (256 * 256)) {
                val quantizedValue = outputBuffer.get().toInt() and 0xFF
                val signedValue = if (quantizedValue > 127) quantizedValue - 256 else quantizedValue
                arr[i] = (signedValue - zeroPoint) * scale
            }
            arr
        }
    }
}

@Composable
fun PerformanceDashboard(latency: Float, fps: Float, modelType: String) {
    Column(modifier = Modifier.background(Color.Black.copy(alpha = 0.7f)).padding(8.dp)) {
        Text("Model: $modelType", color = Color.White)
        Text("Latency: ${"%.2f".format(latency)} ms", color = Color.Green)
        Text("FPS: ${"%.1f".format(fps)}", color = Color.Cyan)
    }
}
