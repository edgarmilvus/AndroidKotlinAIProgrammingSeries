
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.annotation.OptIn
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Manages the segmentation inference logic on a dedicated background thread.
 */
class SegmentationAnalyzer(
    private val interpreter: Interpreter,
    private val onMaskReady: (ByteBuffer) -> Unit
) : ImageAnalysis.Analyzer {

    // A single-threaded dispatcher ensures inference tasks are sequential 
    // and don't overlap, preventing race conditions on the Interpreter.
    private val analysisDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + analysisDispatcher)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        scope.launch {
            try {
                val bitmap = imageProxy.toBitmap() // Simplified conversion
                val inputBuffer = preprocess(bitmap)
                
                // Prepare output buffer (e.g., 256x256x1 for mask)
                val outputBuffer = ByteBuffer.allocateDirect(256 * 256 * 4)
                    .order(ByteOrder.nativeOrder())

                // Perform Inference
                interpreter.run(inputBuffer, outputBuffer)

                // Send result back to UI/Rendering layer
                withContext(Dispatchers.Main) {
                    onMaskReady(outputBuffer)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                // CRITICAL: Always close the ImageProxy to allow CameraX 
                // to provide the next frame.
                imageProxy.close()
            }
        }
    }

    private fun preprocess(bitmap: android.graphics.Bitmap): ByteBuffer {
        // In a real production app, use a specialized YUV to RGB converter 
        // or a RenderScript/Vulkan kernel here.
        val buffer = ByteBuffer.allocateDirect(256 * 256 * 3 * 4)
            .order(ByteOrder.nativeOrder())
        // ... scaling and normalization logic ...
        return buffer
    }
}

/**
 * Camera Setup within a Fragment or Activity
 */
fun startCamera(lifecycleOwner: LifecycleOwner, context: Context) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

    cameraProviderFuture.addListener({
        val cameraProvider = cameraProviderFuture.get()

        val preview = Preview.Builder().build()
        
        val imageAnalysis = ImageAnalysis.Builder()
            // STRATEGY_KEEP_ONLY_LATEST is vital for 60 FPS. 
            // It drops frames if the analyzer is busy, ensuring the 
            // pipeline always processes the most recent temporal data 
            // rather than building a queue of stale frames (backpressure).
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .build()

        imageAnalysis.setAnalyzer(
            ContextCompat.getMainExecutor(context), // Dispatching to executor
            SegmentationAnalyzer(myInterpreter) { mask ->
                // Update Compose State or SurfaceView
            }
        )

        cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis)
    }, ContextCompat.getMainExecutor(context))
}
