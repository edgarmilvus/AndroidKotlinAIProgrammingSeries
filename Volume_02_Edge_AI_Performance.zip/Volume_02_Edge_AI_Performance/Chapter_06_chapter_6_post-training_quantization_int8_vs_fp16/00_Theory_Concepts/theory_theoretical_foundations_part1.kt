
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Define the hardware contexts
interface NpuAccelerator {
    val deviceId: Int
    fun allocateSram(size: Long)
}

interface GpuAccelerator {
    val shaderVersion: String
    fun compileKernel(source: String)
}

// This function can ONLY be called within an NpuAccelerator context
context(NpuAccelerator)
fun executeInt8Inference(input: Tensor): Tensor {
    println("Executing on NPU $deviceId using INT8 precision")
    // Low-level NPU call here
    return Tensor() 
}

// Usage
fun main() {
    val npu = object : NpuAccelerator { 
        override val deviceId = 1
        override fun allocateSram(size: Long) {} 
    }
    
    with(npu) {
        executeInt8Inference(Tensor())
    }
}
