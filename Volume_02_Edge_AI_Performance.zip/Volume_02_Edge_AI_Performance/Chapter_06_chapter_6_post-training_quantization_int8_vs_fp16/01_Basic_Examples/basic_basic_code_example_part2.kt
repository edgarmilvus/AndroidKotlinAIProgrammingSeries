
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.quantization

import android.content.Context
import android.os.SystemClock
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Enum representing the quantization strategy.
 * FP16 is ideal for GPU acceleration.
 * INT8 is ideal for NPU/DSP acceleration.
 */
enum class QuantizationType(val modelPath: String, val description: String) {
    FP16("model_fp16.tflite", "Half-Precision (GPU Optimized)"),
    INT8("model_int8.tflite", "8-bit Integer (NPU Optimized)")
}

/**
 * ModelResult encapsulates the inference outcome and the performance metrics.
 */
data class ModelResult(
    val prediction: Float,
    val latencyMs: Long,
    val precisionUsed: QuantizationType
)

/**
 * TFLiteManager handles the low-level interaction with the TFLite Interpreter.
 * It manages memory mapping and tensor allocation.
 */
@Singleton
class TFLiteManager @Inject constructor(private val context: Context) {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    /**
     * Loads the model from assets into a MappedByteBuffer.
     * MappedByteBuffer is critical for performance as it avoids loading 
     * the entire model into JVM heap memory.
     */
    fun loadModel(type: QuantizationType) {
        close() // Ensure previous interpreter is closed to prevent memory leaks

        val options = Interpreter.Options().apply {
            if (type == QuantizationType.FP16) {
                // FP16 models benefit significantly from the GPU delegate
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
            } else {
                // INT8 models often use NNAPI or XNNPACK for NPU acceleration
                setNumThreads(4) 
                setUseNNAPI(true)
            }
        }

        interpreter = Interpreter(loadModelFile(type.modelPath), options)
    }

    private fun loadModelFile(modelPath: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.open(modelPath))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    /**
     * Performs inference. 
     * Note: Input buffer allocation differs based on quantization.
     */
    fun runInference(inputData: FloatArray): Float {
        val tflite = interpreter ?: throw IllegalStateException("Interpreter not initialized")

        // Input tensor shape: [1, 224, 224, 3] (Example for MobileNet)
        // We allocate a ByteBuffer to match the model's expected input type.
        val inputBuffer = ByteBuffer.allocateDirect(inputData.size * 4).apply {
            order(ByteOrder.nativeOrder())
            asFloatBuffer().put(inputData)
        }

        // Output tensor: [1, 1000] (Example for ImageNet)
        val outputBuffer = ByteBuffer.allocateDirect(1000 * 4).apply {
            order(ByteOrder.nativeOrder())
        }

        tflite.run(inputBuffer, outputBuffer)
        
        // Return the highest probability class (simplified)
        outputBuffer.rewind()
        return outputBuffer.asFloatBuffer().get(0) 
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        interpreter = null
        gpuDelegate = null
    }
}

/**
 * QuantizationRepository abstracts the business logic of switching models.
 */
@Singleton
class QuantizationRepository @Inject constructor(
    private val tfliteManager: TFLiteManager
) {
    suspend fun executeInference(type: QuantizationType, data: FloatArray): ModelResult = withContext(Dispatchers.Default) {
        tfliteManager.loadModel(type)
        
        val startTime = SystemClock.elapsedRealtime()
        val result = tfliteManager.runInference(data)
        val endTime = SystemClock.elapsedRealtime()
        
        ModelResult(
            prediction = result,
            latencyMs = endTime - startTime,
            precisionUsed = type
        )
    }
}

/**
 * QuantizationViewModel manages UI state and triggers inference.
 */
@AndroidEntryPoint
class QuantizationViewModel @Inject constructor(
    private val repository: QuantizationRepository
) : ViewModel() {

    var uiState by mutableStateOf<ModelResult?>(null)
        private set

    var isProcessing by mutableStateOf(false)
        private set

    fun runComparison(type: QuantizationType) {
        viewModelScope.launch {
            isProcessing = true
            try {
                // Dummy input data simulating a pre-processed image
                val dummyInput = FloatArray(1 * 224 * 224 * 3) { 0.5f }
                uiState = repository.executeInference(type, dummyInput)
            } catch (e: Exception) {
                Log.e("QuantizationVM", "Inference failed", e)
            } finally {
                isProcessing = false
            }
        }
    }
}

/**
 * QuantizationScreen: The Jetpack Compose UI for interacting with the models.
 */
@Composable
fun QuantizationScreen(viewModel: QuantizationViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Edge AI Quantization Lab", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Compare FP16 (GPU) vs INT8 (NPU) performance.")

        Spacer(modifier = Modifier.height(24.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            QuantizationType.values().forEach { type ->
                Button(
                    onClick = { viewModel.runComparison(type) },
                    enabled = !viewModel.isProcessing
                ) {
                    Text(text = "Run ${type.name}")
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        if (viewModel.isProcessing) {
            CircularProgressIndicator()
        } else {
            viewModel.uiState?.let { result ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Precision: ${result.precisionUsed.description}")
                        Text(text = "Latency: ${result.latencyMs} ms")
                        Text(text = "Top Prediction: ${result.prediction}")
                    }
                }
            }
        }
    }
}
