
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

data class DriftResult(val input: String, val fpValue: Float, val intValue: Float, val error: Float)

class ComparisonViewModel(
    private val fpInterpreter: Interpreter,
    private val intInterpreter: Interpreter
) : ViewModel() {

    private val _driftResults = MutableStateFlow<List<DriftResult>>(emptyList())
    val driftResults: StateFlow<List<DriftResult>> = _driftResults

    fun analyzeDrift(testPhrases: List<Pair<String, ByteBuffer>>) {
        viewModelScope.launch {
            val results = testPhrases.map { (text, input) ->
                // 1. FP16 Inference
                val fpOutput = FloatArray(1)
                fpInterpreter.run(input, fpOutput)

                // 2. INT8 Inference
                val intOutput = ByteArray(1)
                intInterpreter.run(input, intOutput)

                // 3. Dequantization: real = (quant - zero_point) * scale
                // In a real app, these are fetched from model metadata
                val scale = 0.0235f 
                val zeroPoint = 128
                val dequantizedInt = (intOutput[0].toInt() - zeroPoint) * scale

                val error = abs(fpOutput[0] - dequantizedInt)
                DriftResult(text, fpOutput[0], dequantizedInt, error)
            }
            _driftResults.value = results
        }
    }
}

@Composable
fun DriftMonitorScreen(viewModel: ComparisonViewModel) {
    val results by viewModel.driftResults.collectAsState()

    LazyColumn {
        items(results) { res ->
            val color = when {
                res.error < 0.05f -> Color.Green
                res.error < 0.15f -> Color.Yellow
                else -> Color.Red
            }
            ListItem(
                headlineContent = { Text(res.input) },
                supportingContent = { 
                    Text("FP16: ${res.fpValue} | INT8: ${res.intValue} | Error: ${res.error}") 
                },
                trailingContent = { Box(modifier = Modifier.background(color, shape = CircleShape)) }
            )
        }
    }
}
