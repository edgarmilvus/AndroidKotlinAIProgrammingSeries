
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.ComponentCallbacks2
import android.content.Context
import android.os.Debug
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer

enum class Precision { FP16, INT8 }

class ModelContainer(private val context: Context) {
    private var interpreter: Interpreter? = null
    private var currentPrecision: Precision? = null
    private val mutex = Mutex()

    suspend fun runInference(input: ByteBuffer): ByteBuffer = mutex.withLock {
        val current = interpreter ?: throw IllegalStateException("Model not loaded")
        val output = ByteBuffer.allocateDirect(1024)
        current.run(input, output)
        return output
    }

    suspend fun swapModel(target: Precision) = mutex.withLock {
        if (currentPrecision == target) return@withLock

        // 1. Close existing native resources
        interpreter?.close()
        interpreter = null
        
        // 2. Hint GC to reclaim native buffers
        System.gc()

        // 3. Load new model
        val modelPath = if (target == Precision.FP16) "model_fp16.tflite" else "model_int8.tflite"
        val buffer = loadModelFromAssets(context, modelPath)
        interpreter = Interpreter(buffer)
        currentPrecision = target
    }

    private fun loadModelFromAssets(context: Context, path: String): ByteBuffer {
        return context.assets.openFd(path).use { fd ->
            FileInputStream(fd.fileDescriptor).channel.map(
                FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.length
            )
        }
    }
}

class MemoryManager(
    private val context: Context,
    private val modelContainer: ModelContainer
) : ComponentCallbacks2 {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var lastSwapTime = 0L
    private val HYSTERESIS_MS = 30_000L

    override fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            scope.launch {
                modelContainer.swapModel(Precision.INT8)
            }
        }
    }

    fun requestUpgrade() {
        val now = System.currentTimeMillis()
        if (now - lastSwapTime > HYSTERESIS_MS) {
            scope.launch {
                modelContainer.swapModel(Precision.FP16)
                lastSwapTime = now
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {}
    override fun onLowMemory() { onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) }
}
