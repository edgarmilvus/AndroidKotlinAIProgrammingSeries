
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.os.Debug
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

// --- Hilt Model Provider ---
@Module
@InstallIn(SingletonComponent::class)
object ModelModule {
    @Provides
    @Singleton
    fun provideModelProvider(@ApplicationContext context: Context) = ModelProvider(context)
}

class ModelProvider(private val context: Context) {
    fun loadModelFile(modelPath: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        val startOffset = fileChannel.position()
        val declaredLength = fileChannel.size()
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }
}

// --- Inference Engine ---
class InferenceEngine(modelBuffer: ByteBuffer) {
    private var interpreter: Interpreter = Interpreter(modelBuffer)

    fun runInference(input: ByteBuffer): ByteBuffer {
        val output = ByteBuffer.allocateDirect(1024).order(ByteOrder.nativeOrder()) // Example size
        interpreter.run(input, output)
        return output
    }

    fun close() = interpreter.close()
}

// --- Benchmarking Logic ---
data class BenchmarkResult(
    val modelType: String,
    val coldStartMs: Double,
    val warmStartAvgMs: Double,
    val peakMemoryMb: Long
)

class LatencyBenchmarker @Inject constructor(private val modelProvider: ModelProvider) {
    suspend fun benchmark(modelPath: String, modelType: String, inputData: ByteBuffer): BenchmarkResult = withContext(Dispatchers.Default) {
        val modelBuffer = modelProvider.loadModelFile(modelPath)
        val engine = InferenceEngine(modelBuffer)
        
        // 1. Cold Start
        val coldStartNano = System.nanoTime()
        engine.runInference(inputData)
        val coldStartMs = (System.nanoTime() - coldStartNano) / 1_000_000.0

        // 2. Warm-up Phase (5-10 iterations)
        repeat(10) { engine.runInference(inputData) }

        // 3. Warm Start Average
        val warmStartTimes = mutableListOf<Long>()
        repeat(50) {
            val start = System.nanoTime()
            engine.runInference(inputData)
            warmStartTimes.add(System.nanoTime() - start)
        }
        val avgWarmStartMs = (warmStartTimes.average() / 1_000_000.0)

        // 4. Memory Usage
        val memInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(memInfo)
        val peakMem = memInfo.totalPss / 1024 // KB to MB

        engine.close()
        BenchmarkResult(modelType, coldStartMs, avgWarmStartMs, peakMem)
    }
}

// --- UI Layer ---
@Composable
fun BenchmarkScreen(benchmarker: LatencyBenchmarker) {
    var results by remember { mutableStateOf<List<BenchmarkResult>>(emptyList()) }
    var isRunning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        Button(onClick = {
            scope.launch {
                isRunning = true
                val input = ByteBuffer.allocateDirect(224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
                val fp16 = benchmarker.benchmark("model_fp16.tflite", "FP16", input)
                val int8 = benchmarker.benchmark("model_int8.tflite", "INT8", input)
                results = listOf(fp16, int8)
                isRunning = false
            }
        }, enabled = !isRunning) {
            Text(if (isRunning) "Benchmarking..." else "Run Benchmark")
        }

        results.forEach { res ->
            Text("${res.modelType} -> Cold: ${"%.2f".format(res.coldStartMs)}ms, Warm: ${"%.2f".format(res.warmStartAvgMs)}ms, Mem: ${res.peakMemoryMb}MB")
        }
    }
}
