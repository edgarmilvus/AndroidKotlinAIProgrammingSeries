
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.work.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class CalibrationCollector(private val context: Context) {
    private val capturedTensors = mutableListOf<FloatArray>()
    private val samplingRate = 10 // Capture 1 out of 10 frames

    fun processFrame(bitmap: Bitmap, frameIndex: Int) {
        if (frameIndex % samplingRate != 0) return

        // 1. Pre-processing: Resize and Normalize
        val resized = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val floatArray = bitmapToNormalizedFloatArray(resized)

        // 2. Diversity Filter: Only save if variance is high
        if (calculateVariance(floatArray) > 0.01f) {
            capturedTensors.add(floatArray)
        }
    }

    private fun bitmapToNormalizedFloatArray(bitmap: Bitmap): FloatArray {
        val pixels = IntArray(224 * 224)
        bitmap.getPixels(pixels, 0, 224, 0, 0, 224, 224)
        val floatArray = FloatArray(224 * 224 * 3)
        
        pixels.forEachIndexed { i, color ->
            floatArray[i * 3] = ((color shr 16 and 0xFF) / 255.0f) - 1.0f // Normalize to [-1, 1]
            floatArray[i * 3 + 1] = ((color shr 8 and 0xFF) / 255.0f) - 1.0f
            floatArray[i * 3 + 2] = ((color and 0xFF) / 255.0f) - 1.0f
        }
        return floatArray
    }

    private fun calculateVariance(data: FloatArray): Float {
        val mean = data.average().toFloat()
        return data.map { (it - mean) * (it - mean) }.average().toFloat()
    }

    fun exportDataset() {
        val file = File(context.filesDir, "calibration_data.bin")
        file.writeBytes(serializeTensors(capturedTensors))
        
        val uploadRequest = OneTimeWorkRequestBuilder<UploadWorker>()
            .setInputData(workDataOf("file_path" to file.absolutePath))
            .build()
        WorkManager.getInstance(context).enqueue(uploadRequest)
    }

    private fun serializeTensors(tensors: List<FloatArray>): ByteArray {
        val buffer = ByteBuffer.allocate(tensors.size * 224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
        tensors.forEach { array ->
            array.forEach { buffer.putFloat(it) }
        }
        return buffer.array()
    }
}

class UploadWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val path = inputData.getString("file_path") ?: return Result.failure()
        // Implement network upload to ML server here
        return Result.success()
    }
}
