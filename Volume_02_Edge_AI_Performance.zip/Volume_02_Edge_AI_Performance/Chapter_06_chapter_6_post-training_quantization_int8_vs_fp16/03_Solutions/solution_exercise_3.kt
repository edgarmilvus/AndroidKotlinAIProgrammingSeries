
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton

enum class HardwareProfile { NPU, GPU, CPU }

@Singleton
class HardwareAccelerationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var activeDelegate: Any? = null

    fun getOptimalInterpreter(): Interpreter {
        val profile = detectHardwareProfile()
        return try {
            when (profile) {
                HardwareProfile.NPU -> createNnApiInterpreter()
                HardwareProfile.GPU -> createGpuInterpreter()
                HardwareProfile.CPU -> createCpuInterpreter()
            }
        } catch (e: Exception) {
            // Fallback mechanism
            createCpuInterpreter()
        }
    }

    private fun detectHardwareProfile(): HardwareProfile {
        // Simplified detection logic
        return if (isNpuAvailable()) HardwareProfile.NPU 
               else if (isGpuAvailable()) HardwareProfile.GPU 
               else HardwareProfile.CPU
    }

    private fun createNnApiInterpreter(): Interpreter {
        val options = Interpreter.Options().addDelegate(NnApiDelegate())
        activeDelegate = NnApiDelegate()
        return Interpreter(loadModel("model_int8.tflite"), options)
    }

    private fun createGpuInterpreter(): Interpreter {
        val gpuOptions = GpuDelegate.Options().setPrecisionLossAllowed(true)
        val delegate = GpuDelegate(gpuOptions)
        activeDelegate = delegate
        val options = Interpreter.Options().addDelegate(delegate)
        return Interpreter(loadModel("model_fp16.tflite"), options)
    }

    private fun createCpuInterpreter(): Interpreter {
        val options = Interpreter.Options().setUseXNNPACK(true)
        return Interpreter(loadModel("model_int8.tflite"), options)
    }

    fun cleanup() {
        when (activeDelegate) {
            is GpuDelegate -> (activeDelegate as GpuDelegate).close()
            is NnApiDelegate -> (activeDelegate as NnApiDelegate).close()
        }
    }

    private fun isNpuAvailable(): Boolean = false // Implementation depends on API level/Vendor
    private fun isGpuAvailable(): Boolean = true // implementation via GpuDelegate.options()
    private fun loadModel(path: String): ByteBuffer = TODO("Implement as in Ex 1")
}
