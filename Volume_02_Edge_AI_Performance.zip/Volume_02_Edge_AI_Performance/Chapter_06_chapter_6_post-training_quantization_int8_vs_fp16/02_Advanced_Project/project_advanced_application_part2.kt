
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.quantization

import android.content.Context
import android.os.Build
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Defines the quantization strategy based on the model precision.
 */
sealed class QuantizationStrategy {
    object Int8Npu : QuantizationStrategy()  // High speed, Low power, NPU target
    object Fp16Gpu : QuantizationStrategy()  // High precision, GPU target
    object CpuFallback : QuantizationStrategy() // Safety fallback
}

/**
 * Data class representing the result of an AI inference.
 */
data class InferenceResult(val label: String, val confidence: Float, val latencyMs: Long)

/**
 * Repository responsible for managing the TFLite Interpreter and hardware delegates.
 * This class handles the "heavy lifting" of memory mapping and delegate orchestration.
 */
@Singleton
class InferenceRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    // Use a Mutex or synchronized block to prevent concurrent interpreter access
    private val inferenceMutex = kotlinx.coroutines.sync.Mutex()

    /**
     * Initializes the interpreter based on the selected quantization strategy.
     * This is the core of the Hardware-Aware Orchestration.
     */
    suspend fun initializeEngine(strategy: QuantizationStrategy) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            closeInterpreter() // Clean up previous instance

            val options = Interpreter.Options().apply {
                when (strategy) {
                    is QuantizationStrategy.Int8Npu -> {
                        // INT8 models are best served by NNAPI (NPU/DSP)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            nnApiDelegate = NnApiDelegate()
                            addDelegate(nnApiDelegate)
                        }
                    }
                    is QuantizationStrategy.Fp16Gpu -> {
                        // FP16 models excel on the GPU
                        gpuDelegate = GpuDelegate()
                        addDelegate(gpuDelegate)
                    }
                    is QuantizationStrategy.CpuFallback -> {
                        setNumThreads(Runtime.getRuntime().availableProcessors())
                    }
                }
            }

            val modelBuffer = loadModelFile("model_quantized.tflite")
            interpreter = Interpreter(modelBuffer, options)
        }
    }

    /**
     * Performs inference on a provided ByteBuffer.
     * Structured concurrency ensures we don't block the main thread.
     */
    suspend fun runInference(inputBuffer: ByteBuffer): InferenceResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        
        val outputBuffer = ByteBuffer.allocateDirect(1 * 10 * 4).apply { // Example: 10 classes, 4 bytes each
            order(ByteOrder.nativeOrder())
        }

        inferenceMutex.withLock {
            interpreter?.run(inputBuffer, outputBuffer) 
                ?: throw IllegalStateException("Interpreter not initialized")
        }

        val latency = System.currentTimeMillis() - startTime
        
        // Post-processing: Extracting the highest confidence class
        outputBuffer.rewind()
        val results = FloatArray(10)
        outputBuffer.asFloatBuffer().get(results)
        val maxIdx = results.indices.maxByOrNull { results[it] } ?: -1
        
        InferenceResult(label = "Class $maxIdx", confidence = results[maxIdx], latencyMs = latency)
    }

    private fun loadModelFile(modelPath: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.open(modelPath))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    fun closeInterpreter() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
        interpreter = null
    }
}

/**
 * ViewModel that bridges the UI (Compose) and the AI Repository.
 * Implements MVI-like state management.
 */
@Singleton
class InferenceViewModel @Inject constructor(
    private val repository: InferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<InferenceUiState>(InferenceUiState.Idle)
    val uiState: StateFlow<InferenceUiState> = _uiState.asStateFlow()

    fun onImageAnalyzed(buffer: ByteBuffer, hardwareCapability: String) {
        viewModelScope.launch {
            // Dynamic Strategy Selection logic
            val strategy = when {
                hardwareCapability == "NPU_SUPPORTED" -> QuantizationStrategy.Int8Npu
                hardwareCapability == "GPU_SUPPORTED" -> QuantizationStrategy.Fp16Gpu
                else -> QuantizationStrategy.CpuFallback
            }

            try {
                _uiState.value = InferenceUiState.Processing
                repository.initializeEngine(strategy)
                val result = repository.runInference(buffer)
                _uiState.value = InferenceUiState.Success(result)
            } catch (e: Exception) {
                _uiState.value = InferenceUiState.Error(e.message ?: "Unknown AI Error")
            }
        }
    }
}

sealed class InferenceUiState {
    object Idle : InferenceUiState()
    object Processing : InferenceUiState()
    data class Success(val result: InferenceResult) : InferenceUiState()
    data class Error(val message: String) : InferenceUiState()
}

/**
 * Hilt Module for Dependency Injection
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideInferenceRepository(@ApplicationContext context: Context): InferenceRepository {
        return InferenceRepository(context)
    }
}
