
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ml

import android.content.Context
import android.os.Build
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
    import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TFLiteManager @Inject constructor(private val context: Context) {
    private var interpreter: Interpreter? = null
    
    // Model constants - these must match your specific .tflite model
    private val INPUT_SIZE = 224 
    private val NUM_CLASSES = 1000

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // Use GPU delegate for acceleration if available
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                addDelegate(GpuDelegate())
            }
            // Alternatively, use NNAPI for NPU acceleration
            // addDelegate(NnApiDelegate())
            setNumThreads(4)
        }
        
        try {
            interpreter = Interpreter(loadModelFile(), options)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadModelFile(): MappedByteBuffer {
        val file = context.assets.openFd("model.tflite")
        val inputStream = FileInputStream(file.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    /**
     * Performs inference on the provided ByteBuffer.
     * @param inputBuffer A direct ByteBuffer containing normalized RGB data.
     * @return A float array containing the probabilities for each class.
     */
    fun runInference(inputBuffer: ByteBuffer): FloatArray {
        val output = Array(1) { FloatArray(NUM_CLASSES) }
        interpreter?.run(inputBuffer, output)
        return output[0]
    }

    fun close() {
        interpreter?.close()
        interpreter = null
    }
}
