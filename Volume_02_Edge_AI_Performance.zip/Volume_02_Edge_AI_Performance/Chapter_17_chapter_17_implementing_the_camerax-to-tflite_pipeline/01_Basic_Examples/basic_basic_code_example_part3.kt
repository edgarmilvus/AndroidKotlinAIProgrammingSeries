
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.camera

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.edgeai.performance.ml.TFLiteManager
import java.nio.ByteBuffer
import java.nio.ByteOrder

class TFLiteAnalyzer(
    private val tfliteManager: TFLiteManager,
    private val onResult: (String) -> Unit
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        // 1. Convert ImageProxy (YUV) to Bitmap (RGB)
        // Note: In a production app, use a more efficient YUV-to-RGB conversion 
        // via RenderScript or Vulkan to avoid Bitmap overhead.
        val bitmap = image.toBitmap() 
        
        if (bitmap != null) {
            // 2. Pre-process: Resize and Normalize
            val inputBuffer = preprocessImage(bitmap)
            
            // 3. Run Inference
            val results = tfliteManager.runInference(inputBuffer)
            
            // 4. Post-process: Find the class with the highest probability
            val topClassIndex = results.indices.maxByOrNull { results[it] } ?: -1
            onResult("Detected Class: $topClassIndex")
        }
        
        // CRITICAL: Always close the image proxy to avoid blocking the camera pipeline
        image.close()
    }

    private fun preprocessImage(bitmap: Bitmap): ByteBuffer {
        // Create a direct ByteBuffer for TFLite
        val buffer = ByteBuffer.allocateDirect(1 * 224 * 224 * 3)
        buffer.order(ByteOrder.nativeOrder())

        // Scale bitmap to model size
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        
        val intValues = IntArray(224 * 224)
        scaledBitmap.getPixels(intValues, 0, 224, 0, 0, 224, 224)

        // Normalize pixels from [0, 255] to [0.0, 1.0]
        for (pixel in intValues) {
            buffer.putFloat(((pixel shr 16) and 0xFF) / 255.0f)
            buffer.putFloat(((pixel shr 8) and 0xFF) / 255.0f)
            buffer.putFloat((pixel and 0xFF) / 255.0f)
        }
        
        buffer.rewind()
        return buffer
    }

    // Extension function to convert ImageProxy to Bitmap
    private fun ImageProxy.toBitmap(): Bitmap? {
        // This is a simplified conversion. In reality, you must handle 
        // ImageProxy.getPlanes() for YUV_420_888.
        // For brevity in this basic example, we assume a helper utility exists.
        return ImageUtils.toBitmap(this) 
    }
}
