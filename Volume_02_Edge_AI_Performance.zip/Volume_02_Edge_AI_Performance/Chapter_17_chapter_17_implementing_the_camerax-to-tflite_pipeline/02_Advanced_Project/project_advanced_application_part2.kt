
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.pipeline

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModelInjection
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Singleton

/**
 * HardwareAccelerator defines the strategy for TFLite execution.
 * We prioritize NPU (NNAPI) for quantized models, then GPU, then CPU.
 */
enum class AcceleratorType {
    NPU, GPU, CPU
}

/**
 * Repository responsible for managing the TFLite Interpreter lifecycle
 * and executing hardware-accelerated inference.
 */
@Singleton
class InferenceRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null
    
    private val _inferenceResults = MutableSharedFlow<DetectionResult>(replay = 0)
    val inferenceResults = _inferenceResults.asSharedFlow()

    // Pre-allocated TensorImage to avoid GC pressure during high-frequency loops
    private val tensorImage = TensorImage(org.tensorflow.lite.DataType.UINT8)
    private val imageProcessor = ImageProcessor.Builder()
        .add(ResizeOp(224, 224, org.tensorflow.lite.support.image.ops.ResizeOp.Method.BILINEAR))
        .build()

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        try {
            val options = Interpreter.Options().apply {
                // Hardware Orchestration Logic:
                // 1. Try NNAPI (NPU) for quantized INT8 models
                nnApiDelegate = NnApiDelegate()
                addDelegate(nnApiDelegate)
                
                // 2. Fallback to GPU if NNAPI fails or is unsupported
                // Note: In a real scenario, we would check model quantization first
                // gpuDelegate = GpuDelegate()
                // addDelegate(gpuDelegate)
                
                setNumThreads(4) // CPU fallback threads
            }
            
            val modelBuffer = FileUtil.loadMappedFile(context, "defect_model_quant.tflite")
            interpreter = Interpreter(modelBuffer, options)
            Log.d("AI_PIPELINE", "Interpreter initialized with NPU/GPU acceleration")
        } catch (e: Exception) {
            Log.e("AI_PIPELINE", "Hardware acceleration failed, falling back to CPU", e)
        }
    }

    suspend fun runInference(imageProxy: ImageProxy) = withContext(Dispatchers.Default) {
        try {
            // Convert CameraX ImageProxy to Bitmap
            val bitmap = imageProxy.toBitmap() 
            
            // Pre-process: Resize and normalize using TFLite Support Library
            tensorImage.load(bitmap)
            val processedImage = imageProcessor.process(tensorImage)
            
            // Prepare output buffer (assuming model outputs a float array of 10 classes)
            val outputBuffer = ByteBuffer.allocateDirect(10 * 4) 
            
            // Execute synchronous inference on the hardware delegate
            interpreter?.run(processedImage.buffer, outputBuffer)
            
            // Process results (simplified)
            val results = parseOutput(outputBuffer)
            _inferenceResults.emit(results)
            
        } catch (e: Exception) {
            Log.e("AI_PIPELINE", "Inference error: ${e.message}")
        } finally {
            imageProxy.close() // CRITICAL: Close proxy to allow CameraX to send next frame
        }
    }

    private fun parseOutput(buffer: ByteBuffer): DetectionResult {
        buffer.rewind()
        val floatArray = FloatArray(10)
        buffer.asFloatBuffer().get(floatArray)
        val topClass = floatArray.indices.maxByOrNull { floatArray[it] } ?: -1
        return DetectionResult(label = "Defect_$topClass", confidence = floatArray[topClass])
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * CameraX Analyzer implementation that acts as the bridge.
 * It uses an AtomicBoolean to implement a "Frame Dropping" mechanism.
 */
class DefectDetectionAnalyzer @Inject constructor(
    private val repository: InferenceRepository,
    private val scope: CoroutineScope
) : ImageAnalysis.Analyzer {

    private val isProcessing = AtomicBoolean(false)

    override fun analyze(image: ImageProxy) {
        // Backpressure Strategy: If the previous frame is still being processed by the NPU,
        // drop the current frame immediately to prevent memory buildup.
        if (isProcessing.compareAndSet(false, true)) {
            scope.launch {
                try {
                    repository.runInference(image)
                } finally {
                    isProcessing.set(false)
                }
            }
        } else {
            image.close() // Drop frame
        }
    }
}

/**
 * ViewModel utilizing MVI pattern to expose AI state to Jetpack Compose.
 */
@ViewModelScoped
class DetectionViewModel @Inject constructor(
    private val repository: InferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(DetectionUiState())
    val uiState = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.inferenceResults
                .catch { e -> _uiState.update { it.copy(error = e.message) } }
                .collect { result ->
                    _uiState.update { it.copy(
                        lastDetection = result, 
                        isLoading = false,
                        error = null
                    )}
                }
        }
    }
}

data class DetectionResult(val label: String, val confidence: Float)
data class DetectionUiState(
    val lastDetection: DetectionResult? = null,
    val isLoading: Boolean = true,
    val error: String? = null
)

// Extension to convert ImageProxy to Bitmap (Simplified for brevity)
fun ImageProxy.toBitmap(): Bitmap {
    // In production, use YUV to RGB conversion via ImageProxy.toBitmap() in newer CameraX versions
    // or a custom YuvImage converter.
    return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888) 
}
