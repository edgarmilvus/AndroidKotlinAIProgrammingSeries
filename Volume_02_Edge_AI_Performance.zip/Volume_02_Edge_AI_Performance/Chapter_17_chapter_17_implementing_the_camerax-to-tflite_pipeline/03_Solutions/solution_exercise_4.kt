
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.graphics.RectF
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.conflate
import java.nio.ByteBuffer

class CascadedAnalyzer(
    private val faceDetector: Interpreter,
    private val emotionClassifier: Interpreter,
    private val onResult: (String, RectF) -> Unit
) {
    // Channel to hand off ROI from detector to classifier
    private val roiChannel = Channel<Pair<ImageProxy, RectF>>(capacity = 1)

    suspend fun analyze(image: ImageProxy) {
        // Stage 1: Face Detection
        val faceBox = runFaceDetection(image)
        
        if (faceBox != null) {
            // Pass the image and the detected box to the classifier
            // We use a Channel to decouple the two models
            roiChannel.send(image to faceBox)
        } else {
            image.close()
        }
    }

    suspend fun processEmotionPipeline() {
        roiChannel.receiveAsFlow()
            .conflate() // If classifier is slow, drop old faces
            .collect { (image, box) ->
                try {
                    val croppedFace = cropAndResize(image, box, 48, 48)
                    val emotion = runEmotionClassification(croppedFace)
                    onResult(emotion, box)
                } finally {
                    image.close()
                }
            }
    }

    private fun cropAndResize(image: ImageProxy, box: RectF, tw: Int, th: Int): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(tw * th * 3)
        val yPlane = image.planes[0].buffer
        val yStride = image.planes[0].rowStride
        
        // Map normalized box to pixel coordinates
        val left = (box.left * image.width).toInt()
        val top = (box.top * image.height).toInt()
        val right = (box.right * image.width).toInt()
        val bottom = (box.bottom * image.height).toInt()

        val cropW = right - left
        val cropH = bottom - top

        for (y in 0 until th) {
            for (x in 0 until tw) {
                val srcX = left + (x * cropW / tw)
                val srcY = top + (y * cropH / th)
                val pixel = yPlane.get(srcY * yStride + srcX)
                buffer.put(pixel) // Simplified to grayscale for emotion
            }
        }
        buffer.flip()
        return buffer
    }

    private fun runFaceDetection(image: ImageProxy): RectF? { 
        /* TFLite run logic... return box if confidence > 0.7 */ 
        return RectF(0.1f, 0.1f, 0.4f, 0.4f) 
    }
    
    private fun runEmotionClassification(input: ByteBuffer): String { 
        /* TFLite run logic... return "Happy", "Sad", etc. */ 
        return "Happy" 
    }
}
