
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.media.Image
import java.nio.ByteBuffer
import java.nio.ByteOrder

class YUVtoRGBConverter(private val targetWidth: Int, private val targetHeight: Int) {
    // Pre-allocate buffer to avoid GC pressure
    private val outputBuffer: ByteBuffer = ByteBuffer.allocateDirect(targetWidth * targetHeight * 3)
        .order(ByteOrder.nativeOrder())

    fun convert(image: Image): ByteBuffer {
        outputBuffer.clear()
        
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val yStride = yPlane.rowStride
        val uStride = uPlane.rowStride
        val vStride = vPlane.rowStride

        val imgWidth = image.width
        val imgHeight = image.height

        // Stride-based sampling for "Zero-Copy" resizing
        val xStep = imgWidth.toFloat() / targetWidth
        val yStep = imgHeight.toFloat() / targetHeight

        for (y in 0 until targetHeight) {
            for (x in 0 until targetWidth) {
                val srcX = (x * xStep).toInt()
                val srcY = (y * yStep).toInt()

                // YUV 420 indices
                val yIdx = srcY * yStride + srcX
                // U and V are subsampled by 2x
                val uIdx = (srcY / 2) * uStride + (srcX / 2)
                val vIdx = (srcY / 2) * vStride + (srcX / 2)

                val Y = yBuffer.get(yIdx).toInt() and 0xFF
                val U = uBuffer.get(uIdx).toInt() and 0xFF
                val V = vBuffer.get(vIdx).toInt() and 0xFF

                // YUV to RGB Conversion Formula
                val r = (Y + 1.402 * (V - 128)).toInt().coerceIn(0, 255)
                val g = (Y - 0.344136 * (U - 128) - 0.714136 * (V - 128)).toInt().coerceIn(0, 255)
                val b = (Y + 1.772 * (U - 128)).toInt().coerceIn(0, 255)

                outputBuffer.put(r.toByte())
                outputBuffer.put(g.toByte())
                outputBuffer.put(b.toByte())
            }
        }
        outputBuffer.flip()
        return outputBuffer
    }
}
