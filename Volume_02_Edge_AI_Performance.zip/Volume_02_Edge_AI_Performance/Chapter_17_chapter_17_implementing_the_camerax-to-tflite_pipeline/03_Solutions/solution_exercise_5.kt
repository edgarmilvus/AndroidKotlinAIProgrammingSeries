
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

class AIProcessor(private val scope: CoroutineScope) {
    // Producer-Consumer Channel: Drop oldest frame if NPU is busy
    private val frameChannel = Channel<ImageProxy>(
        capacity = 1, 
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val _uiState = MutableStateFlow<DetectionResult?>(null)
    val uiState: StateFlow<DetectionResult?> = _uiState

    private var droppedFrames = 0L

    init {
        startInferenceLoop()
    }

    // Producer: Called by CameraX Analyzer
    fun onFrameReceived(image: ImageProxy) {
        val offered = frameChannel.trySend(image).isSuccess
        if (!offered) {
            droppedFrames++
            image.close() // Close immediately if we can't process it
        }
    }

    // Consumer: Dedicated inference thread
    private fun startInferenceLoop() {
        scope.launch(Dispatchers.Default) {
            frameChannel.receiveAsFlow()
                .collect { image ->
                    try {
                        // Adaptive Throttling: Check if device is overheating
                        if (shouldThrottle()) {
                            delay(16) // Skip a frame (~1fps drop) to cool down
                        }
                        
                        val result = performInference(image)
                        _uiState.emit(result)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        image.close() // Critical: Close proxy after inference
                    }
                }
        }
    }

    private fun performInference(image: ImageProxy): DetectionResult {
        // TFLite interpreter.run() logic here
        return DetectionResult("Object", RectF(0f, 0f, 1f, 1f))
    }

    private fun shouldThrottle(): Boolean {
        // Implementation would check HardwarePropertiesManager or latency spikes
        return false 
    }

    fun getDroppedFramesCount() = droppedFrames
}

data class DetectionResult(val label: String, val box: RectF)
