
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer

enum class AccelerationMode { CPU, GPU, NNAPI }

class DelegateManager(private val modelBuffer: ByteBuffer) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null

    fun switchDelegate(mode: AccelerationMode): Interpreter {
        // 1. Clean up previous native resources to prevent memory leaks
        interpreter?.close()
        when (currentDelegate) {
            is GpuDelegate -> (currentDelegate as GpuDelegate).close()
            is NnApiDelegate -> (currentDelegate as NnApiDelegate).close()
        }

        val options = Interpreter.Options().apply {
            when (mode) {
                AccelerationMode.CPU -> setNumThreads(4)
                AccelerationMode.GPU -> {
                    val gpuDelegate = GpuDelegate()
                    this.addDelegate(gpuDelegate)
                    currentDelegate = gpuDelegate
                }
                AccelerationMode.NNAPI -> {
                    val nnApiDelegate = NnApiDelegate()
                    this.addDelegate(nnApiDelegate)
                    currentDelegate = nnApiDelegate
                }
            }
        }

        interpreter = Interpreter(modelBuffer, options)
        return interpreter!!
    }

    fun close() {
        interpreter?.close()
        (currentDelegate as? GpuDelegate)?.close()
        (currentDelegate as? NnApiDelegate)?.close()
    }
}

class LatencyProfiler(private val windowSize: Int = 10) {
    private val samples = mutableListOf<Long>()

    fun addSample(nanoTime: Long) {
        samples.add(nanoTime)
        if (samples.size > windowSize) {
            samples.removeAt(0)
        }
    }

    fun getAverageMs(): Double {
        if (samples.isEmpty()) return 0.0
        return (samples.average() / 1_000_000.0)
    }
}

// Usage in Inference Loop
fun runInference(interpreter: Interpreter, input: ByteBuffer, output: ByteBuffer) {
    val startTime = System.nanoTime()
    interpreter.run(input, output)
    val endTime = System.nanoTime()
    
    profiler.addSample(endTime - startTime)
}
