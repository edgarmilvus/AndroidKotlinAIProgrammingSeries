
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.graphics.RectF
import androidx.camera.core.ImageProxy
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawRect
import androidx.compose.ui.viewinterop.AndroidView
import androidx.camera.view.PreviewView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// Data class to hold detection results
data class Detection(val boundingBox: RectF, val label: String, val confidence: Float)

// Utility to map TFLite coordinates to Screen coordinates
class CoordinateMapper {
    fun mapCoordinates(
        normalizedBox: RectF, 
        imageWidth: Int, 
        imageHeight: Int, 
        viewWidth: Int, 
        viewHeight: Int, 
        rotationDegrees: Int
    ): RectF {
        // 1. Handle Rotation: Swap dimensions if portrait (90 or 270 degrees)
        val isPortrait = rotationDegrees == 90 || rotationDegrees == 270
        val srcW = if (isPortrait) imageHeight else imageWidth
        val srcH = if (isPortrait) imageWidth else imageHeight

        // 2. Calculate Scale Factors (Letterboxing/Center Crop logic)
        val scaleX = viewWidth.toFloat() / srcW
        val scaleY = viewHeight.toFloat() / srcH
        val scale = maxOf(scaleX, scaleY) // Maintain aspect ratio

        // 3. Offset to center the image in the view
        val offsetX = (viewWidth - srcW * scale) / 2f
        val offsetY = (viewHeight - srcH * scale) / 2f

        // 4. Map normalized (0-1) to pixel coordinates
        return RectF(
            normalizedBox.left * srcW * scale + offsetX,
            normalizedBox.top * srcH * scale + offsetY,
            normalizedBox.right * srcW * scale + offsetX,
            normalizedBox.bottom * srcH * scale + offsetY
        )
    }
}

class DetectionViewModel : androidx.lifecycle.ViewModel() {
    private val _detections = MutableStateFlow<List<Detection>>(emptyList())
    val detections: StateFlow<List<Detection>> = _detections

    fun updateDetections(newList: List<Detection>) {
        _detections.value = newList
    }
}

@Composable
fun CameraDetectionScreen(viewModel: DetectionViewModel) {
    val detections by viewModel.detections.collectAsState()
    var viewSize by remember { mutableStateOf(Size.Zero) }

    androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize()) {
        // Camera Preview
        AndroidView(
            factory = { context ->
                PreviewView(context).apply {
                    // CameraX binding logic here...
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Bounding Box Overlay
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            viewSize = Size(size.width, size.height)
            detections.forEach { detection ->
                drawRect(
                    color = Color.Green,
                    topLeft = Offset(detection.boundingBox.left, detection.boundingBox.top),
                    size = Size(
                        detection.boundingBox.width(), 
                        detection.boundingBox.height()
                    ),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
            }
        }
    }
}
