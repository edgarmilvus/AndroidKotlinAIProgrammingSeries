
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.audio.sentinel

import android.content.Context
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifetime.ViewModelInject
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * MVI State representing the current status of the Audio Sentinel.
 */
data class AudioSentinelUiState(
    val isMonitoring: Boolean = false,
    val detectionLevel: DetectionLevel = DetectionLevel.IDLE,
    val lastDetectedEvent: String = "None",
    val confidence: Float = 0f,
    val hardwareActive: String = "DSP"
)

enum class DetectionLevel { IDLE, DSP_TRIGGERED, NPU_VALIDATED }

/**
 * Repository responsible for orchestrating the hand-off between DSP and NPU.
 * This class implements the "Cascaded Inference" logic.
 */
@Singleton
class AudioAnalysisRepository @Inject constructor(
    private val context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // TFLite Interpreters
    private var dspInterpreter: Interpreter? = null
    private var npuInterpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        setupInterpreters()
    }

    private fun setupInterpreters() {
        try {
            // Load the lightweight INT8 model for the DSP
            // In a real scenario, we would use a specific DSP delegate (e.g., Hexagon)
            dspInterpreter = Interpreter.create(loadModelFile("dsp_low_power.tflite"))
            
            // Load the high-precision model for the NPU via NNAPI
            nnApiDelegate = NnApiDelegate()
            val npuOptions = Interpreter.Options().addDelegate(nnApiDelegate)
            npuInterpreter = Interpreter.create(loadModelFile("npu_high_precision.tflite"), npuOptions)
        } catch (e: Exception) {
            Log.e("AudioRepo", "Failed to initialize AI hardware delegates", e)
        }
    }

    /**
     * Processes incoming audio buffers through the tiered pipeline.
     */
    fun analyzeAudioStream(audioData: ByteBuffer): Flow<DetectionResult> = flow {
        // STEP 1: DSP Inference (Low Power)
        // The DSP model is small and optimized for INT8.
        val dspOutput = FloatArray(1) 
        dspInterpreter?.run(audioData, dspOutput)
        
        val triggerProbability = dspOutput[0]
        Log.d("AudioRepo", "DSP Probability: $triggerProbability")

        if (triggerProbability > 0.7f) { // Threshold for "Wake-up"
            emit(DetectionResult.DspTriggered(triggerProbability))

            // STEP 2: NPU Inference (High Power)
            // We only reach this block if the DSP detected something relevant.
            // This saves massive amounts of battery.
            val npuOutput = FloatArray(10) // Assume 10 classes of audio events
            npuInterpreter?.run(audioData, npuOutput)
            
            val maxIndex = npuOutput.indices.maxByOrNull { npuOutput[it] } ?: -1
            val confidence = npuOutput[maxIndex]
            
            if (confidence > 0.85f) {
                emit(DetectionResult.NpuValidated("Event_$maxIndex", confidence))
            } else {
                emit(DetectionResult.FalsePositive)
            }
        } else {
            emit(DetectionResult.Idle)
        }
    }.flowOn(Dispatchers.Default)

    private fun loadModelFile(path: String): ByteBuffer {
        return context.assets.open(path).use { it.readBytes().let { bytes ->
            ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
                rewind()
            }
        }}
    }

    fun release() {
        dspInterpreter?.close()
        npuInterpreter?.close()
        nnApiDelegate?.close()
        scope.cancel()
    }
}

sealed class DetectionResult {
    object Idle : DetectionResult()
    data class DspTriggered(val prob: Float) : DetectionResult()
    data class NpuValidated(val label: String, val conf: Float) : DetectionResult()
    object FalsePositive : DetectionResult()
}

/**
 * ViewModel implementing MVI pattern to handle the UI state of the Audio Sentinel.
 */
@AndroidEntryPoint
class AudioSentinelViewModel @Inject constructor(
    private val repository: AudioAnalysisRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(AudioSentinelUiState())
    val uiState: StateFlow<AudioSentinelUiState> = _uiState.asStateFlow()

    private var monitoringJob: Job? = null

    fun toggleMonitoring() {
        if (_uiState.value.isMonitoring) {
            stopMonitoring()
        } else {
            startMonitoring()
        }
    }

    private fun startMonitoring() {
        _uiState.update { it.copy(isMonitoring = true, hardwareActive = "DSP") }
        
        monitoringJob = viewModelScope.launch {
            // Simulate an audio stream from a CameraX-like analyzer or AudioRecord
            while (isActive) {
                val mockAudioBuffer = ByteBuffer.allocateDirect(1024).apply {
                    order(ByteOrder.nativeOrder())
                }
                
                repository.analyzeAudioStream(mockAudioBuffer).collect { result ->
                    handleDetectionResult(result)
                }
                delay(100) // Process every 100ms
            }
        }
    }

    private fun handleDetectionResult(result: DetectionResult) {
        when (result) {
            is DetectionResult.Idle -> {
                _uiState.update { it.copy(detectionLevel = DetectionLevel.IDLE, hardwareActive = "DSP") }
            }
            is DetectionResult.DspTriggered -> {
                _uiState.update { it.copy(
                    detectionLevel = DetectionLevel.DSP_TRIGGERED, 
                    hardwareActive = "NPU/GPU",
                    confidence = result.prob
                )}
            }
            is DetectionResult.NpuValidated -> {
                _uiState.update { it.copy(
                    detectionLevel = DetectionLevel.NPU_VALIDATED,
                    lastDetectedEvent = result.label,
                    confidence = result.conf,
                    hardwareActive = "NPU/GPU"
                )}
            }
            is DetectionResult.FalsePositive -> {
                _uiState.update { it.copy(detectionLevel = DetectionLevel.IDLE, hardwareActive = "DSP") }
            }
        }
    }

    private fun stopMonitoring() {
        monitoringJob?.cancel()
        _uiState.update { it.copy(isMonitoring = false, detectionLevel = DetectionLevel.IDLE) }
    }

    override fun onCleared() {
        super.onCleared()
        repository.release()
    }
}

/**
 * Hilt Module for Dependency Injection.
 */
@Module
@InstallIn(SingletonComponent::class)
object AudioModule {
    @Provides
    @Singleton
    fun provideContext(app: android.app.Application): Context = app.applicationContext
}
