
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.audio.dsp

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data class representing the result of the Audio AI inference.
 */
data class AudioInferenceResult(
    val label: String,
    val confidence: Float,
    val isDetected: Boolean
)

/**
 * Repository responsible for the heavy lifting of Audio AI.
 * It manages the TFLite Interpreter and the NNAPI Delegate to target the DSP.
 */
@Singleton
class AudioAnalysisRepository @Inject constructor(
    private val context: Context
) {
    private var tflite: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null
    
    // Model constants - these should match your .tflite model architecture
    private val MODEL_PATH = "wake_word_model.tflite"
    private val INPUT_SIZE = 16000 // 1 second of 16kHz audio
    private val OUTPUT_SIZE = 3    // e.g., [Silence, Noise, WakeWord]

    init {
        setupTFLite()
    }

    private fun setupTFLite() {
        try {
            val options = Interpreter.Options().apply {
                // CRITICAL: This is where we request the DSP via NNAPI
                nnApiDelegate = NnApiDelegate()
                addDelegate(nnApiDelegate)
                setNumThreads(1) // DSP handles parallelism; CPU threads are less relevant here
            }
            
            // Load the model from assets
            tflite = Interpreter.create(loadModelFile(), options)
            Log.d("AudioAI", "TFLite Interpreter initialized with NNAPI/DSP delegate.")
        } catch (e: Exception) {
            Log.e("AudioAI", "Failed to initialize DSP delegate: ${e.message}")
        }
    }

    private fun loadModelFile(): ByteBuffer {
        context.assets.open(MODEL_PATH).use { inputStream ->
            val bytes = inputStream.readBytes()
            return ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
                rewind()
            }
        }
    }

    /**
     * Processes a chunk of audio data. 
     * This function is designed to be called from a background thread.
     */
    fun analyzeAudio(audioData: FloatArray): AudioInferenceResult {
        val inputBuffer = ByteBuffer.allocateDirect(INPUT_SIZE * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        
        // Fill buffer with audio data
        audioData.forEach { inputBuffer.putFloat(it) }
        inputBuffer.rewind()

        val outputBuffer = Array(1) { FloatArray(OUTPUT_SIZE) }

        // Perform inference on the DSP
        tflite?.run(inputBuffer, outputBuffer)

        val results = outputBuffer[0]
        val maxIndex = results.indices.maxByOrNull { results[it] } ?: -1
        val confidence = results.getOrElse(maxIndex) { 0f }
        
        val label = when(maxIndex) {
            0 -> "Silence"
            1 -> "Background Noise"
            2 -> "Wake Word Detected!"
            else -> "Unknown"
        }

        return AudioInferenceResult(
            label = label,
            confidence = confidence,
            isDetected = maxIndex == 2 && confidence > 0.8f
        )
    }

    fun close() {
        tflite?.close()
        nnApiDelegate?.close()
    }
}

/**
 * ViewModel to bridge the Repository and the Compose UI.
 * It ensures that AI inference does not block the Main Thread.
 */
@AndroidEntryPoint
class AudioViewModel @Inject constructor(
    private val repository: AudioAnalysisRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AudioInferenceResult("Initializing...", 0f, false))
    val uiState: StateFlow<AudioInferenceResult> = _uiState.asStateFlow()

    private var isListening = false
    private var recordingJob: Job? = null

    fun toggleListening() {
        if (isListening) {
            stopListening()
        } else {
            startListening()
        }
        isListening = !isListening
    }

    private fun startListening() {
        recordingJob = viewModelScope.launch(Dispatchers.Default) {
            val sampleRate = 16000
            val bufferSize = AudioRecord.getMinBufferSize(
                sampleRate, 
                AudioFormat.CHANNEL_IN_MONO, 
                AudioFormat.ENCODING_PCM_FLOAT
            )
            
            val audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_FLOAT,
                bufferSize
            )

            audioRecord.startRecording()
            val audioBuffer = FloatArray(16000) // 1 second window

            try {
                while (isActive) {
                    // Read audio data from the hardware buffer
                    val readSize = audioRecord.read(audioBuffer, 0, audioBuffer.size)
                    if (readSize > 0) {
                        // Perform AI inference on the DSP via the repository
                        val result = repository.analyzeAudio(audioBuffer)
                        
                        // Update UI on the Main thread
                        withContext(Dispatchers.Main) {
                            _uiState.value = result
                        }
                    }
                }
            } finally {
                audioRecord.stop()
                audioRecord.release()
            }
        }
    }

    private fun stopListening() {
        recordingJob?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}

/**
 * Jetpack Compose UI for visualizing the Audio AI performance.
 */
@Composable
fun AudioAIScreen(viewModel: AudioViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    androidx.compose.material3.Surface(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        color = androidx.compose.material3.MaterialTheme.colorScheme.background
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            androidx.compose.material3.Text(
                text = "Edge AI DSP Audio Monitor",
                style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
            )
            
            androidx.compose.foundation.layout.Spacer(modifier = androidx.compose.ui.Modifier.height(24.dp))

            // Visual indicator of detection
            androidx.compose.foundation.layout.Box(
                modifier = androidx.compose.ui.Modifier
                    .size(200.dp)
                    .background(
                        if (state.isDetected) androidx.compose.ui.graphics.Color.Green 
                        else androidx.compose.ui.graphics.Color.Gray,
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                androidx.compose.material3.Text(
                    text = state.label,
                    style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                    color = androidx.compose.ui.graphics.Color.White
                )
            }

            androidx.compose.foundation.layout.Spacer(modifier = androidx.compose.ui.Modifier.height(16.dp))

            androidx.compose.material3.Text(
                text = "Confidence: ${(state.confidence * 100).toInt()}%",
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge
            )

            androidx.compose.foundation.layout.Spacer(modifier = androidx.compose.ui.Modifier.height(32.dp))

            androidx.compose.material3.Button(onClick = { viewModel.toggleListening() }) {
                androidx.compose.material3.Text(if (state.label == "Initializing...") "Start Listening" else "Toggle Mic")
            }
        }
    }
}
