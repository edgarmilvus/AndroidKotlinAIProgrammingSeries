
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import java.nio.ByteBuffer
import java.nio.ByteOrder

class LmsAdaptiveFilter(private val filterOrder: Int = 32, private val learningRate: Float = 0.01f) {
    // Direct buffers are allocated outside the JVM heap, allowing C++ to access them without copying
    private val weights = ByteBuffer.allocateDirect(filterOrder * 4).apply {
        order(ByteOrder.nativeOrder())
    }.asFloatBuffer()
    
    private val xBuffer = ByteBuffer.allocateDirect(filterOrder * 4).apply {
        order(ByteOrder.nativeOrder())
    }.asFloatBuffer()

    init {
        for (i in 0 until filterOrder) {
            weights.put(i, 0.0f)
            xBuffer.put(i, 0.0f)
        }
    }

    fun processSample(primarySample: Float, referenceSample: Float): Float {
        // 1. Shift reference buffer (The 'Delay Line')
        for (i in filterOrder - 1 downTo 1) {
            xBuffer.put(i, xBuffer.get(i - 1))
        }
        xBuffer.put(0, referenceSample)

        // 2. Predict noise: y_hat = sum(w[k] * x[n-k])
        var predictedNoise = 0.0f
        for (k in 0 until filterOrder) {
            predictedNoise += weights.get(k) * xBuffer.get(k)
        }

        // 3. Error calculation: e[n] = d[n] - y_hat
        val error = primarySample - predictedNoise

        // 4. Weight Update: w[n+1] = w[n] + mu * e[n] * x[n]
        for (k in 0 until filterOrder) {
            val newWeight = weights.get(k) + learningRate * error * xBuffer.get(k)
            weights.put(k, newWeight)
        }

        return error // The 'cleaned' signal
    }
}

// Orchestrator for Dual-Mic Capture
class AncManager {
    private val filter = LmsAdaptiveFilter()
    
    fun onAudioFrameReceived(primary: FloatArray, reference: FloatArray) {
        val cleaned = FloatArray(primary.size)
        for (i in primary.indices) {
            cleaned[i] = filter.processSample(primary[i], reference[i])
        }
        // Send 'cleaned' to AudioTrack...
    }
}
