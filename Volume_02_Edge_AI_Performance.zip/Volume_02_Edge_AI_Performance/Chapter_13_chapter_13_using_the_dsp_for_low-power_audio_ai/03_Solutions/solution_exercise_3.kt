
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.FileInputStream
import java.nio.channels.FileChannel

class KwsInferenceEngine(context: Context) {
    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        val options = Interpreter.Options().apply {
            // Target the DSP via NNAPI
            nnApiDelegate = NnApiDelegate()
            addDelegate(nnApiDelegate)
            setNumThreads(1) // Force offloading by limiting CPU resources
        }
        
        interpreter = Interpreter(loadModelFile(context, "kws_quantized.tflite"), options)
    }

    private fun loadModelFile(context: Context, modelName: String): ByteBuffer {
        val fileDescriptor = context.assets.openFd(modelName)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    fun runInference(mfccFeatures: FloatArray): String {
        // The model is Int8 quantized. We must convert Float MFCCs to Int8.
        // Input shape: [1, 40, 13] (1 second, 40 frames, 13 coefficients)
        val inputBuffer = ByteBuffer.allocateDirect(40 * 13).apply {
            order(ByteOrder.nativeOrder())
        }
        
        // Quantization: scale float to byte (-128 to 127)
        mfccFeatures.forEach { 
            inputBuffer.put((it * 127).toInt().toByte()) 
        }
        inputBuffer.rewind()

        val output = Array(1) { FloatArray(5) } // 5 possible keywords
        interpreter?.run(inputBuffer, output)

        val maxIndex = output[0].indices.maxByOrNull { output[0][it] } ?: -1
        val confidence = output[0][maxIndex]

        return if (confidence > 0.8f) "WAKE_WORD_DETECTED" else "IDLE"
    }

    fun close() {
        interpreter?.close()
        nnApiDelegate?.close()
    }
}
