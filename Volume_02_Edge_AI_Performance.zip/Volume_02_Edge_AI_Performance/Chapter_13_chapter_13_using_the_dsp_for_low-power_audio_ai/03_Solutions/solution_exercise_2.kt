
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.*

class HighPassFirFilter(private val cutoffFreq: Float, private val sampleRate: Int) {
    // Filter coefficients (b_k) for a simple High-Pass FIR
    // In a real scenario, these are calculated using the Window Method or Parks-McClellan
    private val coefficients = floatArrayOf(0.1f, -0.2f, 0.3f, -0.2f, 0.1f) 
    private val delayLine = FloatArray(coefficients.size)
    private var index = 0

    fun process(sample: Float): Float {
        // Update delay line (Circular Buffer)
        delayLine[index] = sample
        
        var output = 0.0f
        for (k in coefficients.indices) {
            // Convolution: y[n] = sum(b[k] * x[n-k])
            val sampleIdx = (index - k + coefficients.size) % coefficients.size
            output += coefficients[k] * delayLine[sampleIdx]
        }
        
        index = (index + 1) % coefficients.size
        return output
    }
}

class RealTimeAudioEngine {
    private val sampleRate = 16000
    private val filter = HighPassFirFilter(100f, sampleRate)
    private val scope = CoroutineScope(Dispatchers.Default)

    fun startProcessing() {
        scope.launch {
            val recordBufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT)
            val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT, recordBufferSize)
            
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(recordBufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val buffer = FloatArray(256) // Small buffer to keep latency low
            recorder.startRecording()
            track.play()

            while (isActive) {
                val read = recorder.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                for (i in 0 until read) {
                    buffer[i] = filter.process(buffer[i])
                }
                track.write(buffer, 0, read, AudioTrack.WRITE_BLOCKING)
            }
        }
    }
}
