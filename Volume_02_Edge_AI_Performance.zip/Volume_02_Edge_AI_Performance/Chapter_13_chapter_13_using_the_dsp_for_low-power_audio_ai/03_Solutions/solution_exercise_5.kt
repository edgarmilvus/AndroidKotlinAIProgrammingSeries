
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.Context
import android.os.BatteryManager
import dagger.hilt.Inject
import kotlinx.coroutines.flow.*
import javax.inject.Singleton

interface AudioInferenceEngine {
    fun process(frame: FloatArray): FloatArray
}

class CpuEngine : AudioInferenceEngine {
    override fun process(frame: FloatArray) = frame // High-fidelity Float32 logic
}

class GpuEngine : AudioInferenceEngine {
    override fun process(frame: FloatArray) = frame // Balanced logic
}

class DspEngine : AudioInferenceEngine {
    override fun process(frame: FloatArray) = frame // Ultra-low power Int8 logic
}

class EngineFactory @Inject constructor() {
    fun createHighFidelity() = CpuEngine()
    fun createBalanced() = GpuEngine()
    fun createUltraLowPower() = DspEngine()
}

@Singleton
class AudioOrchestrator @Inject constructor(
    private val context: Context,
    private val factory: EngineFactory
) {
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    
    private val _currentEngine = MutableStateFlow<AudioInferenceEngine>(factory.createBalanced())
    val currentEngine: StateFlow<AudioInferenceEngine> = _currentEngine

    fun monitorPowerState() {
        // Poll battery level and update strategy
        // In production, use a BroadcastReceiver for ACTION_BATTERY_CHANGED
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        
        val nextEngine = when {
            level > 50 -> factory.createHighFidelity()
            level in 20..50 -> factory.createBalanced()
            else -> factory.createUltraLowPower()
        }
        
        if (_currentEngine.value::class != nextEngine::class) {
            _currentEngine.value = nextEngine
        }
    }

    fun processAudio(frame: FloatArray): FloatArray {
        // The seamless switch happens here: the flow always provides the latest engine
        return currentEngine.value.process(frame)
    }
}
