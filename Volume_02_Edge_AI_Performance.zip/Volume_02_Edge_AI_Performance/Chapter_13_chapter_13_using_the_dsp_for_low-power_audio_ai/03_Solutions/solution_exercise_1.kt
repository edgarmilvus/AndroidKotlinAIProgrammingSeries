
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import org.jetbrains.kotlinx.jni.JTransforms // Conceptual import for JTransforms
import pl.edu.icm.jtransforms.fft.DoubleFFT_1D
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CircularAudioBuffer(val capacity: Int) {
    private val buffer = FloatArray(capacity)
    private var writeIndex = AtomicInteger(0)
    private var readIndex = AtomicInteger(0)

    fun write(data: FloatArray) {
        for (sample in data) {
            buffer[writeIndex.get() % capacity] = sample
            writeIndex.incrementAndGet()
        }
    }

    fun read(size: Int): FloatArray {
        val result = FloatArray(size)
        for (i in 0 until size) {
            result[i] = buffer[readIndex.get() % capacity]
            readIndex.incrementAndGet()
        }
        return result
    }
}

@AndroidEntryPoint
class SoundAnalyzerService : Service() {
    @Inject lateinit var audioBuffer: CircularAudioBuffer
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isRecording = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isRecording = true
        startCapture()
        startProcessing()
        return START_STICKY
    }

    private fun startCapture() {
        scope.launch(Dispatchers.IO) {
            val bufferSize = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            
            val readBuffer = ShortArray(bufferSize)
            recorder.startRecording()
            
            while (isRecording) {
                val read = recorder.read(readBuffer, 0, bufferSize)
                // Convert PCM 16-bit to Float (-1.0 to 1.0) to avoid repeated conversions in DSP
                val floatBuffer = FloatArray(read) { readBuffer[it] / 32768.0f }
                audioBuffer.write(floatBuffer)
            }
            recorder.stop()
            recorder.release()
        }
    }

    private fun startProcessing() {
        scope.launch(Dispatchers.Default) {
            val frameSize = 1024 // ~64ms at 16kHz
            val fft = DoubleFFT_1D(frameSize.toLong())
            val hannWindow = FloatArray(frameSize) { i -> 0.5f * (1 - Math.cos(2 * Math.PI * i / (frameSize - 1)).toFloat()) }

            while (isRecording) {
                val frame = audioBuffer.read(frameSize)
                if (frame.size < frameSize) continue

                // 1. Windowing
                val windowedFrame = DoubleArray(frameSize) { i -> (frame[i] * hannWindow[i]).toDouble() }

                // 2. FFT (Magnitude Spectrum)
                val fftData = DoubleArray(frameSize * 2) 
                System.arraycopy(windowedFrame, 0, fftData, 0, frameSize)
                fft.realForward(fftData)
                
                val magnitude = DoubleArray(frameSize / 2) { i ->
                    Math.sqrt(fftData[2 * i] * fftData[2 * i] + fftData[2 * i + 1] * fftData[2 * i + 1])
                }

                // 3. Mel-Scaling & DCT (Conceptual implementation)
                val mfccs = computeMFCCs(magnitude) 
                // Pass mfccs to AI Model...
            }
        }
    }

    private fun computeMFCCs(magnitude: DoubleArray): FloatArray {
        // Simplified: In production, this involves a Mel-Filterbank matrix multiplication
        // followed by a Log operation and a Discrete Cosine Transform (DCT).
        return FloatArray(13) { 0.0f } 
    }

    override fun onDestroy() {
        isRecording = false
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
