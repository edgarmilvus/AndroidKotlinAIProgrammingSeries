
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AudioNoiseSuppressor @Inject constructor(
    private val modelBuffer: ByteBuffer
) {
    private val audioChannel = Channel<FloatArray>(Channel.CONFLATED)
    private var interpreter: Interpreter? = null
    
    // State management for RNN
    private var hiddenState: ByteBuffer = ByteBuffer.allocateDirect(128 * 4).apply {
        order(ByteOrder.nativeOrder())
    }

    init {
        val options = Interpreter.Options().apply {
            val nnApiDelegate = NnApiDelegate().apply {
                // Force DSP/Low Power preference
                // Note: Options are set via the delegate constructor in newer TFLite versions
            }
            addDelegate(nnApiDelegate)
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    fun startProcessing(scope: CoroutineScope) {
        // Thread 1: Audio Capture
        scope.launch(Dispatchers.IO) {
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000, 
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 1024
            )
            val buffer = ShortArray(512)
            recorder.startRecording()
            
            while (isActive) {
                recorder.read(buffer, 0, buffer.size)
                // Convert PCM16 to Float32 for the model
                val floatBuffer = FloatArray(buffer.size) { buffer[it] / 32768f }
                audioChannel.send(floatBuffer)
            }
        }

        // Thread 2: AI Inference (The "Consumer")
        scope.launch(Dispatchers.Default) {
            for (frame in audioChannel) {
                processFrame(frame)
            }
        }
    }

    private fun processFrame(frame: FloatArray) {
        val input = ByteBuffer.allocateDirect(frame.size * 4).apply {
            order(ByteOrder.nativeOrder())
            frame.forEach { putFloat(it) }
        }
        
        val output = ByteBuffer.allocateDirect(frame.size * 4).apply {
            order(ByteOrder.nativeOrder())
        }

        // RNN stateful execution: Pass hiddenState as part of the input/output tensors
        val inputs = arrayOf(input, hiddenState)
        val outputs = mutableMapOf<Int, Any>()
        outputs[0] = output
        outputs[1] = hiddenState // Update the state for the next frame

        interpreter?.runForMultipleInputsOutputs(inputs, outputs)
        
        // Send output to AudioTrack for playback...
    }
}
