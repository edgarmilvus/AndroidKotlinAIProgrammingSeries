
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.tensorflow.lite.Interpreter
import javax.inject.Inject
import javax.inject.Singleton

enum class ModelType(val fileName: String) {
    FLOAT32("model_f32.tflite"),
    PTQ_INT8("model_ptq_i8.tflite"),
    QAT_INT8("model_qat_i8.tflite")
}

data class BenchmarkResult(
    val modelType: ModelType,
    val avgLatencyMs: Double,
    val fileSizeKb: Long
)

@Singleton
class LatencyBenchmarker @Inject constructor(
    private val modelManager: ModelManager
) {
    private val _results = MutableStateFlow<List<BenchmarkResult>>(emptyList())
    val results: StateFlow<List<BenchmarkResult>> = _results.asStateFlow()

    // Custom dispatcher to ensure AI tasks don't block UI or Main thread
    private val aiDispatcher = Dispatchers.Default.limitedParallelism(1)

    suspend fun runBenchmark(inputData: ByteBuffer) = withContext(aiDispatcher) {
        val benchmarkList = mutableListOf<BenchmarkResult>()

        ModelType.values().forEach { type ->
            val buffer = modelManager.loadModelFile(type.fileName)
            val interpreter = Interpreter(buffer)
            val output = ByteBuffer.allocateDirect(100).order(ByteOrder.nativeOrder())

            // 1. Warm-up phase: Discard first 5 runs
            repeat(5) { interpreter.run(inputData, output) }

            // 2. High-precision timing
            val iterations = 20
            var totalTime = 0L
            
            repeat(iterations) {
                val start = System.nanoTime()
                interpreter.run(inputData, output)
                totalTime += (System.nanoTime() - start)
            }

            val avgLatency = (totalTime / iterations) / 1_000_000.0
            val fileSize = buffer.capacity() / 1024

            benchmarkList.add(BenchmarkResult(type, avgLatency, fileSize))
            interpreter.close()
        }
        _results.value = benchmarkList
    }
}
