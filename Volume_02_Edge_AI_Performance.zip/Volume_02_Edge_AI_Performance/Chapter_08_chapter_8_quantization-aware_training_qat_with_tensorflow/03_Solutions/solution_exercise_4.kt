
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton

sealed class HardwareProfile {
    object HighPerformance : HardwareProfile() // GPU
    object Balanced : HardwareProfile()       // NPU
    object PowerSave : HardwareProfile()      // CPU
}

@Singleton
class HardwareAcceleratorManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val modelManager: ModelManager
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    
    private val _currentProfile = MutableStateFlow<HardwareProfile>(HardwareProfile.HighPerformance)
    val currentProfile: StateFlow<HardwareProfile> = _currentProfile.asStateFlow()

    // Pre-initialized interpreters to avoid hot-swap hiccups
    private val interpreters = mutableMapOf<HardwareProfile, Interpreter>()

    init {
        setupInterpreters()
        observeThermalStatus()
    }

    private fun setupInterpreters() {
        val modelBuffer = modelManager.loadModelFile("complex_qat_model.tflite")
        
        interpreters[HardwareProfile.HighPerformance] = Interpreter(modelBuffer, Interpreter.Options().addDelegate(GpuDelegate()))
        interpreters[HardwareProfile.Balanced] = Interpreter(modelBuffer, Interpreter.Options().addDelegate(NnApiDelegate()))
        interpreters[HardwareProfile.PowerSave] = Interpreter(modelBuffer, Interpreter.Options().setNumThreads(2))
    }

    private fun observeThermalStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusChangedListener { status ->
                _currentProfile.value = when (status) {
                    PowerManager.THERMAL_STATUS_NONE, 
                    PowerManager.THERMAL_STATUS_LIGHT -> HardwareProfile.HighPerformance
                    PowerManager.THERMAL_STATUS_MODERATE -> HardwareProfile.Balanced
                    else -> HardwareProfile.PowerSave
                }
            }
        }
    }

    fun predict(input: ByteBuffer): ByteBuffer {
        val activeInterpreter = interpreters[_currentProfile.value] 
            ?: interpreters[HardwareProfile.PowerSave]!!
        
        val output = ByteBuffer.allocateDirect(1024)
        activeInterpreter.run(input, output)
        return output
    }
}
