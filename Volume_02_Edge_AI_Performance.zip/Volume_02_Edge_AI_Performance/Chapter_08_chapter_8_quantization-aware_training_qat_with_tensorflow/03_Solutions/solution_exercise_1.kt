
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModelInjection
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.ViewModel
import dagger.hilt.Inject
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

// 1. Model State using Kotlin 2.x Sealed Interface
sealed interface ModelState {
    object Loading : ModelState
    data class Ready(val modelName: String) : ModelState
    data class Error(val message: String) : ModelState
}

// 2. Model Manager for Asset Loading
@Singleton
class ModelManager @Inject constructor(@ApplicationContext private val context: Context) {
    fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }
}

// 3. Inference Engine
class PlantClassifier @Inject constructor(
    private val modelBuffer: MappedByteBuffer
) {
    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        val options = Interpreter.Options().apply {
            // Explicitly request NPU via NNAPI
            nnApiDelegate = NnApiDelegate()
            addDelegate(nnApiDelegate)
            setNumThreads(4)
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    fun classify(bitmap: Bitmap, scale: Float, zeroPoint: Int): IntArray {
        // INT8 Data Pipeline: Convert Bitmap to ByteBuffer
        val inputBuffer = ByteBuffer.allocateDirect(1 * 224 * 224 * 3).apply {
            order(ByteOrder.nativeOrder())
        }

        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        for (pixel in pixels) {
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            
            // Quantization Formula: quantized_value = (real_value / scale) + zero_point
            // Since pixels are 0-255, we normalize to 0.0-1.0 first
            inputBuffer.put(((r / 255f / scale).toInt() + zeroPoint).toByte())
            inputBuffer.put(((g / 255f / scale).toInt() + zeroPoint).toByte())
            inputBuffer.put(((b / 255f / scale).toInt() + zeroPoint).toByte())
        }
        inputBuffer.rewind()

        val outputBuffer = ByteBuffer.allocateDirect(1 * 100).apply { // Assuming 100 classes
            order(ByteOrder.nativeOrder())
        }

        interpreter?.run(inputBuffer, outputBuffer)
        
        // Logic to extract top 3 indices from outputBuffer would go here
        return intArrayOf(0, 1, 2) // Placeholder
    }

    fun close() {
        interpreter?.close()
        nnApiDelegate?.close()
    }
}

// 4. Hilt Module for DI
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun providePlantClassifier(@ApplicationContext context: Context, modelManager: ModelManager): PlantClassifier {
        val buffer = modelManager.loadModelFile("plant_qat_int8.tflite")
        return PlantClassifier(buffer)
    }
}
