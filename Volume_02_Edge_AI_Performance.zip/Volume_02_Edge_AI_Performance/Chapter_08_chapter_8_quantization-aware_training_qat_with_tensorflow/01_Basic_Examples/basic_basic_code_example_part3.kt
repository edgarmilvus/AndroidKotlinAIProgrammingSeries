
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edgeai.performance.data.TFLiteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject

data class InferenceState(
    val result: String = "Waiting for input...",
    val confidence: Float = 0f,
    val isProcessing: Boolean = false
)

@HiltViewModel
class AIViewModel @Inject constructor(
    private val repository: TFLiteRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(InferenceState())
    val uiState: StateFlow<InferenceState> = _uiState.asStateFlow()

    /**
     * Processes an image buffer. 
     * In a real app, this would be called by a CameraX Analyzer.
     */
    fun analyzeImage(bitmapBuffer: ByteBuffer) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true)

            // CRITICAL: Move inference to a background thread.
            // Dispatchers.Default is optimized for CPU-intensive work.
            val result = withContext(Dispatchers.Default) {
                try {
                    val probabilities = repository.runInference(bitmapBuffer)
                    processProbabilities(probabilities)
                } catch (e: Exception) {
                    // Handle inference errors (e.g., buffer overflow)
                    null
                }
            }

            _uiState.value = if (result != null) {
                InferenceState(
                    result = result.first,
                    confidence = result.second,
                    isProcessing = false
                )
            } else {
                _uiState.value.copy(isProcessing = false, result = "Error in inference")
            }
        }
    }

    private fun processProbabilities(probs: FloatArray): Pair<String, Float> {
        // Find the index with the highest probability
        val maxIndex = probs.indices.maxByOrNull { probs[it] } ?: -1
        val confidence = probs[maxIndex]
        val label = "Class $maxIndex" // In production, map this to a labels.txt file
        return Pair(label, confidence)
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}
