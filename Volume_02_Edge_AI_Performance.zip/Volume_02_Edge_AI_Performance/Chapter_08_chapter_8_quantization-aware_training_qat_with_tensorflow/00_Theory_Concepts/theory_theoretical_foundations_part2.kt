
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

// Dependency: implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
// Dependency: implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")

class ModelStreamer(private val aiCore: AiCoreClient) {
    
    // Use a Flow to stream inference results
    fun streamInference(inputFlow: Flow<ByteArray>): Flow<InferenceResult> = 
        inputFlow
            .map { bytes ->
                // Move execution to a dedicated AI dispatcher (NPU/GPU)
                withContext(Dispatchers.Default) {
                    aiCore.runInference(bytes)
                }
            }
            .flowOn(Dispatchers.Default) // Ensure processing happens off-main
            .catch { e -> emit(InferenceResult.Error(e)) }

    suspend fun initializeModel() = coroutineScope {
        // Parallel loading of model metadata and weight buffers
        val metadata = async { aiCore.fetchMetadata() }
        val weights = async { aiCore.loadWeights() }
        
        combineModel(metadata.await(), weights.await())
    }
}
