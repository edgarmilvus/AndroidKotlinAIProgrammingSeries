
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.qat

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Represents the UI State for the Defect Detection screen.
 */
data class DetectionState(
    val isAnalyzing: Boolean = false,
    val detectionResult: String = "Waiting for frame...",
    val confidence: Float = 0f,
    val activeHardware: HardwareAccelerator = HardwareAccelerator.CPU,
    val error: String? = null
)

enum class HardwareAccelerator { CPU, GPU, NPU }

/**
 * Repository responsible for TFLite model orchestration.
 * This is where the QAT-optimized INT8 model is loaded and mapped to hardware.
 */
@Singleton
class DefectDetectionRepository @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null
    
    // The QAT model is INT8, meaning we expect ByteBuffer of bytes, not floats.
    private val inputBufferSize = 224 * 224 * 3 // Example: 224x224 RGB
    private val outputBufferSize = 2 // Binary classification: Defect vs No-Defect

    /**
     * Initializes the interpreter based on hardware availability.
     * QAT models excel on NPUs (via NNAPI) and GPUs.
     */
    fun initializeModel(preference: HardwareAccelerator): HardwareAccelerator {
        val options = Interpreter.Options()
        
        return try {
            when (preference) {
                HardwareAccelerator.NPU -> {
                    // NNAPI is the gateway to the NPU. 
                    // QAT INT8 models are highly optimized for Hexagon/NPU cores.
                    nnApiDelegate = NnApiDelegate()
                    options.addDelegate(nnApiDelegate)
                    HardwareAccelerator.NPU
                }
                HardwareAccelerator.GPU -> {
                    // GPU Delegate handles FP16/INT8 via OpenCL/Vulkan.
                    gpuDelegate = GpuDelegate()
                    options.addDelegate(gpuDelegate)
                    HardwareAccelerator.GPU
                }
                HardwareAccelerator.CPU -> HardwareAccelerator.CPU
            }
            
            // Load the .tflite model from assets
            val modelBuffer = context.assets.open("qat_defect_model_int8.tflite")
                .readBytes()
                .let { java.nio.ByteBuffer.allocateDirect(it.size).put(it).flip() }
            
            interpreter = Interpreter(modelBuffer, options)
            Log.d("EdgeAI", "Model initialized successfully on $preference")
            preference
        } catch (e: Exception) {
            Log.e("EdgeAI", "Hardware acceleration failed, falling back to CPU", e)
            interpreter = Interpreter(context.assets.open("qat_defect_model_int8.tflite").readBytes().let { 
                java.nio.ByteBuffer.allocateDirect(it.size).put(it).flip() 
            })
            HardwareAccelerator.CPU
        }
    }

    /**
     * Performs inference on a bitmap. 
     * Uses Dispatchers.Default to prevent UI jank.
     */
    suspend fun analyzeFrame(bitmap: Bitmap): Pair<String, Float> = withContext(Dispatchers.Default) {
        val tflite = interpreter ?: throw IllegalStateException("Interpreter not initialized")
        
        // 1. Pre-processing: Convert Bitmap to INT8 ByteBuffer
        // Since the model is QAT INT8, we do NOT normalize to 0.0-1.0 floats.
        // Instead, we map 0-255 pixels directly to the quantized range.
        val inputBuffer = ByteBuffer.allocateDirect(inputBufferSize).apply {
            order(ByteOrder.nativeOrder())
        }
        
        // Simplified pixel extraction (In production, use ImageProcessor from TFLite Support)
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        
        pixels.forEach { pixel ->
            inputBuffer.put((pixel shr 16 and 0xFF).toByte()) // R
            inputBuffer.put((pixel shr 8 and 0xFF).toByte())  // G
            inputBuffer.put((pixel and 0xFF).toByte())       // B
        }
        inputBuffer.rewind()

        // 2. Output Buffer: Since it's an INT8 model, the output is often quantized.
        // We use a float array here because TFLite's interpreter handles the 
        // de-quantization of the output tensor automatically if requested.
        val outputBuffer = Array(1) { FloatArray(outputBufferSize) }
        
        tflite.run(inputBuffer, outputBuffer)
        
        val results = outputBuffer[0]
        val maxIdx = if (results[0] > results[1]) 0 else 1
        val confidence = results[maxIdx]
        
        val label = if (maxIdx == 0) "Defect Detected" else "Quality OK"
        Pair(label, confidence)
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * ViewModel implementing MVI pattern to handle AI inference state.
 */
@HiltViewModel
class DefectDetectionViewModel @Inject constructor(
    private val repository: DefectDetectionRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(DetectionState())
    val uiState: StateFlow<DetectionState> = _uiState.asStateFlow()

    init {
        // Default to NPU for QAT models
        val actualHardware = repository.initializeModel(HardwareAccelerator.NPU)
        _uiState.update { it.copy(activeHardware = actualHardware) }
    }

    fun onFrameReceived(bitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzing = true) }
            try {
                val (label, confidence) = repository.analyzeFrame(bitmap)
                _uiState.update { 
                    it.copy(
                        isAnalyzing = false, 
                        detectionResult = label, 
                        confidence = confidence 
                    ) 
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isAnalyzing = false, error = e.message) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}

/**
 * Hilt Module for Dependency Injection.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideContext(app: android.app.Application): Context = app.applicationContext
}
