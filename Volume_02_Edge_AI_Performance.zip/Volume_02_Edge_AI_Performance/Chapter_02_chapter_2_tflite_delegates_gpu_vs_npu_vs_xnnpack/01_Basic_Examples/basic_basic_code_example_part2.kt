
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.delegates

import android.content.Context
import android.os.Build
import android.util.Log
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import dagger.hilt.components.SingletonComponent
import dagger.hilt.provided.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

/**
 * Enum defining the available acceleration modes.
 */
enum class AccelerationMode {
    CPU_XNNPACK, // Optimized CPU
    GPU,         // Mobile GPU (OpenCL/OpenGL)
    NPU_NNAPI    // Neural Processing Unit via NNAPI
}

/**
 * TFLiteModelManager handles the heavy lifting of loading the model 
 * and configuring the hardware delegates.
 */
@Singleton
class TFLiteModelManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    private val TAG = "TFLiteModelManager"

    /**
     * Loads the model and applies the selected delegate.
     * This is a blocking operation and MUST be called on a background thread.
     */
    fun initializeInterpreter(mode: AccelerationMode, modelPath: String) {
        // 1. Clean up existing resources to prevent native memory leaks
        closeInterpreter()

        val options = Interpreter.Options()

        when (mode) {
            AccelerationMode.CPU_XNNPACK -> {
                // XNNPACK is enabled by default in recent TFLite versions, 
                // but we can explicitly configure it.
                options.setUseXNNPACK(true)
                Log.d(TAG, "Configuring XNNPACK (CPU)")
            }
            AccelerationMode.GPU -> {
                // Initialize GPU Delegate
                // GpuDelegate.Options allows for precision tuning (FP16 vs FP32)
                val gpuOptions = GpuDelegate.Options().apply {
                    setPrecisionLossAllowed(true) // Use FP16 for significant speedup
                }
                gpuDelegate = GpuDelegate(gpuOptions)
                options.addDelegate(gpuDelegate)
                Log.d(TAG, "Configuring GPU Delegate")
            }
            AccelerationMode.NPU_NNAPI -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    nnApiDelegate = NnApiDelegate()
                    options.addDelegate(nnApiDelegate)
                    Log.d(TAG, "Configuring NNAPI (NPU)")
                } else {
                    Log.e(TAG, "NNAPI requires Android O+. Falling back to CPU.")
                    options.setUseXNNPACK(true)
                }
            }
        }

        // Load the model file into a MappedByteBuffer for efficiency
        val modelBuffer = loadModelFile(modelPath)
        interpreter = Interpreter(modelBuffer, options)
    }

    /**
     * Performs inference on the provided input buffer.
     */
    fun runInference(inputData: ByteBuffer): FloatArray {
        val currentInterpreter = interpreter ?: throw IllegalStateException("Interpreter not initialized")
        
        // Example: Model expects [1, 224, 224, 3] and outputs [1, 1000]
        val outputBuffer = Array(1) { FloatArray(1000) }
        
        currentInterpreter.run(inputData, outputBuffer)
        
        return outputBuffer[0]
    }

    private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileInputStream = FileInputStream(modelPath)
        val fileChannel = fileInputStream.channel
        val startOffset: Long = 0
        val declaredLength: Long = fileChannel.size()
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun closeInterpreter() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
        interpreter = null
        gpuDelegate = null
        nnApiDelegate = null
        Log.d(TAG, "Native TFLite resources released.")
    }
}

/**
 * ViewModel to bridge the UI and the AI Engine.
 */
@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val modelManager: TFLiteModelManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(InferenceUiState())
    val uiState: StateFlow<InferenceUiState> = _uiState.asStateFlow()

    fun setAccelerationMode(mode: AccelerationMode) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.update { it.copy(isLoading = true) }
            try {
                // In a real app, the model path would come from assets or a downloaded file
                val modelPath = "/data/local/tmp/model.tflite" 
                modelManager.initializeInterpreter(mode, modelPath)
                _uiState.update { it.copy(
                    currentMode = mode, 
                    isLoading = false, 
                    status = "Ready using ${mode.name}" 
                )}
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, status = "Error: ${e.message}") }
            }
        }
    }

    fun runInference() {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.update { it.copy(isProcessing = true) }
            
            val startTime = System.currentTimeMillis()
            
            // Create a dummy input buffer (e.g., 224x224x3 float image)
            val inputBuffer = ByteBuffer.allocateDirect(1 * 224 * 224 * 3 * 4).apply {
                order(ByteOrder.nativeOrder())
                // Fill with dummy data...
            }

            try {
                val result = modelManager.runInference(inputBuffer)
                val endTime = System.currentTimeMillis()
                
                _uiState.update { it.copy(
                    isProcessing = false, 
                    inferenceTime = "${endTime - startTime}ms",
                    status = "Inference successful"
                )}
            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessing = false, status = "Inference failed") }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        modelManager.closeInterpreter()
    }
}

data class InferenceUiState(
    val currentMode: AccelerationMode = AccelerationMode.CPU_XNNPACK,
    val isLoading: Boolean = false,
    val isProcessing: Boolean = false,
    val inferenceTime: String = "0ms",
    val status: String = "Select a mode to begin"
)

/**
 * Compose UI for controlling the AI Engine.
 */
@AndroidEntryPoint
@Composable
fun InferenceScreen(viewModel: InferenceViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "TFLite Delegate Performance Lab", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(20.dp))
        
        Text(text = "Current Status: ${state.status}")
        Text(text = "Latency: ${state.inferenceTime}", style = MaterialTheme.typography.bodyLarge)
        
        Spacer(modifier = Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AccelerationMode.values().forEach { mode ->
                Button(
                    onClick = { viewModel.setAccelerationMode(mode) },
                    enabled = !state.isLoading
                ) {
                    Text(mode.name)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { viewModel.runInference() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !state.isProcessing && !state.isLoading
        ) {
            if (state.isProcessing) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Run Inference")
            }
        }
    }
}
