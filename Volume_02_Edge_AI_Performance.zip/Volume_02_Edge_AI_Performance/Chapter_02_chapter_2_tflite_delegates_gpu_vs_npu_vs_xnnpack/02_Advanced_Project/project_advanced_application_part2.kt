
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.orchestrator

import android.content.Context
import android.os.Build
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.FileInputStream
import java.nio.channels.FileChannel

/**
 * Sealed class representing the state of the AI Inference engine.
 * Implements MVI-style state management for the UI.
 */
sealed class InferenceState {
    object Idle : InferenceState()
    data class Processing(val hardware: String) : InferenceState()
    data class Success(val result: FloatArray, val latencyMs: Long, val hardware: String) : InferenceState()
    data class Error(val message: String) : InferenceState()
}

/**
 * Strategy for Hardware Acceleration.
 * Defines the hierarchy of delegates to attempt.
 */
enum class AccelerationStrategy {
    NPU_PREFERRED, // NNAPI -> GPU -> XNNPACK
    GPU_PREFERRED, // GPU -> NNAPI -> XNNPACK
    CPU_ONLY       // XNNPACK only
}

/**
 * The HardwareOrchestrator handles the complexity of TFLite Delegate initialization.
 * It ensures that the most efficient hardware is used based on the device's capabilities.
 */
@Singleton
class HardwareOrchestrator @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null
    private val TAG = "HardwareOrchestrator"

    /**
     * Initializes the TFLite interpreter with the best available delegate.
     * Implements a fallback mechanism to ensure stability.
     */
    fun initializeInterpreter(modelPath: String, strategy: AccelerationStrategy): String {
        val options = Interpreter.Options()
        var usedHardware = "CPU (XNNPACK)"

        try {
            when (strategy) {
                AccelerationStrategy.NPU_PREFERRED -> {
                    if (tryNnApi(options)) {
                        usedHardware = "NPU (NNAPI)"
                    } else if (tryGpu(options)) {
                        usedHardware = "GPU"
                    }
                }
                AccelerationStrategy.GPU_PREFERRED -> {
                    if (tryGpu(options)) {
                        usedHardware = "GPU"
                    } else if (tryNnApi(options)) {
                        usedHardware = "NPU (NNAPI)"
                    }
                }
                AccelerationStrategy.CPU_ONLY -> {
                    options.setUseXNNPACK(true)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Delegate initialization failed, falling back to CPU", e)
            options.setUseXNNPACK(true)
            usedHardware = "CPU (Fallback)"
        }

        interpreter = Interpreter(loadModelFile(modelPath), options)
        return usedHardware
    }

    private fun tryNnApi(options: Interpreter.Options): Boolean {
        return try {
            // NNAPI is available from Android 8.1 (API 27)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                val nnApiDelegate = NnApiDelegate()
                options.addDelegate(nnApiDelegate)
                currentDelegate = nnApiDelegate
                true
            } else false
        } catch (e: Exception) {
            Log.w(TAG, "NNAPI not supported on this device: ${e.message}")
            false
        }
    }

    private fun tryGpu(options: Interpreter.Options): Boolean {
        return try {
            val gpuDelegate = GpuDelegate()
            options.addDelegate(gpuDelegate)
            currentDelegate = gpuDelegate
            true
        } catch (e: Exception) {
            Log.w(TAG, "GPU Delegate failed: ${e.message}")
            false
        }
    }

    private fun loadModelFile(modelPath: String): ByteBuffer {
        val fileInputStream = FileInputStream(modelPath)
        val fileChannel = fileInputStream.channel
        val startOffset = 0L
        val declaredLength = fileChannel.size()
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun runInference(input: ByteBuffer): FloatArray {
        val output = Array(1) { FloatArray(1000) } // Assuming ImageNet 1000 classes
        interpreter?.run(input, output) ?: throw IllegalStateException("Interpreter not initialized")
        return output[0]
    }

    fun close() {
        interpreter?.close()
        (currentDelegate as? GpuDelegate)?.close()
        (currentDelegate as? NnApiDelegate)?.close()
        interpreter = null
    }
}

/**
 * Repository layer to abstract the data flow between the hardware orchestrator and the ViewModel.
 */
@Singleton
class InferenceRepository @Inject constructor(
    private val orchestrator: HardwareOrchestrator
) {
    suspend fun performInference(
        modelPath: String, 
        inputData: ByteBuffer, 
        strategy: AccelerationStrategy
    ): Pair<FloatArray, String> = withContext(Dispatchers.Default) {
        val hardwareUsed = orchestrator.initializeInterpreter(modelPath, strategy)
        val startTime = System.currentTimeMillis()
        val results = orchestrator.runInference(inputData)
        val latency = System.currentTimeMillis() - startTime
        
        // In a real scenario, we would return the latency as well
        results to hardwareUsed
    }
}

/**
 * ViewModel implementing the MVI pattern to handle the AI lifecycle.
 */
@HiltViewModel
class AIViewModel @Inject constructor(
    private val repository: InferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<InferenceState>(InferenceState.Idle)
    val uiState: StateFlow<InferenceState> = _uiState.asStateFlow()

    fun analyzeImage(modelPath: String, inputBuffer: ByteBuffer) {
        viewModelScope.launch {
            _uiState.value = InferenceState.Processing("Detecting optimal hardware...")
            
            try {
                // We use NPU_PREFERRED for maximum energy efficiency on supported devices
                val (result, hardware) = repository.performInference(
                    modelPath, 
                    inputBuffer, 
                    AccelerationStrategy.NPU_PREFERRED
                )
                
                _uiState.value = InferenceState.Success(
                    result = result, 
                    latencyMs = 0L, // Simplified for example
                    hardware = hardware
                )
            } catch (e: Exception) {
                _uiState.value = InferenceState.Error(e.localizedMessage ?: "Unknown AI Error")
            }
        }
    }
}

/**
 * Hilt Module for providing dependencies.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideContext(app: android.app.Application): Context = app.applicationContext
}
