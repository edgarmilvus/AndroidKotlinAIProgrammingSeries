
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.Serializable
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Configuration for the AI Engine.
 * Using kotlinx.serialization to allow dynamic updates from a remote config.
 */
@Serializable
data class AIConfig(
    val useGpu: Boolean = true,
    val useNpu: Boolean = true,
    val xnnpackThreads: Int = 4,
    val precision: Precision = Precision.FP16
)

enum class Precision { FP32, FP16, INT8 }

/**
 * Interface for the AI Provider, abstracting whether we use 
 * local TFLite or the system-level AICore.
 */
interface AIProvider {
    fun predict(input: FloatArray): Flow<FloatArray>
}

/**
 * The TFLite implementation of the AIProvider.
 * This class manages the lifecycle of the Interpreter and its Delegates.
 */
@Singleton
class TFLiteAIProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val config: AIConfig
) : AIProvider {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // 1. XNNPACK is enabled by default in newer TFLite versions,
            // but we can explicitly configure thread counts.
            setNumThreads(config.xnnpackThreads)

            // 2. GPU Delegation Logic
            if (config.useGpu) {
                try {
                    // Just like CameraX abstracts the camera, 
                    // the GpuDelegate abstracts OpenCL/Vulkan.
                    gpuDelegate = GpuDelegate().apply {
                        // FP16 allows for faster execution on GPUs with 
                        // negligible loss in accuracy.
                        setPrecisionLossAllowed(config.precision == Precision.FP16)
                    }
                    addDelegate(gpuDelegate)
                } catch (e: Exception) {
                    // Fallback to CPU if GPU initialization fails
                    // This is similar to how Room handles migration failures
                }
            }
            
            // Note: NPU delegation usually happens via the NNAPI delegate
            // which is handled internally by TFLite on Android.
        }

        // Load the model from the assets folder
        val modelBuffer = context.assets.open("model.tflite").readBytes()
        interpreter = Interpreter(modelBuffer, options)
    }

    override fun predict(input: FloatArray): Flow<FloatArray> = flow {
        // Perform inference on the Default dispatcher (CPU/GPU bound)
        val output = FloatArray(10) // Example output size
        
        // Sync block to ensure thread-safe access to the interpreter
        synchronized(this@TFLiteAIProvider) {
            interpreter?.run(input, output)
        }
        
        emit(output)
    }.flowOn(Dispatchers.Default)

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
    }
}

/**
 * Hilt Module to provide the AIProvider based on device capabilities.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    
    @Provides
    @Singleton
    fun provideAIConfig(): AIConfig {
        // In a real app, this could be loaded from a JSON file or Firebase Remote Config
        return AIConfig(useGpu = true, useNpu = true)
    }

    @Provides
    @Singleton
    fun provideAIProvider(
        @ApplicationContext context: Context,
        config: AIConfig
    ): AIProvider {
        return TFLiteAIProvider(context, config)
    }
}
