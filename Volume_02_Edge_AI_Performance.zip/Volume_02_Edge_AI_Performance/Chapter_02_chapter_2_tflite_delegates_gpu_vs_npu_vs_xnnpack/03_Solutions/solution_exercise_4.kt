
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.content.BatteryManager
import android.os.SystemClock
import java.io.File
import kotlin.math.pow

data class BenchmarkResult(
    val delegateName: String,
    val meanLatency: Double,
    val p99Latency: Double,
    val avgCurrentDrain: Float
)

class NPUBenchmarkingSuite(private val context: Context) {
    
    fun runSuite(
        configs: List<Pair<String, Interpreter>> 
    ): List<BenchmarkResult> {
        val results = mutableListOf<BenchmarkResult>()

        configs.forEach { (name, interpreter) ->
            val latencies = mutableListOf<Long>()
            
            // 1. Warm-up phase (Discard first 10)
            repeat(10) { 
                interpreter.run(dummyInput(), dummyOutput()) 
            }

            // 2. Measurement phase
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            var totalCurrent = 0f
            var currentSamples = 0

            repeat(100) {
                val start = System.nanoTime()
                interpreter.run(dummyInput(), dummyOutput())
                latencies.add((System.nanoTime() - start) / 1_000_000)
                
                // Track power (Current in microamperes)
                totalCurrent += batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toFloat()
                currentSamples++
            }

            results.add(BenchmarkResult(
                delegateName = name,
                meanLatency = latencies.average(),
                p99Latency = latencies.sorted()[(latencies.size * 0.99).toInt()].toDouble(),
                avgCurrentDrain = totalCurrent / currentSamples
            ))
        }
        return results
    }

    fun exportToCSV(results: List<BenchmarkResult>) {
        val csvFile = File(context.externalCacheDir, "benchmark_results.csv")
        csvFile.printWriter().use { out ->
            out.println("Delegate,Mean_ms,P99_ms,AvgCurrent_uA")
            results.forEach { 
                out.println("${it.delegateName},${it.meanLatency},${it.p99Latency},${it.avgCurrentDrain}") 
            }
        }
    }

    private fun dummyInput() = ByteBuffer.allocateDirect(224 * 224 * 3 * 4)
    private fun dummyOutput() = ByteBuffer.allocateDirect(1000 * 4)
}
