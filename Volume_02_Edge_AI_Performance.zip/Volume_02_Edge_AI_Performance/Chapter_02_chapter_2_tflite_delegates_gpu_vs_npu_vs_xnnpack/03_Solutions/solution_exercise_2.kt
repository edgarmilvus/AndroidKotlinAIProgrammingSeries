
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.os.Build
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DelegateOrchestrator @Inject constructor() {
    private val TAG = "DelegateOrchestrator"

    fun getBestOptions(): Interpreter.Options {
        val options = Interpreter.Options()

        // 1. Attempt NNAPI (NPU) - Only viable on API 29+ for stability
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Log.i(TAG, "Attempting NNAPI initialization...")
                val nnApiDelegate = NnApiDelegate()
                options.addDelegate(nnApiDelegate)
                Log.i(TAG, "NNAPI successfully initialized.")
                return options
            } catch (e: Exception) {
                Log.e(TAG, "NNAPI failed: ${e.message}. Falling back to GPU.")
            }
        }

        // 2. Attempt GPU
        try {
            Log.i(TAG, "Attempting GPU initialization...")
            val gpuDelegate = GpuDelegate()
            options.addDelegate(gpuDelegate)
            Log.i(TAG, "GPU successfully initialized.")
            return options
        } catch (e: Exception) {
            Log.e(TAG, "GPU failed: ${e.message}. Falling back to XNNPACK.")
        }

        // 3. Fallback to XNNPACK (CPU)
        Log.i(TAG, "Using XNNPACK (CPU) as final fallback.")
        options.setNumThreads(Runtime.getRuntime().availableProcessors())
        return options
    }
}

// Hilt Module Integration
// @Provides
// fun provideInterpreter(model: MappedByteBuffer, orchestrator: DelegateOrchestrator): Interpreter {
//     return Interpreter(model, orchestrator.getBestOptions())
// }
