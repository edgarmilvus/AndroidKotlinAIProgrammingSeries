
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer

class HybridInferenceEngine(
    private val stage1Interpreter: Interpreter, // CPU (Custom Ops)
    private val stage2Interpreter: Interpreter, // NPU (Backbone)
    private val stage3Interpreter: Interpreter  // CPU (Head)
) {
    // Channels for pipelining (Capacity 1 to prevent memory bloat)
    private val channel1To2 = Channel<ByteBuffer>(1)
    private val channel2To3 = Channel<ByteBuffer>(1)
    private val finalOutput = Channel<ByteBuffer>(1)

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun startPipeline() {
        // Stage 1: Preprocessing (CPU)
        scope.launch {
            for (input in inputSource()) {
                val output = ByteBuffer.allocateDirect(stage1Interpreter.getOutputTensor(0).shape()[0] * 4)
                stage1Interpreter.run(input, output)
                channel1To2.send(output)
            }
        }

        // Stage 2: Feature Extraction (NPU)
        scope.launch {
            for (input in channel1To2) {
                val output = ByteBuffer.allocateDirect(stage2Interpreter.getOutputTensor(0).shape()[0] * 4)
                stage2Interpreter.run(input, output)
                channel2To3.send(output)
            }
        }

        // Stage 3: Classification (CPU)
        scope.launch {
            for (input in channel2To3) {
                val output = ByteBuffer.allocateDirect(stage3Interpreter.getOutputTensor(0).shape()[0] * 4)
                stage3Interpreter.run(input, output)
                finalOutput.send(output)
            }
        }
    }

    suspend fun getNextResult(): ByteBuffer = finalOutput.receive()

    private fun inputSource() = java.util.stream.Stream.generate { 
        ByteBuffer.allocateDirect(224 * 224 * 3 * 4) 
    }.asIterable() // Simplified source

    fun shutdown() {
        scope.cancel()
        stage1Interpreter.close()
        stage2Interpreter.close()
        stage3Interpreter.close()
    }
}

// Helper to convert Stream to Iterable
private fun <T> java.util.stream.Stream<T>.asIterable() = object : Iterable<T> {
    override fun iterator() = object : MutableIterator<T> {
        val it = this@asIterable.iterator()
        override fun hasNext() = it.hasNext()
        override fun next() = it.next()
    }
}
