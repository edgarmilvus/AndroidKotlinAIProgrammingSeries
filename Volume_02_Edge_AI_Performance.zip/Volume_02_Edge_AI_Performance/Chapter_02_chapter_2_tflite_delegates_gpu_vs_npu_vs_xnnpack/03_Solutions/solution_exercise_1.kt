
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.nio.ByteBuffer
import java.nio.MappedByteBuffer
import javax.inject.Inject
import javax.inject.Singleton

sealed class DelegateType {
    object Cpu : DelegateType()
    object Gpu : DelegateType()
}

@Singleton
class TFLiteModelManager @Inject constructor(private val context: Context) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    fun buildInterpreter(type: DelegateType, modelBuffer: MappedByteBuffer): Interpreter {
        // Crucial: Prevent native memory leaks by closing previous instances
        close()

        val options = Interpreter.Options().apply {
            if (type is DelegateType.Gpu) {
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
            } else {
                // XNNPACK is enabled by default in recent TFLite versions
                setNumThreads(Runtime.getRuntime().availableProcessors())
            }
        }
        
        return Interpreter(modelBuffer, options).also { interpreter = it }
    }

    fun runInference(input: ByteBuffer, output: ByteBuffer): Long {
        val startTime = System.nanoTime()
        interpreter?.run(input, output)
        return (System.nanoTime() - startTime) / 1_000_000 // Convert to ms
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        interpreter = null
        gpuDelegate = null
    }
}

@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val modelManager: TFLiteModelManager,
    private val modelBuffer: MappedByteBuffer // Provided via Hilt Module
) : ViewModel() {

    private val _latency = MutableStateFlow(0L)
    val latency = _latency.asStateFlow()

    private val _selectedDelegate = MutableStateFlow<DelegateType>(DelegateType.Cpu)
    val selectedDelegate = _selectedDelegate.asStateFlow()

    init {
        // Rebuild interpreter whenever delegate changes
        viewModelScope.launch {
            selectedDelegate.collect { type ->
                withContext(Dispatchers.Default) {
                    modelManager.buildInterpreter(type, modelBuffer)
                }
            }
        }
    }

    fun toggleDelegate(isGpu: Boolean) {
        _selectedDelegate.value = if (isGpu) DelegateType.Gpu else DelegateType.Cpu
    }

    fun performInference(input: ByteBuffer, output: ByteBuffer) {
        viewModelScope.launch(Dispatchers.Default) {
            val time = modelManager.runInference(input, output)
            _latency.value = time
        }
    }

    override fun onCleared() {
        modelManager.close()
        super.onCleared()
    }
}
