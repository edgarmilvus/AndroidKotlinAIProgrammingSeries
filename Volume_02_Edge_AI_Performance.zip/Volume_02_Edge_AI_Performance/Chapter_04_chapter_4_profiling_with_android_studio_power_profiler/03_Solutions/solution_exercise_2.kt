
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.Interpreter

class DelegateViewModel : ViewModel() {
    var isGpuEnabled by mutableStateOf(false)
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    fun setupInterpreter(context: Context) {
        val options = Interpreter.Options()
        if (isGpuEnabled) {
            // Initialize GPU Delegate
            gpuDelegate = GpuDelegate()
            options.addDelegate(gpuDelegate)
        }
        
        val modelBuffer = context.assets.open("mobilenet_v2.tflite").readBytes().let {
            ByteBuffer.allocateDirect(it.size).apply {
                order(ByteOrder.nativeOrder())
                put(it)
                rewind()
            }
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    suspend fun runBenchmark(bitmap: Bitmap) = withContext(Dispatchers.Default) {
        val input = preprocessImage(bitmap)
        val output = Array(1) { FloatArray(1001) }
        
        // Warm-up run to avoid shader compilation spikes in profiling
        interpreter?.run(input, output)

        val startTime = System.currentTimeMillis()
        repeat(50) {
            interpreter?.run(input, output)
        }
        val endTime = System.currentTimeMillis()
        
        "Completed 50 runs in ${endTime - startTime}ms"
    }

    override fun onCleared() {
        interpreter?.close()
        gpuDelegate?.close() // Critical: GPU delegates must be manually closed
        super.onCleared()
    }
}
