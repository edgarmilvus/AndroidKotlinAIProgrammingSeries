
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class FallDetectionViewModel : ViewModel() {
    private val _isAiActive = MutableStateFlow(false)
    val isAiActive = _isAiActive.asStateFlow()

    // Heuristic threshold (e.g., 2g)
    private val TRIGGER_THRESHOLD = 2.0f 

    fun processSensorData(accelX: Float, accelY: Float, accelZ: Float) {
        viewModelScope.launch(Dispatchers.Default) {
            val magnitude = kotlin.math.sqrt(accelX * accelX + accelY * accelY + accelZ * accelZ)
            
            if (magnitude > TRIGGER_THRESHOLD) {
                // GATE OPEN: Trigger the high-power AI model
                _isAiActive.value = true
                runFallDetectionModel()
            } else {
                // GATE CLOSED: Stay in low-power polling mode
                _isAiActive.value = false
            }
        }
    }

    private suspend fun runFallDetectionModel() {
        // Simulate heavy TFLite inference
        withContext(Dispatchers.Default) {
            // interpreter.run(...)
            kotlinx.coroutines.delay(50) // Simulate 50ms inference time
        }
    }
}
