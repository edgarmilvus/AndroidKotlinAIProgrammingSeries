
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

class QuantizationBenchmarkViewModel : ViewModel() {
    
    suspend fun compareModels(context: Context, bitmap: Bitmap) = withContext(Dispatchers.Default) {
        val fp32Energy = measureEnergy {
            runBenchmarkLoop(context, "model_fp32.tflite", bitmap)
        }
        
        val int8Energy = measureEnergy {
            runBenchmarkLoop(context, "model_int8.tflite", bitmap)
        }
        
        "FP32: $fp32Energy, INT8: $int8Energy"
    }

    private fun runBenchmarkLoop(context: Context, modelPath: String, bitmap: Bitmap) {
        val interpreter = loadModel(context, modelPath)
        val input = preprocessImage(bitmap) // Pre-processed once outside the loop
        val output = Array(1) { FloatArray(1001) }

        repeat(100) {
            interpreter.run(input, output)
        }
        interpreter.close()
    }

    private fun loadModel(context: Context, path: String): Interpreter {
        val buffer = context.assets.open(path).readBytes().let {
            ByteBuffer.allocateDirect(it.size).apply {
                order(ByteOrder.nativeOrder())
                put(it)
                rewind()
            }
        }
        return Interpreter(buffer)
    }
}
