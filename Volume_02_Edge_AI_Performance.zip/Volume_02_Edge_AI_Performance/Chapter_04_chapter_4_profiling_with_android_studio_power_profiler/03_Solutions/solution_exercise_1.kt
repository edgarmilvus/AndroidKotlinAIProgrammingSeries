
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

class InferenceViewModel : ViewModel() {
    var classificationResult by mutableStateOf("No result yet")
    private var interpreter: Interpreter? = null

    fun initModel(context: Context) {
        // Load model from assets
        val modelBuffer = context.assets.open("mobilenet_v2.tflite").readBytes().let {
            ByteBuffer.allocateDirect(it.size).apply {
                order(ByteOrder.nativeOrder())
                put(it)
                rewind()
            }
        }
        // Default CPU options
        interpreter = Interpreter(modelBuffer)
    }

    fun runInference(bitmap: Bitmap) {
        viewModelScope.launch {
            // Shift to Default dispatcher for CPU-intensive AI work
            val result = withContext(Dispatchers.Default) {
                val input = preprocessImage(bitmap)
                val output = Array(1) { FloatArray(1001) }
                
                // The "Power Spike" occurs exactly here
                interpreter?.run(input, output)
                
                "Top Class: ${output[0].indices.maxByOrNull { output[0][it] }}"
            }
            classificationResult = result
        }
    }

    private fun preprocessImage(bitmap: Bitmap): ByteBuffer {
        // Simplified preprocessing: resize to 224x224 and normalize
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val buffer = ByteBuffer.allocateDirect(1 * 224 * 224 * 3 * 4)
        buffer.order(ByteOrder.nativeOrder())
        // ... (Pixel normalization logic omitted for brevity)
        return buffer
    }

    override fun onCleared() {
        interpreter?.close()
        super.onCleared()
    }
}

@Composable
fun BaselineScreen(viewModel: InferenceViewModel, bitmap: Bitmap?) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "AI Power Baseline Test", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(onClick = { bitmap?.let { viewModel.runInference(it) } }) {
            Text("Run Single Inference")
        }
        
        Text(text = viewModel.classificationResult, modifier = Modifier.padding(top = 16.dp))
    }
}
