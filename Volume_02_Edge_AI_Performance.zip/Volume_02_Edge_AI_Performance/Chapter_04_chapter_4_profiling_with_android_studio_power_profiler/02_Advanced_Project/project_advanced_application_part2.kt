
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.power

import android.content.Context
import android.os.PowerManager
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.InstallIn
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.components.SingletonComponent
import dagger.hilt.providedIn
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Represents the current hardware acceleration strategy.
 */
sealed class InferenceStrategy {
    object NpuOptimized : InferenceStrategy() // Lowest power, INT8
    object GpuAccelerated : InferenceStrategy() // High performance, FP16
    object CpuFallback : InferenceStrategy() // Safe mode, pruned model
}

/**
 * State for the MVI pattern.
 */
data class InferenceUiState(
    val currentStrategy: InferenceStrategy = InferenceStrategy.NpuOptimized,
    val thermalStatus: Int = PowerManager.THERMAL_STATUS_NONE,
    val lastInferenceTimeMs: Long = 0,
    val isProcessing: Boolean = false
)

/**
 * Repository responsible for managing the TFLite Interpreter and Delegate switching.
 * This is the "Hardware-Aware" core of the application.
 */
@Singleton
class PowerAwareInferenceRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    // Use a Mutex to ensure thread-safe interpreter reconfiguration
    private val reconfigurationMutex = kotlinx.coroutines.sync.Mutex()

    /**
     * Dynamically configures the TFLite interpreter based on the provided strategy.
     * This method is called when the Power Profiler indicates thermal pressure.
     */
    suspend fun updateStrategy(strategy: InferenceStrategy) = reconfigurationMutex.withLock {
        withContext(Dispatchers.Default) {
            Log.d("AI_POWER", "Switching to strategy: ${strategy::class.java.simpleName}")
            
            // 1. Clean up existing resources to prevent memory leaks and power drain
            currentDelegate?.let {
                if (it is GpuDelegate) it.close()
                if (it is NnApiDelegate) it.close()
            }
            interpreter?.close()

            // 2. Initialize new delegate based on strategy
            val options = Interpreter.Options().apply {
                when (strategy) {
                    is InferenceStrategy.NpuOptimized -> {
                        // NPU via NNAPI: Best power efficiency
                        currentDelegate = NnApiDelegate()
                        addDelegate(currentDelegate as NnApiDelegate)
                    }
                    is InferenceStrategy.GpuAccelerated -> {
                        // GPU: High throughput, higher power
                        currentDelegate = GpuDelegate()
                        addDelegate(currentDelegate as GpuDelegate)
                    }
                    is InferenceStrategy.CpuFallback -> {
                        // CPU: XNNPACK is enabled by default in newer TFLite versions
                        setNumThreads(4)
                        currentDelegate = null
                    }
                }
            }

            // 3. Load the model (In production, use a memory-mapped file)
            val modelBuffer = loadModelFile("model_quantized.tflite")
            interpreter = Interpreter(modelBuffer, options)
        }
    }

    fun runInference(input: ByteBuffer): FloatArray {
        val output = Array(1) { FloatArray(10) } // Assuming 10 classes
        interpreter?.run(input, output)
        return output[0]
    }

    private fun loadModelFile(modelName: String): ByteBuffer {
        // Standard boilerplate to load .tflite from assets
        return context.assets.open(modelName).use { it.readBytes().let { bytes ->
            ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
                rewind()
            }
        }}
    }

    fun getThermalStatus(): Int = powerManager.currentThermalStatus
}

/**
 * ViewModel implementing MVI to orchestrate power-aware AI.
 */
@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val repository: PowerAwareInferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(InferenceUiState())
    val uiState: StateFlow<InferenceUiState> = _uiState.asStateFlow()

    init {
        monitorThermalState()
    }

    private fun monitorThermalState() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                val status = repository.getThermalStatus()
                val strategy = when (status) {
                    PowerManager.THERMAL_STATUS_NONE, 
                    PowerManager.THERMAL_STATUS_LIGHT -> InferenceStrategy.NpuOptimized
                    PowerManager.THERMAL_STATUS_MODERATE, 
                    PowerManager.THERMAL_STATUS_STRONG -> InferenceStrategy.GpuAccelerated
                    else -> InferenceStrategy.CpuFallback
                }

                if (strategy != _uiState.value.currentStrategy) {
                    _uiState.update { it.copy(thermalStatus = status, currentStrategy = strategy) }
                    repository.updateStrategy(strategy)
                }
                delay(5000) // Poll thermal state every 5 seconds
            }
        }
    }

    fun processFrame(buffer: ByteBuffer) {
        viewModelScope.launch(Dispatchers.Default) {
            val startTime = System.currentTimeMillis()
            _uiState.update { it.copy(isProcessing = true) }
            
            try {
                val results = repository.runInference(buffer)
                // Handle results...
            } finally {
                val duration = System.currentTimeMillis() - startTime
                _uiState.update { it.copy(isProcessing = false, lastInferenceTimeMs = duration) }
            }
        }
    }
}

@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideRepository(@ApplicationContext context: Context) = PowerAwareInferenceRepository(context)
}
