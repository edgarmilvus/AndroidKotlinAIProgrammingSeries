
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.data

import android.content.Context
import android.os.Build
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * InferenceRepository manages the TFLite model lifecycle.
 * It is designed to be swapped between CPU and GPU to observe 
 * power consumption differences in the Android Studio Power Profiler.
 */
@Singleton
class InferenceRepository @Inject constructor(private val context: Context) {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    // Model configuration
    private val modelPath = "mobilenet_v2.tflite" 
    private val inputSize = 224 // Standard MobileNet input size
    private val numChannels = 3

    /**
     * Initializes the interpreter. 
     * @param useGpu If true, utilizes the GPU delegate; otherwise, uses CPU.
     */
    fun initializeModel(useGpu: Boolean) {
        // Close existing interpreter to free memory and power
        closeInterpreter()

        val options = Interpreter.Options().apply {
            if (useGpu) {
                // The GPU delegate offloads tensor math from CPU to GPU
                // This should show a shift in the Power Profiler from CPU to GPU
                gpuDelegate = GpuDelegate()
                addDelegate(gpuDelegate)
            } else {
                // CPU execution: High power consumption on CPU cores
                setNumThreads(4) 
            }
        }

        interpreter = Interpreter(loadModelFile(), options)
    }

    /**
     * Performs inference on the provided image buffer.
     * Uses Direct ByteBuffer to avoid expensive JNI memory copies.
     */
    fun runInference(inputBuffer: ByteBuffer): FloatArray {
        val outputBuffer = Array(1) { FloatArray(1001) } // Example: 1001 ImageNet classes
        
        // The actual blocking call where the hardware acceleration happens
        interpreter?.run(inputBuffer, outputBuffer) 
        
        return outputBuffer[0]
    }

    private fun loadModelFile(): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        val startOffset = fileChannel.position()
        val declaredLength = fileChannel.size()
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun closeInterpreter() {
        interpreter?.close()
        gpuDelegate?.close()
        interpreter = null
        gpuDelegate = null
    }
}
