
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edgeai.performance.data.InferenceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import javax.inject.Inject

@HiltViewModel
class AIViewModel @Inject constructor(
    private val repository: InferenceRepository
) : ViewModel() {

    private val _inferenceResult = MutableStateFlow("Ready")
    val inferenceResult: StateFlow<String> = _inferenceResult.asStateFlow()

    private val _isGpuEnabled = MutableStateFlow(false)
    val isGpuEnabled: StateFlow<Boolean> = _isGpuEnabled.asStateFlow()

    fun toggleHardwareAcceleration() {
        _isGpuEnabled.value = !_isGpuEnabled.value
        repository.initializeModel(useGpu = _isGpuEnabled.value)
    }

    /**
     * Process an image frame.
     * In a real app, this would be called by a CameraX Analyzer.
     */
    fun processFrame(bitmapBuffer: ByteBuffer) {
        viewModelScope.launch {
            // CRITICAL: Move execution to Dispatchers.Default.
            // Edge AI inference is CPU/GPU intensive and MUST NOT run on the Main thread.
            val result = withContext(Dispatchers.Default) {
                try {
                    val probabilities = repository.runInference(bitmapBuffer)
                    // Find the index of the highest probability
                    val maxIndex = probabilities.indices.maxByOrNull { probabilities[it] } ?: -1
                    "Class ID: $maxIndex"
                } catch (e: Exception) {
                    "Error: ${e.localizedMessage}"
                }
            }
            _inferenceResult.value = result
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.closeInterpreter()
    }
}
