
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.inspection

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppComponent
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Hardware Acceleration Strategy
 * Determines the best delegate based on the quantized model's requirements
 * and the device's hardware capabilities.
 */
enum class AccelerationMode {
    NPU_NNAPI, GPU_DELEGATE, CPU_FALLBACK
}

/**
 * Data class representing the inference result.
 */
data class InspectionResult(
    val label: String,
    val confidence: Float,
    val latencyMs: Long,
    val accelerator: AccelerationMode
)

/**
 * Repository handling the heavy lifting of TFLite model management.
 * Implements a Singleton pattern via Hilt to avoid reloading the model into memory.
 */
@Singleton
class ModelInferenceRepository @Inject constructor(
    private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null
    
    private val modelPath = "anomaly_quantized_int8.tflite"

    // Configuration for the quantized model
    private val inputShape = intArrayOf(1, 224, 224, 3)
    private val bytesPerChannel = 1 // INT8 quantization

    init {
        initializeInterpreter()
    }

    private fun initializeInterpreter() {
        val options = Interpreter.Options().apply {
            // Orchestration Logic: Prioritize NPU for INT8 Quantized Models
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    nnApiDelegate = NnApiDelegate()
                    this.addDelegate(nnApiDelegate)
                } catch (e: Exception) {
                    // Fallback to GPU if NNAPI fails
                    gpuDelegate = GpuDelegate()
                    this.addDelegate(gpuDelegate)
                }
            } else {
                gpuDelegate = GpuDelegate()
                this.addDelegate(gpuDelegate)
            }
            this.setNumThreads(4)
        }
        
        // Load model from assets
        val modelBuffer = context.assets.open(modelPath).use { it.readBytes() }
        val byteBuffer = ByteBuffer.allocateDirect(modelBuffer.size).apply {
            order(ByteOrder.nativeOrder())
            put(modelBuffer)
        }
        interpreter = Interpreter(byteBuffer, options)
    }

    /**
     * Performs inference using structured concurrency.
     * Uses Dispatchers.Default to ensure the UI thread is never blocked.
     */
    suspend fun runInference(bitmap: Bitmap): InspectionResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        
        // 1. Pre-processing: Quantize the input
        // In a real scenario, we map Float32 [0,1] to Int8 [-128, 127]
        val inputBuffer = preprocess(bitmap)
        
        // 2. Output Buffer allocation
        val outputBuffer = ByteBuffer.allocateDirect(1 * 5 * bytesPerChannel).apply {
            order(ByteOrder.nativeOrder())
        }

        // 3. Execution
        interpreter?.run(inputBuffer, outputBuffer)

        val latency = System.currentTimeMillis() - startTime
        
        // 4. Post-processing: De-quantize the output
        val result = postprocess(outputBuffer)
        
        InspectionResult(
            label = result.first,
            confidence = result.second,
            latencyMs = latency,
            accelerator = determineCurrentAccelerator()
        )
    }

    private fun preprocess(bitmap: Bitmap): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(inputShape[0] * inputShape[1] * inputShape[2] * inputShape[3] * bytesPerChannel)
        buffer.order(ByteOrder.nativeOrder())
        
        // Manual quantization loop: Float32 -> Int8
        // In production, use TFLite Support Library TensorImage for efficiency
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        
        for (pixel in pixels) {
            val r = ((pixel shr 16 and 0xFF) - 128).toByte()
            val g = ((pixel shr 8 and 0xFF) - 128).toByte()
            val b = ((pixel and 0xFF) - 128).toByte()
            buffer.put(r).put(g).put(b)
        }
        buffer.rewind()
        return buffer
    }

    private fun postprocess(buffer: ByteBuffer): Pair<String, Float> {
        buffer.rewind()
        val results = ByteArray(5)
        buffer.get(results)
        
        // Find index of max value (ArgMax)
        var maxIdx = 0
        var maxVal = -128.toByte()
        for (i in results.indices) {
            if (results[i] > maxVal) {
                maxVal = results[i]
                maxIdx = i
            }
        }
        
        // De-quantize confidence: (value - zero_point) / scale
        // Assuming scale = 0.01 and zero_point = -128 for this example
        val confidence = (maxVal.toInt() - (-128)) * 0.01f
        val labels = listOf("Normal", "Crack", "Dent", "Discoloration", "Unknown")
        
        return labels[maxIdx] to confidence
    }

    private fun determineCurrentAccelerator(): AccelerationMode {
        return when {
            nnApiDelegate != null -> AccelerationMode.NPU_NNAPI
            gpuDelegate != null -> AccelerationMode.GPU_DELEGATE
            else -> AccelerationMode.CPU_FALLBACK
        }
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}

/**
 * ViewModel implementing MVI pattern.
 * Manages the state of the AI inspection process.
 */
@HiltViewModel
class InspectionViewModel @Inject constructor(
    private val repository: ModelInferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(InspectionUiState())
    val uiState: StateFlow<InspectionUiState> = _uiState.asStateFlow()

    private val inferenceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun onFrameReceived(bitmap: Bitmap) {
        // Prevent overlapping inference calls to avoid memory pressure
        if (_uiState.value.isProcessing) return

        inferenceScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            
            try {
                val result = repository.runInference(bitmap)
                _uiState.update { it.copy(
                    lastResult = result,
                    isProcessing = false,
                    error = null
                )}
            } catch (e: Exception) {
                _uiState.update { it.copy(
                    isProcessing = false, 
                    error = "Inference Failed: ${e.localizedMessage}"
                )}
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
        inferenceScope.cancel()
    }
}

data class InspectionUiState(
    val lastResult: InspectionResult? = null,
    val isProcessing: Boolean = false,
    val error: String? = null
)

/**
 * Hilt Module for providing the Context and Repository.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideModelRepository(@BindsInstance context: Context): ModelInferenceRepository {
        return ModelInferenceRepository(context)
    }
}
