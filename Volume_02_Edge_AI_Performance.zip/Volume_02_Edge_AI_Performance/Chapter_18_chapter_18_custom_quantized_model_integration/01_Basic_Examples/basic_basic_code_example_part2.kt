
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.data

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository responsible for managing the TFLite Interpreter and hardware delegates.
 * It handles the loading of the quantized model and executes inference.
 */
@Singleton
class QuantizedModelRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null

    // Model constants - these must match the specific quantized model's requirements
    private val INPUT_SIZE = 224 
    private val PIXEL_SIZE = 3 // RGB
    private val NUM_CLASSES = 1000

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options().apply {
            // STRATEGY: Hardware Acceleration Selection
            // 1. Try NNAPI (NPU) for Android 9+
            // 2. Fallback to GPU
            // 3. Fallback to CPU (XNNPACK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                nnApiDelegate = NnApiDelegate()
                this.addDelegate(nnApiDelegate)
            } else {
                gpuDelegate = GpuDelegate()
                this.addDelegate(gpuDelegate)
            }
            
            // Optimize for latency (1 thread per core for quantized models)
            setNumThreads(Runtime.getRuntime().availableProcessors())
        }

        try {
            interpreter = Interpreter(loadModelFile(), options)
        } catch (e: Exception) {
            e.printStackTrace()
            // In production, handle model loading failure via a Result wrapper
        }
    }

    private fun loadModelFile(): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = context.assets.openFd("quantized_model.tflite")
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    /**
     * Performs inference on a quantized input.
     * @param inputData A ByteBuffer containing the quantized (INT8) image data.
     * @return The classification result as a FloatArray.
     */
    suspend fun classify(inputData: ByteBuffer): FloatArray = withContext(Dispatchers.Default) {
        val outputBuffer = Array(1) { FloatArray(NUM_CLASSES) }
        
        // Ensure the input buffer is in the correct byte order for native TFLite
        inputData.order(ByteOrder.nativeOrder())

        // Execution: This is a blocking call to the native C++ TFLite runtime
        interpreter?.run(inputData, outputBuffer) 
            ?: throw IllegalStateException("Interpreter not initialized")

        return@withContext outputBuffer[0]
    }

    /**
     * Crucial: Close delegates and interpreter to prevent native memory leaks.
     */
    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
    }
}
