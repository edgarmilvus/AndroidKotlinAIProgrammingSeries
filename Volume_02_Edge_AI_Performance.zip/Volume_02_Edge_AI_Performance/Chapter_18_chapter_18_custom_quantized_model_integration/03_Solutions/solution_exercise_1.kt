
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelManager @Inject constructor(@ApplicationContext private val context: Context) {
    fun loadModelFile(modelPath: String): ByteBuffer {
        return FileUtil.loadMappedFile(context, modelPath)
    }
}

class QuantizedModelWrapper(
    private val modelBuffer: ByteBuffer
) : AutoCloseable {
    private val interpreter = Interpreter(modelBuffer)

    suspend fun classify(inputPixels: FloatArray): FloatArray = withContext(Dispatchers.Default) {
        val inputTensor = interpreter.getInputTensor(0)
        val outputTensor = interpreter.getOutputTensor(0)

        // 1. Extract Quantization Parameters
        val inputParams = inputTensor.quantizationParams()
        val inputScale = inputParams.scale()
        val inputZeroPoint = inputParams.zeroPoint().toInt()

        val outputParams = outputTensor.quantizationParams()
        val outputScale = outputParams.scale()
        val outputZeroPoint = outputParams.zeroPoint().toInt()

        // 2. Quantize Input: RealValue -> QuantizedValue
        // Formula: QuantizedValue = (RealValue / Scale) + ZeroPoint
        val inputBuffer = ByteBuffer.allocateDirect(inputPixels.size).apply {
            order(ByteOrder.nativeOrder())
        }
        
        inputPixels.forEach { pixel ->
            val quantized = (pixel / inputScale).toInt() + inputZeroPoint
            inputBuffer.put(quantized.toByte())
        }
        inputBuffer.rewind()

        // 3. Inference
        val outputBuffer = ByteBuffer.allocateDirect(outputTensor.numElements()).apply {
            order(ByteOrder.nativeOrder())
        }
        interpreter.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()

        // 4. De-quantize Output: QuantizedValue -> RealValue
        // Formula: RealValue = (QuantizedValue - ZeroPoint) * Scale
        val results = FloatArray(outputTensor.numElements())
        for (i in results.indices) {
            val quantizedValue = outputBuffer.get().toInt()
            results[i] = (quantizedValue - outputZeroPoint) * outputScale
        }
        
        results
    }

    override fun close() {
        interpreter.close()
    }
}
