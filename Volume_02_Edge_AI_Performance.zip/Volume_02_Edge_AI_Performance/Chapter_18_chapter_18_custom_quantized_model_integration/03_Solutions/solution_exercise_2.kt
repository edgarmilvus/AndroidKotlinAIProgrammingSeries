
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.system.measureNanoTime

sealed class ModelConfig {
    object FP16 : ModelConfig()
    object INT8 : ModelConfig()
}

interface ModelRunner {
    fun runInference(input: FloatArray): FloatArray
    fun close()
}

data class BenchmarkResult(
    val latencyMs: Double,
    val confidence: Float,
    val modelType: String
)

class BenchmarkViewModel(
    private val fp16Runner: ModelRunner,
    private val int8Runner: ModelRunner
) : ViewModel() {

    private val _results = MutableStateFlow<BenchmarkResult?>(null)
    val results = _results.asStateFlow()

    private val _currentConfig = MutableStateFlow<ModelConfig>(ModelConfig.FP16)
    val currentConfig = _currentConfig.asStateFlow()

    fun switchModel(config: ModelConfig) {
        _currentConfig.value = config
    }

    fun executeBenchmark(testImage: FloatArray) {
        viewModelScope.launch {
            val runner = if (_currentConfig.value is ModelConfig.INT8) int8Runner else fp16Runner
            
            val output: FloatArray
            val nanoTime = measureNanoTime {
                output = runner.runInference(testImage)
            }

            _results.value = BenchmarkResult(
                latencyMs = nanoTime / 1_000_000.0,
                confidence = output.maxOrNull() ?: 0f,
                modelType = if (_currentConfig.value is ModelConfig.INT8) "INT8" else "FP16"
            )
        }
    }
}

@Composable
fun BenchmarkScreen(viewModel: BenchmarkViewModel) {
    val result by viewModel.results.collectAsState()
    val config by viewModel.currentConfig.collectAsState()

    // Use derivedStateOf to prevent unnecessary recompositions 
    // when only non-visual state changes
    val displayLatency = remember { 
        derivedStateOf { result?.let { "Latency: ${"%.2f".format(it.latencyMs)} ms" } ?: "No Data" } 
    }

    Column {
        Row {
            Button(onClick = { viewModel.switchModel(ModelConfig.FP16) }) { Text("FP16") }
            Button(onClick = { viewModel.switchModel(ModelConfig.INT8) }) { Text("INT8") }
        }
        Text(text = displayLatency.value)
        Text(text = "Confidence: ${result?.confidence ?: 0f}")
    }
}
