
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.os.Build
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.gpu.GpuDelegate
import java.nio.ByteBuffer

enum class AccelerationTier { NPU, GPU, CPU }

class DelegateOrchestrator(private val modelBuffer: ByteBuffer) {
    private var interpreter: Interpreter? = null
    var activeTier = AccelerationTier.CPU
        private set

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val options = Interpreter.Options()
        
        // Tier 1: NNAPI (NPU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                options.addDelegate(NnApiDelegate())
                interpreter = Interpreter(modelBuffer, options)
                activeTier = AccelerationTier.NPU
                return 
            } catch (e: Exception) {
                // Fallback to next tier
            }
        }

        // Tier 2: GPU Delegate
        try {
            options.addDelegate(GpuDelegate())
            interpreter = Interpreter(modelBuffer, options)
            activeTier = AccelerationTier.GPU
            return
        } catch (e: Exception) {
            // Fallback to next tier
        }

        // Tier 3: CPU (XNNPACK is enabled by default in newer TFLite versions)
        interpreter = Interpreter(modelBuffer, options)
        activeTier = AccelerationTier.CPU
    }

    suspend fun warmUp(dummyInput: ByteBuffer, dummyOutput: ByteBuffer) {
        withContext(Dispatchers.Default) {
            repeat(3) {
                interpreter?.run(dummyInput, dummyOutput)
            }
        }
    }

    fun runInference(input: ByteBuffer, output: ByteBuffer) {
        interpreter?.run(input, output)
    }

    fun close() {
        interpreter?.close()
    }
}
