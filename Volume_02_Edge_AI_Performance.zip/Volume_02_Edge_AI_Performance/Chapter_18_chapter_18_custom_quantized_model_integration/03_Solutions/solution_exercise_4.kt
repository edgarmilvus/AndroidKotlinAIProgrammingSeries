
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import org.json.JSONObject
import java.nio.ByteBuffer

data class QuantConfig(val scale: Float, val zeroPoint: Int)

class ManualDequantizer {
    fun loadConfigFromJson(jsonString: String): QuantConfig {
        val json = JSONObject(jsonString)
        return QuantConfig(
            scale = json.getDouble("scale").toFloat(),
            zeroPoint = json.getInt("zeroPoint")
        )
    }

    // Inline function to reduce overhead in high-frequency loops
    inline fun ByteArray.dequantize(config: QuantConfig): FloatArray {
        val result = FloatArray(this.size)
        for (i in this.indices) {
            // Convert signed Byte to Int, subtract ZeroPoint, multiply by Scale
            // Formula: RealValue = (QuantizedValue - ZeroPoint) * Scale
            result[i] = (this[i].toInt() - config.zeroPoint) * config.scale
        }
        return result
    }
}

// Usage Example
suspend fun processCustomModel(rawOutput: ByteBuffer, jsonConfig: String) {
    val dequantizer = ManualDequantizer()
    val config = dequantizer.loadConfigFromJson(jsonConfig)
    
    val bytes = ByteArray(rawOutput.remaining())
    rawOutput.get(bytes)
    
    val probabilities = bytes.dequantize(config)
    // probabilities is now a FloatArray ready for UI
}
