
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.app.ActivityManager
import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class NativeModelLoader(private val context: Context) {
    fun mapModelFile(fileName: String): ByteBuffer {
        val file = context.assets.open(fileName).use { input ->
            // Copy asset to internal storage to get a File descriptor for mmap
            val tempFile = java.io.File(context.cacheDir, fileName)
            tempFile.outputStream().use { output -> input.copyTo(output) }
            tempFile
        }

        return RandomAccessFile(file, "r").use { raf ->
            raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length())
        }
    }
}

class TensorBufferPool(private val bufferSize: Int, private val poolSize: Int) {
    private val pool = Array(poolSize) { 
        ByteBuffer.allocateDirect(bufferSize).apply { order(ByteOrder.nativeOrder()) } 
    }
    private var index = 0

    fun acquire(): ByteBuffer {
        val buffer = pool[index]
        buffer.clear()
        index = (index + 1) % poolSize
        return buffer
    }
}

class LargeModelManager(
    context: Context,
    private val modelName: String
) : androidx.lifecycle.DefaultLifecycleObserver {
    
    private var interpreter: Interpreter? = null
    private val bufferPool = TensorBufferPool(1024 * 100, 3) // Example size
    private val loader = NativeModelLoader(context)

    fun init() {
        val mappedBuffer = loader.mapModelFile(modelName)
        interpreter = Interpreter(mappedBuffer)
    }

    fun runInference(inputData: FloatArray): FloatArray {
        val inputBuffer = bufferPool.acquire()
        // Fill buffer...
        val outputBuffer = ByteBuffer.allocateDirect(100) 
        interpreter?.run(inputBuffer, outputBuffer)
        return FloatArray(100) // Simplified
    }

    override fun onStop(owner: androidx.lifecycle.LifecycleOwner) {
        // Be a good citizen: release native resources when app is backgrounded
        interpreter?.close()
        interpreter = null
    }
}
