
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// --- DI Module ---
@Module
@InstallIn(SingletonComponent::class)
object ThermalModule {
    @Provides
    @Singleton
    fun providePowerManager(@ApplicationContext context: Context): PowerManager =
        context.getSystemService(Context.POWER_MANAGER_SERVICE) as PowerManager
}

// --- Thermal Monitor Service ---
@Singleton
class ThermalMonitor @Inject constructor(
    private val powerManager: PowerManager
) {
    // Using callbackFlow to convert listener callbacks into a cold stream
    fun observeThermalStatus(): Flow<Int> = callbackFlow {
        val listener = PowerManager.OnThermalStatusListener { status ->
            trySend(status)
        }
        
        powerManager.addThermalStatusListener(listener)
        
        // Emit initial state immediately
        trySend(powerManager.currentThermalStatus)

        // Ensure listener is removed when flow is cancelled/closed
        awaitClose {
            powerManager.removeThermalStatusListener(listener)
        }
    }.distinctUntilChanged()
     .flowOn(Dispatchers.Default)
}

// --- ViewModel ---
@HiltViewModel
class ThermalViewModel @Inject constructor(
    private val thermalMonitor: ThermalMonitor
) : ViewModel() {

    val thermalState: StateFlow<Int> = thermalMonitor.observeThermalStatus()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = PowerManager.THERMAL_STATUS_NONE
        )
}

// --- Compose UI ---
@Composable
fun ThermalDashboardScreen(viewModel: ThermalViewModel = hiltViewModel()) {
    val status by viewModel.thermalState.collectAsStateWithLifecycle()

    val (label, color) = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Cool" to Color.Green
        PowerManager.THERMAL_STATUS_LIGHT -> "Light" to Color.Yellow
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderate" to Color(0xFFFFA500) // Orange
        PowerManager.THERMAL_STATUS_SEVERE -> "Severe" to Color.Red
        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL" to Color.Black
        else -> "Unknown" to Color.Gray
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Device Thermal Health", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        // Thermal Gauge
        Box(
            modifier = Modifier
                .size(200.dp)
                .background(color, shape = CircleShape)
                .border(4.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = label, color = Color.White, style = MaterialTheme.typography.titleLarge)
        }
    }
}
