
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

enum class HardwareAccelerator { NPU, GPU, CPU }

class DelegateFactory {
    fun createInterpreter(accel: HardwareAccelerator): TFLiteInterpreter {
        return when (accel) {
            HardwareAccelerator.NPU -> TFLiteInterpreter(delegate = "NNAPI")
            HardwareAccelerator.GPU -> TFLiteInterpreter(delegate = "GPU")
            HardwareAccelerator.CPU -> TFLiteInterpreter(delegate = "XNNPACK")
        }
    }
}

@Singleton
class HardwareMigrationManager @Inject constructor(
    private val thermalMonitor: ThermalMonitor,
    private val delegateFactory: DelegateFactory
) {
    private val _currentAccel = MutableStateFlow(HardwareAccelerator.NPU)
    val currentAccel: StateFlow<HardwareAccelerator> = _currentAccel.asStateFlow()

    private var currentInterpreter: TFLiteInterpreter? = null
    private val migrationChannel = Channel<HardwareAccelerator>(Channel.CONFLATED)

    suspend fun startMigrationListener() = coroutineScope {
        // Handle migration requests sequentially
        launch {
            for (nextAccel in migrationChannel) {
                performMigration(nextAccel)
            }
        }

        thermalMonitor.observeThermalStatus().collect { status ->
            when (status) {
                PowerManager.THERMAL_STATUS_MODERATE -> migrationChannel.send(HardwareAccelerator.GPU)
                PowerManager.THERMAL_STATUS_SEVERE -> migrationChannel.send(HardwareAccelerator.CPU)
                PowerManager.THERMAL_STATUS_NONE -> migrationChannel.send(HardwareAccelerator.NPU)
            }
        }
    }

    fun reportLatency(latencyMs: Long) {
        if (latencyMs > 100) { // Latency Watchdog
            val next = when (_currentAccel.value) {
                HardwareAccelerator.NPU -> HardwareAccelerator.GPU
                HardwareAccelerator.GPU -> HardwareAccelerator.CPU
                HardwareAccelerator.CPU -> HardwareAccelerator.CPU
            }
            migrationChannel.trySend(next)
        }
    }

    private suspend fun performMigration(accel: HardwareAccelerator) {
        if (_currentAccel.value == accel) return
        
        withContext(Dispatchers.Default) {
            currentInterpreter?.close() // Free hardware buffers
            currentInterpreter = delegateFactory.createInterpreter(accel)
            _currentAccel.value = accel
        }
    }
}

// Dummy class for representation
class TFLiteInterpreter(val delegate: String) {
    fun close() { println("Releasing $delegate") }
}
