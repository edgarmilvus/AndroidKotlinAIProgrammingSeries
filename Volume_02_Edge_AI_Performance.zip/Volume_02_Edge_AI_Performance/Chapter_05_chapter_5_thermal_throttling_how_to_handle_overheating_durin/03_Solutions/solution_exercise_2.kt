
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

@Singleton
class InferenceCoordinator @Inject constructor(
    private val thermalMonitor: ThermalMonitor
) {
    private val _effectiveFps = MutableStateFlow(0f)
    val effectiveFps: StateFlow<Float> = _effectiveFps.asStateFlow()

    private val _skipRate = MutableStateFlow(0)
    val skipRate: StateFlow<Int> = _skipRate.asStateFlow()

    suspend fun runInferenceLoop(onInference: suspend (frame: Int) -> Unit) = coroutineScope {
        var frameIndex = 0
        var lastFrameTime = System.nanoTime()

        // Observe thermal status to update skip rate dynamically
        launch {
            thermalMonitor.observeThermalStatus().collect { status ->
                _skipRate.value = when (status) {
                    PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> 0
                    PowerManager.THERMAL_STATUS_MODERATE -> 1 // Process every 2nd frame
                    PowerManager.THERMAL_STATUS_SEVERE -> 3   // Process every 4th frame
                    PowerManager.THERMAL_STATUS_CRITICAL -> 9 // Process every 10th frame
                    else -> 0
                }
            }
        }

        while (isActive) {
            val currentSkipRate = _skipRate.value
            
            if (frameIndex % (currentSkipRate + 1) == 0) {
                val startTime = System.nanoTime()
                onInference(frameIndex)
                val endTime = System.nanoTime()
                
                // Calculate actual FPS
                val durationMs = (endTime - startTime) / 1_000_000f
                _effectiveFps.value = 1000f / durationMs
            }

            frameIndex++
            // Base delay to prevent 100% CPU spinning
            delay(16) // Target ~60fps raw input
        }
    }
}

@Composable
fun PerformanceOverlay(coordinator: InferenceCoordinator) {
    val fps by coordinator.effectiveFps.collectAsStateWithLifecycle()
    val skip by coordinator.skipRate.collectAsStateWithLifecycle()

    Surface(
        color = Color.Black.copy(alpha = 0.6f),
        modifier = Modifier.padding(16.dp).fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text("Effective FPS: ${"%.2f".format(fps)}", color = Color.Green)
            Text("Skip Rate: 1/${skip + 1}", color = Color.White)
        }
    }
}
