
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

data class PipelineConfiguration(
    val fps: Int,
    val model: ModelStrategy,
    val accelerator: HardwareAccelerator,
    val userWarning: String? = null
)

@Singleton
class ThermalOrchestrator @Inject constructor(
    private val thermalMonitor: ThermalMonitor
) {
    val pipelineConfig: StateFlow<PipelineConfiguration> = thermalMonitor.observeThermalStatus()
        .map { status ->
            when (status) {
                PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> 
                    PipelineConfiguration(30, HighPrecisionStrategy(), HardwareAccelerator.NPU)
                
                PowerManager.THERMAL_STATUS_MODERATE -> 
                    PipelineConfiguration(15, HighPrecisionStrategy(), HardwareAccelerator.GPU, 
                        "Optimizing for temperature...")
                
                PowerManager.THERMAL_STATUS_SEVERE -> 
                    PipelineConfiguration(10, LowPrecisionStrategy(), HardwareAccelerator.GPU, 
                        "Reducing quality to prevent overheating")
                
                PowerManager.THERMAL_STATUS_CRITICAL -> 
                    PipelineConfiguration(2, LowPrecisionStrategy(), HardwareAccelerator.CPU, 
                        "Critical Heat: Minimum functionality mode")
                
                else -> PipelineConfiguration(30, HighPrecisionStrategy(), HardwareAccelerator.NPU)
            }
        }.stateIn(
            scope = CoroutineScope(Dispatchers.Default),
            started = SharingStarted.Eagerly,
            initialValue = PipelineConfiguration(30, HighPrecisionStrategy(), HardwareAccelerator.NPU)
        )
}

class ThermalAwareInferenceEngine @Inject constructor(
    private val orchestrator: ThermalOrchestrator,
    private val migrationManager: HardwareMigrationManager
) {
    suspend fun execute() = coroutineScope {
        orchestrator.pipelineConfig.collect { config ->
            // 1. Update Hardware
            migrationManager.requestMigration(config.accelerator)
            
            // 2. Run loop with dynamic FPS
            val frameDelay = 1000L / config.fps
            
            // Simulation of inference loop
            launch {
                while (orchestrator.pipelineConfig.value == config) {
                    val start = System.currentTimeMillis()
                    
                    // Run inference using config.model
                    config.model.executeInference(floatArrayOf(0f))
                    
                    val end = System.currentTimeMillis()
                    migrationManager.reportLatency(end - start)
                    
                    delay(frameDelay)
                }
            }
        }
    }
}

@Composable
fun ThermalAwareUI(orchestrator: ThermalOrchestrator) {
    val config by orchestrator.pipelineConfig.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(config.userWarning) {
        config.userWarning?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Main AI Viewport here...
        
        SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
