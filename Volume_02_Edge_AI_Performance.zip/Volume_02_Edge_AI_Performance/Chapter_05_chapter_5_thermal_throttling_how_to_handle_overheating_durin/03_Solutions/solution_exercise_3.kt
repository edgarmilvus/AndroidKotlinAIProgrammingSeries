
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

sealed class ModelState {
    object Loading : ModelState()
    data class Active(val strategy: ModelStrategy) : ModelState()
    data class Switching(val from: String, val to: String) : ModelState()
}

interface ModelStrategy {
    val name: String
    fun executeInference(input: FloatArray): FloatArray
    fun release()
}

@Singleton
class ModelManager @Inject constructor(
    private val thermalMonitor: ThermalMonitor
) {
    private val _state = MutableStateFlow<ModelState>(ModelState.Loading)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    private var cooldownJob: Job? = null

    suspend fun startModelOrchestration() = coroutineScope {
        thermalMonitor.observeThermalStatus().collect { status ->
            when {
                status >= PowerManager.THERMAL_STATUS_MODERATE -> {
                    cancelCooldown()
                    switchToModel(LowPrecisionStrategy())
                }
                status < PowerManager.THERMAL_STATUS_MODERATE -> {
                    startCooldownTimer()
                }
            }
        }
    }

    private suspend fun startCooldownTimer() {
        cooldownJob?.cancel()
        cooldownJob = coroutineScope {
            launch {
                delay(30_000) // 30 second cooldown
                switchToModel(HighPrecisionStrategy())
            }
        }
    }

    private fun cancelCooldown() {
        cooldownJob?.cancel()
    }

    private suspend fun switchToModel(newStrategy: ModelStrategy) {
        withContext(Dispatchers.Default) {
            val oldStrategy = (_state.value as? ModelState.Active)?.strategy
            _state.value = ModelState.Switching(oldStrategy?.name ?: "None", newStrategy.name)
            
            // Simulate heavy weight loading
            delay(500) 
            
            oldStrategy?.release() // Explicit memory cleanup
            _state.value = ModelState.Active(newStrategy)
        }
    }
}

class HighPrecisionStrategy : ModelStrategy {
    override val name = "Gold Model (EfficientNet)"
    override fun executeInference(input: FloatArray) = input // Dummy
    override fun release() { /* Close TFLite Interpreter */ }
}

class LowPrecisionStrategy : ModelStrategy {
    override val name = "Silver Model (MobileNet)"
    override fun executeInference(input: FloatArray) = input // Dummy
    override fun release() { /* Close TFLite Interpreter */ }
}
