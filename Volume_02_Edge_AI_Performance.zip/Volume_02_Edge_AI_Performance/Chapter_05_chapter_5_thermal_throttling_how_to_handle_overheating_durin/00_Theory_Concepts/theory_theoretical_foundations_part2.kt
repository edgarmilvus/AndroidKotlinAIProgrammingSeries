
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

// Experimental feature: requires -Xcontext-receivers compiler flag
interface ThermalAware {
    val currentStatus: Int
    fun shouldReducePrecision(): Boolean = currentStatus >= PowerManager.THERMAL_STATUS_MODERATE
    fun shouldDropFrames(): Boolean = currentStatus >= PowerManager.THERMAL_STATUS_SEVERE
}

class AIInferenceEngine(override val currentStatus: Int) : ThermalAware

// This function can ONLY be called within a ThermalAware context
context(ThermalAware)
fun performInference(input: TensorData): TensorResult {
    return if (shouldReducePrecision()) {
        // Execute using INT8 quantization instead of FP16
        runQuantizedInference(input)
    } else {
        // Execute using full precision
        runFullPrecisionInference(input)
    }
}

// Usage in a ViewModel or Service
fun executeTask(engine: AIInferenceEngine, data: TensorData) {
    with(engine) {
        performInference(data)
    }
}
