
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.thermal.performance

import android.content.Context
import android.os.PowerManager
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the operational strategy based on thermal pressure.
 */
sealed class InferenceStrategy {
    object HighPerformance : InferenceStrategy() { // NPU, Max Frequency
        val delegate = "NNAPI/NPU"
        val frameSkip = 0 
    }
    object Balanced : InferenceStrategy() { // GPU, Moderate Frequency
        val delegate = "GPU"
        val frameSkip = 1 
    }
    object PowerSaver : InferenceStrategy() { // CPU (Quantized), Low Frequency
        val delegate = "CPU"
        val frameSkip = 3
    }
    object Critical : InferenceStrategy() { // Emergency Stop/Minimal
        val delegate = "CPU"
        val frameSkip = 10
    }
}

/**
 * ThermalMonitor: Observes the system's thermal status using Android PowerManager.
 * It converts the system's integer constants into a reactive Flow of InferenceStrategies.
 */
@Singleton
class ThermalMonitor @Inject constructor(
    private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    
    private val _thermalState = MutableStateFlow<InferenceStrategy>(InferenceStrategy.HighPerformance)
    val thermalState: StateFlow<InferenceStrategy> = _thermalState.asStateFlow()

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        val strategy = when (status) {
            PowerManager.THERMAL_STATUS_NONE, 
            PowerManager.THERMAL_STATUS_LIGHT -> InferenceStrategy.HighPerformance
            
            PowerManager.THERMAL_STATUS_MODERATE -> InferenceStrategy.Balanced
            
            PowerManager.THERMAL_STATUS_SEVERE -> InferenceStrategy.PowerSaver
            
            PowerManager.THERMAL_STATUS_CRITICAL -> InferenceStrategy.Critical
            else -> InferenceStrategy.Balanced
        }
        _thermalState.value = strategy
        Log.w("ThermalMonitor", "Thermal status changed to $status. Switching to ${strategy::class.simpleName}")
    }

    fun startMonitoring() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusListener(thermalListener)
        }
    }

    fun stopMonitoring() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.removeThermalStatusListener(thermalListener)
        }
    }
}

/**
 * AIModelRepository: Handles the hardware-aware loading of the AI model.
 * In a real scenario, this would wrap TFLite's Interpreter.
 */
@Singleton
class AIModelRepository @Inject constructor() {
    private var currentDelegate: String = "NONE"

    // Simulates the heavy operation of re-initializing the model with a different hardware delegate
    suspend fun updateHardwareDelegate(strategy: InferenceStrategy): Boolean = withContext(Dispatchers.Default) {
        val targetDelegate = when (strategy) {
            is InferenceStrategy.HighPerformance -> "NPU/NNAPI"
            is InferenceStrategy.Balanced -> "GPU"
            is InferenceStrategy.PowerSaver -> "CPU_QUANTIZED"
            is InferenceStrategy.Critical -> "CPU_MINIMAL"
        }

        if (currentDelegate == targetDelegate) return@withContext true

        Log.i("AIModelRepository", "Reconfiguring AI Engine: $currentDelegate -> $targetDelegate")
        // Simulate model reload latency (e.g., allocating tensors on GPU)
        delay(200) 
        currentDelegate = targetDelegate
        return@withContext true
    }

    fun runInference(data: FloatArray): FloatArray {
        // Actual inference logic would go here
        return floatArrayOf(0.9f, 0.1f) 
    }
}

/**
 * InferenceViewModel: The orchestrator that connects thermal state to the AI execution loop.
 */
@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val thermalMonitor: ThermalMonitor,
    private val modelRepository: AIModelRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow("Initializing...")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    init {
        thermalMonitor.startMonitoring()
        observeThermalChanges()
    }

    private fun observeThermalChanges() {
        viewModelScope.launch {
            thermalMonitor.thermalState.collect { strategy ->
                _uiState.value = "Mode: ${strategy::class.simpleName} | Delegate: ${getDelegateName(strategy)}"
                // Critical: Trigger the repository to switch hardware delegates
                modelRepository.updateHardwareDelegate(strategy)
            }
        }
    }

    private fun getDelegateName(strategy: InferenceStrategy): String = when(strategy) {
        is InferenceStrategy.HighPerformance -> "NPU"
        is InferenceStrategy.Balanced -> "GPU"
        is InferenceStrategy.PowerSaver -> "CPU (INT8)"
        is InferenceStrategy.Critical -> "CPU (Low Power)"
    }

    /**
     * The main inference loop. Demonstrates hardware-aware orchestration
     * by applying 'frame skipping' based on the current thermal strategy.
     */
    fun startInferenceLoop(frameStream: Flow<FloatArray>) {
        viewModelScope.launch(Dispatchers.Default) {
            _isProcessing.value = true
            var frameCount = 0

            frameStream.collect { frameData ->
                val currentStrategy = thermalMonitor.thermalState.value
                val skip = when (currentStrategy) {
                    is InferenceStrategy.HighPerformance -> 0
                    is InferenceStrategy.Balanced -> 1
                    is InferenceStrategy.PowerSaver -> 3
                    is InferenceStrategy.Critical -> 10
                }

                // Hardware-aware orchestration: Only process if the frame index matches the skip pattern
                if (frameCount % (skip + 1) == 0) {
                    val result = modelRepository.runInference(frameData)
                    // Handle result...
                }
                frameCount++
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        thermalMonitor.stopMonitoring()
    }
}

/**
 * Hilt Module for providing Context and Dependencies
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideContext(app: android.app.Application): Context = app.applicationContext
}
