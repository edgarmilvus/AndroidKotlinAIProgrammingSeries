
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.thermal.example

import android.content.Context
import android.os.PowerManager
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. THERMAL MONITOR REPOSITORY
 * Responsible for interfacing with the Android PowerManager to track SoC heat.
 */
@Singleton
class ThermalRepository @Inject constructor(
    private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    // A StateFlow that emits the current thermal status of the device
    private val _thermalStatus = MutableStateFlow(PowerManager.THERMAL_STATUS_NONE)
    val thermalStatus: StateFlow<Int> = _thermalStatus.asStateFlow()

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        Log.d("ThermalRepo", "Thermal status changed to: $status")
        _thermalStatus.value = status
    }

    fun startMonitoring() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusListener(thermalListener)
        }
    }

    fun stopMonitoring() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.removeThermalStatusListener(thermalListener)
        }
    }
}

/**
 * 2. INFERENCE ENGINE
 * Simulates an AI model (e.g., MobileNetV2) running on NPU/GPU.
 */
class AIInferenceEngine @Inject constructor() {
    // Simulates the time taken for one inference pass
    suspend fun runInference(frameId: Int): String = withContext(Dispatchers.Default) {
        // Simulate heavy computation (NPU/GPU load)
        delay(30) 
        "Detection Result for Frame $frameId: [Object A, Object B]"
    }
}

/**
 * 3. VIEWMODEL
 * The Orchestrator. It listens to thermal changes and adjusts the inference strategy.
 */
@AndroidEntryPoint
class ThermalInferenceViewModel @Inject constructor(
    private val thermalRepository: ThermalRepository,
    private val inferenceEngine: AIInferenceEngine
) : ViewModel() {

    // UI State
    var currentThermalState by mutableStateOf("Cool")
    var inferenceResult by mutableStateOf("Waiting for frames...")
    var framesProcessed by mutableIntStateOf(0)
    var currentSkipRate by mutableIntStateOf(0) // 0 = every frame, 1 = every 2nd frame, etc.

    private var inferenceJob: Job? = null

    init {
        thermalRepository.startMonitoring()
        observeThermalStatus()
        startInferenceLoop()
    }

    private fun observeThermalStatus() {
        viewModelScope.launch {
            thermalRepository.thermalStatus.collect { status ->
                handleThermalChange(status)
            }
        }
    }

    private fun handleThermalChange(status: Int) {
        when (status) {
            PowerManager.THERMAL_STATUS_NONE -> {
                currentThermalState = "Cool"
                currentSkipRate = 0 // Process every frame
            }
            PowerManager.THERMAL_STATUS_LIGHT -> {
                currentThermalState = "Warm"
                currentSkipRate = 0 // Still okay
            }
            PowerManager.THERMAL_STATUS_MODERATE -> {
                currentThermalState = "Hot"
                currentSkipRate = 2 // Skip 2 frames, process 1
            }
            PowerManager.THERMAL_STATUS_SEVERE -> {
                currentThermalState = "Very Hot"
                currentSkipRate = 5 // Skip 5 frames, process 1
            }
            PowerManager.THERMAL_STATUS_CRITICAL -> {
                currentThermalState = "Critical"
                currentSkipRate = 10 // Drastic reduction
            }
            PowerManager.THERMAL_STATUS_EMERGENCY -> {
                currentThermalState = "Emergency"
                stopInference() // Stop AI to prevent shutdown
            }
        }
    }

    private fun startInferenceLoop() {
        inferenceJob = viewModelScope.launch(Dispatchers.Default) {
            var frameCounter = 0
            while (isActive) {
                // THE CORE LOGIC: Adaptive Frame Skipping
                // Only run inference if the frameCounter is divisible by (skipRate + 1)
                if (frameCounter % (currentSkipRate + 1) == 0) {
                    val result = inferenceEngine.runInference(frameCounter)
                    
                    // Switch to Main thread to update UI
                    withContext(Dispatchers.Main) {
                        inferenceResult = result
                        framesProcessed++
                    }
                }
                
                frameCounter++
                // Simulate a 30FPS camera feed (33ms per frame)
                delay(33) 
            }
        }
    }

    private fun stopInference() {
        inferenceJob?.cancel()
        inferenceResult = "Inference stopped due to overheating!"
    }

    override fun onCleared() {
        super.onCleared()
        thermalRepository.stopMonitoring()
    }
}

/**
 * 4. JETPACK COMPOSE UI
 * Displays the real-time thermal state and the impact on AI performance.
 */
@Composable
fun ThermalMonitorScreen(viewModel: ThermalInferenceViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "Edge AI Thermal Controller", style = MaterialTheme.typography.headlineMedium)
                Spacer(modifier = Modifier.height(32.dp))

                ThermalStatusCard(viewModel.currentThermalState, viewModel.currentSkipRate)
                
                Spacer(modifier = Modifier.height(24.dp))

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "AI Output:", style = MaterialTheme.typography.labelLarge)
                        Text(text = viewModel.inferenceResult, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Total Frames Processed: ${viewModel.framesProcessed}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun ThermalStatusCard(status: String, skipRate: Int) {
    val color = when (status) {
        "Cool" -> MaterialTheme.colorScheme.primary
        "Warm" -> MaterialTheme.colorScheme.secondary
        "Hot" -> MaterialTheme.colorScheme.tertiary
        "Very Hot" -> androidx.compose.ui.graphics.Color.Magenta
        "Critical" -> androidx.compose.ui.graphics.Color.Red
        else -> androidx.compose.ui.graphics.Color.Black
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Device State: $status", style = MaterialTheme.typography.headlineSmall, color = color)
            Text(text = "Current Strategy: Skipping $skipRate frames", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
