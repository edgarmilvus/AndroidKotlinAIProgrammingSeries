
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import android.hardware.HardwareBuffer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the result of an AI inference operation.
 */
@kotlinx.serialization.Serializable
data class InferenceResult(val label: String, val confidence: Float)

/**
 * Abstraction for the System AI Provider (AICore/Gemini Nano).
 */
interface AIProvider {
    suspend fun runInference(buffer: HardwareBuffer): InferenceResult
}

/**
 * Production implementation of AICore interaction.
 */
@Singleton
class AICoreProvider @Inject constructor() : AIProvider {
    override suspend fun runInference(buffer: HardwareBuffer): InferenceResult = withContext(Dispatchers.Default) {
        // In a real scenario, this would be a JNI call to the AICore system service.
        // The 'buffer' is passed as a handle, ensuring zero-copy.
        val result = nativeInfer(buffer) 
        InferenceResult(result.label, result.confidence)
    }

    private external fun nativeInfer(buffer: HardwareBuffer): NativeResult
    data class NativeResult(val label: String, val confidence: Float)
}

/**
 * The ImageProcessor manages the stream of buffers from CameraX to AICore.
 */
@Singleton
class ImageProcessor @Inject constructor(
    private val aiProvider: AIProvider
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // We use a SharedFlow to broadcast inference results to multiple UI components
    private val _results = MutableSharedFlow<InferenceResult>()
    val results: SharedFlow<InferenceResult> = _results.asSharedFlow()

    /**
     * Processes a stream of HardwareBuffers. 
     * Just as CameraX manages the buffer queue, we manage the flow of inference.
     */
    fun processBufferStream(bufferFlow: Flow<HardwareBuffer>) {
        scope.launch {
            bufferFlow
                .collect { buffer ->
                    try {
                        // Zero-copy inference: we pass the buffer handle, not the pixels.
                        val result = aiProvider.runInference(buffer)
                        _results.emit(result)
                    } finally {
                        // CRITICAL: HardwareBuffers must be closed to prevent native memory leaks.
                        // This is like calling finish() on an Activity or closing a Room DB.
                        buffer.close()
                    }
                }
        }
    }
}
