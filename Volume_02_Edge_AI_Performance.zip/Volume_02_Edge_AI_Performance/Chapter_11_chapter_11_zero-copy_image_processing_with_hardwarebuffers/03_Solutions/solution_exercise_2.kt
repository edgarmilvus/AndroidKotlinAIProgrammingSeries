
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.graphics.HardwareBuffer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class BufferMetadata(
    val width: Int,
    val height: Int,
    val format: Int,
    val usage: Int,
    val isCpuReadHeavy: Boolean
)

@Singleton
class BufferDiagnostics @Inject constructor() {
    private val _currentMetadata = MutableStateFlow<BufferMetadata?>(null)
    val currentMetadata: StateFlow<BufferMetadata?> = _currentMetadata.asStateFlow()

    fun inspectBuffer(buffer: HardwareBuffer) {
        // Extract properties from the HardwareBuffer API
        val usage = buffer.usage
        val metadata = BufferMetadata(
            width = buffer.width,
            height = buffer.height,
            format = buffer.format,
            usage = usage,
            // Warning: USAGE_CPU_READ_OFTEN can trigger cache flushes, slowing down GPU/NPU
            isCpuReadHeavy = (usage and HardwareBuffer.USAGE_CPU_READ_OFTEN) != 0
        )
        _currentMetadata.value = metadata
    }
}

@Composable
fun BufferInspectorScreen(viewModel: BufferDiagnostics) {
    val metadata by viewModel.currentMetadata.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "HardwareBuffer Inspector", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        metadata?.let { data ->
            if (data.isCpuReadHeavy) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.Red)) {
                    Text(
                        text = "PERFORMANCE WARNING: CPU_READ_OFTEN detected. This may cause pipeline stalls!",
                        modifier = Modifier.padding(8.dp),
                        color = Color.White
                    )
                }
            }

            LazyColumn {
                item { PropertyRow("Width", "${data.width} px") }
                item { PropertyRow("Height", "${data.height} px") }
                item { PropertyRow("Format", "0x${Integer.toHexString(data.format)}") }
                item { PropertyRow("Usage Flags", "0x${Integer.toHexString(data.usage)}") }
            }
        } ?: Text("Waiting for buffer...")
    }
}

@Composable
fun PropertyRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
        Text(text = value, style = MaterialTheme.typography.bodyLarge)
    }
}
