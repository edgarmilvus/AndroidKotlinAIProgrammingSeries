
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.graphics.HardwareBuffer
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import android.opengl.GLES20

class SegmentationPipeline(modelBuffer: java.nio.ByteBuffer) {
    private val interpreter: Interpreter
    private var maskBuffer: HardwareBuffer? = null

    init {
        val options = Interpreter.Options().apply {
            // Enable GPU/NPU delegate with HardwareBuffer support
            addDelegate(GpuDelegate().apply {
                // allowPrecisionLoss allows the NPU to use FP16 for 2x speedup
                this.setPrecisionLossAllowed(true)
            })
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    fun processFrame(inputBuffer: HardwareBuffer) {
        // 1. Allocate output HardwareBuffer for the mask (e.g., 256x256)
        // In production, use a pool to avoid allocation every frame
        maskBuffer = HardwareBuffer.create(
            256, 256, HardwareBuffer.RGBA_8888, 1,
            HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or HardwareBuffer.USAGE_GPU_COLOR_OUTPUT
        )

        // 2. Zero-Copy Inference
        // We bind the HardwareBuffer handles directly to the TFLite tensors
        val inputs = mapOf("input_tensor" to inputBuffer)
        val outputs = mapOf("mask_tensor" to maskBuffer)
        
        // TFLite GPU Delegate handles the internal Sync Fences
        interpreter.runForMultipleInputsOutputs(inputs, outputs)
    }

    fun renderOverlay(cameraTexId: Int, maskTexId: Int) {
        // 3. Fragment Shader Logic (GLSL)
        val fragmentShader = """
            precision mediump float;
            uniform sampler2D u_CameraTexture;
            uniform sampler2D u_MaskTexture;
            varying vec2 v_TexCoord;
            
            void main() {
                vec4 cameraColor = texture2D(u_CameraTexture, v_TexCoord);
                vec4 maskColor = texture2D(u_MaskTexture, v_TexCoord);
                
                // If mask is white (1.0), keep original. If black (0.0), blur/darken.
                float alpha = maskColor.r; 
                vec4 blurredColor = cameraColor * 0.5; // Simplified blur
                gl_FragColor = mix(blurredColor, cameraColor, alpha);
            }
        """.trimIndent()
        
        // Bind the mask HardwareBuffer to maskTexId and draw...
    }
}
