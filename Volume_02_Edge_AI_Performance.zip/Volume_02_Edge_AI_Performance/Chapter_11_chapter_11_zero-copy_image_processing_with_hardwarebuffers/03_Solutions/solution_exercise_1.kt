
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.graphics.HardwareBuffer
import android.hardware.HardwareBuffer
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLES30
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.compose.runtime.*
import androidx.compose.ui.viewinterop.AndroidView
import android.view.SurfaceView
import android.opengl.GLSurfaceView

class ZeroCopyAnalyzer(private val glRenderer: CameraGLRenderer) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        // 1. Extract HardwareBuffer from ImageProxy
        val hardwareBuffer = image.hardwareBuffer 
            ?: throw IllegalStateException("HardwareBuffer not available")

        // 2. Pass the buffer to the GL renderer for binding
        // We pass the buffer handle; the renderer handles the EGL binding
        glRenderer.updateTexture(hardwareBuffer)

        // Crucial: Close the image proxy to return the buffer to the pool
        image.close()
    }
}

class CameraGLRenderer : GLSurfaceView.Renderer {
    private var textureId = -1
    private var currentBuffer: HardwareBuffer? = null

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // 3. Create a texture of type GL_TEXTURE_EXTERNAL_OES
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        
        // Set filtering parameters
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    }

    fun updateTexture(buffer: HardwareBuffer) {
        this.currentBuffer = buffer
        // In a real production app, the actual EGL binding happens via JNI 
        // using eglCreateImageKHR and glEGLImageTargetTexture2DOES.
        // Here we simulate the trigger for the GL thread to bind the new buffer.
        bindHardwareBufferToTexture(buffer, textureId)
    }

    private fun bindHardwareBufferToTexture(buffer: HardwareBuffer, texId: Int) {
        // This call represents the native bridge to EGL_ANDROID_get_native_client_buffer
        NativeEGLBridge.bindBufferToTexture(buffer, texId)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        // Render the OES texture using a simple quad and fragment shader
        renderQuad(textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }
    
    private fun renderQuad(texId: Int) { /* Implementation of quad rendering */ }
}

@Composable
fun CameraPreviewScreen(analyzer: ZeroCopyAnalyzer) {
    AndroidView(
        factory = { context ->
            GLSurfaceView(context).apply {
                setEGLContextClientVersion(2)
                setRenderer(CameraGLRenderer())
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
        }
    )
}
