
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// GLSL Compute Shader (yuv_to_rgb.glsl)
/*
#version 310 es
layout(local_size_x = 16, local_size_y = 16) in;

// Input YUV planes (Simplified: assuming packed or separate images)
layout(rgba8, binding = 0) uniform readonly image2D u_YPlane;
layout(rgba8, binding = 1) uniform readonly image2D u_UVPlane;
layout(rgba8, binding = 2) uniform writeonly image2D u_RGBOutput;

void main() {
    ivec2 pos = ivec2(gl_GlobalInvocationID.xy);
    
    float y = imageLoad(u_YPlane, pos).r;
    vec2 uv = imageLoad(u_UVPlane, pos / 2).rg - 0.5;
    
    // BT.601 Conversion Matrix
    float r = y + 1.402 * uv.y;
    float g = y - 0.344136 * uv.x - 0.714136 * uv.y;
    float b = y + 1.772 * uv.x;
    
    imageStore(u_RGBOutput, pos, vec4(r, g, b, 1.0));
}
*/

class YuvComputePipeline {
    private var computeProgram: Int = 0
    private var rgbOutputBuffer: HardwareBuffer? = null

    fun setupComputeShader(context: Context) {
        val shaderCode = loadShaderFromAssets(context, "yuv_to_rgb.glsl")
        computeProgram = OpenGLUtils.compileComputeShader(shaderCode)
    }

    fun executeConversion(yuvBuffer: HardwareBuffer) {
        // 1. Create RGB output buffer if not exists
        if (rgbOutputBuffer == null) {
            rgbOutputBuffer = HardwareBuffer.create(
                yuvBuffer.width, yuvBuffer.height, HardwareBuffer.RGBA_8888, 1,
                HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or HardwareBuffer.USAGE_GPU_COLOR_OUTPUT
            )
        }

        GLES30.glUseProgram(computeProgram)

        // 2. Bind HardwareBuffers as images
        // We use the EGL extension to bind HardwareBuffer to an image unit
        val yuvImage = NativeEGLBridge.createEGLImage(yuvBuffer)
        val rgbImage = NativeEGLBridge.createEGLImage(rgbOutputBuffer!!)
        
        GLES30.glBindImageTexture(0, yuvImage, 0, false, 0, GLES30.GL_READ_ONLY, GLES30.GL_RGBA8)
        GLES30.glBindImageTexture(2, rgbImage, 0, false, 0, GLES30.GL_WRITE_ONLY, GLES30.GL_RGBA8)

        // 3. Dispatch the shader
        val groupsX = (yuvBuffer.width + 15) / 16
        val groupsY = (yuvBuffer.height + 15) / 16
        GLES30.glDispatchCompute(groupsX, groupsY, 1)

        // 4. Memory Barrier to ensure write is complete before NPU reads
        GLES30.glMemoryBarrier(GLES30.GL_SHADER_IMAGE_ACCESS_BARRIER_BIT)
    }

    fun getRgbBufferForNpu(): HardwareBuffer = rgbOutputBuffer!!
}
