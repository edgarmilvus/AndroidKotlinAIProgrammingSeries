
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.graphics.HardwareBuffer
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.runBlocking

class HardwareBufferPool(
    private val bufferCount: Int,
    private val width: Int,
    private val height: Int
) {
    private val pool = Array(bufferCount) {
        HardwareBuffer.create(width, height, HardwareBuffer.RGBA_8888, 1, 
            HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or HardwareBuffer.USAGE_CPU_READ_OFTEN)
    }
    
    private val freeBuffers = Semaphore(bufferCount)
    private val writeIndex = AtomicInteger(0)
    
    // Channel to send buffers to the NPU consumer
    val processingQueue = Channel<HardwareBuffer>(Channel.CONFLATED)

    fun acquireNextBuffer(): HardwareBuffer? {
        // Non-blocking attempt to get a buffer
        if (freeBuffers.tryAcquire()) {
            val index = writeIndex.getAndIncrement() % bufferCount
            return pool[index]
        }
        // If no buffers are free, we drop the frame to maintain real-time latency
        return null 
    }

    fun releaseBuffer(buffer: HardwareBuffer) {
        freeBuffers.release()
    }

    fun closeAll() {
        pool.forEach { it.close() }
    }
}

class HighFpsPipeline(private val pool: HardwareBufferPool) {
    fun onCameraFrame(imageProxy: ImageProxy) {
        val buffer = pool.acquireNextBuffer()
        if (buffer == null) {
            imageProxy.close() // Drop frame
            return
        }

        // Zero-copy: we don't copy data, we just pass the handle to the NPU
        // Note: In a real app, you'd map the imageProxy.hardwareBuffer here
        pool.processingQueue.trySend(buffer)
        imageProxy.close()
    }

    suspend fun startNpuConsumer() {
        for (buffer in pool.processingQueue) {
            try {
                runInference(buffer)
            } finally {
                // Crucial: release back to pool so Camera can use it again
                pool.releaseBuffer(buffer)
            }
        }
    }

    private fun runInference(buffer: HardwareBuffer) { /* NPU Logic */ }
}
