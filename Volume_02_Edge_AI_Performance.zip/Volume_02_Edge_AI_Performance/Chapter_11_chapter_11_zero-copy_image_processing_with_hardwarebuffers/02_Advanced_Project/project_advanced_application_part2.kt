
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.zerocopy

import android.hardware.HardwareBuffer
import android.media.Image
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.inject.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import javax.inject.Qualifier

// --- DI Qualifiers for Hardware Orchestration ---
@Qualifier @Retention(AnnotationRetention.BINARY) annotation class NpuDispatcher
@Qualifier @Retention(AnnotationRetention.BINARY) annotation class GpuDispatcher

/**
 * Repository responsible for the Zero-Copy AI Pipeline.
 * It manages the TFLite Interpreter and handles HardwareBuffer mapping.
 */
@Singleton
class ZeroCopyImageRepository @Inject constructor() {
    private val TAG = "ZeroCopyRepo"
    
    // Hardware-aware orchestration: Prefer NPU -> GPU -> CPU
    private var isNpuAvailable = checkNpuAvailability()
    
    // In a real scenario, this would be a TFLite Interpreter with a GPU/NNAPI Delegate
    private var aiInterpreter: Any? = null 

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        Log.d(TAG, "Initializing AI Engine. NPU Available: $isNpuAvailable")
        // Logic to initialize TFLite with GpuDelegateV2 or NnApiDelegate
        // The delegate is configured to accept HardwareBuffers directly
        aiInterpreter = Object() // Placeholder for TFLite Interpreter
    }

    /**
     * The critical Zero-Copy path.
     * @param hardwareBuffer The buffer provided by CameraX ImageProxy
     */
    suspend fun processFrameZeroCopy(hardwareBuffer: HardwareBuffer): Result<FloatArray> = withContext(Dispatchers.Default) {
        try {
            // UNDER THE HOOD: 
            // Instead of: hardwareBuffer -> ByteBuffer -> FloatArray -> Model
            // We do: hardwareBuffer -> Model (via GPU/NPU Delegate)
            
            Log.d(TAG, "Processing HardwareBuffer: ${hardwareBuffer.description}")
            
            // Simulate NPU Inference Latency
            delay(12) // Target 60fps (16.6ms total budget)
            
            // Mock result of the AI model
            Result.success(FloatArray(10) { it.toFloat() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun checkNpuAvailability(): Boolean {
        // Logic to query Android NNAPI for NPU support
        return true 
    }
}

/**
 * MVI State for the Neural Filter UI
 */
data class NeuralFilterState(
    val isProcessing: Boolean = false,
    val inferenceTime: Long = 0,
    val hardwareAccelerator: String = "Unknown",
    val error: String? = null
)

/**
 * ViewModel managing the AI pipeline lifecycle.
 */
@HiltViewModel
class NeuralFilterViewModel @Inject constructor(
    private val repository: ZeroCopyImageRepository
) : ViewModel() {

    private val _state = MutableStateFlow(NeuralFilterState())
    val state: StateFlow<NeuralFilterState> = _state.asStateFlow()

    // Structured Concurrency: Using a specific supervisor job for AI tasks
    private val aiJob = SupervisorJob()
    private val aiScope = CoroutineScope(Dispatchers.Default + aiJob)

    fun onFrameReceived(imageProxy: ImageProxy) {
        val buffer = imageProxy.hardwareBuffer ?: run {
            imageProxy.close()
            return
        }

        aiScope.launch {
            val startTime = System.currentTimeMillis()
            
            val result = repository.processFrameZeroCopy(buffer)
            
            val duration = System.currentTimeMillis() - startTime
            
            _state.update { it.copy(
                isProcessing = true, 
                inferenceTime = duration,
                hardwareAccelerator = if (duration < 15) "NPU" else "GPU"
            )}
            
            // Crucial: Close the ImageProxy only after the HardwareBuffer is released by the NPU
            imageProxy.close()
        }
    }

    override fun onCleared() {
        super.onCleared()
        aiJob.cancel() // Prevent memory leaks and orphan NPU tasks
    }
}

/**
 * CameraX Analyzer that bridges the Camera stream to the ViewModel.
 */
class ZeroCopyAnalyzer @Inject constructor(
    private val viewModel: NeuralFilterViewModel
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        // Pass the proxy to the ViewModel. 
        // The ViewModel handles the HardwareBuffer extraction.
        viewModel.onFrameReceived(image)
    }
}
