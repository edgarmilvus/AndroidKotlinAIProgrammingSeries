
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.zerocopy

import android.hardware.HardwareBuffer
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import javax.annotation.Nonnull

/**
 * Manages the lifecycle and allocation of HardwareBuffers for AI inference.
 * Zero-copy requires the buffer to be allocated with specific usage flags
 * to be accessible by both the CPU (for setup) and the GPU/NPU (for inference).
 */
@RequiresApi(Build.VERSION_CODES.R)
class HardwareBufferManager {
    private val TAG = "HardwareBufferMgr"

    /**
     * Creates a HardwareBuffer optimized for GPU/NPU access.
     * 
     * @param width Image width
     * @param height Image height
     * @param stride The byte alignment of the image rows
     */
    fun createInferenceBuffer(width: Int, height: Int, stride: Int): HardwareBuffer {
        return HardwareBuffer.create(
            width, 
            height, 
            HardwareBuffer.COLOR_SPACE_LINEAR_SRGB, // Standard color space for AI models
            HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or // Allow GPU to read as a texture
            HardwareBuffer.USAGE_CPU_READ_RARELY or   // CPU rarely reads, mostly writes/manages
            HardwareBuffer.USAGE_GPU_WRITE_RARELY,    // GPU might write results back
            1 // Max number of buffers in the pool
        ).also {
            Log.d(TAG, "Allocated HardwareBuffer: ${it.width}x${it.height}")
        }
    }

    /**
     * Ensures the buffer is closed to prevent native memory leaks.
     * HardwareBuffers are not managed by the JVM Garbage Collector.
     */
    fun releaseBuffer(buffer: HardwareBuffer) {
        buffer.close()
        Log.d(TAG, "HardwareBuffer released.")
    }
}
