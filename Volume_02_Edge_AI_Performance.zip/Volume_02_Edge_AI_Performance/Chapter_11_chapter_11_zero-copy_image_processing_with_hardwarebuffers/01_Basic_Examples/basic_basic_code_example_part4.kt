
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.zerocopy

import android.hardware.HardwareBuffer
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val repository: InferenceRepository,
    private val bufferManager: HardwareBufferManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(InferenceUiState())
    val uiState: StateFlow<InferenceUiState> = _uiState.asStateFlow()

    data class InferenceUiState(
        val detectionLabel: String = "Waiting...",
        val confidence: Float = 0f,
        val isProcessing: Boolean = false
    )

    /**
     * Entry point for CameraX Analyzer.
     * Receives the HardwareBuffer directly from the camera frame.
     */
    @RequiresApi(Build.VERSION_CODES.R)
    fun onFrameReceived(buffer: HardwareBuffer) {
        // Prevent overlapping inference calls to avoid ANRs and memory pressure
        if (_uiState.value.isProcessing) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true)
            
            // Perform Zero-Copy inference
            val result = repository.runZeroCopyInference(buffer)
            
            _uiState.value = _uiState.value.copy(
                detectionLabel = result.label,
                confidence = result.confidence,
                isProcessing = false
            )
            
            // CRITICAL: The HardwareBuffer must be closed after the NPU is done with it.
            // If the buffer comes from CameraX ImageProxy, ImageProxy.close() handles this.
            // If we allocated it manually, we must call bufferManager.releaseBuffer(buffer).
        }
    }
}
