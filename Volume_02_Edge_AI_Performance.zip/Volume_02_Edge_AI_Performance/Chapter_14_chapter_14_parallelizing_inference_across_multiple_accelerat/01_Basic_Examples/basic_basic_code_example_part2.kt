
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.parallel

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data class representing the combined result of multiple accelerators.
 */
data class ParallelInferenceResult(
    val gpuResult: FloatArray,
    val npuResult: FloatArray,
    val latencyMs: Long
)

/**
 * Interface for an Inference Engine to abstract the hardware delegate.
 */
interface InferenceEngine {
    fun runInference(input: ByteBuffer): FloatArray
    fun close()
}

/**
 * GPU Implementation: Optimized for FP16/FP32 models.
 */
class GpuInferenceEngine(context: Context, modelBuffer: ByteBuffer) : InferenceEngine {
    private val options = Interpreter.Options().apply {
        // Add the GPU delegate for hardware acceleration
        addDelegate(GpuDelegate())
        setNumThreads(1) // GPU handles parallelism internally
    }
    private val interpreter = Interpreter(modelBuffer, options)

    override fun runInference(input: ByteBuffer): FloatArray {
        val output = FloatArray(10) // Assuming a 10-class output
        interpreter.run(input, output)
        return output
    }

    override fun close() {
        interpreter.close()
    }
}

/**
 * NPU Implementation: Optimized for INT8 quantized models via NNAPI.
 */
class NpuInferenceEngine(context: Context, modelBuffer: ByteBuffer) : InferenceEngine {
    private val options = Interpreter.Options().apply {
        // NNAPI leverages the NPU/DSP via the Android system service
        addDelegate(NnApiDelegate())
        setNumThreads(4) // CPU fallback threads if NPU cannot handle an op
    }
    private val interpreter = Interpreter(modelBuffer, options)

    override fun runInference(input: ByteBuffer): FloatArray {
        val output = FloatArray(10)
        interpreter.run(input, output)
        return output
    }

    override fun close() {
        interpreter.close()
    }
}

/**
 * Manager responsible for orchestrating multiple accelerators.
 * Using @Singleton because Interpreter initialization is expensive.
 */
@Singleton
class ParallelInferenceManager @Inject constructor(
    private val context: Context
) {
    private var gpuEngine: GpuInferenceEngine? = null
    private var npuEngine: NpuInferenceEngine? = null

    // Lazy initialization to avoid blocking app startup
    suspend fun initialize() = withContext(Dispatchers.IO) {
        Log.d("AI_PERF", "Initializing Accelerators...")
        // In a real app, load .tflite files from assets into ByteBuffers
        val dummyBuffer = ByteBuffer.allocateDirect(1024).order(ByteOrder.nativeOrder())
        
        gpuEngine = GpuInferenceEngine(context, dummyBuffer)
        npuEngine = NpuInferenceEngine(context, dummyBuffer)
        Log.d("AI_PERF", "Accelerators Ready.")
    }

    /**
     * The core parallelization logic.
     * Uses Coroutines 'async' to trigger inference on multiple devices simultaneously.
     */
    suspend fun performParallelInference(input: ByteBuffer): ParallelInferenceResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // Launch both inferences in parallel
        val gpuDeferred = async {
            Log.d("AI_PERF", "GPU starting on ${Thread.currentThread().name}")
            gpuEngine?.runInference(input) ?: floatArrayOf()
        }

        val npuDeferred = async {
            Log.d("AI_PERF", "NPU starting on ${Thread.currentThread().name}")
            npuEngine?.runInference(input) ?: floatArrayOf()
        }

        // Wait for both to complete (Join point)
        val gpuRes = gpuDeferred.await()
        val npuRes = npuDeferred.await()
        
        val endTime = System.currentTimeMillis()

        ParallelInferenceResult(
            gpuResult = gpuRes,
            npuResult = npuRes,
            latencyMs = endTime - startTime
        )
    }

    fun release() {
        gpuEngine?.close()
        npuEngine?.close()
    }
}

/**
 * ViewModel that connects the AI logic to the Compose UI.
 */
@AndroidEntryPoint
class InferenceViewModel @Inject constructor(
    private val inferenceManager: ParallelInferenceManager
) : ViewModel() {

    private val _uiState = MutableStateFlow<ParallelInferenceResult?>(null)
    val uiState: StateFlow<ParallelInferenceResult?> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            inferenceManager.initialize()
        }
    }

    fun processImage() {
        viewModelScope.launch {
            // Simulate an input buffer from a camera frame
            val inputBuffer = ByteBuffer.allocateDirect(224 * 224 * 3 * 4) 
                .order(ByteOrder.nativeOrder())

            try {
                // Execute parallel inference
                val result = inferenceManager.performParallelInference(inputBuffer)
                _uiState.value = result
            } catch (e: Exception) {
                Log.e("AI_PERF", "Inference failed", e)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        inferenceManager.release()
    }
}
