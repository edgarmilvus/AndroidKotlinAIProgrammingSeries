
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.PriorityQueue

data class Frame(val id: Int, val buffer: ByteBuffer)
data class InferenceResult(val id: Int, val data: FloatArray)

interface InferenceWorker {
    suspend fun process(frame: Frame): InferenceResult
}

class MultiAcceleratorLoadBalancer(
    private val workers: List<InferenceWorker>,
    private val scope: CoroutineScope
) {
    private val resultBuffer = PriorityQueue<InferenceResult>(compareBy { it.id })
    private val bufferMutex = Mutex()
    private var nextFrameToEmit = 0

    suspend fun processStream(frameStream: ReceiveChannel<Frame>, onResult: (InferenceResult) -> Unit) {
        coroutineScope {
            for (frame in frameStream) {
                // Round-robin distribution
                val worker = workers[frame.id % workers.size]
                
                launch(Dispatchers.Default) {
                    val result = worker.process(frame)
                    
                    bufferMutex.withLock {
                        resultBuffer.add(result)
                        // Emit all ready frames in sequence
                        while (resultBuffer.isNotEmpty() && resultBuffer.peek().id == nextFrameToEmit) {
                            onResult(resultBuffer.poll())
                            nextFrameToEmit++
                        }
                    }
                }
            }
        }
    }
}

class NpuWorker(val interpreter: Interpreter) : InferenceWorker {
    override suspend fun process(frame: Frame): InferenceResult {
        val out = FloatArray(10)
        interpreter.run(frame.buffer, out)
        return InferenceResult(frame.id, out)
    }
}
// GPUWorker implementation would be similar...
