
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton

enum class Accelerator { NPU, GPU, CPU }

@Singleton
class AdaptiveInferenceProvider @Inject constructor(
    private val context: Context
) {
    private val _activeAccelerator = MutableStateFlow(Accelerator.CPU)
    val activeAccelerator: StateFlow<Accelerator> = _activeAccelerator

    private var interpreter: Interpreter? = null
    private val LATENCY_THRESHOLD_NS = 50_000_000L // 50ms

    suspend fun initializeBestDelegate() = withContext(Dispatchers.IO) {
        val priorityChain = listOf(
            Accelerator.NPU to { Interpreter.Options().addDelegate(NnApiDelegate()) },
            Accelerator.GPU to { Interpreter.Options().addDelegate(GpuDelegate()) },
            Accelerator.CPU to { Interpreter.Options().setNumThreads(4) }
        )

        for ((accel, optionsProvider) in priorityChain) {
            try {
                val options = optionsProvider()
                val testInterpreter = Interpreter(loadModel(), options)
                
                // Warm-up phase: run dummy inference to trigger JIT/SRAM loading
                val dummyInput = ByteBuffer.allocateDirect(1 * 224 * 224 * 3)
                val dummyOutput = FloatArray(10)
                
                val start = System.nanoTime()
                testInterpreter.run(dummyInput, dummyOutput)
                val duration = System.nanoTime() - start

                if (accel == Accelerator.NPU && duration > LATENCY_THRESHOLD_NS) {
                    continue // NPU is too slow (likely falling back to CPU internally)
                }

                // Success: Assign this as the primary interpreter
                this@AdaptiveInferenceProvider.interpreter = testInterpreter
                _activeAccelerator.value = accel
                return@withContext 
            } catch (e: Exception) {
                // Log error and fallback to next in chain
                println("Delegate ${accel.name} failed: ${e.message}")
            }
        }
    }

    private fun loadModel(): java.nio.MappedByteBuffer = TODO("Load model")
    
    fun runInference(input: ByteBuffer, output: Any) {
        interpreter?.run(input, output) ?: throw IllegalStateException("Interpreter not initialized")
    }
}
