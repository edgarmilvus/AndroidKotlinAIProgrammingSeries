
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edgeai.performance.data.ModelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import javax.inject.Inject

sealed class InferenceState {
    object Idle : InferenceState()
    object Processing : InferenceState()
    data class Success(val label: String, val confidence: Float) : InferenceState()
    data class Error(val message: String) : InferenceState()
}

@HiltViewModel
class ClassificationViewModel @Inject constructor(
    private val repository: ModelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<InferenceState>(InferenceState.Idle)
    val uiState: StateFlow<InferenceState> = _uiState.asStateFlow()

    /**
     * Triggered by the UI or a CameraX analyzer.
     * Uses Dispatchers.Default to prevent blocking the Main thread.
     */
    fun runInference(imageBuffer: ByteBuffer) {
        viewModelScope.launch {
            _uiState.value = InferenceState.Processing

            try {
                // Switch to Default dispatcher for heavy computation
                val results = withContext(Dispatchers.Default) {
                    repository.classify(imageBuffer)
                }

                // Post-process the results (find the index with the max probability)
                val topResult = results.withIndex().maxByOrNull { it.value }
                
                if (topResult != null) {
                    _uiState.value = InferenceState.Success(
                        label = "Class ${topResult.index}", 
                        confidence = topResult.value
                    )
                }
            } catch (e: Exception) {
                _uiState.value = InferenceState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }
}
