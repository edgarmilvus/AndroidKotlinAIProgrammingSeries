
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.data

import android.content.Context
import android.content.res.AssetFileDescriptor
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ModelRepository handles the heavy lifting of AI inference.
 * It is marked as @Singleton to avoid reloading the model into memory 
 * multiple times, which would cause catastrophic memory pressure.
 */
@Singleton
class ModelRepository @Inject constructor(private val context: Context) : AutoCloseable {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        try {
            // 1. Load the model file as a MappedByteBuffer
            // This avoids loading the entire model into the JVM heap, 
            // reducing GC pressure and startup time.
            val modelBuffer = loadModelFile("model_quantized.tflite")

            // 2. Configure Hardware Acceleration
            // We initialize the GpuDelegate. On devices with a compatible NPU, 
            // TFLite will attempt to route operations there via the GPU driver.
            val options = Interpreter.Options().apply {
                gpuDelegate = GpuDelegate().also { this@ModelRepository.gpuDelegate = it }
                setNumThreads(4) // Fallback for CPU operations
            }

            interpreter = Interpreter(modelBuffer, options)
        } catch (e: Exception) {
            e.printStackTrace()
            // In a real app, implement a fallback to CPU-only mode here
        }
    }

    private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = context.assets.openFd(modelPath)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    /**
     * Performs inference on the provided input buffer.
     * @param inputBuffer A direct ByteBuffer containing the pre-processed image pixels.
     * @return A FloatArray containing the classification probabilities.
     */
    fun classify(inputBuffer: ByteBuffer): FloatArray {
        val outputBuffer = Array(1) { FloatArray(1001) } // Assuming 1001 classes (ImageNet)
        
        // The actual inference call. This is a JNI call to the C++ TFLite runtime.
        interpreter?.run(inputBuffer, outputBuffer)
        
        return outputBuffer[0]
    }

    override fun close() {
        // CRITICAL: GPU delegates and Interpreters hold native memory.
        // Failing to close them leads to native memory leaks that the JVM GC cannot fix.
        interpreter?.close()
        gpuDelegate?.close()
    }
}
