
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.orchestration

import android.content.Context
import android.os.Build
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.FileInputStream
import java.nio.channels.FileChannel

/**
 * Represents the current hardware acceleration state.
 */
sealed class AccelerationMode {
    object NPU : AccelerationMode() // NNAPI / TPU
    object GPU : AccelerationMode() // OpenCL / Vulkan
    object CPU : AccelerationMode() // XNNPACK
}

/**
 * Data class for Inference Results to be consumed by the UI.
 */
data class DetectionResult(
    val boundingBoxes: List<RectF>,
    val labels: List<String>,
    val confidence: Float,
    val latencyMs: Long,
    val activeHardware: AccelerationMode
)

data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * The Hardware Orchestrator manages the lifecycle of TFLite Interpreters
 * and handles the dynamic switching of delegates.
 */
@Singleton
class AIHardwareOrchestrator @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private var currentDelegate: Any? = null
    private var activeMode: AccelerationMode = AccelerationMode.CPU

    // Optimized for AI workloads: High priority, multi-threaded
    private val aiDispatcher = Dispatchers.Default 

    /**
     * Initializes the interpreter based on the available hardware and model quantization.
     * @param modelPath Path to the .tflite file in assets
     * @param useInt8 Whether the model is INT8 quantized (required for NPU)
     */
    suspend fun initializeEngine(modelPath: String, useInt8: Boolean) = withContext(aiDispatcher) {
        try {
            val options = Interpreter.Options()
            
            // Logic for Hardware Selection
            activeMode = when {
                // NPU is preferred for INT8 on Android 9+ (API 28)
                useInt8 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P -> {
                    Log.i("AI_ORCH", "Optimizing for NPU via NNAPI")
                    currentDelegate = NnApiDelegate()
                    options.addDelegate(currentDelegate)
                    AccelerationMode.NPU
                }
                // GPU is preferred for FP16/FP32
                else -> {
                    Log.i("AI_ORCH", "Optimizing for GPU via GPU Delegate")
                    currentDelegate = GpuDelegate()
                    options.addDelegate(currentDelegate)
                    AccelerationMode.GPU
                }
            }

            // Zero-copy model loading using MappedByteBuffer
            val modelBuffer = loadModelFile(modelPath)
            interpreter = Interpreter(modelBuffer, options)
            
            // Warm-up: Perform a dummy inference to compile shaders/graphs
            performWarmup()
            
        } catch (e: Exception) {
            Log.e("AI_ORCH", "Hardware acceleration failed, falling back to CPU", e)
            activeMode = AccelerationMode.CPU
            interpreter = Interpreter(loadModelFile(modelPath))
        }
    }

    private fun loadModelFile(path: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(path).fileDescriptor)
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    private fun performWarmup() {
        // Create a dummy input buffer to trigger JIT/Shader compilation
        val dummyInput = ByteBuffer.allocateDirect(1 * 224 * 224 * 3).apply {
            order(ByteOrder.nativeOrder())
        }
        val dummyOutput = Array(1) { FloatArray(10) }
        interpreter?.run(dummyInput, dummyOutput)
    }

    fun runInference(inputBuffer: ByteBuffer): DetectionResult {
        val startTime = System.currentTimeMillis()
        
        // Output tensors (Adjust based on your specific model's output shape)
        val locations = Array(1) { Array(10) { FloatArray(4) } }
        val classes = Array(1) { FloatArray(10) }
        val scores = Array(1) { FloatArray(10) }
        val numDetections = FloatArray(1)

        val outputs = mapOf(
            0 to locations,
            1 to classes,
            2 to scores,
            3 to numDetections
        )

        interpreter?.runForMultipleInputsOutputs(arrayOf(inputBuffer), outputs)
        
        val latency = System.currentTimeMillis() - startTime
        
        // Process raw tensors into domain objects
        return DetectionResult(
            boundingBoxes = emptyList(), // Simplified for brevity
            labels = emptyList(),        // Simplified for brevity
            confidence = scores[0][0],
            latencyMs = latency,
            activeHardware = activeMode
        )
    }

    fun close() {
        interpreter?.close()
        (currentDelegate as? GpuDelegate)?.close()
        (currentDelegate as? NnApiDelegate)?.close()
    }
}

/**
 * Repository layer to abstract the AI logic from the ViewModel.
 */
@Singleton
class InferenceRepository @Inject constructor(
    private val orchestrator: AIHardwareOrchestrator
) {
    private val _inferenceState = MutableStateFlow<DetectionResult?>(null)
    val inferenceState = _inferenceState.asStateFlow()

    suspend fun setup(modelName: String, isQuantized: Boolean) {
        orchestrator.initializeEngine(modelName, isQuantized)
    }

    suspend fun processFrame(buffer: ByteBuffer) = withContext(Dispatchers.Default) {
        val result = orchestrator.runInference(buffer)
        _inferenceState.emit(result)
    }
}

/**
 * ViewModel implementing MVI pattern for AI state management.
 */
@dagger.hilt.android.lifecycle.HiltViewModel
class AIViewModel @Inject constructor(
    private val repository: InferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(AIUiState())
    val uiState = _uiState.asStateFlow()

    fun onFrameReceived(buffer: ByteBuffer) {
        viewModelScope.launch {
            repository.processFrame(buffer)
            repository.inferenceState.collect { result ->
                result?.let {
                    _uiState.update { state -> 
                        state.copy(lastDetection = it, isProcessing = false) 
                    }
                }
            }
        }
    }

    fun initAI() {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            repository.setup("model_quantized.tflite", isQuantized = true)
            _uiState.update { it.copy(isProcessing = false) }
        }
    }
}

data class AIUiState(
    val lastDetection: DetectionResult? = null,
    val isProcessing: Boolean = false
)

@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideOrchestrator(@ApplicationContext context: Context) = AIHardwareOrchestrator(context)
}
