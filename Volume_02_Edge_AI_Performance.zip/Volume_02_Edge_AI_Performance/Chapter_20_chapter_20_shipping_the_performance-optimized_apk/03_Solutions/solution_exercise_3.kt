
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import kotlinx.coroutines.*
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import kotlin.math.abs

data class BenchmarkResult(
    val modelName: String,
    val coldStartMs: Long,
    val avgWarmStartMs: Double,
    val peakRamMb: Double,
    val accuracyLoss: Double
)

class QuantizationBenchmarker(private val context: Context) {

    suspend fun runSuite(
        models: List<Pair<String, ByteBuffer>>, 
        goldenInputs: List<ByteBuffer>, 
        expectedOutputs: List<FloatArray>>
    ): List<BenchmarkResult> = withContext(Dispatchers.Default) {
        models.map { (name, modelBuffer) ->
            val interpreter = Interpreter(modelBuffer)
            
            // 1. Cold Start
            val startTime = System.nanoTime()
            runInference(interpreter, goldenInputs[0])
            val coldStart = (System.nanoTime() - startTime) / 1_000_000

            // 2. Warm Start (99 iterations)
            val warmStartTimes = mutableListOf<Long>()
            repeat(99) {
                val start = System.nanoTime()
                runInference(interpreter, goldenInputs[0])
                warmStartTimes.add((System.nanoTime() - start) / 1_000_000)
            }
            val avgWarmStart = warmStartTimes.average()

            // 3. Memory Footprint
            val memoryInfo = ActivityManager.MemoryInfo()
            (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memoryInfo)
            val peakRam = Debug.getNativeHeapAllocatedSize().toDouble() / (1024 * 1024)

            // 4. Precision Drift
            var totalError = 0.0
            goldenInputs.forEachIndexed { index, input ->
                val output = FloatArray(expectedOutputs[index].size)
                runInference(interpreter, input, output)
                totalError += calculateL2Norm(output, expectedOutputs[index])
            }
            val avgAccuracyLoss = totalError / goldenInputs.size

            interpreter.close()
            BenchmarkResult(name, coldStart, avgWarmStart, peakRam, avgAccuracyLoss)
        }
    }

    private fun runInference(interpreter: Interpreter, input: ByteBuffer, output: FloatArray? = null) {
        if (output == null) {
            // Dummy output for timing
            val dummy = FloatArray(1) 
            interpreter.run(input, dummy)
        } else {
            interpreter.run(input, output)
        }
    }

    private fun calculateL2Norm(actual: FloatArray, expected: FloatArray): Double {
        var sum = 0.0
        for (i in actual.indices) {
            sum += abs(actual[i] - expected[i]).toDouble()
        }
        return sum / actual.size
    }
}
