
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.os.Build
import javax.inject.Qualifier
import javax.inject.Singleton
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class OptimizedInterpreter

sealed class HardwareProfile(
    val preferredDelegate: HardwareAccelerator,
    val cpuThreads: Int,
    val useFp16: Boolean
) {
    object Snapdragon8Gen2 : HardwareProfile(HardwareAccelerator.NPU, 4, true)
    object MaliG710 : HardwareProfile(HardwareAccelerator.GPU, 4, false)
    object GenericSafe : HardwareProfile(HardwareAccelerator.CPU, 2, false)
}

@Singleton
class SoCMapper @Inject constructor() {
    fun getProfile(): HardwareProfile {
        val board = Build.BOARD ?: ""
        val hardware = Build.HARDWARE ?: ""
        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL else ""

        return when {
            socModel.contains("SM8550") || hardware.contains("qcom") -> HardwareProfile.Snapdragon8Gen2
            hardware.contains("mali") -> HardwareProfile.MaliG710
            else -> HardwareProfile.GenericSafe
        }
    }
}

@Module
@InstallIn(SingletonComponent::class)
object SoCModule {
    @Provides
    @Singleton
    @OptimizedInterpreter
    fun provideOptimizedInterpreter(
        socMapper: SoCMapper,
        orchestrator: DelegateOrchestrator
    ): Interpreter {
        val profile = socMapper.getProfile()
        val options = Interpreter.Options().apply {
            setNumThreads(profile.cpuThreads)
            if (profile.useFp16) {
                // Logic to enable FP16 via GPU delegate
            }
        }
        
        // Apply the preferred delegate from the profile
        when (profile.preferredDelegate) {
            HardwareAccelerator.NPU -> options.addDelegate(NnApiDelegate())
            HardwareAccelerator.GPU -> options.addDelegate(GpuDelegate())
            HardwareAccelerator.CPU -> { /* XNNPACK default */ }
        }
        
        return Interpreter(loadModel(), options)
    }
    
    private fun loadModel(): ByteBuffer { /* ... */ }
}
