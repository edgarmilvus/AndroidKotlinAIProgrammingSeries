
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// Note: This code assumes a Dynamic Feature Module named ":ai_models" exists
import android.content.Context
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallSessionState
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class ModelDownloadState {
    object NotDownloaded : ModelDownloadState()
    data class Downloading(val progress: Int) : ModelDownloadState()
    object Ready : ModelDownloadState()
    data class Error(val message: String) : ModelDownloadState()
}

@Singleton
class ModelDeliveryManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val splitInstallManager = SplitInstallManagerFactory.create(context)
    
    private val _downloadState = MutableStateFlow<ModelDownloadState>(ModelDownloadState.NotDownloaded)
    val downloadState = _downloadState.asStateFlow()

    fun downloadModelModule() {
        val request = SplitInstallRequest.newBuilder()
            .addModule("ai_models")
            .build()

        splitInstallManager.startInstall(request)
            .addOnSuccessListener { sessionId -> 
                // Monitor progress via listener
            }
            .addOnFailureListener { e -> 
                _downloadState.value = ModelDownloadState.Error(e.localizedMessage ?: "Download failed")
            }

        splitInstallManager.registerListener { state ->
            if (state.moduleNames().contains("ai_models")) {
                when (state.status()) {
                    SplitInstallSessionStatus.DOWNLOADING -> {
                        val progress = (state.bytesDownloaded() * 100 / state.totalBytesToDownload()).toInt()
                        _downloadState.value = ModelDownloadState.Downloading(progress)
                    }
                    SplitInstallSessionStatus.INSTALLED -> {
                        _downloadState.value = ModelDownloadState.Ready
                    }
                    SplitInstallSessionStatus.FAILED -> {
                        _downloadState.value = ModelDownloadState.Error("Installation failed")
                    }
                }
            }
        }
    }

    fun getModelAssetPath(fileName: String): String {
        // Crucial: In DFMs, we must use the SplitCompat context to access assets
        val assetManager = context.assets 
        // In a real DFM, you'd use SplitCompat.install(context) in the Application class
        return assetManager.openFd(fileName).let { it.absolutePath }
    }
}

@Composable
fun ModelDownloadScreen(viewModel: ModelViewModel = hiltViewModel()) {
    val state by viewModel.deliveryManager.downloadState.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (state) {
            is ModelDownloadState.NotDownloaded -> {
                Button(onClick = { viewModel.startDownload() }) { Text("Download AI Model") }
            }
            is ModelDownloadState.Downloading -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(progress = (state as ModelDownloadState.Downloading).progress / 100f)
                    Text("Downloading: ${(state as ModelDownloadState.Downloading).progress}%")
                }
            }
            is ModelDownloadState.Ready -> {
                Text("Model Ready for Inference!", color = Color.Green)
            }
            is ModelDownloadState.Error -> {
                Text("Error: ${(state as ModelDownloadState.Error).message}", color = Color.Red)
            }
        }
    }
}
