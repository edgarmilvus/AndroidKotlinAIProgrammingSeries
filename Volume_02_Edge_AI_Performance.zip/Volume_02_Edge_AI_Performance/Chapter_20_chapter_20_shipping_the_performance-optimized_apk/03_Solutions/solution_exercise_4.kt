
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

enum class ThermalStrategy {
    MAX_PERFORMANCE, // NPU
    BALANCED,        // GPU
    POWER_SAVER,     // CPU Quantized
    CRITICAL         // Throttle/Pause
}

@Singleton
class ThermalRuntimeManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val _currentStrategy = MutableStateFlow(ThermalStrategy.MAX_PERFORMANCE)
    val currentStrategy = _currentStrategy.asStateFlow()

    private var lastSwitchTime = 0L
    private val HYSTERESIS_DELAY = 10_000L // 10 seconds cooldown

    init {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            powerManager.addThermalStatusListener { status ->
                handleThermalStatus(status)
            }
        }
    }

    private fun handleThermalStatus(status: Int) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastSwitchTime < HYSTERESIS_DELAY) return

        val newStrategy = when (status) {
            PowerManager.THERMAL_STATUS_NONE, 
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalStrategy.MAX_PERFORMANCE
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalStrategy.BALANCED
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalStrategy.POWER_SAVER
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStrategy.CRITICAL
            else -> ThermalStrategy.BALANCED
        }

        if (newStrategy != _currentStrategy.value) {
            _currentStrategy.value = newStrategy
            lastSwitchTime = currentTime
        }
    }
}

class ModelRuntime @Inject constructor(
    private val thermalManager: ThermalRuntimeManager,
    private val orchestrator: DelegateOrchestrator
) {
    private var interpreter: Interpreter? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    init {
        scope.launch {
            thermalManager.currentStrategy.collect { strategy ->
                reconfigureInterpreter(strategy)
            }
        }
    }

    private suspend fun reconfigureInterpreter(strategy: ThermalStrategy) {
        // Avoid UI freeze by recreating interpreter in background
        val options = when (strategy) {
            ThermalStrategy.MAX_PERFORMANCE -> orchestrator.getNpuOptions()
            ThermalStrategy.BALANCED -> orchestrator.getGpuOptions()
            ThermalStrategy.POWER_SAVER -> orchestrator.getCpuOptions()
            ThermalStrategy.CRITICAL -> {
                interpreter?.close()
                interpreter = null
                return
            }
        }
        
        val oldInterpreter = interpreter
        interpreter = Interpreter(loadModelFile(), options)
        oldInterpreter?.close()
    }
    
    private fun loadModelFile(): ByteBuffer { /* ... */ }
}
