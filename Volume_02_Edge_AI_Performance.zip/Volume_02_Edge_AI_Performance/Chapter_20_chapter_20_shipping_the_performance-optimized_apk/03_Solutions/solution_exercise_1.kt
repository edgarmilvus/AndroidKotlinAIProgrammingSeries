
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import javax.inject.Inject
import javax.inject.Singleton

sealed class HardwareAccelerator(val displayName: String) {
    object NPU : HardwareAccelerator("Qualcomm Hexagon/Google Tensor NPU")
    object GPU : HardwareAccelerator("Mobile GPU (OpenCL/OpenGL)")
    object CPU : HardwareAccelerator("CPU (XNNPACK)")
}

@Singleton
class DelegateOrchestrator @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val _activeAccelerator = MutableStateFlow<HardwareAccelerator>(HardwareAccelerator.CPU)
    val activeAccelerator: StateFlow<HardwareAccelerator> = _activeAccelerator.asStateFlow()

    private var currentDelegate: Interpreter.Options? = null

    fun getOptimizedOptions(): Interpreter.Options {
        if (currentDelegate != null) return currentDelegate!!

        val options = Interpreter.Options()
        
        // 1. Priority: NPU via NNAPI
        if (isNnApiSupported()) {
            try {
                val nnApiDelegate = NnApiDelegate()
                options.addDelegate(nnApiDelegate)
                _activeAccelerator.value = HardwareAccelerator.NPU
                currentDelegate = options
                return options
            } catch (e: Exception) {
                // Fallback to next priority
            }
        }

        // 2. Priority: GPU
        try {
            val gpuDelegate = GpuDelegate()
            options.addDelegate(gpuDelegate)
            _activeAccelerator.value = HardwareAccelerator.GPU
            currentDelegate = options
            return options
        } catch (e: Exception) {
            // Fallback to CPU
        }

        // 3. Priority: CPU with XNNPACK (Enabled by default in recent TFLite versions)
        options.setNumThreads(Runtime.getRuntime().availableProcessors())
        _activeAccelerator.value = HardwareAccelerator.CPU
        currentDelegate = options
        return options
    }

    private fun isNnApiSupported(): Boolean {
        // Simple check for API level; in production, use a more robust 
        // check or attempt to instantiate the delegate.
        return android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P
    }
}

@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideDelegateOrchestrator(@ApplicationContext context: Context) = 
        DelegateOrchestrator(context)
}

// --- Compose UI Integration ---
@Composable
fun HardwareStatusScreen(viewModel: AIViewModel = hiltViewModel()) {
    val accelerator by viewModel.orchestrator.activeAccelerator.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "AI Engine Status", style = MaterialTheme.typography.h5)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Running on: ${accelerator.displayName}",
            color = MaterialTheme.colors.primary,
            style = MaterialTheme.typography.body1
        )
    }
}
