
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.edgeai.performance.latency

import android.content.Context
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.system.measureNanoTime

/**
 * Hardware Acceleration Modes for Edge AI.
 */
enum class AccelerationMode {
    NPU_HIGH_PRECISION, // Full INT8/FP16 on NPU
    GPU_FALLBACK,       // Fallback to GPU if NPU throttles
    CPU_TINY_MODEL      // Extreme fallback to quantized tiny model on CPU
}

/**
 * Telemetry data representing a single inference event.
 */
data class InferenceMetrics(
    val latencyMs: Double,
    val mode: AccelerationMode,
    val timestamp: Long = System.currentTimeMillis(),
    val thermalThrottled: Boolean = false
)

/**
 * The Repository handles the actual interaction with the AI Hardware.
 * It wraps the TFLite interpreter and measures execution time.
 */
@Singleton
class HardwareInferenceRepository @Inject constructor(
    private val context: Context
) {
    private val _metricsFlow = MutableSharedFlow<InferenceMetrics>(replay = 1)
    val metricsFlow = _metricsFlow.asSharedFlow()

    private var currentMode = AccelerationMode.NPU_HIGH_PRECISION
    
    // Simulation of an AI Model's inference process
    // In a real scenario, this would call interpreter.run(input, output)
    suspend fun runInference(inputData: FloatArray): FloatArray = withContext(Dispatchers.Default) {
        var result = FloatArray(10)
        var isThrottled = false

        val nanoTime = measureNanoTime {
            // Simulate hardware-specific latency
            val simulatedDelay = when (currentMode) {
                AccelerationMode.NPU_HIGH_PRECISION -> if (isThrottled) 45L else 12L
                AccelerationMode.GPU_FALLBACK -> 22L
                AccelerationMode.CPU_TINY_MODEL -> 30L
            }
            delay(simulatedDelay) // Simulate NPU processing time
            result = FloatArray(10) { it.toFloat() }
        }

        val latencyMs = nanoTime / 1_000_000.0
        
        // Heuristic to detect thermal throttling (simulated)
        if (currentMode == AccelerationMode.NPU_HIGH_PRECISION && latencyMs > 30.0) {
            isThrottled = true
        }

        _metricsFlow.emit(InferenceMetrics(latencyMs, currentMode, thermalThrottled = isThrottled))
        return@withContext result
    }

    fun setAccelerationMode(mode: AccelerationMode) {
        Log.d("HardwareRepo", "Switching acceleration mode to: $mode")
        this.currentMode = mode
    }
}

/**
 * ViewModel that orchestrates the latency visualization and hardware switching logic.
 */
@HiltViewModel
class LatencyOrchestratorViewModel @Inject constructor(
    private val repository: HardwareInferenceRepository
) : androidx.lifecycle.ViewModel() {

    // State for the UI to visualize
    private val _uiState = MutableStateFlow(LatencyUiState())
    val uiState: StateFlow<LatencyUiState> = _uiState.asStateFlow()

    private val latencyHistory = ConcurrentLinkedQueue<Double>()
    private val MAX_HISTORY_SIZE = 100

    init {
        observeLatency()
    }

    private fun observeLatency() {
        viewModelScope.launch {
            repository.metricsFlow.collect { metrics ->
                updateLatencyHistory(metrics.latencyMs)
                evaluateHardwareStrategy(metrics)
                
                _uiState.update { it.copy(
                    currentLatency = metrics.latencyMs,
                    currentMode = metrics.mode,
                    isThrottled = metrics.thermalThrottled,
                    history = latencyHistory.toList()
                )}
            }
        }
    }

    private fun updateLatencyHistory(latency: Double) {
        latencyHistory.add(latency)
        if (latencyHistory.size > MAX_HISTORY_SIZE) {
            latencyHistory.poll()
        }
    }

    /**
     * The "Brain" of the Orchestrator. 
     * Implements a hysteresis-based switching logic to prevent "jittering" 
     * between NPU and GPU.
     */
    private fun evaluateHardwareStrategy(metrics: InferenceMetrics) {
        val avgLatency = latencyHistory.average()
        
        when {
            // If NPU is throttling and average latency exceeds 30ms, move to GPU
            metrics.mode == AccelerationMode.NPU_HIGH_PRECISION && avgLatency > 30.0 -> {
                repository.setAccelerationMode(AccelerationMode.GPU_FALLBACK)
            }
            // If GPU is also struggling, move to CPU Tiny Model
            metrics.mode == AccelerationMode.GPU_FALLBACK && avgLatency > 40.0 -> {
                repository.setAccelerationMode(AccelerationMode.CPU_TINY_MODEL)
            }
            // Recovery: If we are on CPU and latency is very low, try NPU again
            metrics.mode == AccelerationMode.CPU_TINY_MODEL && avgLatency < 15.0 -> {
                repository.setAccelerationMode(AccelerationMode.NPU_HIGH_PRECISION)
            }
        }
    }

    fun processFrame(data: FloatArray) {
        viewModelScope.launch {
            repository.runInference(data)
        }
    }
}

data class LatencyUiState(
    val currentLatency: Double = 0.0,
    val currentMode: AccelerationMode = AccelerationMode.NPU_HIGH_PRECISION,
    val isThrottled: Boolean = false,
    val history: List<Double> = emptyList()
)

/**
 * Hilt Module for providing dependencies.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIHardwareModule {
    @Provides
    @Singleton
    fun provideRepository(@BindsInstance context: Context): HardwareInferenceRepository {
        return HardwareInferenceRepository(context)
    }
}
