
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.camera

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.edgeai.performance.ui.NpuLatencyViewModel
import java.nio.ByteBuffer
import java.nio.ByteOrder

class NpuAnalyzer(private val viewModel: NpuLatencyViewModel) : ImageAnalysis.Analyzer {
    
    override fun analyze(image: ImageProxy) {
        // 1. Pre-processing: Convert ImageProxy to ByteBuffer
        // In a real app, you would resize the image to the model's input size (e.g., 224x224)
        val buffer = ByteBuffer.allocateDirect(224 * 224 * 3 * 4) // Example size
        buffer.order(ByteOrder.nativeOrder())
        
        // [SIMULATED PRE-PROCESSING]
        // In production, use YUV to RGB conversion and normalization here.
        
        // 2. Pass the buffer to the ViewModel for inference and latency measurement
        viewModel.processFrame(buffer)
        
        // 3. Crucial: Close the image to allow the next frame to be processed
        image.close()
    }
}
