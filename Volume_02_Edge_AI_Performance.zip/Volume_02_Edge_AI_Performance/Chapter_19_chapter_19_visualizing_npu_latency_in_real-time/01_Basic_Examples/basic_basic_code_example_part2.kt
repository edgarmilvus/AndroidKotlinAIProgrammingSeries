
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.data

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository responsible for managing the TFLite Interpreter and 
 * measuring the raw inference latency on the NPU.
 */
@Singleton
class NpuLatencyRepository @Inject constructor(private val context: Context) {
    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        try {
            // 1. Initialize the NNAPI Delegate to force NPU acceleration
            // NNAPI automatically selects the best available accelerator (NPU -> GPU -> CPU)
            nnApiDelegate = NnApiDelegate()
            
            val options = Interpreter.Options().apply {
                addDelegate(nnApiDelegate)
                setNumThreads(4) // CPU fallback threads
            }

            // 2. Load the model file from assets
            val modelBuffer = loadModelFile("model_quantized.tflite")
            interpreter = Interpreter(modelBuffer, options)
            Log.d("NPU_REPO", "Interpreter initialized with NNAPI Delegate")
        } catch (e: Exception) {
            Log.e("NPU_REPO", "Failed to initialize NPU: ${e.message}")
        }
    }

    /**
     * Performs inference and returns the latency in milliseconds.
     * @param inputData The pre-processed tensor data.
     * @return The time taken for the NPU to process the request.
     */
    fun runInferenceWithLatency(inputData: ByteBuffer): Double {
        val output = Array(1) { FloatArray(1000) } // Assume 1000 classes
        
        // Start timing
        val startTime = System.nanoTime()
        
        // Execute the model
        interpreter?.run(inputData, output)
        
        // End timing
        val endTime = System.nanoTime()
        
        // Calculate duration in milliseconds (1ms = 1,000,000ns)
        return (endTime - startTime).toDouble() / 1_000_000.0
    }

    private fun loadModelFile(modelPath: String): ByteBuffer {
        val fileInputStream = FileInputStream(context.assets.openFd(modelPath))
        val fileChannel = fileInputStream.channel
        val startOffset = 0L
        val declaredLength = fileChannel.size()
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun close() {
        interpreter?.close()
        nnApiDelegate?.close()
    }
}
