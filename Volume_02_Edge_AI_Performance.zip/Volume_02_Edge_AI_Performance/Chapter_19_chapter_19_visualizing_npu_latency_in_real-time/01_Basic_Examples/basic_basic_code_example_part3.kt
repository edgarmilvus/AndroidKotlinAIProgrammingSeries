
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.edgeai.performance.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edgeai.performance.data.NpuLatencyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NpuLatencyViewModel @Inject constructor(
    private val repository: NpuLatencyRepository
) : ViewModel() {

    // StateFlow to hold the current latency value for the UI
    private val _latencyState = MutableStateFlow(0.0)
    val latencyState: StateFlow<Double> = _latencyState.asStateFlow()

    // A list to hold the last 50 readings for a real-time graph
    private val _latencyHistory = MutableStateFlow<List<Double>>(emptyList())
    val latencyHistory: StateFlow<List<Double>> = _latencyHistory.asStateFlow()

    /**
     * Processes the frame on a background thread and updates the state.
     */
    fun processFrame(inputData: java.nio.ByteBuffer) {
        viewModelScope.launch(Dispatchers.Default) {
            // Measure latency on the Default dispatcher (optimized for CPU/Compute)
            val latency = repository.runInferenceWithLatency(inputData)
            
            // Update the current value
            _latencyState.value = latency
            
            // Update the history for the sparkline graph
            val currentHistory = _latencyHistory.value.toMutableList()
            currentHistory.add(latency)
            if (currentHistory.size > 50) {
                currentHistory.removeAt(0)
            }
            _latencyHistory.value = currentHistory
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}
