
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// A data class to hold the telemetry of a single inference pass
@Serializable
data class InferenceMetric(
    val tensorId: String,
    val computeLatencyMs: Long,
    val transferLatencyMs: Long,
    val totalLatencyMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

class NpuLatencyMonitor @Inject constructor(
    private val aiCoreClient: AiCoreClient 
) {
    // StateFlow allows the UI to always have the latest latency value
    private val _latencyStream = MutableStateFlow<InferenceMetric?>(null)
    val latencyStream: StateFlow<InferenceMetric?> = _latencyStream.asStateFlow()

    suspend fun trackInference(tensorId: String, block: suspend () -> Unit) {
        val startTime = System.nanoTime()
        
        // Execute the actual NPU work
        block()
        
        val endTime = System.nanoTime()
        val totalMs = (endTime - startTime) / 1_000_000
        
        // In a real scenario, we would extract internal NPU timings from the HAL
        val computeMs = totalMs - 2 // Mocking transfer overhead
        val transferMs = 2L 

        _latencyStream.value = InferenceMetric(
            tensorId = tensorId,
            computeLatencyMs = computeMs,
            transferLatencyMs = transferMs,
            totalLatencyMs = totalMs
        )
    }
}
