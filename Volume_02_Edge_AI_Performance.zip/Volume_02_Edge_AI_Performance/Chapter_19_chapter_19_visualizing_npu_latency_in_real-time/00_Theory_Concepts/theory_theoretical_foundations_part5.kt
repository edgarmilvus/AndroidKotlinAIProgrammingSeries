
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

@HiltViewModel
class LatencyViewModel @Inject constructor(
    private val telemetryCollector: NpuTelemetryCollector
) : ViewModel() {

    private val _uiState = MutableStateFlow(LatencyUiState())
    val uiState: StateFlow<LatencyUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            telemetryCollector.metricFlow.collect { metric ->
                updateUiState(metric)
            }
        }
    }

    private fun updateUiState(metric: InferenceMetric) {
        val current = _uiState.value
        
        // Calculate Exponential Moving Average for smoothing
        val alpha = 0.2
        val smoothedLatency = (alpha * metric.totalLatencyMs) + ((1 - alpha) * current.smoothedLatency)
        
        _uiState.update { 
            it.copy(
                smoothedLatency = smoothedLatency,
                history = (it.history + metric.totalLatencyMs).takeLast(100),
                lastMetric = metric
            )
        }
    }
}

data class LatencyUiState(
    val smoothedLatency: Double = 0.0,
    val history: List<Long> = emptyList(),
    val lastMetric: InferenceMetric? = null
)
