
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Inject
import dagger.module.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

// 1. The Wrapper Class
@Singleton
class LatencyTracker @Inject constructor() {
    private val _lastLatencyMs = MutableStateFlow(0L)
    val lastLatencyMs: StateFlow<Long> = _lastLatencyMs.asStateFlow()

    /**
     * Wraps the inference call to measure pure compute latency.
     * Returns the result of the inference lambda.
     */
    fun <T> trackInference(block: () -> T): T {
        // System.nanoTime() is used for elapsed time measurement
        val start = System.nanoTime()
        val result = block()
        val end = System.nanoTime()
        
        val durationNs = end - start
        // Convert nanoseconds to microseconds for higher precision in the Flow
        _lastLatencyMs.value = durationNs / 1000 
        return result
    }
}

// 2. ViewModel to bridge Tracker and UI
@HiltViewModel
class InferenceViewModel @Inject constructor(
    private val latencyTracker: LatencyTracker
) : ViewModel() {
    val latencyFlow = latencyTracker.lastLatencyMs
}

// 3. Compose UI
@Composable
fun LatencyScreen(viewModel: InferenceViewModel = hiltViewModel()) {
    val latencyUs by viewModel.latencyFlow.collectAsStateWithLifecycle()
    
    // Convert microseconds to milliseconds with 3 decimal places
    val formattedLatency = (latencyUs / 1000f).let { "%.3f ms".format(it) }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = "NPU Latency: $formattedLatency",
            style = MaterialTheme.typography.headlineMedium
        )
    }
}

// 4. Hilt Module
@Module
@InstallIn(SingletonComponent::class)
object LatencyModule {
    @Provides
    @Singleton
    fun provideLatencyTracker(): LatencyTracker = LatencyTracker()
}
