
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.flow.*
import java.util.*

data class LatencyStats(
    val p50: Float,
    val p95: Float,
    val p99: Float,
    val isSpiking: Boolean
)

class TailLatencyAnalyzer {
    private val windowSize = 1000
    private val measurements = mutableListOf<Float>()
    
    private val _stats = MutableStateFlow(LatencyStats(0f, 0f, 0f, false))
    val stats: StateFlow<LatencyStats> = _stats.asStateFlow()

    fun addMeasurement(latency: Float) {
        if (measurements.size >= windowSize) {
            measurements.removeAt(0)
        }
        measurements.add(latency)

        if (measurements.size >= 100) { // Need minimum sample size for percentiles
            updateStats(latency)
        }
    }

    private fun updateStats(currentLatency: Float) {
        val sorted = measurements.sorted()
        val p50 = sorted[(0.50 * sorted.size).toInt()]
        val p95 = sorted[(0.95 * sorted.size).toInt()]
        val p99 = sorted[(0.99 * sorted.size).toInt()]

        // Jitter Detection: Spike if current is > 3x the median
        val isSpiking = currentLatency > (p50 * 3)

        _stats.value = LatencyStats(p50, p95, p99, isSpiking)
    }
}
