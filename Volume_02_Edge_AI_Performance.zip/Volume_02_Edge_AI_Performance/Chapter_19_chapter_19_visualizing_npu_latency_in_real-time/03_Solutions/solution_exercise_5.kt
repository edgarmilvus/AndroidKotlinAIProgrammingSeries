
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.os.Trace
import android.util.Log

class SystemTraceWrapper(private val analyzer: TailLatencyAnalyzer) {
    
    fun <T> traceInference(block: () -> T): T {
        // 1. Mark the broad phase in Perfetto
        Trace.beginSection("AI_Pipeline_Total")
        try {
            // 2. Mark the specific NPU Compute phase
            Trace.beginSection("NPU_Inference_Compute")
            val result = block()
            Trace.endSection() // End NPU_Inference_Compute
            
            return result
        } finally {
            Trace.endSection() // End AI_Pipeline_Total
        }
    }

    fun reportLatency(latency: Float) {
        analyzer.addMeasurement(latency)
        
        // 3. Triggered Tracing: If a spike is detected, 
        // we write a high-priority log that is searchable in Perfetto
        if (analyzer.stats.value.isSpiking) {
            Trace.beginSection("LATENCY_SPIKE_DETECTED")
            Log.w("NPU_Profiler", "P99 Spike: $latency ms")
            Trace.endSection()
        }
    }
}

// Integration with the LatencyTracker from Exercise 1
class ProfessionalLatencyTracker @Inject constructor(
    private val analyzer: TailLatencyAnalyzer
) {
    private val traceWrapper = SystemTraceWrapper(analyzer)

    fun <T> track(block: () -> T): T {
        val start = System.nanoTime()
        val result = traceWrapper.traceInference(block)
        val end = System.nanoTime()
        
        val durationMs = (end - start) / 1_000_000f
        traceWrapper.reportLatency(durationMs)
        
        return result
    }
}
