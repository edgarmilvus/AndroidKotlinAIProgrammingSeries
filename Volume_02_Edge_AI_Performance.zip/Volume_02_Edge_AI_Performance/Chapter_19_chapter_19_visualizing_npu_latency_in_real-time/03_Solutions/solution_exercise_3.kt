
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer

interface InferenceEngine {
    fun runInference(input: ByteBuffer): ByteBuffer
    fun close()
}

class CpuEngine(modelBuffer: ByteBuffer) : InferenceEngine {
    private val interpreter = Interpreter(modelBuffer)
    override fun runInference(input: ByteBuffer): ByteBuffer {
        val output = ByteBuffer.allocateDirect(1024) // Simplified output size
        interpreter.run(input, output)
        return output
    }
    override fun close() = interpreter.close()
}

class GpuEngine(modelBuffer: ByteBuffer) : InferenceEngine {
    private val options = Interpreter.Options().addDelegate(GpuDelegate())
    private val interpreter = Interpreter(modelBuffer, options)
    override fun runInference(input: ByteBuffer): ByteBuffer {
        val output = ByteBuffer.allocateDirect(1024)
        interpreter.run(input, output)
        return output
    }
    override fun close() {
        interpreter.close()
        // GpuDelegate should be closed explicitly in some TFLite versions
    }
}

class NpuEngine(modelBuffer: ByteBuffer) : InferenceEngine {
    private val options = Interpreter.Options().addDelegate(NnApiDelegate())
    private val interpreter = Interpreter(modelBuffer, options)
    override fun runInference(input: ByteBuffer): ByteBuffer {
        val output = ByteBuffer.allocateDirect(1024)
        interpreter.run(input, output)
        return output
    }
    override fun close() = interpreter.close()
}

class BenchmarkManager @Inject constructor(private val modelBuffer: ByteBuffer) {
    private var currentEngine: InferenceEngine? = null
    var cpuLatency = 0f

    fun switchEngine(type: EngineType): InferenceEngine {
        currentEngine?.close() // Critical: Prevent native memory leaks
        
        currentEngine = when (type) {
            EngineType.CPU -> CpuEngine(modelBuffer)
            EngineType.GPU -> GpuEngine(modelBuffer)
            EngineType.NPU -> NpuEngine(modelBuffer)
        }
        return currentEngine!!
    }

    fun calculateSpeedup(npuLatency: Float): Float {
        return if (npuLatency > 0) cpuLatency / npuLatency else 1f
    }
}

enum class EngineType { CPU, GPU, NPU }
