
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import java.util.*

@Composable
fun LatencySparkline(latencies: List<Float>) {
    // Optimization: We use a derived state to avoid recalculating 
    // min/max on every single frame if the list hasn't changed.
    val range by remember(latencies) {
        derivedStateOf {
            val min = latencies.minOrNull() ?: 0f
            val max = latencies.maxOrNull() ?: 100f
            min to max
        }
    }

    Canvas(modifier = Modifier
        .fillMaxWidth()
        .height(100.dp)
    ) {
        if (latencies.size < 2) return@Canvas

        val (min, max) = range
        val widthStep = size.width / (latencies.size - 1)
        val heightRange = (max - min).coerceAtLeast(1f) // Avoid division by zero

        val path = Path().apply {
            latencies.forEachIndexed { index, value ->
                // Map the value to the Y-coordinate (inverted for Canvas)
                val x = index * widthStep
                val y = size.height - ((value - min) / heightRange * size.height)
                if (index == 0) moveTo(x, y) else lineTo(x, y)
            }
        }

        // Determine color based on the latest value (the end of the sparkline)
        val latest = latencies.last()
        val lineColor = when {
            latest < 15f -> Color.Green
            latest <= 30f -> Color.Yellow
            else -> Color.Red
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 3f)
        )
    }
}

// ViewModel implementation for the Circular Buffer
class SparklineViewModel : ViewModel() {
    private val _history = MutableStateFlow<List<Float>>(emptyList())
    val history: StateFlow<List<Float>> = _history.asStateFlow()

    private val buffer = ArrayDeque<Float>(60)

    fun addMeasurement(ms: Float) {
        if (buffer.size >= 60) buffer.removeFirst()
        buffer.addLast(ms)
        _history.value = buffer.toList() // Emit a new list to trigger Compose state
    }
}
