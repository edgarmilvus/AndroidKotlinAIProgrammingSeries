
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.analysis

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UI State representing the current status of the LLM Analysis.
 * Using a sealed class for MVI-style state management.
 */
sealed class AnalysisUiState {
    object Idle : AnalysisUiState()
    object Loading : AnalysisUiState()
    data class Processing(val partialResponse: String) : AnalysisUiState()
    data class Success(val finalResponse: String) : AnalysisUiState()
    data class Error(val message: String) : AnalysisUiState()
}

/**
 * Low-level engine wrapper for MediaPipe LLM Inference.
 * Handles the lifecycle of the heavy native LLM object.
 */
@Singleton
class LlmInferenceEngine @Inject constructor(
    private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the engine with hardware-aware options
    fun initialize(modelPath: String) {
        if (llmInference != null) return

        val options = LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            // Hardware Orchestration: GPU is prioritized for custom LLMs
            // to avoid blocking the main thread and reducing latency.
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Generates a response using a cold Flow to stream tokens.
     * This prevents the UI from freezing during long generations.
     */
    fun generateResponse(prompt: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("Engine not initialized")
        
        // We use the streaming API to provide immediate feedback to the user
        engine.generateResponseAsync(prompt) { partialResult, done ->
            // Note: MediaPipe callbacks happen on a background thread
            // We emit the partial result into the flow
            emit(partialResult)
        }
    }.flowOn(Dispatchers.Default) // Ensure AI computation happens off the Main thread

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * Repository layer to handle business logic and prompt engineering.
 */
@Singleton
class DocumentAnalysisRepository @Inject constructor(
    private val engine: LlmInferenceEngine
) {
    // System prompt to constrain the Custom LLM (Llama/Gemma) behavior
    private val SYSTEM_PROMPT = "You are a professional document analyst. " +
            "Provide concise, accurate summaries based ONLY on the provided text. " +
            "If the answer is not in the text, say 'Information not found'.\n\n"

    fun analyzeDocument(content: String, query: String): Flow<String> {
        val fullPrompt = "$SYSTEM_PROMPT\nContext: $content\n\nQuestion: $query\n\nAnswer:"
        return engine.generateResponse(fullPrompt)
    }

    fun initEngine(path: String) = engine.initialize(path)
}

/**
 * ViewModel implementing MVI pattern to bridge the UI and the LLM Repository.
 */
@HiltViewModel
class AnalysisViewModel @Inject constructor(
    private val repository: DocumentAnalysisRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AnalysisUiState>(AnalysisUiState.Idle)
    val uiState: StateFlow<AnalysisUiState> = _uiState.asStateFlow()

    fun initializeModel(modelPath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.initEngine(modelPath)
            } catch (e: Exception) {
                _uiState.value = AnalysisUiState.Error("Model Load Failed: ${e.localizedMessage}")
            }
        }
    }

    fun processQuery(documentText: String, userQuery: String) {
        viewModelScope.launch {
            _uiState.value = AnalysisUiState.Loading
            
            val accumulatedResponse = StringBuilder()
            
            repository.analyzeDocument(documentText, userQuery)
                .catch { e -> 
                    _uiState.value = AnalysisUiState.Error("Inference Error: ${e.localizedMessage}") 
                }
                .collect { token ->
                    accumulatedResponse.append(token)
                    // Update UI state with partial results for a "typing" effect
                    _uiState.value = AnalysisUiState.Processing(accumulatedResponse.toString())
                }
            
            _uiState.value = AnalysisUiState.Success(accumulatedResponse.toString())
        }
    }
}

/**
 * Hilt Module for providing dependencies.
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideContext(context: Context) = context
}
