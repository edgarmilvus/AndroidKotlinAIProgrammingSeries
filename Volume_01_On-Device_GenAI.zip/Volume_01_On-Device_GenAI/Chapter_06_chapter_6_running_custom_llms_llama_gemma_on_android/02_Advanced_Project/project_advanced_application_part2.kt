
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.summarizer

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.Module
import com.google.dagger.Provides
import com.google.dagger.hilt.InstallIn
import com.google.dagger.hilt.android.AndroidAppState
import com.google.dagger.hilt.android.AndroidViewModel
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.dagger.hilt.components.SingletonComponent
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DI Module for Hardware-Aware LLM Configuration ---
@Module
@InstallIn(SingletonComponent::class)
object LlmModule {
    @Provides
    @Singleton
    fun provideLlmInference(@AndroidAppState context: Context): LlmInference {
        // Configure the LLM for GPU acceleration
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemma-2b-it-gpu-int4.bin") // Path to local .bin model
            .setMaxTokens(1024)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            .build()
        
        return LlmInference.createFromOptions(context, options)
    }
}

// --- 2. Repository for AI Orchestration ---
@Singleton
class LocalLlmRepository @Inject constructor(
    private val llmInference: LlmInference
) {
    /**
     * Generates a summary using a streaming flow.
     * Uses Dispatchers.Default to ensure the heavy inference doesn't block the main thread.
     */
    fun summarizeDocument(text: String): Flow<String> = flow {
        val prompt = "Summarize the following text concisely and objectively:\n\n$text\n\nSummary:"
        
        // MediaPipe's generateResponse allows for streaming tokens
        llmInference.generateResponseAsync(prompt) { partialResult, done ->
            // Emit the partial token to the flow
            emit(partialResult)
        }
    }.flowOn(Dispatchers.Default) // Hardware orchestration happens here
}

// --- 3. MVI State Management ---
data class SummarizerUiState(
    val inputText: String = "",
    val summary: String = "",
    val isProcessing: Boolean = false,
    val error: String? = null
)

sealed class SummarizerIntent {
    data class UpdateInput(val text: String) : SummarizerIntent()
    object StartSummarization : SummarizerIntent()
}

@HiltViewModel
class SummarizationViewModel @Inject constructor(
    private val repository: LocalLlmRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SummarizerUiState())
    val uiState: StateFlow<SummarizerUiState> = _uiState.asStateFlow()

    fun handleIntent(intent: SummarizerIntent) {
        when (intent) {
            is SummarizerIntent.UpdateInput -> {
                _uiState.update { it.copy(inputText = intent.text) }
            }
            SummarizerIntent.StartSummarization -> performSummarization()
        }
    }

    private fun performSummarization() {
        val currentText = _uiState.value.inputText
        if (currentText.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, summary = "", error = null) }
            
            try {
                // Collecting the stream from the repository
                repository.summarizeDocument(currentText)
                    .catch { e -> 
                        _uiState.update { it.copy(error = e.localizedMessage, isProcessing = false) } 
                    }
                    .collect { token ->
                        // Update UI state incrementally as tokens are generated
                        _uiState.update { it.copy(summary = it.summary + token) }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Inference failed: ${e.message}", isProcessing = false) }
            } finally {
                _uiState.update { it.copy(isProcessing = false) }
            }
        }
    }
}
