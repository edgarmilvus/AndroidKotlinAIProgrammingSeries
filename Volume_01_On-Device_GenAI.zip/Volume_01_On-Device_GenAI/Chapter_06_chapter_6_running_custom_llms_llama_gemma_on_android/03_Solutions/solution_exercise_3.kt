
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class DocumentRepository(private val context: Context) {
    // Memory Safety: Read file using a stream to avoid OOM on huge files
    suspend fun readTextFile(uri: Uri): String = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            inputStream.bufferedReader().use { it.readText() }
        } ?: ""
    }

    // Context Window Management: Head-and-Tail Truncation
    fun prepareContext(text: String, maxChars: Int = 8000): String {
        if (text.length <= maxChars) return text
        
        val half = maxChars / 2
        // Keep the beginning (intro) and the end (conclusion) of the doc
        return text.take(half) + "\n... [Truncated for length] ...\n" + text.takeLast(half)
    }
}

@HiltViewModel
class RAGViewModel @Inject constructor(
    private val llmInference: LlmInference,
    private val repository: DocumentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<LLMState>(LLMState.Idle)
    val uiState = _uiState.asStateFlow()

    fun askAboutDocument(uri: Uri, query: String) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = LLMState.Thinking
            try {
                val rawText = repository.readTextFile(uri)
                val truncatedContext = repository.prepareContext(rawText)
                
                // Augmented Prompt Construction
                val finalPrompt = """
                    Context: $truncatedContext
                    
                    Question: $query
                    
                    Answer based strictly on the context provided:
                """.trimIndent()

                val response = llmInference.generateResponse(finalPrompt)
                _uiState.value = LLMState.Success(response)
            } catch (e: Exception) {
                _uiState.value = LLMState.Error("Failed to process document: ${e.message}")
            }
        }
    }
}
