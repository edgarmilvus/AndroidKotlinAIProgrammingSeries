
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. Streaming Wrapper using callbackFlow
class StreamingAiRepository @Inject constructor(private val llmInference: LlmInference) {
    fun streamResponse(prompt: String): Flow<String> = callbackFlow {
        val options = LlmInference.LlmInferenceOptions.builder().build() 
        
        // MediaPipe Async API
        llmInference.generateResponseAsync(prompt) { partialResult, done ->
            trySend(partialResult)
            if (done) {
                channel.close()
            }
        }
        
        // Crucial: close the channel when the flow is cancelled
        awaitClose { 
            // MediaPipe handles internal cancellation, but we ensure flow cleanup here
        }
    }.flowOn(Dispatchers.Default)
}

// 2. ViewModel with Streaming State
@HiltViewModel
class StreamingViewModel @Inject constructor(private val repository: StreamingAiRepository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    private var generationJob: Job? = null

    fun sendPrompt(text: String) {
        generationJob?.cancel() // Cancel existing generation
        
        val userMsg = ChatMessage("User", text)
        _messages.value += userMsg
        
        // Add a placeholder for the AI response
        val aiMsgIndex = _messages.value.size
        _messages.value += ChatMessage("Assistant", "")

        generationJob = viewModelScope.launch {
            repository.streamResponse(text).collect { token ->
                val currentList = _messages.value.toMutableList()
                val currentText = currentList[aiMsgIndex].content
                currentList[aiMsgIndex] = currentList[aiMsgIndex].copy(content = currentText + token)
                _messages.value = currentList
            }
        }
    }

    fun stopGeneration() {
        generationJob?.cancel()
    }
}

// 3. Compose UI with Auto-Scroll
@Composable
fun StreamingChatScreen(viewModel: StreamingViewModel = hiltViewModel()) {
    val messages by viewModel.messages.collectAsState()
    val listState = rememberLazyListState()

    // Auto-scroll logic
    LaunchedEffect(messages) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column {
        LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            items(messages) { msg ->
                Text("${msg.role}: ${msg.content}", modifier = Modifier.padding(8.dp))
            }
        }
        Button(onClick = { viewModel.stopGeneration() }) { Text("Stop") }
    }
}
