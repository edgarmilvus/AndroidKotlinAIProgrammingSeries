
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Hilt Module for Dependency Injection
@Module
@InstallIn(SingletonComponent::class)
object LLMModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/user/0/com.example.app/files/model.bin")
            .setMaxTokens(512)
            .setTopK(40)
            .setTemperature(0.7f)
            .build()
        return LlmInference.createFromOptions(context, options)
    }
}

// 2. UI State Management
sealed class LLMState {
    object Idle : LLMState()
    object Thinking : LLMState()
    data class Success(val response: String) : LLMState()
    data class Error(val message: String) : LLMState()
}

// 3. ViewModel for Asynchronous Execution
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val _uiState = MutableStateFlow<LLMState>(LLMState.Idle)
    val uiState: StateFlow<LLMState> = _uiState.asStateFlow()

    fun sendQuery(prompt: String) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = LLMState.Thinking
            try {
                // Blocking call executed on Default dispatcher to avoid ANR
                val result = llmInference.generateResponse(prompt)
                _uiState.value = LLMState.Success(result)
            } catch (e: Exception) {
                _uiState.value = LLMState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }
}

// 4. Compose UI
@Composable
fun PrivateNoteAssistant(viewModel: ChatViewModel = hiltViewModel()) {
    var inputText by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TextField(
            value = inputText,
            onValueChange = { inputText = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask your private assistant...") },
            enabled = state !is LLMState.Thinking
        )
        Button(
            onClick = { viewModel.sendQuery(inputText) },
            modifier = Modifier.align(Alignment.End),
            enabled = state !is LLMState.Thinking
        ) {
            Text(if (state is LLMState.Thinking) "Thinking..." else "Send")
        }
        Spacer(modifier = Modifier.height(16.dp))
        when (state) {
            is LLMState.Success -> Text((state as LLMState.Success).response)
            is LLMState.Error -> Text("Error: ${(state as LLMState.Error).message}", color = Color.Red)
            is LLMState.Thinking -> CircularProgressIndicator()
            else -> Text("Enter a prompt to start brainstorming.")
        }
    }
}
