
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Hilt Module for Singleton LlmInference
@Module
@InstallIn(SingletonComponent::class)
object GenAIModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        val modelPath = "${context.filesDir}/gemma-2b-it-cpu-int4.bin"
        
        // Ensure model exists before initializing to prevent native crash
        if (!File(modelPath).exists()) {
            throw IllegalStateException("Model file not found at $modelPath. Please initialize the app first.")
        }

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(512)
            .setTemperature(0.7f)
            .build()
            
        return LlmInference.createFromOptions(context, options)
    }
}

// 2. Repository to abstract LLM logic
@Singleton
class AiRepository @Inject constructor(private val llmInference: LlmInference) {
    suspend fun getResponse(prompt: String): String = withContext(Dispatchers.Default) {
        // LlmInference.generateResponse is a blocking call
        llmInference.generateResponse(prompt)
    }
}

// 3. ViewModel for UI State management
@HiltViewModel
class JournalViewModel @Inject constructor(private val repository: AiRepository) : ViewModel() {
    var uiState by mutableStateOf(JournalUiState())
        private set

    fun sendPrompt(text: String) {
        viewModelScope.launch {
            uiState = uiState.copy(isLoading = true, response = "")
            try {
                val result = repository.getResponse(text)
                uiState = uiState.copy(response = result, isLoading = false)
            } catch (e: Exception) {
                uiState = uiState.copy(response = "Error: ${e.message}", isLoading = false)
            }
        }
    }
}

data class JournalUiState(val response: String = "", val isLoading: Boolean = false)

// 4. Basic Compose UI
@Composable
fun JournalScreen(viewModel: JournalViewModel = hiltViewModel()) {
    var inputText by remember { mutableStateOf("") }
    val state = viewModel.uiState

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Private Journal AI", style = MaterialTheme.typography.headlineMedium)
        
        Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text(text = state.response)
        }

        if (state.isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        Row {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Reflect on your day...") }
            )
            Button(onClick = { 
                viewModel.sendPrompt(inputText)
                inputText = "" 
            }) {
                Text("Ask")
            }
        }
    }
}
