
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

data class BenchmarkResult(
    val ttftMs: Long,
    val tps: Double,
    val peakMemoryMb: Long,
    val prompt: String
)

class PerformanceBenchmark @Inject constructor(private val llmInference: LlmInference) {
    
    suspend fun runBenchmark(prompt: String): BenchmarkResult = withContext(Dispatchers.Default) {
        var firstTokenTime = 0L
        var totalTokens = 0
        val startTime = System.nanoTime()
        
        // Capture memory before start
        val runtime = Runtime.getRuntime()
        val startMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)

        // Use a custom callback to track timing
        llmInference.generateResponseAsync(prompt) { token, done ->
            if (firstTokenTime == 0L) {
                firstTokenTime = (System.nanoTime() - startTime) / 1_000_000
            }
            totalTokens++
            if (done) {
                // Final calculations happen after the flow completes
            }
        }
        
        // Note: In a real scenario, we'd wrap generateResponseAsync in a 
        // suspendCoroutine to wait for the 'done' callback.
        
        val endTime = System.nanoTime()
        val totalDurationMs = (endTime - startTime) / 1_000_000
        val generationDurationMs = totalDurationMs - firstTokenTime
        
        val tps = if (generationDurationMs > 0) {
            (totalTokens.toDouble() / (generationDurationMs / 1000.0))
        } else 0.0
        
        val endMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        
        BenchmarkResult(
            ttftMs = firstTokenTime,
            tps = tps,
            peakMemoryMb = endMem - startMem,
            prompt = prompt
        )
    }
}

@Composable
fun DebugDashboard(results: List<BenchmarkResult>) {
    LazyColumn {
        items(results) { res ->
            Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Prompt: ${res.prompt}", fontWeight = FontWeight.Bold)
                    Text("TTFT: ${res.ttftMs}ms")
                    Text("TPS: ${String.format("%.2f", res.tps)} tokens/sec")
                    Text("Mem Delta: ${res.peakMemoryMb}MB")
                }
            }
        }
    }
}
