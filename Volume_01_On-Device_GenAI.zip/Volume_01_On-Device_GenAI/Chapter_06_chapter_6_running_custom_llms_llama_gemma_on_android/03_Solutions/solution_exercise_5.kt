
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// 1. Repository wrapping the callback API into a Flow
class LLMRepository @Inject constructor(private val llmInference: LlmInference) {
    fun streamResponse(prompt: String): Flow<String> = callbackFlow {
        var accumulatedText = ""
        
        llmInference.generateResponseAsync(prompt) { partialResult, done ->
            accumulatedText += partialResult
            trySend(accumulatedText) // Emit the current state of the response
            
            if (done) {
                close() // Close the flow when generation is complete
            }
        }
        
        awaitClose { 
            // Logic to cancel the internal MediaPipe session if supported
        }
    }.flowOn(Dispatchers.Default)
}

// 2. ViewModel with Cancellation Logic
@HiltViewModel
class StreamingViewModel @Inject constructor(
    private val repository: LLMRepository
) : ViewModel() {

    private val _responseState = MutableStateFlow("")
    val responseState = _responseState.asStateFlow()
    
    private var generationJob: Job? = null

    fun startStreaming(prompt: String) {
        generationJob?.cancel() // Cancel any existing generation
        _responseState.value = ""
        
        generationJob = viewModelScope.launch {
            repository.streamResponse(prompt).collect { text ->
                _responseState.value = text
            }
        }
    }

    fun stopGeneration() {
        generationJob?.cancel()
        _responseState.value += "\n[Generation Stopped by User]"
    }
}

// 3. UI Integration with Auto-Scroll
@Composable
fun StreamingChatScreen(viewModel: StreamingViewModel = hiltViewModel()) {
    val response by viewModel.responseState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Auto-scroll to bottom when text changes
    LaunchedEffect(response) {
        if (response.isNotEmpty()) {
            listState.animateScrollToItem(listState.layoutInfo.totalItemsCount)
        }
    }

    Column {
        LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            item { Text(text = response) }
        }
        Row {
            Button(onClick = { viewModel.startStreaming("Hello!") }) { Text("Send") }
            Button(onClick = { viewModel.stopGeneration() }) { Text("Stop") }
        }
    }
}
