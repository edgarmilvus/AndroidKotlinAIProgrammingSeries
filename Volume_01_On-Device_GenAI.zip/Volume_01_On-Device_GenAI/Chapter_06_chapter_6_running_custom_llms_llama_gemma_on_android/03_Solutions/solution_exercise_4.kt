
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

data class BenchmarkResult(
    val modelName: String,
    val ttftMs: Long,
    val tps: Double,
    val totalLatencyMs: Long,
    val peakRamMb: Long
)

class BenchmarkService @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun getPeakRam(): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024) // Simplified for example
    }

    suspend fun runBenchmark(
        modelPath: String, 
        prompt: String, 
        useGpu: Boolean
    ): BenchmarkResult {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            // Note: GPU delegation is set via specific MediaPipe options 
            // depending on the build version (e.g., .setDelegate(Delegate.GPU))
            .build()
        
        val inference = LlmInference.createFromOptions(context, options)
        
        val startTime = System.nanoTime()
        var firstTokenTime: Long = 0
        
        // We use a custom callback to capture the very first token
        var totalChars = 0
        inference.generateResponseAsync(prompt) { partialResult, done ->
            if (firstTokenTime == 0L) {
                firstTokenTime = System.nanoTime() - startTime
            }
            totalChars += partialResult.length
        }
        
        // In a real scenario, we would await the 'done' callback
        // This is a simplified synchronous representation for the benchmark
        val endTime = System.nanoTime()
        val totalLatency = (endTime - startTime) / 1_000_000
        val ttft = firstTokenTime / 1_000_000
        val tps = totalChars.toDouble() / (totalLatency / 1000.0)

        return BenchmarkResult(modelPath, ttft, tps, totalLatency, getPeakRam())
    }
}
