
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

// 1. Hardware Capability Sensing
enum class DeviceTier { LOW_END, MID_RANGE, HIGH_END }

class DeviceCapabilityManager(private val context: Context) {
    fun getDeviceTier(): DeviceTier {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val totalRamGb = memoryInfo.totalMem / (1024 * 1024 * 1024)
        return when {
            totalRamGb >= 12 -> DeviceTier.HIGH_END
            totalRamGb >= 6 -> DeviceTier.MID_RANGE
            else -> DeviceTier.LOW_END
        }
    }
}

// 2. Strategy Pattern for Inference
interface InferenceStrategy {
    fun getModelPath(): String
    fun getOptions(): LlmInference.LlmInferenceOptions
}

class GpuStrategy : InferenceStrategy {
    override fun getModelPath() = "gemma-2b-gpu.bin"
    override fun getOptions() = LlmInference.LlmInferenceOptions.builder()
        .setDelegate(LlmInference.Delegate.GPU) // Use GPU for high-end
        .build()
}

class CpuStrategy : InferenceStrategy {
    override fun getModelPath() = "gemma-2b-cpu.bin"
    override fun getOptions() = LlmInference.LlmInferenceOptions.builder()
        .setDelegate(LlmInference.Delegate.CPU)
        .build()
}

// 3. Lifecycle-Aware Manager
@Singleton
class AdaptiveModelManager @Inject constructor(
    private val context: Context,
    private val capabilityManager: DeviceCapabilityManager
) : DefaultLifecycleObserver {

    private var llmInference: LlmInference? = null

    fun getInference(): LlmInference {
        if (llmInference == null) {
            loadModel()
        }
        return llmInference!!
    }

    private fun loadModel() {
        val tier = capabilityManager.getDeviceTier()
        if (tier == DeviceTier.LOW_END) throw UnsupportedOperationException("Device RAM too low")

        val strategy = if (tier == DeviceTier.HIGH_END) GpuStrategy() else CpuStrategy()
        
        try {
            llmInference = LlmInference.createFromOptions(
                context, 
                strategy.getOptions().setModelPath(strategy.getModelPath()).build()
            )
        } catch (e: OutOfMemoryError) {
            // Fallback to CPU if GPU fails
            llmInference = LlmInference.createFromOptions(context, CpuStrategy().getOptions().build())
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        // Release 2GB of RAM when app is in background
        llmInference?.close()
        llmInference = null
    }
}
