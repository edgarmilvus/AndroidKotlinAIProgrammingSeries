
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

data class Persona(val displayName: String, val systemInstruction: String)

val Personas = listOf(
    Persona("Code Reviewer", "You are a world-class Kotlin expert. Give short, punchy answers with code snippets."),
    Persona("Creative Writer", "You are a poetic novelist. Use descriptive, flowery language and metaphors."),
    Persona("Legal Aid", "You are a precise legal assistant. Be formal, cautious, and cite general principles.")
)

@HiltViewModel
class PersonaViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    var selectedPersona by mutableStateOf(Personas[0])
        private set

    private val _uiState = MutableStateFlow<LLMState>(LLMState.Idle)
    val uiState: StateFlow<LLMState> = _uiState.asStateFlow()

    fun switchPersona(persona: Persona) {
        selectedPersona = persona
        // Context Reset: Clear state to prevent persona bleed
        _uiState.value = LLMState.Idle 
    }

    fun sendQuery(userPrompt: String) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = LLMState.Thinking
            
            // Prompt Engineering: Prepend system instruction to the user input
            val augmentedPrompt = "${selectedPersona.systemInstruction}\n\nUser: $userPrompt\nAssistant:"
            
            try {
                val result = llmInference.generateResponse(augmentedPrompt)
                _uiState.value = LLMState.Success(result)
            } catch (e: Exception) {
                _uiState.value = LLMState.Error(e.localizedMessage ?: "Error")
            }
        }
    }
}

@Composable
fun PersonaSelector(viewModel: PersonaViewModel) {
    Column {
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Personas.forEach { persona ->
                FilterChip(
                    selected = viewModel.selectedPersona == persona,
                    onClick = { viewModel.switchPersona(persona) },
                    label = { Text(persona.displayName) },
                    modifier = Modifier.padding(4.dp)
                )
            }
        }
    }
}
