
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// 1. Persona Definition
sealed class AiPersona(val name: String, val systemInstruction: String) {
    object Stoic : AiPersona("Stoic Philosopher", "You are a Stoic philosopher. Respond with brevity, focusing on virtue, logic, and what is within one's control.")
    object Friend : AiPersona("Compassionate Friend", "You are a warm, empathetic friend. Provide emotional validation and gentle encouragement.")
    object Analyst : AiPersona("Critical Analyst", "You are a productivity expert. Be direct, identify inefficiencies, and provide actionable bullet points.")
}

data class ChatMessage(val role: String, val content: String)

// 2. Prompt Orchestrator for Context Management
class PromptOrchestrator {
    fun buildPrompt(persona: AiPersona, history: List<ChatMessage>, currentQuery: String): String {
        val contextWindowSize = 3 // Keep last 3 exchanges
        val recentHistory = history.takeLast(contextWindowSize * 2)
        
        val historyString = recentHistory.joinToString("\n") { 
            "${it.role}: ${it.content}" 
        }

        return """
            $persona.systemInstruction
            
            Recent Conversation:
            $historyString
            
            User: $currentQuery
            Assistant:
        """.trimIndent()
    }
}

// 3. ViewModel with StateFlow
@HiltViewModel
class PersonaViewModel @Inject constructor(
    private val repository: AiRepository,
    private val orchestrator: PromptOrchestrator = PromptOrchestrator()
) : ViewModel() {
    
    private val _selectedPersona = MutableStateFlow<AiPersona>(AiPersona.Stoic)
    val selectedPersona = _selectedPersona.asStateFlow()

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory = _chatHistory.asStateFlow()

    private val _response = MutableStateFlow("")
    val response = _response.asStateFlow()

    fun switchPersona(persona: AiPersona) {
        _selectedPersona.value = persona
    }

    fun sendMessage(text: String) {
        viewModelScope.launch {
            val fullPrompt = orchestrator.buildPrompt(
                _selectedPersona.value, 
                _chatHistory.value, 
                text
            )
            
            val result = repository.getResponse(fullPrompt)
            
            // Update history: User message + AI response
            _chatHistory.value += listOf(
                ChatMessage("User", text),
                ChatMessage("Assistant", result)
            )
            _response.value = result
        }
    }
}
