
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.ondeviceai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ondeviceai.data.LlmRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel that bridges the Repository and the Compose UI.
 * Uses StateFlow to maintain the current chat state.
 */
@HiltViewModel
class LlmViewModel @Inject constructor(
    private val repository: LlmRepository
) : ViewModel() {

    // State representing the current conversation
    private val _uiState = MutableStateFlow(LlmUiState())
    val uiState: StateFlow<LlmUiState> = _uiState.asStateFlow()

    init {
        // In a real app, the path would be dynamic (e.g., from internal storage)
        val modelPath = "/data/local/tmp/gemma-2b-it-gpu-int4.bin"
        repository.initializeModel(modelPath)
    }

    fun sendPrompt(prompt: String) {
        if (prompt.isBlank()) return

        // Add user message to state immediately
        val currentMessages = _uiState.value.messages.toMutableList()
        currentMessages.add(ChatMessage(text = prompt, isUser = true))
        
        // Add a placeholder for the AI response
        currentMessages.add(ChatMessage(text = "", isUser = false))
        
        _uiState.update { it.copy(
            messages = currentMessages, 
            isLoading = true 
        ) }

        viewModelScope.launch(Dispatchers.Default) {
            try {
                var accumulatedResponse = ""
                
                // Collect tokens from the repository flow
                repository.generateResponseFlow(prompt).collect { token ->
                    accumulatedResponse += token
                    
                    // Update the last message in the list (the AI response)
                    _uiState.update { state ->
                        val updatedMessages = state.messages.toMutableList()
                        updatedMessages[updatedMessages.lastIndex] = 
                            ChatMessage(text = accumulatedResponse, isUser = false)
                        
                        state.copy(messages = updatedMessages)
                    }
                }
            } catch (e: Exception) {
                // Handle errors (e.g., model crash, OOM)
                _uiState.update { it.copy(errorMessage = e.localizedMessage) }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.closeModel()
    }
}

data class LlmUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

data class ChatMessage(val text: String, val isUser: Boolean)
