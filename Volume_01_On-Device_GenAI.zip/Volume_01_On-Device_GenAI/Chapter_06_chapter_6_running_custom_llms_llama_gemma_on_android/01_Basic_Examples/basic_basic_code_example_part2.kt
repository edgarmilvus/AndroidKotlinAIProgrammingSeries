
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. LLM Repository
 * Encapsulates the MediaPipe LlmInference engine.
 * This class is a Singleton because loading an LLM into memory is expensive.
 */
@Singleton
class LlmRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // The path to the .bin model file on the device storage
    private val modelPath = "/data/local/tmp/gemma-2b-it-cpu-int4.bin"

    init {
        setupLlmInference()
    }

    private fun setupLlmInference() {
        try {
            // Configure the LLM Inference options
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(512) // Limit response length to prevent memory spikes
                .setTopK(40)
                .setTemperature(0.7f) // Balance between creativity and coherence
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            Log.d("LlmRepo", "LLM Model loaded successfully from $modelPath")
        } catch (e: Exception) {
            Log.e("LlmRepo", "Failed to initialize LLM: ${e.message}")
        }
    }

    /**
     * Generates a response based on the input prompt.
     * Uses a suspending function to ensure it can be called from a coroutine.
     */
    suspend fun generateResponse(prompt: String): Result<String> = withContext(Dispatchers.Default) {
        return@withContext try {
            val engine = llmInference ?: throw IllegalStateException("LLM Engine not initialized")
            
            // Synchronous call to the MediaPipe engine
            val response = engine.generateResponse(prompt)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun close() {
        llmInference?.close()
    }
}

/**
 * 2. LLM ViewModel
 * Manages the UI state and ensures AI inference doesn't block the Main thread.
 */
@AndroidEntryPoint
class LlmViewModel @Inject constructor(
    private val repository: LlmRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LlmUiState())
    val uiState: StateFlow<LlmUiState> = _uiState.asStateFlow()

    fun sendPrompt(prompt: String) {
        if (prompt.isBlank()) return

        viewModelScope.launch {
            // Update UI to show loading state
            _uiState.value = _uiState.value.copy(
                messages = _uiState.value.messages + ChatMessage(prompt, isUser = true),
                isLoading = true
            )

            // Perform inference on Dispatchers.Default (via Repository)
            val result = repository.generateResponse(prompt)

            result.onSuccess { response ->
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + ChatMessage(response, isUser = false),
                    isLoading = false
                )
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + ChatMessage("Error: ${error.message}", isUser = false),
                    isLoading = false
                )
            }
        }
    }
}

// --- Supporting Data Models ---

data class LlmUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false
)

data class ChatMessage(val text: String, val isUser: Boolean)

/**
 * 3. Jetpack Compose UI
 * A simple chat interface to interact with the LLM.
 */
@Composable
fun LlmChatScreen(viewModel: LlmViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(state.messages) { msg ->
                Text(
                    text = if (msg.isUser) "You: ${msg.text}" else "AI: ${msg.text}",
                    modifier = Modifier.padding(vertical = 4.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        if (state.isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask the local LLM...") }
            )
            Button(onClick = {
                viewModel.sendPrompt(inputText)
                inputText = ""
            }) {
                Text("Send")
            }
        }
    }
}
