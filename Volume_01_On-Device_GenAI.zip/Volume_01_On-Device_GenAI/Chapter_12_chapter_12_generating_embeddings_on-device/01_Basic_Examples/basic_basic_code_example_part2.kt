
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.embeddings

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import java.io.IOException

/**
 * TextEmbeddingGenerator encapsulates the MediaPipe TextEmbedder logic.
 * It is responsible for loading the TFLite model and converting text to vectors.
 */
class TextEmbeddingGenerator(context: Context) {

    // The TextEmbedder is the core MediaPipe object that handles inference.
    private var textEmbedder: TextEmbedder? = null

    init {
        try {
            // Initialize the TextEmbedder with options.
            // The model file (e.g., universal_sentence_encoder.tflite) 
            // must be placed in the 'assets' folder.
            val options = TextEmbedder.TextEmbedderOptions.builder()
                .setBaseOptions(
                    com.google.mediapipe.tasks.core.BaseOptions.builder()
                        .setModelAssetPath("universal_sentence_encoder.tflite")
                        .build()
                )
                .build()
            
            textEmbedder = TextEmbedder.createFromOptions(context, options)
        } catch (e: IOException) {
            // In a real-world app, use a custom Exception or a Result wrapper.
            throw RuntimeException("Failed to initialize TextEmbedder: ${e.message}")
        }
    }

    /**
     * Generates a semantic embedding for the given text.
     * @param text The input string to vectorize.
     * @return A FloatArray representing the embedding vector.
     */
    fun generateEmbedding(text: String): FloatArray {
        val embedder = textEmbedder ?: throw IllegalStateException("Embedder not initialized")
        
        // MediaPipe's embed() method performs the tokenization and model inference.
        val result: TextEmbedderResult = embedder.embed(text)
        
        // The embedding is returned as a FloatArray within the result object.
        return result.embedding() 
    }

    /**
     * Closes the TFLite interpreter to free up native memory.
     * This is critical to prevent memory leaks.
     */
    fun close() {
        textEmbedder?.close()
        textEmbedder = null
    }
}
