
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.embeddings

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder.TextEmbedderOptions
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EmbeddingRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // The TextEmbedder is the core engine provided by MediaPipe
    private var textEmbedder: TextEmbedder? = null

    /**
     * Initializes the TextEmbedder. 
     * In a real app, the .tflite model file should be placed in the 'assets' folder.
     */
    fun initializeModel() {
        if (textEmbedder != null) return

        val options = TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite") // Model in assets
                    .build()
            )
            .build()

        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    /**
     * Generates a vector embedding for the given text.
     * We use Dispatchers.Default because model inference is CPU-intensive.
     */
    suspend fun generateEmbedding(text: String): FloatArray = withContext(Dispatchers.Default) {
        val embedder = textEmbedder ?: throw IllegalStateException("Model not initialized")
        
        // MediaPipe's embed method returns a TextEmbeddingResult object
        val result = embedder.embed(text)
        
        // The actual vector is stored in the 'embedding' property
        result.embedding() 
    }

    fun close() {
        textEmbedder?.close()
        textEmbedder = null
    }
}
