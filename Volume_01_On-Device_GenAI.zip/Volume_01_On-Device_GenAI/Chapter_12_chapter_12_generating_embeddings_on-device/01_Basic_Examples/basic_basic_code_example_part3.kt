
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.embeddings

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * EmbeddingRepository handles the business logic of embedding generation.
 * It ensures that heavy AI computation occurs on the Default dispatcher.
 */
@Singleton
class EmbeddingRepository @Inject constructor(
    private val context: Context
) {
    // Lazy initialization of the generator to avoid blocking app startup.
    private val generator by lazy { TextEmbeddingGenerator(context) }

    /**
     * Converts text to a vector asynchronously.
     * We use Dispatchers.Default because embedding generation is CPU-intensive.
     */
    suspend fun getTextEmbedding(text: String): Result<FloatArray> = withContext(Dispatchers.Default) {
        runCatching {
            if (text.isBlank()) throw IllegalArgumentException("Input text cannot be empty")
            generator.generateEmbedding(text)
        }
    }

    fun releaseResources() {
        generator.close()
    }
}
