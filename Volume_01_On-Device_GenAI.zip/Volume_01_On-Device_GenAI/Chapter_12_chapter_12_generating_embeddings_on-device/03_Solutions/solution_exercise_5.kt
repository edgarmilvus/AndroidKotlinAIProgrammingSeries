
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.ComponentCallbacks2
import android.util.LruCache
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import java.util.concurrent.atomic.AtomicInteger

class VectorCache {
    // Hot Cache: RAM
    private val ramCache = LruCache<String, FloatArray>(100) 
    
    fun get(text: String): FloatArray? = ramCache.get(text)
    fun put(text: String, vector: FloatArray) = ramCache.put(text, vector)
    fun clear() = ramCache.evictAll()
}

class ModelProvider @Inject constructor(
    private val context: Context
) : ComponentCallbacks2 {
    private var textEmbedder: TextEmbedder? = null
    private val refCount = AtomicInteger(0)
    private val cache = VectorCache()

    fun acquireEmbedder(): TextEmbedder {
        if (refCount.getAndIncrement() == 0) {
            // Load model from disk
            textEmbedder = loadModel()
        }
        return textEmbedder!!
    }

    fun releaseEmbedder() {
        if (refCount.decrementAndGet() == 0) {
            textEmbedder?.close()
            textEmbedder = null
        }
    }

    fun getEmbedding(text: String): FloatArray {
        cache.get(text)?.let { return it }
        
        val embedder = acquireEmbedder()
        val vector = embedder.embed(text).embeddingResult().embeddings().first().floatEmbedding()
        cache.put(text, vector)
        releaseEmbedder()
        
        return vector
    }

    private fun loadModel(): TextEmbedder { /* ... standard init ... */ }

    override fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            cache.clear()
            if (refCount.get() == 0) {
                textEmbedder?.close()
                textEmbedder = null
            }
        }
    }
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {}
    override fun onLowMemory() { cache.clear() }
}
