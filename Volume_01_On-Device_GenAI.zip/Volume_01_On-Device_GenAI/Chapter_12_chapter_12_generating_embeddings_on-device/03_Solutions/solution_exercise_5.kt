
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

class HybridSearchEngine @Inject constructor(
    private val embeddingHelper: TextEmbeddingHelper,
    private val noteDao: NoteDao
) {
    private val k = 60 // RRF constant

    suspend fun hybridSearch(query: String, semanticWeight: Float): List<NoteEntity> {
        val allNotes = noteDao.getAllNotes().first()
        val queryEmbedding = embeddingHelper.getEmbedding(query)

        // 1. Keyword Matcher (Simple Boolean/Frequency)
        val keywordResults = allNotes.filter { it.content.contains(query, ignoreCase = true) }
            .map { it.id }

        // 2. Semantic Matcher
        val semanticResults = allNotes.map { note ->
            note.id to embeddingHelper.calculateCosineSimilarity(queryEmbedding, note.embedding)
        }.sortedByDescending { it.second }.map { it.first }

        // 3. Reciprocal Rank Fusion (RRF)
        val scores = mutableMapOf<Int, Float>()
        
        // Rank keyword results
        keywordResults.forEachIndexed { index, id ->
            val rank = index + 1
            scores[id] = scores.getOrDefault(id, 0f) + (1.0f / (k + rank))
        }
        
        // Rank semantic results
        semanticResults.forEachIndexed { index, id ->
            val rank = index + 1
            scores[id] = scores.getOrDefault(id, 0f) + (1.0f / (k + rank))
        }

        // 4. Weighting & Final Sorting
        // Note: In a real RRF, weighting is often applied to the individual rank contributions
        return allNotes.sortedByDescending { note ->
            val rrfScore = scores.getOrDefault(note.id, 0f)
            // Apply semanticWeight to boost semantic results over keyword results
            rrfScore * (1 + (semanticWeight * 0.5f)) 
        }
    }
}
