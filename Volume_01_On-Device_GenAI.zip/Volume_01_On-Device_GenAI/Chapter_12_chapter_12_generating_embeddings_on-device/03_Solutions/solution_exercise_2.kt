
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlin.math.sqrt

object VectorMathUtils {
    fun euclideanDistance(v1: FloatArray, v2: FloatArray): Float {
        var sum = 0.0f
        for (i in v1.indices) {
            val diff = v1[i] - v2[i]
            sum += diff * diff
        }
        return sqrt(sum)
    }

    fun averageVectors(vectors: List<FloatArray>): FloatArray {
        if (vectors.isEmpty()) return floatArrayOf()
        val dimension = vectors[0].size
        val average = FloatArray(dimension)
        for (v in vectors) {
            for (i in 0 until dimension) {
                average[i] += v[i]
            }
        }
        for (i in 0 until dimension) {
            average[i] /= vectors.size.toFloat()
        }
        return average
    }
}

class ClusterManager(private val textEmbedder: TextEmbedder) {
    data class Cluster(var name: String, var centroid: FloatArray, val members: MutableList<String> = mutableListOf())

    private val clusters = mutableListOf<Cluster>()

    fun initializeSeeds(seeds: Map<String, String>) {
        seeds.forEach { (name, text) ->
            val embedding = textEmbedder.embed(text).embeddingResult().embeddings().first().floatEmbedding()
            clusters.add(Cluster(name, embedding))
        }
    }

    fun assignSnippet(text: String): String {
        val snippetEmbedding = textEmbedder.embed(text).embeddingResult().embeddings().first().floatEmbedding()
        
        // Find closest centroid using Euclidean Distance
        val closestCluster = clusters.minByOrNull { VectorMathUtils.euclideanDistance(snippetEmbedding, it.centroid) }
            ?: throw IllegalStateException("No seeds initialized")

        closestCluster.members.add(text)
        
        // Dynamic Centroid Update: Recalculate average of all members
        val allMemberEmbeddings = closestCluster.members.map { 
            textEmbedder.embed(it).embeddingResult().embeddings().first().floatEmbedding() 
        }
        closestCluster.centroid = VectorMathUtils.averageVectors(allMemberEmbeddings)
        
        return closestCluster.name
    }

    fun getClusters() = clusters
}
