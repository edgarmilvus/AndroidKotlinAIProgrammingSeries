
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

class ZeroShotCategorizer(private val helper: TextEmbeddingHelper) {
    
    // 1. Centroid Definition
    private val categoryCentroids: Map<String, FloatArray> = mapOf(
        "Urgent" to helper.getEmbedding("I need help immediately, this is an emergency"),
        "Billing" to helper.getEmbedding("I have a question about my invoice and payment"),
        "General Inquiry" to helper.getEmbedding("I would like more information about your services")
    )

    private val confidenceThreshold = 0.5f

    // 2. Classification Logic
    fun categorize(text: String): String {
        val inputEmbedding = helper.getEmbedding(text)
        var bestCategory = "Uncategorized"
        var highestSimilarity = -1f

        for ((category, centroid) in categoryCentroids) {
            val similarity = helper.calculateCosineSimilarity(inputEmbedding, centroid)
            if (similarity > highestSimilarity) {
                highestSimilarity = similarity
                bestCategory = category
            }
        }

        // 3. Thresholding
        return if (highestSimilarity >= confidenceThreshold) {
            bestCategory
        } else {
            "Uncategorized"
        }
    }
}

// Usage Example in a ViewModel or Activity
// val categorizer = ZeroShotCategorizer(embeddingHelper)
// val tag = categorizer.categorize("My credit card was charged twice!") // Returns "Billing"
