
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. Vector Persistence: Room TypeConverter
class VectorConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String = value.joinToString(",")
    
    @TypeConverter
    fun toFloatArray(value: String): FloatArray = value.split(",").map { it.toFloat() }.toFloatArray()
}

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val embedding: FloatArray // Converted via VectorConverter
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes")
    fun getAllNotes(): Flow<List<NoteEntity>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)
}

// 2. DI Integration
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideTextEmbedder(@ApplicationContext context: Context): TextEmbeddingHelper {
        return TextEmbeddingHelper(context)
    }
}

// 3. Semantic Querying Repository
@Singleton
class NoteRepository @Inject constructor(
    private val noteDao: NoteDao,
    private val embeddingHelper: TextEmbeddingHelper
) {
    fun searchNotes(query: String): Flow<List<NoteEntity>> = flow {
        val queryEmbedding = withContext(Dispatchers.Default) {
            embeddingHelper.getEmbedding(query)
        }
        
        // Retrieve all notes and rank them in memory
        noteDao.getAllNotes().collect { notes ->
            val rankedNotes = notes.map { note ->
                val similarity = embeddingHelper.calculateCosineSimilarity(
                    queryEmbedding, note.embedding
                )
                note to similarity
            }.sortedByDescending { it.second }
             .filter { it.second > 0.4f } // Relevance filter
             .map { it.first }
            
            emit(rankedNotes)
        }
    }.flowOn(Dispatchers.Default)
}
