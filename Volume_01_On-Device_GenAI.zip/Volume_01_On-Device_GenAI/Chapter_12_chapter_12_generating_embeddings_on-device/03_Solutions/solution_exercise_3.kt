
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.room.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.nio.ByteBuffer

// --- Room Entity ---
@Entity(tableName = "document_chunks")
data class DocumentChunk(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val documentId: String,
    val text: String,
    @ColumnInfo(typeAffinity = ColumnInfo.TFLITE_FLOAT_ARRAY) // Conceptual
    val embeddingBlob: ByteArray 
)

@Dao
interface ChunkDao {
    @Insert
    suspend fun insertChunks(chunks: List<DocumentChunk>)

    @Query("SELECT * FROM document_chunks WHERE documentId = :docId")
    suspend fun getChunksForDocument(docId: String): List<DocumentChunk>
}

// --- Document Processor ---
class DocumentProcessor {
    fun chunkText(text: String, chunkSize: Int = 200, overlap: Int = 50): List<String> {
        val words = text.split(" ")
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < words.size) {
            val end = kotlin.math.min(start + chunkSize, words.size)
            chunks.add(words.subList(start, end).joinToString(" "))
            start += (chunkSize - overlap)
        }
        return chunks
    }
}

// --- RAG Service ---
class RagService @Inject constructor(
    private val chunkDao: ChunkDao,
    private val textEmbedder: TextEmbedder
) {
    // Convert FloatArray to ByteArray for Room storage
    private fun FloatArray.toByteArray(): ByteArray {
        val buffer = ByteBuffer.allocate(this.size * 4)
        this.forEach { buffer.putFloat(it) }
        return buffer.array()
    }

    private fun ByteArray.toFloatArray(): FloatArray {
        val buffer = ByteBuffer.wrap(this)
        val array = FloatArray(this.size / 4)
        for (i in array.indices) array[i] = buffer.float
        return array
    }

    suspend fun indexDocument(docId: String, fullText: String) = withContext(Dispatchers.Default) {
        val processor = DocumentProcessor()
        val chunks = processor.chunkText(fullText)
        
        val entities = chunks.map { text ->
            val embedding = textEmbedder.embed(text).embeddingResult().embeddings().first().floatEmbedding()
            DocumentChunk(documentId = docId, text = text, embeddingBlob = embedding.toByteArray())
        }
        chunkDao.insertChunks(entities)
    }

    suspend fun retrieveTopK(query: String, k: Int = 3): String = withContext(Dispatchers.Default) {
        val queryEmb = textEmbedder.embed(query).embeddingResult().embeddings().first().floatEmbedding()
        val allChunks = chunkDao.getChunksForDocument("manual_1") // Simplified

        val topChunks = allChunks.map { chunk ->
            val chunkEmb = chunk.embeddingBlob.toFloatArray()
            chunk to VectorMath.cosineSimilarity(queryEmb, chunkEmb)
        }.sortedByDescending { it.second }.take(k)

        // Construct Context Window
        "Context:\n" + topChunks.joinToString("\n---\n") { it.first.text }
    }
}
