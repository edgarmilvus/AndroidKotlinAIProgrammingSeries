
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

class EmbeddingIndexer @Inject constructor(
    private val embeddingHelper: TextEmbeddingHelper,
    private val noteDao: NoteDao
) {
    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    // 2. Concurrency Control: Limit parallelism to avoid NPU saturation
    private val indexingDispatcher = Dispatchers.Default.limitedParallelism(2)

    suspend fun indexDocuments(documents: List<String>) = withContext(indexingDispatcher) {
        val startTime = System.currentTimeMillis()
        val batchSize = 20
        val totalDocs = documents.size
        
        // 1. Batch Processing (Chunking)
        documents.chunked(batchSize).forEachIndexed { index, batch ->
            batch.map { doc ->
                async {
                    val vector = embeddingHelper.getEmbedding(doc)
                    NoteEntity(content = doc, embedding = vector)
                }
            }.awaitAll().let { notes ->
                notes.forEach { noteDao.insertNote(it) }
            }
            
            // 4. Progress Tracking
            val currentProgress = ((index + 1) * batchSize).toFloat() / totalDocs
            _progress.value = currentProgress.coerceAtMost(1.0f)
            
            // 3. Memory Management: Hint to GC between batches
            System.gc() 
        }
        
        val totalTime = System.currentTimeMillis() - startTime
        println("Indexed $totalDocs docs in ${totalTime}ms. Avg: ${totalTime/totalDocs}ms/doc")
    }
}
