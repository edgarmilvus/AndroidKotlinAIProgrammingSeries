
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.flow.*

class BatchEmbeddingProcessor @Inject constructor(
    private val context: Context
) {
    private val semaphore = Semaphore(3) // Limit to 3 concurrent inferences to prevent OOM
    private var textEmbedder: TextEmbedder? = null

    private fun initEmbedder(useGpu: Boolean) {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                .setModelAssetPath("model.tflite")
                .setDelegate(if (useGpu) Delegate.GPU : Delegate.CPU)
                .build())
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    fun processAll(texts: List<String>): Flow<Float> = flow {
        initEmbedder(useGpu = true)
        
        // Warm-up phase
        textEmbedder?.embed("warmup")

        val batchSize = 16
        val chunks = texts.chunked(batchSize)
        var processedCount = 0

        coroutineScope {
            chunks.map { batch ->
                async(Dispatchers.Default) {
                    semaphore.withPermit {
                        batch.map { text ->
                            textEmbedder?.embed(text)?.embeddingResult()
                                ?.embeddings()?.first()?.floatEmbedding()
                        }
                    }
                }
            }.awaitAll()
            
            // This is a simplified progress tracker
            chunks.forEach { 
                processedCount += it.size
                emit(processedCount.toFloat() / texts.size)
            }
        }
    }
}
