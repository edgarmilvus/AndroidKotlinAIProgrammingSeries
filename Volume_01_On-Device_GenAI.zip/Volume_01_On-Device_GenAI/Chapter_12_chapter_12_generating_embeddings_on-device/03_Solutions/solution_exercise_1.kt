
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sqrt

// 1. Embedding Pipeline Helper
class TextEmbeddingHelper(context: Context) {
    private val textEmbedder: TextEmbedder = TextEmbedder.createFromOptions(
        context, 
        TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(com.google.mediapipe.tasks.core.BaseOptions.builder()
                .setModelAssetPath("universal_sentence_encoder.tflite") // Ensure model is in assets
                .build())
            .build()
    )

    fun getEmbedding(text: String): FloatArray {
        val result = textEmbedder.embed(text)
        return result.embeddings().get(0).floatArray
    }

    // 2. Cosine Similarity Implementation
    fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

// 3. UI Implementation
@Composable
fun SimilarityScreen(helper: TextEmbeddingHelper) {
    var text1 by remember { mutableStateOf("") }
    var text2 by remember { mutableStateOf("") }
    var resultLabel by remember { mutableStateOf("Enter text to compare") }
    var score by remember { mutableStateOf(0f) }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
        TextField(value = text1, onValueChange = { text1 = it }, label = { Text("Text 1") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        TextField(value = text2, onValueChange = { text2 = it }, label = { Text("Text 2") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(onClick = {
            // Run embedding on background thread to avoid UI freeze
            kotlinx.coroutines.GlobalScope.launch(Dispatchers.Default) {
                val v1 = helper.getEmbedding(text1)
                val v2 = helper.getEmbedding(text2)
                val similarity = helper.calculateCosineSimilarity(v1, v2)
                
                val label = when {
                    similarity > 0.8f -> "Very Similar"
                    similarity > 0.5f -> "Somewhat Related"
                    else -> "Unrelated"
                }
                
                withContext(Dispatchers.Main) {
                    score = similarity
                    resultLabel = label
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Compare")
        }
        
        Text(text = "Score: ${"%.2f".format(score)}", style = MaterialTheme.typography.headlineSmall)
        Text(text = "Result: $resultLabel", style = MaterialTheme.typography.bodyLarge)
    }
}
