
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.qualifiers.ApplicationContext
import com.google.dagger.Module
import com.google.dagger.Provides
import com.google.dagger.hilt.InstallIn
import com.google.dagger.hilt.components.SingletonComponent
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.core.BaseOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// --- Data Model ---
data class Note(val id: Int, val content: String, val embedding: FloatArray? = null)
data class SearchResult(val note: Note, val score: Float)

// --- Hilt Module for MediaPipe ---
@Module
@InstallIn(SingletonComponent::class)
object EmbeddingModule {
    @Provides
    @Singleton
    fun provideTextEmbedder(@ApplicationContext context: Context): TextEmbedder {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("universal_sentence_encoder.tflite").build())
            .build()
        return TextEmbedder.createFromOptions(context, options)
    }
}

// --- Vector Math Utility ---
object VectorMath {
    fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        val magnitude = kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB)
        return if (magnitude == 0f) 0f else dotProduct / magnitude
    }
}

// --- ViewModel ---
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val textEmbedder: TextEmbedder
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults

    // Mock Database
    private val notesDb = listOf(
        Note(1, "Healthy recipes for dinner"),
        Note(2, "Nutritious meals for athletes"),
        Note(3, "How to fix a leaking faucet"),
        Note(4, "Low-calorie cooking tips"),
        Note(5, "Android development with Kotlin")
    ).map { note ->
        // Pre-compute embeddings for the "database"
        val result = textEmbedder.embed(note.content)
        note.copy(embedding = result.embeddingResult().embeddings().first().floatEmbedding())
    }

    private var searchJob: Job? = null

    fun onQueryChanged(query: String) {
        searchJob?.cancel()
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }

        searchJob = viewModelScope.launch(Dispatchers.Default) {
            delay(300) // Debounce to prevent excessive inference
            
            val queryEmbedding = textEmbedder.embed(query)
                .embeddingResult().embeddings().first().floatEmbedding()

            val results = notesDb.mapNotNull { note ->
                note.embedding?.let { emb ->
                    SearchResult(note, VectorMath.cosineSimilarity(queryEmbedding, emb))
                }
            }.sortedByDescending { it.score }.take(5)

            _searchResults.value = results
        }
    }
}
