
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.genai.embeddings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Data model representing a document and its pre-computed embedding.
 */
data class SemanticDocument(
    val id: String,
    val content: String,
    val embedding: FloatArray
)

/**
 * Repository handling the lifecycle of the MediaPipe TextEmbedder.
 * Orchestrates hardware delegation to GPU/NPU for low-latency inference.
 */
@Singleton
class EmbeddingRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null

    // Lazy initialization of the embedder to avoid blocking the main thread during DI
    private suspend fun getEmbedder(): TextEmbedder = withContext(Dispatchers.Default) {
        textEmbedder ?: TextEmbedder.createFromOptions(context, TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                .setModelAssetPath("universal_sentence_encoder.tflite")
                .setDelegate(Delegate.GPU) // Hardware acceleration: Use GPU/NPU
                .build())
            .build()).also { textEmbedder = it }
    }

    suspend fun generateEmbedding(text: String): FloatArray = withContext(Dispatchers.Default) {
        val embedder = getEmbedder()
        // MediaPipe returns a result object containing the embedding vector
        val result = embedder.embed(text)
        result.embedding() ?: throw IllegalStateException("Failed to generate embedding")
    }

    /**
     * Computes Cosine Similarity between two vectors.
     * Formula: (A · B) / (||A|| * ||B||)
     */
    fun computeSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel managing the semantic search state.
 * Implements a reactive flow from query input to ranked results.
 */
@HiltViewModel
@AndroidEntryPoint
class SemanticSearchViewModel @Inject constructor(
    private val repository: EmbeddingRepository
) : ViewModel() {

    private val _searchState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchState: StateFlow<SearchUiState> = _searchState.asStateFlow()

    // Simulated local vector store (In production, this would be a Room DB with a BLOB column)
    private val documentStore = mutableListOf<SemanticDocument>()

    fun addDocument(id: String, content: String) {
        viewModelScope.launch {
            val vector = repository.generateEmbedding(content)
            documentStore.add(SemanticDocument(id, content, vector))
        }
    }

    fun performSemanticSearch(query: String) {
        viewModelScope.launch {
            _searchState.value = SearchUiState.Loading
            
            try {
                // 1. Generate embedding for the user's query on Dispatchers.Default
                val queryVector = repository.generateEmbedding(query)

                // 2. Calculate similarity against all stored documents
                // Using .asSequence() for better performance on large lists
                val results = documentStore.asSequence()
                    .map { doc -> 
                        val score = repository.computeSimilarity(queryVector, doc.embedding)
                        doc to score 
                    }
                    .filter { it.second > 0.7f } // Threshold for relevance
                    .sortedByDescending { it.second }
                    .take(5)
                    .map { it.first }
                    .toList()

                _searchState.value = SearchUiState.Success(results)
            } catch (e: Exception) {
                _searchState.value = SearchUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    sealed class SearchUiState {
        object Idle : SearchUiState()
        object Loading : SearchUiState()
        data class Success(val documents: List<SemanticDocument>) : SearchUiState()
        data class Error(val message: String) : SearchUiState()
    }
}
