
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.embeddings.search

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Data model representing a document with its associated embedding vector.
 */
data class SemanticDocument(
    val id: String,
    val content: String,
    val embedding: FloatArray
)

/**
 * UI State for the Semantic Search screen.
 */
data class SearchUiState(
    val query: String = "",
    val results: List<SemanticDocument> = emptyList(),
    val isProcessing: Boolean = false,
    val errorMessage: String? = null
)

/**
 * Manages the lifecycle and configuration of the MediaPipe Text Embedder.
 * This is a Singleton to avoid the heavy cost of reloading the model into memory.
 */
@Singleton
class EmbeddingModelManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null

    // Using a lazy initialization pattern to ensure the model is loaded on a background thread
    suspend fun getEmbedder(): TextEmbedder = withContext(Dispatchers.Default) {
        textEmbedder?.let { return@withContext it }

        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                BaseOptions.builder()
                    .setModelAssetPath("sentence_transformer_quantized.tflite")
                    // HARDWARE ORCHESTRATION: 
                    // Priority: GPU -> NPU (via NNAPI) -> CPU
                    .setDelegate(Delegate.GPU) 
                    .build()
            )
            .build()

        TextEmbedder.createFromOptions(context, options).also {
            textEmbedder = it
        }
    }

    fun close() {
        textEmbedder?.close()
    }
}

/**
 * Repository handling the logic of embedding generation and vector similarity.
 */
@Singleton
class EmbeddingRepository @Inject constructor(
    private val modelManager: EmbeddingModelManager
) {
    // In a real-world app, this would be a Room database with a BLOB column for the FloatArray
    private val vectorStore = mutableListOf<SemanticDocument>()

    suspend fun addDocument(id: String, text: String) = withContext(Dispatchers.Default) {
        val embedder = modelManager.getEmbedder()
        val embedding = embedder.embed(text).embedding
        vectorStore.add(SemanticDocument(id, text, embedding))
    }

    suspend fun search(query: String, topK: Int = 5): List<SemanticDocument> = withContext(Dispatchers.Default) {
        if (query.isBlank()) return@withContext emptyList()

        val embedder = modelManager.getEmbedder()
        val queryEmbedding = embedder.embed(query).embedding

        // Perform a linear scan for cosine similarity
        // For > 10,000 documents, use an HNSW index or Faiss-like library
        vectorStore
            .map { doc -> 
                doc to cosineSimilarity(queryEmbedding, doc.embedding) 
            }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    /**
     * Mathematical implementation of Cosine Similarity: (A · B) / (||A|| * ||B||)
     */
    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        val denominator = sqrt(normA) * sqrt(normB)
        return if (denominator == 0f) 0f else dotProduct / denominator
    }
}

/**
 * ViewModel implementing MVI pattern for semantic search.
 */
@HiltViewModel
@AndroidEntryPoint
class SemanticSearchViewModel @Inject constructor(
    private val repository: EmbeddingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    /**
     * Handles the search intent. Uses structured concurrency to ensure
     * that previous search jobs are cancelled if a new query is entered.
     */
    private var searchJob: Job? = null

    fun onQueryChanged(newQuery: String) {
        _uiState.update { it.copy(query = newQuery) }
        
        // Debounce search to avoid hammering the NPU on every keystroke
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(300) // 300ms debounce
            performSemanticSearch(newQuery)
        }
    }

    private suspend fun performSemanticSearch(query: String) {
        _uiState.update { it.copy(isProcessing = true, errorMessage = null) }
        
        try {
            // Execute search on Dispatchers.Default via the repository
            val results = repository.search(query)
            _uiState.update { it.copy(results = results, isProcessing = false) }
        } catch (e: Exception) {
            Log.e("SemanticSearch", "Error generating embeddings", e)
            _uiState.update { it.copy(errorMessage = "AI Model Error: ${e.localizedMessage}", isProcessing = false) }
        }
    }

    fun ingestDocument(id: String, text: String) {
        viewModelScope.launch {
            repository.addDocument(id, text)
        }
    }
}
