
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Gradle Dependencies
// implementation("com.google.ai.client.generativeai:generativeai:0.7.0") // Hypothetical AICore Wrapper
// implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
// implementation("androidx.room:room-ktx:2.6.1")

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*

/**
 * Represents a semantic vector in a high-dimensional space.
 * Using a Value Class to avoid heap allocation overhead for the wrapper.
 */
@Serializable
@JvmInline
value class EmbeddingVector(val values: FloatArray) {
    // Calculate cosine similarity between this vector and another
    fun similarity(other: EmbeddingVector): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in values.indices) {
            dotProduct += values[i] * other.values[i]
            normA += values[i] * values[i]
            normB += other.values[i] * other.values[i]
        }
        return dotProduct / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
    }
}

/**
 * The Interface for the Embedding Provider.
 * This abstracts whether we are using AICore, MediaPipe, or a Custom TFLite model.
 */
interface EmbeddingProvider {
    suspend fun generateEmbedding(text: String): EmbeddingVector
    
    // Process a stream of text chunks and emit vectors
    fun generateEmbeddingStream(texts: Flow<String>): Flow<EmbeddingVector> = flow {
        texts.collect { text ->
            emit(generateEmbedding(text))
        }
    }
}

/**
 * Production-ready implementation using a hypothetical AICore client.
 * This would be injected via Hilt.
 */
class AICoreEmbeddingProvider(
    private val aiCoreClient: AICoreClient // System-level service wrapper
) : EmbeddingProvider {

    override suspend fun generateEmbedding(text: String): EmbeddingVector = withContext(Dispatchers.Default) {
        // The 'why': We move to Default dispatcher because the JNI call 
        // to the NPU/GPU is computationally expensive.
        val rawVector = aiCoreClient.embed(text) 
        EmbeddingVector(rawVector)
    }
}

/**
 * Use case for Semantic Search.
 * Demonstrates the integration of Flow and Vector similarity.
 */
class SemanticSearchUseCase(
    private val embeddingProvider: EmbeddingProvider,
    private val vectorDatabase: VectorDao // Room DAO
) {
    suspend fun findSimilarDocuments(query: String): List<Document> {
        // 1. Convert query to vector
        val queryVector = embeddingProvider.generateEmbedding(query)
        
        // 2. Retrieve all candidates from local DB
        val candidates = vectorDatabase.getAllEmbeddings()
        
        // 3. Rank by cosine similarity
        return candidates
            .map { doc -> doc to queryVector.similarity(doc.vector) }
            .filter { it.second > 0.7f } // Threshold for relevance
            .sortedByDescending { it.second }
            .map { it.first }
    }
}
