
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PrivacyFirstRepository @Inject constructor(
    private val embeddingService: EmbeddingService,
    private val vectorStore: LocalVectorStore,
    private val genAIService: LocalGenAIService
) {
    /**
     * The core RAG pipeline:
     * 1. Embed the user query.
     * 2. Retrieve top-K relevant local documents.
     * 3. Construct a grounded prompt.
     * 4. Generate a response using the local LLM.
     */
    suspend fun askPrivateQuestion(query: String): String = withContext(Dispatchers.Default) {
        // Step 1: Vectorize the query
        val queryVector = embeddingService.embed(query)

        // Step 2: Retrieve relevant context from the local store
        val relevantDocs = vectorStore.search(queryVector, topK = 3)
        val contextText = relevantDocs.joinToString("\n") { it.content }

        // Step 3: Augment the prompt
        // We explicitly tell the LLM to use ONLY the provided context for privacy and accuracy.
        val augmentedPrompt = """
            You are a private assistant. Use the following snippets of the user's 
            personal notes to answer the question. If the answer is not in the 
            context, say "I don't have that information in your notes."
            
            CONTEXT:
            $contextText
            
            USER QUESTION: 
            $query
            
            ANSWER:
        """.trimIndent()

        // Step 4: Generate the response locally
        return@withContext genAIService.generateResponse(augmentedPrompt)
    }

    /**
     * Indexes a new piece of text into the local store.
     */
    suspend fun indexNote(id: String, content: String) = withContext(Dispatchers.Default) {
        val vector = embeddingService.embed(content)
        vectorStore.addDocument(LocalDocument(id, content, vector))
    }
}
