
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Data model representing a piece of private information and its vector representation.
 */
data class DocumentChunk(
    val text: String,
    val embedding: FloatArray
)

/**
 * Repository handling the "Privacy-First" retrieval logic.
 * It uses MediaPipe to turn text into vectors and performs a local similarity search.
 */
@Singleton
class LocalRetrievalRepository @Inject constructor(context: Context) {
    
    // Initialize MediaPipe Text Embedder
    private val textEmbedder: TextEmbedder = TextEmbedder.createFromOptions(
        context,
        TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite") // Model must be in assets
                    .build()
            ).build()
    )

    // Simple in-memory vector store for demonstration
    private val vectorStore = mutableListOf<DocumentChunk>()

    /**
     * Indexes private text into the local store.
     * In a production app, this would be saved to a Room database using a Vector extension.
     */
    suspend fun indexDocument(text: String) = withContext(Dispatchers.Default) {
        val embedding = getEmbedding(text)
        vectorStore.add(DocumentChunk(text, embedding))
    }

    /**
     * Retrieves the most relevant text chunks based on the query.
     */
    suspend fun retrieveRelevantContext(query: String, topK: Int = 2): List<String> = withContext(Dispatchers.Default) {
        val queryEmbedding = getEmbedding(query)
        
        // Calculate cosine similarity between query and all stored documents
        vectorStore
            .map { chunk -> chunk to cosineSimilarity(queryEmbedding, chunk.embedding) }
            .sortedByDescending { it.second } // Highest similarity first
            .take(topK)
            .map { it.first.text }
    }

    private fun getEmbedding(text: String): FloatArray {
        val result: TextEmbedderResult = textEmbedder.embed(text)
        return result.embeddingResult().embeddings().get(0).floatArray
    }

    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel that orchestrates the flow: Query -> Retrieval -> Gemini Nano -> UI.
 */
@HiltViewModel
class PrivacyFirstViewModel @Inject constructor(
    private val repository: LocalRetrievalRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<String>("Ask something about your private data...")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    fun onQuerySubmitted(query: String) {
        viewModelScope.launch {
            _uiState.value = "Searching local records..."
            
            // 1. Retrieval Step (Privacy-First)
            val contextChunks = repository.retrieveRelevantContext(query)
            val contextString = contextChunks.joinToString("\n")

            _uiState.value = "Generating answer locally..."

            // 2. Augmentation & Generation Step
            val finalAnswer = generateLocalResponse(query, contextString)
            _uiState.value = finalAnswer
        }
    }

    private suspend fun generateLocalResponse(query: String, context: String): String = withContext(Dispatchers.Default) {
        // Construct a prompt that tells Gemini Nano to use ONLY the provided context
        val prompt = """
            You are a private assistant. Use the following local context to answer the user's question.
            If the answer is not in the context, say "I don't have that information in your local records."
            
            Context:
            $context
            
            Question: $query
            Answer:
        """.trimIndent()

        try {
            // This is a conceptual call to AICore/Gemini Nano
            // In reality, you use the GenerativeModel API from the Google AI SDK
            // return GeminiNano.generate(prompt)
            "Local Response based on: $context \n\nAnswer: This is a simulated Gemini Nano response."
        } catch (e: Exception) {
            "Error generating local response: ${e.message}"
        }
    }
}
