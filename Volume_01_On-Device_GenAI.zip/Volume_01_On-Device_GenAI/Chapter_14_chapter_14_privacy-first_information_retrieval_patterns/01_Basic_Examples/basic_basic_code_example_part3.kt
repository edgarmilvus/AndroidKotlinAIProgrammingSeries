
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder.TextEmbedderOptions
import java.io.File

/**
 * Handles the transformation of text to vectors using a local TFLite model.
 * This ensures that the text being "indexed" never leaves the device.
 */
class EmbeddingService(context: Context) {
    private var textEmbedder: TextEmbedder? = null

    init {
        // Initialize the MediaPipe TextEmbedder with a local model file
        val options = TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite") 
                    .build()
            )
            .build()
        
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    /**
     * Converts a string into a FloatArray embedding.
     * This is a computationally expensive operation; must be called on Dispatchers.Default.
     */
    fun embed(text: String): FloatArray {
        val result = textEmbedder?.embed(text) 
            ?: throw IllegalStateException("TextEmbedder not initialized")
        
        // MediaPipe returns a result object; we extract the embedding vector
        return result.embeddingResult().embeddings().get(0).floatArray()
    }
    
    fun close() {
        textEmbedder?.close()
    }
}
