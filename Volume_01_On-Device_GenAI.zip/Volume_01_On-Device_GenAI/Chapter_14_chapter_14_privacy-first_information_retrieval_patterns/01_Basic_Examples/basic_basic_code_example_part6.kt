
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JournalViewModel @Inject constructor(
    private val repository: PrivacyFirstRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<JournalUiState>(JournalUiState.Idle)
    val uiState: StateFlow<JournalUiState> = _uiState.asStateFlow()

    fun onQuerySubmitted(query: String) {
        viewModelScope.launch {
            _uiState.value = JournalUiState.Loading
            val response = repository.askPrivateQuestion(query)
            _uiState.value = JournalUiState.Success(response)
        }
    }

    fun onNoteAdded(id: String, content: String) {
        viewModelScope.launch {
            repository.indexNote(id, content)
        }
    }
}

sealed class JournalUiState {
    object Idle : JournalUiState()
    object Loading : JournalUiState()
    data class Success(val answer: String) : JournalUiState()
}

// --- Compose UI ---
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PrivacyJournalScreen(viewModel: JournalViewModel) {
    var query by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Text(text = "Private Memory Assistant", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        TextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Ask about your notes...") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Button(
            onClick = { viewModel.onQuerySubmitted(query) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Ask Locally")
        }

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        when (state) {
            is JournalUiState.Loading -> CircularProgressIndicator()
            is JournalUiState.Success -> {
                Text(
                    text = (state as JournalUiState.Success).answer,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            else -> Text("Enter a question to begin.")
        }
    }
}
