
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.privacy.retrieval

import android.content.Context
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.Singletons
import dagger.hilt.android.scope.ViewModelScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as javaxInject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate

/**
 * DATA MODELS
 */
data class KnowledgeDocument(val id: String, val content: String, val embedding: FloatArray)
data class RetrievalState(
    val query: String = "",
    val response: String = "",
    val isProcessing: Boolean = false,
    val error: String? = null
)

/**
 * LOCAL EMBEDDING ENGINE
 * Handles the conversion of text to high-dimensional vectors using TFLite.
 * Optimized for GPU execution to ensure low-latency retrieval.
 */
@Singleton
class LocalEmbeddingEngine @javaxInject constructor(
    @ApplicationContext private val context: Context
) {
    private var interpreter: Interpreter? = null
    private val gpuDelegate = GpuDelegate()

    init {
        // Load the embedding model (e.g., Sentence-BERT or MobileBERT) from assets
        val options = Interpreter.Options().apply {
            addDelegate(gpuDelegate)
            setNumThreads(4)
        }
        // In production, use a specific .tflite file for embeddings
        // interpreter = Interpreter(loadModelFile("embedding_model.tflite"), options)
    }

    suspend fun embed(text: String): FloatArray = withContext(Dispatchers.Default) {
        // Simulation of TFLite inference: Text -> Tokenization -> Model -> Vector
        // In a real implementation, you would call interpreter?.run(input, output)
        Log.d("EmbeddingEngine", "Vectorizing text on GPU: $text")
        FloatArray(384) { (0..1000).random() / 1000f } // Mocked 384-dim vector
    }

    fun calculateCosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        var dotProduct = 0f
        var normA = 0f
        var normB = 0f
        for (i in v1.indices) {
            dotProduct += v1[i] * v2[i]
            normA += v1[i] * v1[i]
            normB += v2[i] * v2[i]
        }
        return dotProduct / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble())).toFloat()
    }
}

/**
 * PRIVACY-FIRST REPOSITORY
 * Orchestrates the flow between the Vector Store, Embedding Engine, and Gemini Nano.
 */
@Singleton
class PrivacyKnowledgeRepository @javaxInject constructor(
    private val embeddingEngine: LocalEmbeddingEngine,
    @ApplicationContext private val context: Context
) {
    // Simulated local Vector DB (In production, use Room with a BLOB for embeddings)
    private val vectorStore = mutableListOf<KnowledgeDocument>()

    // Initialize Gemini Nano via MediaPipe
    private val llmInference = LlmInference.createFromOptions(context, 
        LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to on-device model
            .setMaxTokens(512)
            .setTemperature(0.7f)
            .build()
    )

    suspend fun addDocument(text: String) {
        val vector = embeddingEngine.embed(text)
        vectorStore.add(KnowledgeDocument(java.util.UUID.randomUUID().toString(), text, vector))
    }

    suspend fun retrieveAndGenerate(query: String): Result<String> = withContext(Dispatchers.Default) {
        try {
            // 1. Vectorize the user query
            val queryVector = embeddingEngine.embed(query)

            // 2. Local Vector Search (Cosine Similarity)
            // We sort documents by similarity and take the top 3 (Top-K)
            val contextDocuments = vectorStore
                .map { it to embeddingEngine.calculateCosineSimilarity(queryVector, it.embedding) }
                .filter { it.second > 0.7f } // Similarity threshold
                .sortedByDescending { it.second }
                .take(3)
                .map { it.first.content }
                .joinToString("\n---\n")

            if (contextDocuments.isEmpty()) {
                return@withContext Result.success("I couldn't find any relevant private notes to answer this.")
            }

            // 3. Construct the Augmented Prompt
            // This is the critical "Privacy-First" prompt engineering step
            val augmentedPrompt = """
                You are a private assistant. Use the following excerpts from the user's 
                private notes to answer the question. If the answer isn't in the context, 
                say you don't know. Do not use outside knowledge.
                
                CONTEXT:
                $contextDocuments
                
                QUESTION: 
                $query
                
                ANSWER:
            """.trimIndent()

            // 4. Local LLM Inference (Gemini Nano)
            val response = llmInference.generateResponse(augmentedPrompt)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * RETRIEVAL VIEWMODEL
 * Implements MVI pattern to handle the AI pipeline state.
 */
@HiltViewModel
@ViewModelScoped
class RetrievalViewModel @javaxInject constructor(
    private val repository: PrivacyKnowledgeRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(RetrievalState())
    val uiState: StateFlow<RetrievalState> = _uiState.asStateFlow()

    fun onQuerySubmitted(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(query = query, isProcessing = true, error = null) }
            
            // Structured Concurrency: Ensure the AI task is cancelled if ViewModel is cleared
            val result = repository.retrieveAndGenerate(query)
            
            result.onSuccess { answer ->
                _uiState.update { it.copy(response = answer, isProcessing = false) }
            }.onFailure { exception ->
                _uiState.update { it.copy(error = exception.message, isProcessing = false) }
            }
        }
    }

    fun onNoteAdded(note: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addDocument(note)
        }
    }
}
