
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.kt
// Description: Advanced Application
// ==========================================

// Gradle Dependencies (Kotlin DSL)
/*
implementation("com.google.ai.client.generativeai:generativeai:0.7.0") // Gemini Nano/AICore
implementation("com.google.mediapipe:tasks-text:0.10.14")           // MediaPipe for Embeddings
implementation("com.google.dagger:hilt-android:2.51.1")
implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
*/

package com.ai.privacy.retrieval

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the state of the Privacy-First Retrieval process.
 */
sealed interface RetrievalState {
    object Idle : RetrievalState
    object EmbeddingQuery : RetrievalState
    object SearchingLocalStore : RetrievalState
    object SynthesizingAnswer : RetrievalState
    data class Success(val answer: String, val sources: List<String>) : RetrievalState
    data class Error(val message: String) : RetrievalState
}

/**
 * Repository handling the heavy lifting of the Local RAG pipeline.
 * Orchestrates MediaPipe (Embeddings) and AICore (Gemini Nano).
 */
@Singleton
class LocalRAGRepository @Inject constructor(
    private val embeddingEngine: EmbeddingEngine, // Wrapper for MediaPipe TFLite
    private val vectorStore: LocalVectorStore,   // Local vector DB (e.g., ObjectBox)
    private val geminiNano: GeminiNanoClient     // AICore Wrapper
) {
    // We use Dispatchers.Default for AI workloads to avoid blocking the Main thread
    // and to leverage multi-core CPU/NPU capabilities.
    private val aiDispatcher = Dispatchers.Default

    suspend fun performPrivacyFirstQuery(query: String): RetrievalResult = withContext(aiDispatcher) {
        try {
            // 1. Generate Embedding for the user query (GPU/NPU Accelerated)
            val queryVector = embeddingEngine.embedText(query)

            // 2. Perform Vector Search for top-K most relevant local documents
            val relevantDocs = vectorStore.findNearestNeighbors(queryVector, k = 3)
            
            if (relevantDocs.isEmpty()) {
                return@withContext RetrievalResult.NoContextFound
            }

            // 3. Construct a Privacy-Preserving Prompt
            // We inject the local context directly into the prompt for Gemini Nano
            val contextBlock = relevantDocs.joinToString("\n\n") { it.content }
            val augmentedPrompt = """
                You are a private on-device assistant. Use the following pieces of 
                retrieved local context to answer the user's question. 
                If the answer is not in the context, say you don't know.
                
                CONTEXT:
                $contextBlock
                
                USER QUESTION: 
                $query
                
                ANSWER:
            """.trimIndent()

            // 4. Synthesis via Gemini Nano (AICore)
            val finalAnswer = geminiNano.generateResponse(augmentedPrompt)
            
            RetrievalResult.Success(
                answer = finalAnswer, 
                sources = relevantDocs.map { it.sourceId }
            )
        } catch (e: Exception) {
            Log.e("LocalRAG", "Pipeline failure", e)
            RetrievalResult.Failure(e.localizedMessage ?: "Unknown Error")
        }
    }
}

/**
 * ViewModel implementing MVI-style state management for the Retrieval UI.
 */
@HiltViewModel
class PrivateKnowledgeBaseViewModel @Inject constructor(
    private val repository: LocalRAGRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<RetrievalState>(RetrievalState.Idle)
    val uiState: StateFlow<RetrievalState> = _uiState.asStateFlow()

    fun askQuestion(query: String) {
        if (query.isBlank()) return

        // Structured Concurrency: launch in viewModelScope
        viewModelScope.launch {
            _uiState.value = RetrievalState.EmbeddingQuery
            
            // Transition through states to provide granular UI feedback
            // Note: In a real app, the repository could emit a Flow of progress
            _uiState.value = RetrievalState.SearchingLocalStore
            
            val result = repository.performPrivacyFirstQuery(query)
            
            _uiState.value = RetrievalState.SynthesizingAnswer
            
            when (result) {
                is RetrievalResult.Success -> {
                    _uiState.value = RetrievalState.Success(result.answer, result.sources)
                }
                is RetrievalResult.NoContextFound -> {
                    _uiState.value = RetrievalState.Error("No local information found regarding this topic.")
                }
                is RetrievalResult.Failure -> {
                    _uiState.value = RetrievalState.Error(result.error)
                }
            }
        }
    }
}

// --- Supporting Data Models & Interfaces ---

data class LocalDocument(val sourceId: String, val content: String, val vector: FloatArray)
sealed class RetrievalResult {
    data class Success(val answer: String, val sources: List<String>) : RetrievalResult()
    object NoContextFound : RetrievalResult()
    data class Failure(val error: String) : RetrievalResult()
}

interface EmbeddingEngine {
    suspend fun embedText(text: String): FloatArray
}

interface LocalVectorStore {
    suspend fun findNearestNeighbors(vector: FloatArray, k: Int): List<LocalDocument>
}

interface GeminiNanoClient {
    suspend fun generateResponse(prompt: String): String
}
