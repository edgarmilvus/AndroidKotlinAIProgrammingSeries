
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.*

class DocumentProcessor {
    // Sliding Window Chunking: 500 chars with 50 char overlap
    fun chunkText(text: String, chunkSize: Int = 500, overlap: Int = 50): List<String> {
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            val end = (start + chunkSize).coerceAtMost(text.length)
            chunks.add(text.substring(start, end))
            if (end == text.length) break
            start += (chunkSize - overlap)
        }
        return chunks
    }
}

class RAGCoordinator @Inject constructor(
    private val embeddingService: EmbeddingService,
    private val noteDao: NoteDao, // Reusing NoteDao logic for chunks
    private val generativeModel: GenerativeModel
) {
    suspend fun answerQuestion(query: String): String = withContext(Dispatchers.IO) {
        // 1. Retrieval Phase
        val queryVector = embeddingService.embed(query)
        val allChunks = noteDao.getAllNotes() // Assuming chunks stored as NoteEntity
        
        val topKChunks = allChunks
            .map { it to embeddingService.calculateCosineSimilarity(queryVector, it.embedding) }
            .sortedByDescending { it.second }
            .take(3) // Retrieve Top-3
            .map { it.first.content }
            .joinToString("\n---\n")

        // 2. Grounding Phase
        val groundedPrompt = """
            You are a technical assistant. Use ONLY the provided context to answer the question.
            If the answer is not contained within the context, say "I don't know based on the provided documentation."
            
            CONTEXT:
            $topKChunks
            
            QUESTION: 
            $query
            
            ANSWER:
        """.trimIndent()

        val response = generativeModel.generateContent(groundedPrompt)
        response.text ?: "No answer could be generated."
    }
}
