
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// --- Hilt Module ---
@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides @Singleton
    fun provideTextEmbedder(): TextEmbedder = TextEmbedder.create() // Simplified init

    @Provides @Singleton
    fun provideLlmInference(): LlmInference = LlmInference.create() // Simplified init
}

// --- RAG Manager ---
class VaultQueryManager @Inject constructor(
    private val embedder: TextEmbedder,
    private val llm: LlmInference,
    private val vectorStore: LocalVectorStore // Assume Room-based store
) {
    suspend fun askVault(userQuery: String): String = withContext(Dispatchers.Default) {
        // 1. Embedding Generation
        val queryVector = embedder.embed(userQuery)

        // 2. Vector Search
        val contextDocs = vectorStore.findNearest(queryVector, k = 3)
        val contextText = contextDocs.joinToString("\n") { it.text }

        // 3. Prompt Engineering (Strict Grounding)
        val systemPrompt = """
            You are a secure vault assistant. Answer the question using ONLY the provided context.
            If the answer is not in the context, say "I don't know." 
            Do not use outside knowledge.
            
            Context:
            $contextText
            
            Question: $userQuery
            Answer:
        """.trimIndent()

        // 4. Synthesis via Gemini Nano
        return@withContext llm.generateResponse(systemPrompt)
    }
}
