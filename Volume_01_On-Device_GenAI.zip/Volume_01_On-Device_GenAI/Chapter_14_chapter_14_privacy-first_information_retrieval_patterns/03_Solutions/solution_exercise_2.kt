
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

data class HealthMetric(val type: String, val value: String, val timestamp: Long)

class HealthPromptBuilder {
    fun buildSummaryPrompt(metrics: List<HealthMetric>): String {
        val dataString = metrics.joinToString("\n") { "${it.type}: ${it.value}" }
        return """
            SYSTEM INSTRUCTION: You are a private health data summarizer. 
            Your goal is to identify trends in the user's data. 
            CRITICAL: Do not provide medical diagnoses, prescriptions, or clinical advice. 
            If data looks abnormal, simply suggest the user consult a professional.
            
            USER DATA FOR TODAY:
            $dataString
            
            Please provide a concise, encouraging summary of today's health trends.
        """.trimIndent()
    }
}

class HealthSummaryViewModel @Inject constructor(
    private val promptBuilder: HealthPromptBuilder
) : androidx.lifecycle.ViewModel() {

    // Initializing Gemini Nano via the Google AI Edge SDK
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano", 
        apiKey = "NOT_NEEDED_FOR_AICORE" // AICore handles auth internally on-device
    )

    fun generateDailySummary(metrics: List<HealthMetric>): Flow<String> = flow {
        try {
            val prompt = promptBuilder.buildSummaryPrompt(metrics)
            
            // Using the suspend function for generation
            val response = generativeModel.generateContent(prompt)
            emit(response.text ?: "Unable to generate summary.")
        } catch (e: Exception) {
            emit("Error accessing AICore: ${e.localizedMessage}")
        }
    }
}
