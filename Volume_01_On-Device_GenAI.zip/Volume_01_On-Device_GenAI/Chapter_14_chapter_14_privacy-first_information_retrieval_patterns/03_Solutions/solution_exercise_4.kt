
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.util.LruCache
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.text_embedder.TextEmbedder
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.*

class OptimizedEmbeddingService(context: Context) {
    private val textEmbedder: TextEmbedder by lazy {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                .setModelAssetPath("embedding_model_int8.tflite") // Using Quantized Model
                .setDelegate(Delegate.GPU) // Hardware Acceleration
                .build())
            .build()
        TextEmbedder.createFromOptions(context, options)
    }

    fun embed(text: String) = textEmbedder.embed(text).embedding
}

class OptimizedRAGViewModel @Inject constructor(
    private val embeddingService: OptimizedEmbeddingService,
    private val generativeModel: GenerativeModel
) : androidx.lifecycle.ViewModel() {

    // LRU Cache to store common query results (Query -> Response)
    private val responseCache = LruCache<String, String>(100)

    fun askQuestionStreaming(query: String): Flow<String> = flow {
        // 1. Cache Lookup
        responseCache.get(query)?.let {
            emit(it)
            return@flow
        }

        // 2. Streaming Generation
        val prompt = "Context: ... Question: $query" // Simplified for brevity
        val fullResponse = StringBuilder()
        
        generativeModel.generateContentStream(prompt).collect { chunk ->
            val text = chunk.text ?: ""
            fullResponse.append(text)
            emit(text) // Stream token-by-token to UI
        }
        
        // 3. Store in Cache
        responseCache.put(query, fullResponse.toString())
    }
}
