
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.paging.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class OptimizedSearchManager(private val embedder: TextEmbedder) {

    // 1. Embedding Batching: Processes docs in chunks to reduce native bridge overhead
    suspend fun batchProcessEmbeddings(texts: List<String>): List<FloatArray> = withContext(Dispatchers.Default) {
        texts.chunked(10).flatMap { batch ->
            embedder.embedBatch(batch) // Hypothetical batch API
        }
    }

    // 2. Simplified Quantization: Convert Float32 to Float16 (simulated via Short/Half-precision logic)
    // In a real scenario, use ByteBuffer.allocateDirect and Float.floatToFloat16 (if available)
    fun quantizeVector(vector: FloatArray): ShortArray {
        return ShortArray(vector.size) { i ->
            (vector[i] * 32767).toInt().toShort() 
        }
    }

    // 3. Asynchronous Paging for UI responsiveness
    fun getSemanticSearchResults(query: String, allDocs: List<Document>): Flow<PagingData<Document>> {
        return Pager(PagingConfig(pageSize = 20)) {
            object : PagingSource<Int, Document>() {
                override fun getRefreshKey(state: PagingState<Int, Document>): Int? = null
                
                override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Document> {
                    val queryVector = embedder.embed(query)
                    val sorted = allDocs.sortedByDescending { 
                        calculateCosineSimilarity(queryVector, it.embedding) 
                    }
                    
                    val page = sorted.drop(params.prevKey ?: 0).take(params.loadSize)
                    return LoadResult.Page(
                        data = page,
                        prevKey = if (params.prevKey == null) null else params.prevKey - params.loadSize,
                        nextKey = if (page.isEmpty()) null else (params.prevKey ?: 0) + params.loadSize
                    )
                }
            }
        }.flow
    }
}
