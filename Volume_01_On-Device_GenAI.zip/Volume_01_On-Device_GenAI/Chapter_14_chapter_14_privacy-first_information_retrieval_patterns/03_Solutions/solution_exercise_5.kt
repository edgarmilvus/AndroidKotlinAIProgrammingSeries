
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*

class HybridSearchManager(
    private val ftsDao: FtsDao, 
    private val vectorStore: LocalVectorStore,
    private val embedder: TextEmbedder
) {
    private val K = 60 // Standard RRF constant

    suspend fun hybridSearch(query: String): List<Document> = coroutineScope {
        // 1. Dual-Path Retrieval (Parallel Execution)
        val ftsDeferred = async { ftsDao.searchKeywords(query) }
        val vectorDeferred = async { 
            val vec = embedder.embed(query)
            vectorStore.findNearest(vec, k = 50)
        }

        val ftsResults = ftsDeferred.await()
        val vectorResults = vectorDeferred.await()

        // 2. Reciprocal Rank Fusion (RRF)
        val scores = mutableMapOf<Int, Double>()

        // Process FTS Ranks
        ftsResults.forEachIndexed { index, doc ->
            val rank = index + 1
            scores[doc.id] = scores.getOrDefault(doc.id, 0.0) + (1.0 / (K + rank))
        }

        // Process Vector Ranks
        vectorResults.forEachIndexed { index, doc ->
            val rank = index + 1
            scores[doc.id] = scores.getOrDefault(doc.id, 0.0) + (1.0 / (K + rank))
        }

        // 3. Merge and Return Top Results
        return@coroutineScope scores.entries
            .sortedByDescending { it.value }
            .take(10)
            .map { entry -> vectorStore.getDocumentById(entry.key) }
    }
}
