
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.tasks.vision.image_embedder.ImageEmbedder
import com.google.mediapipe.tasks.text.text_embedder.TextEmbedder
import androidx.work.*

class MultiModalEmbeddingService(context: Context) {
    // CLIP-style models provide a shared embedding space
    private val textEmbedder = TextEmbedder.createFromOptions(context, 
        TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("clip_text.tflite").build())
            .build())

    private val imageEmbedder = ImageEmbedder.createFromOptions(context, 
        ImageEmbedder.ImageEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("clip_image.tflite").build())
            .build())

    fun embedText(text: String) = textEmbedder.embed(text).embedding
    fun embedImage(bitmap: Bitmap) = imageEmbedder.embed(bitmap).embedding
}

class ImageIndexingWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val service = MultiModalEmbeddingService(applicationContext)
        val images = fetchImagesFromMediaStore() // Helper to get local Bitmaps
        
        images.forEach { bitmap ->
            val vector = service.embedImage(bitmap)
            saveToVectorDb(bitmap.id, vector) // Store in Room/SQLite
        }
        Result.success()
    }
    
    private fun fetchImagesFromMediaStore(): List<Bitmap> { /* Implementation */ return emptyList() }
    private fun saveToVectorDb(id: Long, vector: FloatArray) { /* Implementation */ }
}

class VisualSearchViewModel @Inject constructor(
    private val multiModalService: MultiModalEmbeddingService,
    private val vectorDb: VectorDb
) : androidx.lifecycle.ViewModel() {

    suspend fun searchImages(query: String): List<ImageResult> = withContext(Dispatchers.IO) {
        // Convert text query to the shared vector space
        val queryVector = multiModalService.embedText(query)
        
        // Compare text vector directly against image vectors
        val allImageVectors = vectorDb.getAllVectors()
        allImageVectors
            .map { it to calculateCosineSimilarity(queryVector, it.vector) }
            .sortedByDescending { it.second }
            .take(5)
            .map { ImageResult(it.first.id) }
    }
    
    private fun calculateCosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        // Standard cosine similarity implementation...
        return 0.0f 
    }
}
