
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import androidx.room.*
import com.google.mediapipe.tasks.text.text_embedder.TextEmbedder
import com.google.mediapipe.tasks.core.BaseOptions
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// 1. Data Layer: Room Entity
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    @ColumnInfo(typeAffinity = ColumnInfo.BLOB) 
    val embedding: FloatArray // Stored as BLOB in SQLite
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes")
    suspend fun getAllNotes(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)
}

@Database(entities = [NoteEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
}

// 2. Embedding Service
@Singleton
class EmbeddingService @Inject constructor(context: Context) {
    private val textEmbedder: TextEmbedder by lazy {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("embedding_model.tflite").build())
            .build()
        TextEmbedder.createFromOptions(context, options)
    }

    fun embed(text: String): FloatArray {
        return textEmbedder.embed(text).embedding
    }

    fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble())).toFloat()
    }
}

// 3. ViewModel for Search Logic
@AndroidEntryPoint
class NoteViewModel @Inject constructor(
    private val noteDao: NoteDao,
    private val embeddingService: EmbeddingService
) : androidx.lifecycle.ViewModel() {

    suspend fun searchNotes(query: String): List<Pair<NoteEntity, Float>> = withContext(Dispatchers.IO) {
        val queryVector = embeddingService.embed(query)
        val allNotes = noteDao.getAllNotes()

        allNotes.map { note ->
            val similarity = embeddingService.calculateCosineSimilarity(queryVector, note.embedding)
            note to similarity
        }.sortedByDescending { it.second }
    }
    
    suspend fun saveNote(content: String) = withContext(Dispatchers.IO) {
        val vector = embeddingService.embed(content)
        noteDao.insertNote(NoteEntity(content = content, embedding = vector))
    }
}
