
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.ondeviceai.semanticsearch

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sqrt

/**
 * 1. DATA MODEL
 * Represents a piece of knowledge stored in our local "Vector Store".
 */
data class KnowledgeSnippet(
    val id: Int,
    val text: String,
    val embedding: FloatArray
)

/**
 * 2. THE SEMANTIC REPOSITORY
 * Handles the conversion of text to vectors and the similarity search.
 */
class SemanticSearchRepository(context: Context) {
    private var textEmbedder: TextEmbedder? = null
    private val knowledgeBase = mutableListOf<KnowledgeSnippet>()

    init {
        setupEmbedder(context)
    }

    private fun setupEmbedder(context: Context) {
        // Initialize MediaPipe TextEmbedder
        // The model file (.tflite) must be in the 'assets' folder
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite")
                    .build()
            )
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    /**
     * Converts a string into a high-dimensional vector.
     * This is a CPU/GPU intensive task and must be called on Dispatchers.Default.
     */
    fun embedText(text: String): FloatArray {
        val result: TextEmbedderResult = textEmbedder!!.embed(text)
        return result.embedding()
    }

    /**
     * Seeds the local store with some initial data.
     * In a real app, this would happen during onboarding or via a background sync.
     */
    suspend fun seedKnowledgeBase() = withContext(Dispatchers.Default) {
        val documents = listOf(
            "To reset your password, go to Settings > Security > Reset Password.",
            "Our refund policy allows returns within 30 days of purchase.",
            "You can enable Dark Mode in the Appearance section of the settings.",
            "Contact support at support@example.com for technical issues.",
            "The premium subscription costs $9.99 per month."
        )

        documents.forEachIndexed { index, text ->
            val vector = embedText(text)
            knowledgeBase.add(KnowledgeSnippet(index, text, vector))
        }
    }

    /**
     * Performs a Cosine Similarity search to find the most relevant snippet.
     */
    fun findMostRelevant(query: String): String? {
        val queryVector = embedText(query)
        
        // Find the snippet with the highest cosine similarity
        return knowledgeBase
            .map { it to cosineSimilarity(queryVector, it.embedding) }
            .maxByOrNull { it.second }
            ?.first?.text
    }

    /**
     * MATHEMATICAL CORE: Cosine Similarity
     * Formula: (A · B) / (||A|| * ||B||)
     */
    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * 3. THE VIEWMODEL
 * Orchestrates the flow: Query -> Search -> Context Injection -> Final Prompt.
 */
class SearchViewModel(private val repository: SemanticSearchRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            repository.seedKnowledgeBase()
            _uiState.value = SearchUiState.Idle
        }
    }

    fun performSemanticSearch(userQuery: String) {
        viewModelScope.launch {
            _uiState.value = SearchUiState.Processing
            
            // Switch to Default dispatcher for heavy mathematical calculations
            val result = withContext(Dispatchers.Default) {
                val context = repository.findMostRelevant(userQuery)
                
                if (context != null) {
                    // CONTEXT INJECTION STEP:
                    // We wrap the retrieved context into a prompt that guides the LLM.
                    "CONTEXT: $context\n\nUSER QUESTION: $userQuery\n\nANSWER (Based only on the context provided):"
                } else {
                    "I'm sorry, I couldn't find any relevant information in the local knowledge base."
                }
            }
            
            _uiState.value = SearchUiState.Success(result)
        }
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    object Processing : SearchUiState()
    data class Success(val finalPrompt: String) : SearchUiState()
}

/**
 * 4. THE UI LAYER (Jetpack Compose)
 */
@Composable
fun SemanticSearchScreen(viewModel: SearchViewModel) {
    var query by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "On-Device Semantic Search", style = MaterialTheme.typography.headlineMedium)
        
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Ask a question (e.g., 'How do I change my password?')") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.performSemanticSearch(query) },
            modifier = Modifier.fillMaxWidth(),
            enabled = state !is SearchUiState.Processing
        ) {
            Text(if (state is SearchUiState.Processing) "Searching..." else "Search & Inject")
        }

        Divider()

        when (val s = state) {
            is SearchUiState.Loading -> CircularProgressIndicator()
            is SearchUiState.Success -> {
                Text(text = "Generated Prompt for Gemini Nano:", style = MaterialTheme.typography.labelLarge)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = s.finalPrompt,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            else -> Text("Enter a query to see the Context Injection pipeline in action.")
        }
    }
}
