
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * 1. The Embedding Repository
 * Handles the heavy lifting of converting text to vectors and calculating similarity.
 */
@Singleton
class EmbeddingRepository @Inject constructor(context: Context) {
    
    // Initialize MediaPipe TextEmbedder
    private val textEmbedder: TextEmbedder by lazy {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite") // Model must be in assets
                    .build()
            )
            .build()
        TextEmbedder.createFromOptions(context, options)
    }

    /**
     * Converts a string into a float array (embedding).
     * Must be called on a background thread.
     */
    fun embedText(text: String): FloatArray {
        val result: TextEmbedderResult = textEmbedder.embed(text)
        return result.embeddingResult().embeddings().get(0).floatArray()
    }

    /**
     * Calculates Cosine Similarity between two vectors.
     * Formula: (A · B) / (||A|| * ||B||)
     */
    fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * 2. The ViewModel
 * Orchestrates the search flow and manages UI state.
 */
@HiltViewModel
class SemanticSearchViewModel @Inject constructor(
    private val repository: EmbeddingRepository
) : ViewModel() {

    // Local "Knowledge Base" - in a real app, these would be stored in a Vector DB or Room
    private val knowledgeBase = listOf(
        "The company vacation policy allows for 25 days of paid time off per year.",
        "Health insurance covers dental and vision starting from the first day of employment.",
        "The office is located in downtown San Francisco and is open from 9 AM to 6 PM.",
        "Employees can request a home-office stipend of up to $500 for ergonomic furniture."
    )

    private val _searchResult = MutableStateFlow<String>("")
    val searchResult: StateFlow<String> = _searchResult.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun performSemanticSearch(query: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            
            // Switch to Default dispatcher for CPU-intensive AI work
            val result = withContext(Dispatchers.Default) {
                try {
                    val queryVector = repository.embedText(query)
                    
                    // Find the document with the highest cosine similarity
                    knowledgeBase
                        .map { doc -> 
                            val docVector = repository.embedText(doc)
                            doc to repository.calculateCosineSimilarity(queryVector, docVector)
                        }
                        .maxByOrNull { it.second } // Get the highest similarity score
                        ?.first ?: "No relevant context found."
                } catch (e: Exception) {
                    "Error during embedding: ${e.localizedMessage}"
                }
            }
            
            _searchResult.value = result
            _isProcessing.value = false
        }
    }
}

/**
 * 3. The Jetpack Compose UI
 */
@AndroidEntryPoint
@Composable
fun SemanticSearchScreen(viewModel: SemanticSearchViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var query by remember { mutableStateOf("") }
    val result by viewModel.searchResult.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "Local AI Knowledge Search", style = MaterialTheme.typography.headlineMedium)
        
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Ask about company policy...") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.performSemanticSearch(query) },
            enabled = !isProcessing && query.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isProcessing) {
                CircularProgressIndicator(size = 20.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Search Semantically")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Retrieved Context:", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = result, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

// Helper for CircularProgressIndicator size
@Composable
fun CircularProgressIndicator(size: androidx.compose.ui.unit.Dp, color: androidx.compose.ui.graphics.Color) {
    androidx.compose.material3.CircularProgressIndicator(
        modifier = Modifier.size(size),
        color = color,
        strokeWidth = 2.dp
    )
}
