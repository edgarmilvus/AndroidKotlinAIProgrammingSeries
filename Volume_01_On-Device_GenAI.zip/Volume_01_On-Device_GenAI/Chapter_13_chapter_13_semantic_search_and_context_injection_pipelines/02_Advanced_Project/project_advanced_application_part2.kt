
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.semantic

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Represents a document fragment with its corresponding semantic vector.
 */
data class DocumentChunk(val text: String, val embedding: FloatArray)

/**
 * VectorStore handles the semantic similarity calculations.
 * In a full production app, this would be replaced by an SQLite-based 
 * vector extension or a specialized library like ObjectBox Vector Search.
 */
@Singleton
class LocalVectorStore @Inject constructor() {
    private val documents = mutableListOf<DocumentChunk>()

    fun addDocument(text: String, embedding: FloatArray) {
        documents.add(DocumentChunk(text, embedding))
    }

    fun findMostRelevant(queryEmbedding: FloatArray, topK: Int = 3): List<String> {
        return documents
            .map { it to cosineSimilarity(queryEmbedding, it.embedding) }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first.text }
    }

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * Repository orchestrating MediaPipe TextEmbedder and the VectorStore.
 */
@Singleton
class SemanticSearchRepository @Inject constructor(
    private val context: Context,
    private val vectorStore: LocalVectorStore
) {
    private var textEmbedder: TextEmbedder? = null

    init {
        // Hardware-aware orchestration: Initialize MediaPipe to use GPU/NPU
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                .setModelAssetPath("universal_sentence_encoder.tflite")
                .setDelegate(Delegate.GPU) // Explicitly target GPU for low-latency embeddings
                .build())
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    suspend fun embedText(text: String): FloatArray = withContext(Dispatchers.Default) {
        textEmbedder?.embed(text)?.embedding ?: floatArrayOf()
    }

    suspend fun retrieveContext(query: String): String = withContext(Dispatchers.Default) {
        val queryVector = embedText(query)
        val relevantChunks = vectorStore.findMostRelevant(queryVector)
        relevantChunks.joinToString("\n---\n")
    }
}

/**
 * ViewModel implementing the Context Injection Pipeline.
 * Uses MVI-style state management for the UI.
 */
@HiltViewModel
class SemanticChatViewModel @Inject constructor(
    private val repository: SemanticSearchRepository,
    private val geminiNano: GeminiNanoClient // Wrapper for AICore/GenerativeAI SDK
) : ViewModel() {

    private val _uiState = MutableStateFlow<ChatState>(ChatState.Idle)
    val uiState: StateFlow<ChatState> = _uiState.asStateFlow()

    fun askQuestion(userQuery: String) {
        viewModelScope.launch {
            _uiState.value = ChatState.Loading
            
            try {
                // 1. Semantic Retrieval (The "R" in RAG)
                // This runs on Dispatchers.Default via the repository
                val context = repository.retrieveContext(userQuery)

                // 2. Context Injection (The "A" in RAG)
                // We wrap the retrieved context in a system instruction
                val augmentedPrompt = """
                    You are a helpful assistant. Use the following retrieved context 
                    to answer the user's question. If the answer is not in the context, 
                    say "I don't have enough local information to answer this."
                    
                    CONTEXT:
                    $context
                    
                    USER QUESTION: 
                    $userQuery
                """.trimIndent()

                // 3. Local Generation (The "G" in RAG)
                // Gemini Nano processes the augmented prompt on the NPU
                val response = geminiNano.generateResponse(augmentedPrompt)
                
                _uiState.value = ChatState.Success(response)
            } catch (e: Exception) {
                _uiState.value = ChatState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    sealed class ChatState {
        object Idle : ChatState()
        object Loading : ChatState()
        data class Success(val answer: String) : ChatState()
        data class Error(val message: String) : ChatState()
    }
}
