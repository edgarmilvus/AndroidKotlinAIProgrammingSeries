
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.rag

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Data model representing a piece of knowledge and its semantic vector.
 */
data class KnowledgeChunk(
    val content: String,
    val embedding: FloatArray
)

/**
 * Repository responsible for semantic search and vector operations.
 * Uses MediaPipe TextEmbedder with hardware acceleration.
 */
@Singleton
class SemanticKnowledgeRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null
    private val knowledgeBase = mutableListOf<KnowledgeChunk>()

    // Initialize the Embedder with GPU acceleration
    init {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite")
                    .setDelegate(com.google.mediapipe.tasks.core.Delegate.GPU) // Hardware acceleration
                    .build()
            )
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    /**
     * Indexes a document by breaking it into chunks and generating embeddings.
     */
    suspend fun indexDocument(text: String) = withContext(Dispatchers.Default) {
        val chunks = text.split(Regex("(?<=\\.)\\s+")) // Simple sentence splitting
        chunks.forEach { chunk ->
            val embedding = textEmbedder?.embed(chunk)?.embeddingResult() 
                ?: throw IllegalStateException("Embedder not initialized")
            knowledgeBase.add(KnowledgeChunk(chunk, embedding))
        }
    }

    /**
     * Performs a semantic search to find the most relevant context for a query.
     */
    suspend fun findRelevantContext(query: String, topK: Int = 3): List<String> = withContext(Dispatchers.Default) {
        val queryEmbedding = textEmbedder?.embed(query)?.embeddingResult() 
            ?: return@withContext emptyList()

        // Calculate cosine similarity across the knowledge base
        knowledgeBase
            .map { chunk -> chunk to cosineSimilarity(queryEmbedding, chunk.embedding) }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first.content }
    }

    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel orchestrating the Context Injection Pipeline.
 * Follows MVI pattern for state management.
 */
@HiltViewModel
@AndroidEntryPoint
class KnowledgeChatViewModel @Inject constructor(
    private val repository: SemanticKnowledgeRepository,
    // Assume GeminiNanoClient is a wrapper around AICore
    private val geminiClient: GeminiNanoClient 
) : ViewModel() {

    private val _uiState = MutableStateFlow<ChatState>(ChatState.Idle)
    val uiState: StateFlow<ChatState> = _uiState.asStateFlow()

    fun askQuestion(userQuery: String) {
        viewModelScope.launch {
            _uiState.value = ChatState.Loading
            try {
                // 1. Semantic Retrieval Phase
                val contextChunks = repository.findRelevantContext(userQuery)
                val augmentedContext = contextChunks.joinToString("\n") { "- $it" }

                // 2. Context Injection Phase (Prompt Engineering)
                val finalPrompt = buildInjectionPrompt(userQuery, augmentedContext)

                // 3. Generation Phase (Offloaded to AICore/NPU)
                val response = withContext(Dispatchers.Default) {
                    geminiClient.generateResponse(finalPrompt)
                }

                _uiState.value = ChatState.Success(response)
            } catch (e: Exception) {
                _uiState.value = ChatState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private fun buildInjectionPrompt(query: String, context: String): String {
        return """
            You are a helpful assistant. Use the following pieces of retrieved context 
            to answer the user's question. If the answer is not in the context, 
            say that you don't know.
            
            CONTEXT:
            $context
            
            USER QUESTION: 
            $query
            
            ANSWER:
        """.trimIndent()
    }
}

sealed class ChatState {
    object Idle : ChatState()
    object Loading : ChatState()
    data class Success(val answer: String) : ChatState()
    data class Error(val message: String) : ChatState()
}

// Mock client for Gemini Nano integration
class GeminiNanoClient @Inject constructor() {
    suspend fun generateResponse(prompt: String): String {
        delay(1000) // Simulate NPU inference latency
        return "This is a simulated response from Gemini Nano based on the provided context."
    }
}
