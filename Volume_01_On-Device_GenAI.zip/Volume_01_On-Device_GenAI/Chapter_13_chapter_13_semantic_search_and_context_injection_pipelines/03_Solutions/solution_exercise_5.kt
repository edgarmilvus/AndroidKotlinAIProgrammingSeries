
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.roundToInt

class QuantizedVectorStore(private val filePath: String, private val dimensions: Int) {
    private val file = RandomAccessFile(filePath, "rw")
    private val buffer: ByteBuffer = file.channel.map(FileChannel.MapMode.READ_WRITE, 0, 100 * 1024 * 1024) // 100MB map

    // Quantization: Float (-1.0 to 1.0) -> Byte (0 to 255)
    fun quantize(vector: FloatArray): ByteArray {
        return ByteArray(dimensions) { i ->
            ((vector[i] + 1.0f) * 127.5f).roundToInt().toByte()
        }
    }

    fun addVector(id: Int, vector: FloatArray) {
        val quantized = quantize(vector)
        buffer.position(id * dimensions)
        buffer.put(quantized)
    }

    fun search(queryVector: FloatArray): Int {
        var bestId = -1
        var maxSimilarity = Float.NEGATIVE_INFINITY

        // Linear scan over MappedByteBuffer (OS handles paging)
        for (id in 0 until (buffer.capacity() / dimensions)) {
            val similarity = calculateQuantizedSimilarity(queryVector, id)
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                bestId = id
            }
        }
        return bestId
    }

    private fun calculateQuantizedSimilarity(query: FloatArray, docId: Int): Float {
        var dotProduct = 0.0f
        val offset = docId * dimensions
        
        for (i in 0 until dimensions) {
            // De-quantize on the fly for calculation
            val quantizedVal = buffer.get(offset + i).toInt() and 0xFF
            val floatVal = (quantizedVal / 127.5f) - 1.0f
            dotProduct += query[i] * floatVal
        }
        return dotProduct
    }
}
