
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.room.*

@Fts4
@Entity(tableName = "notes_fts")
data class NoteFts(val content: String)

class HybridSearchEngine(
    private val ftsDao: NoteFtsDao,
    private val vectorStore: SemanticSearchManager
) {
    private val K_RRF = 60 // Standard constant for RRF

    suspend fun hybridSearch(query: String): List<Note> {
        // 1. Lexical Layer (Exact Match / Keywords)
        val lexicalResults = ftsDao.search(query) // Returns List of Note IDs
        
        // 2. Semantic Layer (Meaning)
        val semanticResults = vectorStore.search(query, topK = 50)
            .map { it.first.id }

        // 3. Reciprocal Rank Fusion (RRF)
        val scores = mutableMapOf<String, Double>()

        // Process Lexical Ranks
        lexicalResults.forEachIndexed { index, id ->
            val score = 1.0 / (K_RRF + (index + 1))
            scores[id] = scores.getOrDefault(id, 0.0) + score
        }

        // Process Semantic Ranks
        semanticResults.forEachIndexed { index, id ->
            val score = 1.0 / (K_RRF + (index + 1))
            scores[id] = scores.getOrDefault(id, 0.0) + score
        }

        // Sort by combined RRF score
        val finalIds = scores.entries
            .sortedByDescending { it.value }
            .map { it.key }

        return fetchNotesByIds(finalIds)
    }

    private fun fetchNotesByIds(ids: List<String>): List<Note> {
        // Implementation to fetch Note objects from Room
        return emptyList()
    }
}
