
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.layout.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// Mock for Gemini Nano Interface
interface GeminiNano {
    suspend fun generateResponse(prompt: String): String
}

class ContextInjectionManager(
    private val searchManager: SemanticSearchManager,
    private val llm: GeminiNano
) {
    suspend fun answerQuestion(query: String): Pair<String, List<Note>> {
        // 1. Top-K Retrieval
        val relevantNotes = searchManager.search(query, topK = 3)
        val contextText = relevantNotes.joinToString("\n\n") { it.first.content }
        
        // 2. Prompt Engineering (Strict Constraint)
        val systemPrompt = """
            You are a technical assistant. Use ONLY the following context to answer the question. 
            If the answer is not in the context, say 'I do not have enough information.'
            
            Context:
            $contextText
            
            Question: $query
            Answer:
        """.trimIndent()
        
        // 3. Generation
        val response = llm.generateResponse(systemPrompt)
        return response to relevantNotes.map { it.first }
    }
}

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val state by viewModel.uiState.collectAsState()
    
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(state.messages) { msg ->
                Text(text = "${msg.role}: ${msg.text}", modifier = Modifier.padding(vertical = 4.dp))
                if (msg.sources.isNotEmpty()) {
                    Text(text = "Sources: ${msg.sources.joinToString { it.id }}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        // Input field omitted for brevity
    }
}
