
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

data class FAQItem(val question: String, val answer: String, val embedding: FloatArray)

@Singleton
class RagHelpCenter @Inject constructor(
    private val generativeModel: GenerativeModel,
    private val semanticRepository: SemanticRepository // From Exercise 1
) {
    private val knowledgeBase = listOf<FAQItem>() // Assume populated from JSON

    suspend fun askAssistant(userQuery: String): String {
        // 1. Retrieval: Get top 3 relevant snippets
        val contextSnippets = retrieveContext(userQuery, k = 3)
        
        // 2. Augmentation: Construct the "Strict Grounding" prompt
        val augmentedPrompt = buildStrictPrompt(userQuery, contextSnippets)
        
        // 3. Generation: Call Gemini Nano
        return try {
            val response = generativeModel.generateContent(augmentedPrompt)
            response.text ?: "I couldn't generate an answer."
        } catch (e: Exception) {
            "Error connecting to AICore: ${e.localizedMessage}"
        }
    }

    private fun retrieveContext(query: String, k: Int): List<String> {
        // Use the same cosine similarity logic from Exercise 1
        // Return the 'answer' field of the top K matching FAQItems
        return knowledgeBase
            .map { it to cosineSimilarity(queryEmbedding, it.embedding) }
            .sortedByDescending { it.second }
            .take(k)
            .map { it.first.answer }
    }

    private fun buildStrictPrompt(query: String, context: List<String>): String {
        val contextBlock = context.joinToString("\n\n") { "Snippet: $it" }
        return """
            You are a strict technical support assistant. 
            Use ONLY the provided context to answer the user's question. 
            If the answer is not contained within the context, respond exactly with: "I am sorry, but I don't have enough information in my documentation to answer that."
            Do not use your own general knowledge.
            
            CONTEXT:
            $contextBlock
            
            USER QUESTION: 
            $query
            
            ANSWER:
        """.trimIndent()
    }
    
    // cosineSimilarity implementation omitted for brevity (same as Exercise 1)
}
