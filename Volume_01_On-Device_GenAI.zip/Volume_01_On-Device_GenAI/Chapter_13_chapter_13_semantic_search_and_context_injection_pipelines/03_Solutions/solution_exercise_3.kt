
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger

data class ChatMessage(val role: String, val text: String, val timestamp: Long)

class ContextWindowManager(
    private val generativeModel: GenerativeModel,
    private val tokenLimit: Int = 4000
) {
    private var longTermMemory = ""
    private val shortTermHistory = mutableListOf<ChatMessage>()

    // Heuristic: 1 word approx 1.3 tokens
    private fun estimateTokens(text: String): Int = 
        text.split(Regex("\\s+")).size * 1.3.toInt()

    suspend fun processMessage(userMessage: String): String = coroutineScope {
        shortTermHistory.add(ChatMessage("user", userMessage, System.currentTimeMillis()))
        
        if (currentTotalTokens() > tokenLimit) {
            compressMemory()
        }

        val finalPrompt = assemblePrompt()
        val response = generativeModel.generateContent(finalPrompt).text ?: ""
        
        shortTermHistory.add(ChatMessage("model", response, System.currentTimeMillis()))
        response
    }

    private suspend fun compressMemory() = withContext(Dispatchers.Default) {
        // Take the oldest 50% of the history
        val splitIndex = shortTermHistory.size / 2
        val toSummarize = shortTermHistory.subList(0, splitIndex)
        val historyText = toSummarize.joinToString("\n") { "${it.role}: ${it.text}" }

        val summaryPrompt = """
            Summarize the following conversation segment. 
            Extract key facts, user preferences, and decisions. 
            Keep it concise for long-term memory injection.
            
            CONVERSATION:
            $historyText
            
            SUMMARY:
        """.trimIndent()

        val summary = generativeModel.generateContent(summaryPrompt).text ?: ""
        
        // Update long term memory and clear the summarized portion of short term
        longTermMemory += "\n$summary"
        repeat(splitIndex) { shortTermHistory.removeAt(0) }
    }

    private fun assemblePrompt(): String {
        val recentHistory = shortTermHistory.joinToString("\n") { "${it.role}: ${it.text}" }
        return """
            System: You are a helpful AI.
            Long-term Memory: $longTermMemory
            Recent Conversation:
            $recentHistory
            Model:
        """.trimIndent()
    }

    private fun currentTotalTokens(): Int = 
        estimateTokens(longTermMemory) + shortTermHistory.sumOf { estimateTokens(it.text) }
}
