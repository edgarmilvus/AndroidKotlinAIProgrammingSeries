
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class DocumentChunker(
    private val maxChunkSize: Int = 500,
    private val overlapSize: Int = 50
) {
    fun chunkText(text: String): List<String> {
        val chunks = mutableListOf<String>()
        var start = 0
        
        while (start < text.length) {
            var end = start + maxChunkSize
            if (end >= text.length) end = text.length
            
            // Refine end boundary to avoid splitting thoughts
            end = findBestBoundary(text, end)
            
            chunks.add(text.substring(start, end))
            
            // Slide window back by overlap size
            start += (maxChunkSize - overlapSize)
            if (start >= text.length || (maxChunkSize - overlapSize) <= 0) break
        }
        return chunks
    }

    private fun findBestBoundary(text: String, end: Int): Int {
        if (end >= text.length) return text.length
        
        // Priority 1: Paragraph break
        val paragraphBreak = text.lastIndexOf('\n', end)
        if (paragraphBreak > end - 100) return paragraphBreak
        
        // Priority 2: Sentence boundary
        val sentenceBreak = text.lastIndexOf(". ", end)
        if (sentenceBreak > end - 100) return sentenceBreak + 1
        
        // Priority 3: Space
        val spaceBreak = text.lastIndexOf(' ', end)
        if (spaceBreak > end - 100) return spaceBreak
        
        return end // Fallback to hard cut
    }
    
    fun reconstructContext(chunks: List<String>, targetIndex: Int): String {
        val start = (targetIndex - 1).coerceAtLeast(0)
        val end = (targetIndex + 1).coerceAtMost(chunks.size - 1)
        return chunks.subList(start, end + 1).joinToString("\n")
    }
}
