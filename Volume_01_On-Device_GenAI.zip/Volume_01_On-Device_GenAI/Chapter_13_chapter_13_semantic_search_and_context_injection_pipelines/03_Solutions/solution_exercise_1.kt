
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import kotlin.math.sqrt

data class Note(val id: String, val content: String)

class SemanticSearchManager(private val textEmbedder: TextEmbedder) {
    // In-memory storage mapping Note ID to its embedding vector
    private val vectorStore = mutableMapOf<String, FloatArray>()
    private val notesStore = mutableMapOf<String, Note>()

    fun indexNote(note: Note) {
        val embedding = generateEmbedding(note.content)
        vectorStore[note.id] = embedding
        notesStore[note.id] = note
    }

    fun search(query: String, topK: Int = 3): List<Pair<Note, Float>> {
        val queryVector = generateEmbedding(query)
        
        return vectorStore.map { (id, noteVector) ->
            val similarity = calculateCosineSimilarity(queryVector, noteVector)
            notesStore[id]!! to similarity
        }
        .filter { !it.second.isNaN() } // Handle potential NaN from zero-vectors
        .sortedByDescending { it.second }
        .take(topK)
    }

    private fun generateEmbedding(text: String): FloatArray {
        val result: TextEmbedderResult = textEmbedder.embed(text)
        return result.embedding()
    }

    private fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        
        val magnitude = sqrt(normA.toDouble()) * sqrt(normB.toDouble())
        return if (magnitude == 0.0) 0f else (dotProduct / magnitude).toFloat()
    }
}
