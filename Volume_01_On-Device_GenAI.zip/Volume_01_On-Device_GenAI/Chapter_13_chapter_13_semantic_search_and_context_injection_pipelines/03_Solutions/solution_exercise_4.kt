
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

class HybridSearchEngine(
    private val semanticRepo: SemanticRepository,
    private val documents: List<Document>
) {
    // Simple Inverted Index for Keyword Search
    private val invertedIndex = ConcurrentHashMap<String, MutableSet<Int>>()

    init {
        documents.forEachIndexed { id, doc ->
            doc.content.lowercase().split(Regex("\\W+")).forEach { word ->
                invertedIndex.getOrPut(word) { mutableSetOf() }.add(id)
            }
        }
    }

    suspend fun hybridSearch(query: String): List<Document> = coroutineScope {
        // Run both searches in parallel
        val semanticDeferred = async { semanticRepo.searchNotes(query) }
        val keywordDeferred = async { keywordSearch(query) }

        val semanticResults = semanticDeferred.await()
        val keywordResults = keywordDeferred.await()

        applyRRF(semanticResults, keywordResults)
    }

    private fun keywordSearch(query: String): List<Document> {
        val queryWords = query.lowercase().split(Regex("\\W+"))
        val docScores = mutableMapOf<Int, Int>()

        queryWords.forEach { word ->
            invertedIndex[word]?.forEach { docId ->
                docScores[docId] = docScores.getOrDefault(docId, 0) + 1
            }
        }
        return docScores.entries
            .sortedByDescending { it.value }
            .map { documents[it.key] }
    }

    private fun applyRRF(semantic: List<Document>, keyword: List<Document>, k: Int = 60): List<Document> {
        val scores = mutableMapOf<Int, Double>()

        // RRF Formula: score = sum( 1 / (k + rank) )
        semantic.forEachIndexed { index, doc ->
            scores[doc.id] = scores.getOrDefault(doc.id, 0.0) + 1.0 / (k + index + 1)
        }
        keyword.forEachIndexed { index, doc ->
            scores[doc.id] = scores.getOrDefault(doc.id, 0.0) + 1.0 / (k + index + 1)
        }

        return scores.entries
            .sortedByDescending { it.value }
            .map { documents[it.key] }
    }
}

data class Document(val id: Int, val content: String)
