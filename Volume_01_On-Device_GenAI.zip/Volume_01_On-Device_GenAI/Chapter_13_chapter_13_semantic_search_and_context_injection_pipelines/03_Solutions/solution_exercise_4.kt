
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.util.LruCache

class OptimizedVectorStore(private val db: NoteDao) {
    // 1. Embedding Cache to avoid redundant MediaPipe inferences
    private val queryCache = LruCache<String, FloatArray>(100)

    // 2. Quantization: Convert Float32 [-1, 1] to Int8 [-127, 127]
    fun quantize(vector: FloatArray): ByteArray {
        return ByteArray(vector.size) { i ->
            (vector[i] * 127f).toInt().toByte()
        }
    }

    fun dequantize(bytes: ByteArray): FloatArray {
        return FloatArray(bytes.size) { i ->
            bytes[i].toFloat() / 127f
        }
    }

    suspend fun searchOptimized(query: String, category: String): List<Note> {
        val startTime = System.nanoTime()
        
        // Stage 1: Coarse Filtering (Room SQL)
        // Only retrieve notes in the specific category to reduce N
        val filteredNotes = db.getNotesByCategory(category) 
        
        // Stage 2: Fine Filtering (Vector Similarity)
        val queryVector = queryCache.get(query) ?: run {
            // Assume embedder is available here
            val vector = FloatArray(384) // Mock embedding
            queryCache.put(query, vector)
            vector
        }

        val results = filteredNotes.map { note ->
            val noteVector = dequantize(note.quantizedEmbedding)
            note to calculateCosineSimilarity(queryVector, noteVector)
        }.sortedByDescending { it.second }

        val endTime = System.nanoTime()
        println("Retrieval latency: ${(endTime - startTime) / 1_000_000}ms")
        
        return results.take(10).map { it.first }
    }
    
    private fun calculateCosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        // ... same implementation as Exercise 1 ...
        return 0.0f 
    }
}
