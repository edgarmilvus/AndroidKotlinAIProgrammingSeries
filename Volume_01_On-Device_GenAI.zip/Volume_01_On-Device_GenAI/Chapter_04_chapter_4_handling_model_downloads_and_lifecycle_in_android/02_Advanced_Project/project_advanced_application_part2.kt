
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.lifecycle

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Represents the different quantization levels of the model.
 * Higher precision requires more RAM and NPU capabilities.
 */
enum class ModelVariant(val fileName: String, val minRamGb: Int) {
    QUANTIZED_INT4("gemini_nano_int4.bin", 6),
    QUANTIZED_INT8("gemini_nano_int8.bin", 12),
    FULL_PRECISION("gemini_nano_fp16.bin", 16)
}

sealed class ModelLifecycleState {
    object Idle : ModelLifecycleState()
    data class Downloading(val progress: Float) : ModelLifecycleState()
    object Verifying : ModelLifecycleState()
    object LoadingIntoMemory : ModelLifecycleState()
    data class Ready(val inferenceEngine: LlmInference) : ModelLifecycleState()
    data class Error(val message: String) : ModelLifecycleState()
}

@Singleton
class ModelLifecycleRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    /**
     * Determines the best model variant based on the device's physical RAM.
     */
    fun determineOptimalVariant(): ModelVariant {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalRamGb = (memoryInfo.totalMem / (1024 * 1024 * 1024)).toInt()
        
        return ModelVariant.values().filter { it.minRamGb <= totalRamGb }
            .maxByOrNull { it.minRamGb } ?: ModelVariant.QUANTIZED_INT4
    }

    /**
     * Handles the asynchronous download and integrity check of the model.
     * In a real scenario, this would integrate with DownloadManager or WorkManager.
     */
    suspend fun downloadAndVerifyModel(variant: ModelVariant): Result<String> = withContext(Dispatchers.IO) {
        try {
            Log.d("ModelRepo", "Downloading ${variant.fileName} for hardware profile...")
            // Simulate download progress
            for (i in 1..10) {
                delay(200) // Simulate network latency
            }
            
            val modelPath = "${context.filesDir}/models/${variant.fileName}"
            // Perform checksum verification here (e.g., SHA-256)
            Result.success(modelPath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Initializes the LLM Inference engine using the specified hardware delegate.
     */
    suspend fun initializeInferenceEngine(modelPath: String): LlmInference = withContext(Dispatchers.Default) {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            // Hardware orchestration: MediaPipe handles GPU/NPU delegation internally 
            // based on the provided model format and device capabilities.
            .build()
        
        LlmInference.createFromOptions(context, options)
    }
}

@HiltViewModel
@AndroidEntryPoint
class ModelManagerViewModel @Inject constructor(
    private val repository: ModelLifecycleRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ModelLifecycleState>(ModelLifecycleState.Idle)
    val uiState: StateFlow<ModelLifecycleState> = _uiState.asStateFlow()

    fun setupModel() {
        viewModelScope.launch {
            try {
                // 1. Hardware Assessment
                val variant = repository.determineOptimalVariant()
                
                // 2. Download Phase
                _uiState.value = ModelLifecycleState.Downloading(0f)
                val downloadResult = repository.downloadAndVerifyModel(variant)
                
                if (downloadResult.isFailure) {
                    _uiState.value = ModelLifecycleState.Error("Download failed: ${downloadResult.exceptionOrNull()?.message}")
                    return@launch
                }

                // 3. Loading Phase (Memory Mapping)
                _uiState.value = ModelLifecycleState.LoadingIntoMemory
                val engine = repository.initializeInferenceEngine(downloadResult.getOrThrow())
                
                // 4. Ready Phase
                _uiState.value = ModelLifecycleState.Ready(engine)
                
            } catch (e: Exception) {
                _uiState.value = ModelLifecycleState.Error("Lifecycle Exception: ${e.localizedMessage}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Crucial: Explicitly release the LLM engine to prevent native memory leaks
        if (_uiState.value is ModelLifecycleState.Ready) {
            (_uiState.value as ModelLifecycleState.Ready).inferenceEngine.close()
        }
    }
}
