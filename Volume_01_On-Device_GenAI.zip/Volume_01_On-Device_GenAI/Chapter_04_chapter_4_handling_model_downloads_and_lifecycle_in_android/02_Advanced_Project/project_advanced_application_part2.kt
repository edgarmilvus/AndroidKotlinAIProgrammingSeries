
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.orchestrator

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import java.io.File
import java.security.MessageDigest

/**
 * Represents the current state of the Model Lifecycle.
 */
sealed class ModelLifecycleState {
    object Uninitialized : ModelLifecycleState()
    data class Downloading(val progress: Float) : ModelLifecycleState()
    object Verifying : ModelLifecycleState()
    object LoadingIntoHardware : ModelLifecycleState()
    data class Ready(val modelHandle: ModelInstance) : ModelLifecycleState()
    data class Error(val message: String) : ModelLifecycleState()
}

/**
 * Wrapper for the loaded AI model and its hardware delegate.
 */
data class ModelInstance(
    val file: File,
    val hardwareAccelerator: HardwareAccelerator,
    val version: String
)

enum class HardwareAccelerator { NPU, GPU, CPU }

/**
 * Repository responsible for the physical acquisition and verification of the model.
 */
@Singleton
class ModelDownloadRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val modelDir = context.filesDir.absolutePath + "/ai_models"
    
    // In a real app, this would come from a remote Firebase Remote Config or API
    private val modelManifest = mapOf(
        "high_end" to "https://cdn.ai.com/models/gemini_nano_npu.bin",
        "mid_end" to "https://cdn.ai.com/models/gemini_nano_gpu.bin",
        "fallback" to "https://cdn.ai.com/models/gemini_nano_cpu.bin"
    )

    fun getTargetModelUrl(): String {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> modelManifest["high_end"]!!
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> modelManifest["mid_end"]!!
            else -> modelManifest["fallback"]!!
        }
    }

    suspend fun downloadModel(onProgress: (Float) -> Unit): Result<File> = withContext(Dispatchers.IO) {
        try {
            val targetFile = File(modelDir, "active_model.bin")
            if (!File(modelDir).exists()) File(modelDir).mkdirs()

            // Simulation of a resumable download stream
            for (i in 1..100) {
                delay(20) // Simulate network latency
                onProgress(i / 100f)
            }
            
            // In production, use OkHttp or WorkManager to stream the bytes to targetFile
            Result.success(targetFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun verifyChecksum(file: File, expectedHash: String): Boolean {
        val bytes = file.readBytes()
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val actualHash = digest.joinToString("") { "%02x".format(it) }
        return actualHash == expectedHash
    }
}

/**
 * Manager that handles the loading of the model into the specific hardware delegate.
 */
@Singleton
class ModelLifecycleManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var currentInstance: ModelInstance? = null

    suspend fun loadModel(file: File, accelerator: HardwareAccelerator): ModelInstance = withContext(Dispatchers.Default) {
        Log.d("ModelLifecycle", "Initializing model on $accelerator...")
        
        // Simulate TFLite/MediaPipe loading logic
        // Here we would actually initialize the GenAi LlmInference or TFLite Interpreter
        // with a GpuDelegate or NpuDelegate.
        delay(1500) // Simulate hardware buffer allocation and weight loading
        
        val instance = ModelInstance(file, accelerator, "v1.0.4")
        currentInstance = instance
        instance
    }

    fun unloadModel() {
        // Crucial: Explicitly nullify and trigger GC or call .close() on TFLite Interpreter
        currentInstance = null
        System.gc() 
    }
}

/**
 * ViewModel implementing the MVI-like state management for the AI lifecycle.
 */
@HiltViewModel
@AndroidEntryPoint
class AIModelViewModel @Inject constructor(
    private val repository: ModelDownloadRepository,
    private val lifecycleManager: ModelLifecycleManager
) : ViewModel() {

    private val _uiState = MutableStateFlow<ModelLifecycleState>(ModelLifecycleState.Uninitialized)
    val uiState: StateFlow<ModelLifecycleState> = _uiState.asStateFlow()

    private val modelJob = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + modelJob)

    fun initializeModel() {
        scope.launch {
            try {
                // 1. Hardware Detection
                val accelerator = detectHardware()
                
                // 2. Download Phase
                _uiState.value = ModelLifecycleState.Downloading(0f)
                val downloadResult = repository.downloadModel { progress ->
                    _uiState.value = ModelLifecycleState.Downloading(progress)
                }

                if (downloadResult.isFailure) {
                    _uiState.value = ModelLifecycleState.Error("Download failed")
                    return@launch
                }

                // 3. Verification Phase
                _uiState.value = ModelLifecycleState.Verifying
                val file = downloadResult.getOrThrow()
                if (!repository.verifyChecksum(file, "expected_sha_hash")) {
                    _uiState.value = ModelLifecycleState.Error("Checksum mismatch")
                    return@launch
                }

                // 4. Hardware Loading Phase
                _uiState.value = ModelLifecycleState.LoadingIntoHardware
                val instance = lifecycleManager.loadModel(file, accelerator)

                // 5. Ready Phase
                _uiState.value = ModelLifecycleState.Ready(instance)

            } catch (e: Exception) {
                _uiState.value = ModelLifecycleState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private fun detectHardware(): HardwareAccelerator {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> HardwareAccelerator.NPU
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> HardwareAccelerator.GPU
            else -> HardwareAccelerator.CPU
        }
    }

    override fun onCleared() {
        super.onCleared()
        lifecycleManager.unloadModel()
        modelJob.cancel()
    }
}
