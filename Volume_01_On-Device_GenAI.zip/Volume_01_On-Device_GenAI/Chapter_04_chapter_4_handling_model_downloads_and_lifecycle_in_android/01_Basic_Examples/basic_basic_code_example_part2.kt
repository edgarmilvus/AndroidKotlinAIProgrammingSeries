
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.lifecycle

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.LifecycleViewModelComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the current state of the AI Model lifecycle.
 */
sealed class ModelStatus {
    object Idle : ModelStatus()
    data class Downloading(val progress: Int) : ModelStatus()
    object Ready : ModelStatus()
    data class Error(val message: String) : ModelStatus()
}

/**
 * Repository responsible for the physical management of the model file.
 * Handles downloading from remote and verifying local existence.
 */
@Singleton
class ModelRepository @Inject constructor(
    private val context: Context
) {
    private val client = OkHttpClient()
    private val modelUrl = "https://storage.googleapis.com/my-genai-models/gemini_nano_quantized.bin"
    private val modelFileName = "local_model.bin"

    // Get the absolute path to the model in the app's internal storage
    private val modelFile: File 
        get() = File(context.filesDir, modelFileName)

    suspend fun initializeModel(): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (modelFile.exists()) {
                Log.d("ModelRepo", "Model already exists locally.")
                Result.success(modelFile)
            } else {
                Log.d("ModelRepo", "Model not found. Starting download...")
                downloadModel()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun downloadModel(): Result<File> {
        val request = Request.Builder().url(modelUrl).build()
        val response = client.newCall(request).execute()

        if (!response.isSuccessful) throw Exception("Server returned error: ${response.code}")

        val body = response.body ?: throw Exception("Response body is null")
        val contentLength = body.contentLength()
        
        // Use a buffer to write the stream to disk to avoid loading the whole model into RAM
        body.byteStream().use { inputStream ->
            FileOutputStream(modelFile).use { outputStream ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                var totalBytesRead = 0L

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead
                    // Note: In a real app, you'd pipe this progress back to the UI via a Flow
                }
            }
        }
        Result.success(modelFile)
    }
}

/**
 * ViewModel managing the UI state and triggering the model lifecycle.
 */
@AndroidEntryPoint
class ModelViewModel @Inject constructor(
    private val repository: ModelRepository
) : ViewModel() {

    private val _status = MutableStateFlow<ModelStatus>(ModelStatus.Idle)
    val status: StateFlow<ModelStatus> = _status.asStateFlow()

    fun prepareModel() {
        viewModelScope.launch {
            _status.value = ModelStatus.Downloading(0)
            
            // Switch to Default dispatcher for the heavy lifting of file verification/loading
            val result = withContext(Dispatchers.Default) {
                repository.initializeModel()
            }

            result.fold(
                onSuccess = { 
                    Log.i("ModelVM", "Model ready at ${it.absolutePath}")
                    _status.value = ModelStatus.Ready 
                },
                onFailure = { 
                    _status.value = ModelStatus.Error(it.message ?: "Unknown error") 
                }
            )
        }
    }
}

/**
 * Jetpack Compose UI reflecting the Model Lifecycle.
 */
@Composable
fun ModelLifecycleScreen(viewModel: ModelViewModel) {
    val status by viewModel.status.collectAsState()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when (status) {
            is ModelStatus.Idle -> {
                Button(onClick = { viewModel.prepareModel() }) {
                    Text("Initialize AI Model")
                }
            }
            is ModelStatus.Downloading -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Downloading Large Model... Please wait.")
                }
            }
            is ModelStatus.Ready -> {
                Text("✅ Model Loaded and Ready for Inference!", style = MaterialTheme.typography.headlineSmall)
            }
            is ModelStatus.Error -> {
                Text("❌ Error: ${(status as ModelStatus.Error).message}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
