
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.modelmgmt

import android.content.Context
import android.util.Log
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.*
import javax.inject.Inject
import javax.inject.Singleton
import org.tensorflow.lite.Interpreter
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.io.path.Path
import kotlin.io.path.exists

/**
 * Sealed interface representing the various states of the Model Lifecycle.
 * This allows the UI to reactively update based on whether the model is 
 * downloading, ready, or in an error state.
 */
sealed interface ModelState {
    object Idle : ModelState
    data class Downloading(val progress: Float) : ModelState
    object Ready : ModelState
    data class Error(val message: String) : ModelState
}

/**
 * Repository responsible for the physical lifecycle of the .tflite file.
 * It handles downloading from a CDN and managing the local file system.
 */
@Singleton
class ModelRepository @Inject constructor(
    private val context: Context,
    private val httpClient: OkHttpClient
) {
    private val modelFileName = "summarizer_v1.tflite"
    private val modelUrl = "https://cdn.example.com/models/$modelFileName"

    // Internal storage path: /data/user/0/com.example.genai/files/models/
    private val modelFile: File 
        get() = File(context.filesDir, "models/$modelFileName").apply {
            parentFile?.mkdirs()
        }

    /**
     * Checks if the model is already downloaded.
     */
    fun isModelDownloaded(): Boolean = modelFile.exists()

    /**
     * Downloads the model using a streaming approach to avoid loading 
     * the entire binary into RAM.
     */
    suspend fun downloadModel(onProgress: (Float) -> Unit): Result<File> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(modelUrl).build()
            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) throw IOException("Unexpected code $response")

            val body = response.body ?: throw IOException("Empty response body")
            val totalBytes = body.contentLength()
            
            FileOutputStream(modelFile).use { outputStream ->
                body.byteStream().use { inputStream ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L

                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        // Update progress periodically
                        if (totalBytes > 0) {
                            onProgress(totalRead.toFloat() / totalBytes)
                        }
                    }
                }
            }
            Result.success(modelFile)
        } catch (e: Exception) {
            Log.e("ModelRepo", "Download failed", e)
            Result.failure(e)
        }
    }

    /**
     * Loads the model into a MappedByteBuffer.
     * Mmap is critical for AI models as it allows the OS to manage memory 
     * and prevents loading the entire file into the JVM heap.
     */
    fun loadModelFile(): MappedByteBuffer {
        val fileInputStream = FileInputStream(modelFile)
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }
}

/**
 * ViewModel that orchestrates the lifecycle. It ensures that the
 * TFLite Interpreter is created on a background thread and closed properly.
 */
@HiltViewModel
class SummarizerViewModel @Inject constructor(
    private val repository: ModelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ModelState>(ModelState.Idle)
    val uiState: StateFlow<ModelState> = _uiState.asStateFlow()

    private var tfliteInterpreter: Interpreter? = null

    /**
     * Orchestrates the "Check -> Download -> Load" flow.
     */
    fun prepareModel() {
        viewModelScope.launch {
            if (repository.isModelDownloaded()) {
                initializeInterpreter()
            } else {
                downloadAndInitialize()
            }
        }
    }

    private suspend fun downloadAndInitialize() {
        _uiState.value = ModelState.Downloading(0f)
        
        val result = repository.downloadModel { progress ->
            _uiState.value = ModelState.Downloading(progress)
        }

        result.fold(
            onSuccess = {
                initializeInterpreter()
            },
            onFailure = {
                _uiState.value = ModelState.Error("Failed to download model: ${it.message}")
            }
        )
    }

    private suspend fun initializeInterpreter() = withContext(Dispatchers.Default) {
        try {
            // Load the model into memory using Mmap
            val modelBuffer = repository.loadModelFile()
            
            // Configure TFLite options (e.g., using NNAPI or GPU)
            val options = Interpreter.Options().apply {
                setNumThreads(4) // Optimize for quad-core mobile CPUs
            }
            
            tfliteInterpreter = Interpreter(modelBuffer, options)
            _uiState.value = ModelState.Ready
        } catch (e: Exception) {
            _uiState.value = ModelState.Error("Interpreter Init Failed: ${e.message}")
        }
    }

    /**
     * Performs inference. MUST be called on a background thread.
     */
    fun summarizeText(input: String, onResult: (String) -> Unit) {
        val interpreter = tfliteInterpreter ?: return
        
        viewModelScope.launch(Dispatchers.Default) {
            try {
                // 1. Pre-processing: Convert String to FloatArray (simplified)
                val inputData = preprocess(input)
                val outputData = Array(1) { FloatArray(128) } // Example output shape

                // 2. Inference: This is the computationally expensive part
                interpreter.run(inputData, outputData)

                // 3. Post-processing: Convert FloatArray back to String
                val result = postprocess(outputData[0])
                
                withContext(Dispatchers.Main) {
                    onResult(result)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onResult("Inference Error: ${e.message}")
                }
            }
        }
    }

    private fun preprocess(text: String): Array<FloatArray> {
        // In a real app, you'd use a Tokenizer here.
        return Array(1) { FloatArray(128) { 0.1f } } 
    }

    private fun postprocess(output: FloatArray): String {
        // In a real app, you'd map IDs back to words.
        return "This is a simulated summary of the input text."
    }

    /**
     * CRITICAL: Release native memory when the ViewModel is destroyed.
     * TFLite Interpreters are not garbage collected by the JVM.
     */
    override fun onCleared() {
        super.onCleared()
        tfliteInterpreter?.close()
        tfliteInterpreter = null
        Log.d("SummarizerVM", "Interpreter closed and native memory released.")
    }
}

/**
 * Jetpack Compose UI Layer.
 */
@Composable
fun SummarizerScreen(viewModel: SummarizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsState()
    var inputText by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
    ) {
        when (state) {
            is ModelState.Idle -> {
                Button(onClick = { viewModel.prepareModel() }) {
                    Text("Initialize AI Model")
                }
            }
            is ModelState.Downloading -> {
                val progress = (state as ModelState.Downloading).progress
                Text("Downloading Model... ${(progress * 100).toInt()}%")
                LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
            }
            is ModelState.Ready -> {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("Enter text to summarize") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { 
                    viewModel.summarizeText(inputText) { resultText = it } 
                }) {
                    Text("Summarize")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Result: $resultText", style = MaterialTheme.typography.bodyLarge)
            }
            is ModelState.Error -> {
                Text("Error: ${(state as ModelState.Error).message}", color = androidx.compose.ui.graphics.Color.Red)
                Button(onClick = { viewModel.prepareModel() }) {
                    Text("Retry")
                }
            }
        }
    }
}
