
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the theoretical states of the AI Model Lifecycle.
 */
sealed class ModelLifecycleState {
    object Uninitialized : ModelLifecycleState()
    data class Downloading(val progress: Float) : ModelLifecycleState()
    object ReadyOnDisk : ModelLifecycleState()
    object LoadingIntoRam : ModelLifecycleState()
    object Active : ModelLifecycleState()
    data class Error(val message: String) : ModelLifecycleState()
}

@Singleton
class AiLifecycleManager @Inject constructor(
    private val modelProvider: SystemAiProvider // Theoretical system wrapper
) {
    private val _lifecycleState = MutableStateFlow<ModelLifecycleState>(ModelLifecycleState.Uninitialized)
    val lifecycleState: StateFlow<ModelLifecycleState> = _lifecycleState.asStateFlow()

    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * Orchestrates the transition from Uninitialized to Active.
     * This mirrors the "Room Migration" logic where we ensure state 
     * consistency before allowing access.
     */
    fun initializeModel() {
        managerScope.launch {
            try {
                // 1. Check if model exists on disk
                if (!modelProvider.isModelPresent()) {
                    _lifecycleState.value = ModelLifecycleState.Downloading(0f)
                    
                    // Observe download progress via a Flow from the system provider
                    modelProvider.downloadModel().collect { progress ->
                        _lifecycleState.value = ModelLifecycleState.Downloading(progress)
                    }
                }

                _lifecycleState.value = ModelLifecycleState.ReadyOnDisk

                // 2. Load model into memory (The "Warm-up" phase)
                _lifecycleState.value = ModelLifecycleState.LoadingIntoRam
                
                // We use withContext(Dispatchers.IO) because loading weights 
                // is a heavy blocking I/O operation.
                withContext(Dispatchers.IO) {
                    modelProvider.loadModelToRam()
                }

                _lifecycleState.value = ModelLifecycleState.Active
            } catch (e: Exception) {
                _lifecycleState.value = ModelLifecycleState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    fun releaseModel() {
        managerScope.launch {
            modelProvider.unloadModel()
            _lifecycleState.value = ModelLifecycleState.ReadyOnDisk
        }
    }
}
