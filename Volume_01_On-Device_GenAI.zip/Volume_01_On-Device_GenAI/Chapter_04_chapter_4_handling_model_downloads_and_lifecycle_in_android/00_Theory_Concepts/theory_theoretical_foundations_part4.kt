
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.kt
// Description: Theoretical Foundations
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GenAiViewModel @Inject constructor(
    private val lifecycleManager: AiLifecycleManager
) : ViewModel() {

    // Expose the lifecycle state to the UI
    val uiState: StateFlow<ModelLifecycleState> = lifecycleManager.lifecycleState

    init {
        // Start the initialization process immediately upon ViewModel creation
        lifecycleManager.initializeModel()
    }

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            // Theoretical Guard: Ensure model is active before inference
            if (lifecycleManager.lifecycleState.value is ModelLifecycleState.Active) {
                executeInference(prompt)
            } else {
                // Handle the case where the model was evicted by LMK
                lifecycleManager.initializeModel()
            }
        }
    }

    private suspend fun executeInference(prompt: String) {
        // Inference logic here
    }
}
