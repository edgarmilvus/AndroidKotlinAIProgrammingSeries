
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import okhttp3.OkHttpClient
import okhttp3.Request
import okio.buffer
import okio.sink
import java.io.File
import java.security.MessageDigest

// Custom Exceptions
class ChecksumMismatchException(message: String) : Exception(message)
class InsufficientStorageException(message: String) : Exception(message)

class ModelDownloader(private val okHttpClient: OkHttpClient) {

    suspend fun downloadModel(
        url: String, 
        expectedHash: String, 
        targetFile: File
    ): Result<File> = runCatching {
        val tempFile = File(targetFile.parent, "${targetFile.name}.tmp")
        
        // 1. Download Logic: Stream directly to disk to save RAM
        val request = Request.Builder().url(url).build()
        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Server returned ${response.code}")
            
            val body = response.body ?: throw Exception("Empty response body")
            
            // Check for storage space before writing (simplified check)
            if (targetFile.parentFile?.usableSpace ?: 0 < body.contentLength()) {
                throw InsufficientStorageException("Not enough space to download model")
            }

            tempFile.sink().buffer().use { sink ->
                sink.writeAll(body.source())
            }
        }

        // 2. Checksum Verification
        val actualHash = calculateSha256(tempFile)
        if (actualHash != expectedHash) {
            tempFile.delete() // Clean up corrupted file
            throw ChecksumMismatchException("Expected $expectedHash but got $actualHash")
        }

        // 3. Atomic Save: Rename .tmp to .tflite
        if (tempFile.renameTo(targetFile)) {
            targetFile
        } else {
            throw Exception("Failed to finalize model file")
        }
    }

    private fun calculateSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { fis ->
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
