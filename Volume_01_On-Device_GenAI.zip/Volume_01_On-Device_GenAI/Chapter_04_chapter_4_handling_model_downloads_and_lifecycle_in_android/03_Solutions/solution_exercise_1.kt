
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.flow.*
import java.io.*
import java.net.URL
import java.security.MessageDigest

// 1. The Worker handling the download and verification
class ModelDownloadWorker(appContext: Context, params: WorkerParameters) : 
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val modelUrl = inputData.getString("MODEL_URL") ?: return Result.failure()
        val expectedHash = inputData.getString("EXPECTED_HASH") ?: return Result.failure()
        val destinationFile = File(applicationContext.filesDir, "model.tflite")

        return try {
            // Download file
            URL(modelUrl).openStream().use { input ->
                destinationFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            // Integrity Check: SHA-256
            if (verifyChecksum(destinationFile, expectedHash)) {
                Result.success()
            } else {
                destinationFile.delete() // Clean up corrupted file
                Result.retry() // Trigger exponential backoff
            }
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun verifyChecksum(file: File, expectedHash: String): Boolean {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { fis ->
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
        return actualHash.equals(expectedHash, ignoreCase = true)
    }
}

// 2. ViewModel to bridge WorkManager and Compose UI
class ModelDownloadViewModel(private val context: Context) : androidx.lifecycle.ViewModel() {
    
    private val workManager = WorkManager.getInstance(context)

    val downloadStatus: StateFlow<DownloadState> = workManager
        .getWorkInfosForUniqueWorkFlow("model_download")
        .flatMapLatest { infoList ->
            val info = infoList.firstOrNull()
            when (info?.state) {
                WorkInfo.State.RUNNING -> flowOf(DownloadState.Downloading)
                WorkInfo.State.SUCCEEDED -> flowOf(DownloadState.Success)
                WorkInfo.State.FAILED -> flowOf(DownloadState.Error("Download Failed"))
                else -> flowOf(DownloadState.Idle)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DownloadState.Idle)

    fun startDownload(url: String, hash: String) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.UNMETERED)
            .setRequiresCharging(true)
            .build()

        val request = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, WorkRequest.MIN_BACKOFF_MILLIS, java.util.concurrent.TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("MODEL_URL" to url, "EXPECTED_HASH" to hash))
            .build()

        workManager.enqueueUniqueWork("model_download", ExistingWorkPolicy.KEEP, request)
    }
}

sealed class DownloadState {
    object Idle : DownloadState()
    object Downloading : DownloadState()
    object Success : DownloadState()
    data class Error(val message: String) : DownloadState()
}
