
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

class ModelStorageManager(private val context: Context) {
    private val mutex = Mutex()
    private val MIN_STORAGE_REQUIRED = 500 * 1024 * 1024L // 500MB

    suspend fun safeDownloadModel(modelName: String, downloadAction: suspend () -> Unit) {
        mutex.withLock {
            if (getAvailableInternalSpace() < MIN_STORAGE_REQUIRED) {
                performEviction()
                if (getAvailableInternalSpace() < MIN_STORAGE_REQUIRED) {
                    throw Exception("Insufficient storage even after cleanup")
                }
            }
            downloadAction()
        }
    }

    private fun getAvailableInternalSpace(): Long {
        val stat = StatFs(context.filesDir.absolutePath)
        return stat.availableBytes
    }

    private fun performEviction() {
        // LRU Eviction: Delete files starting with 'model_' that aren't the current one
        val models = context.filesDir.listFiles { _, name -> name.startsWith("model_") }
            ?.sortedBy { it.lastModified() } // Oldest first

        models?.take(2)?.forEach { it.delete() } // Delete 2 oldest models
    }

    // Lifecycle-linked loading wrapper
    inner class ModelInstance(private val modelFile: File) {
        private var interpreter: Any? = null // Mocking TFLite Interpreter

        fun load() {
            // Load model into memory/GPU
            interpreter = "Loaded ${modelFile.name}"
        }

        fun release() {
            // Explicitly release native memory
            interpreter = null
        }
    }
}

// Usage in ViewModel
class AIViewModel(private val storageManager: ModelStorageManager) : ViewModel() {
    private var modelInstance: ModelStorageManager.ModelInstance? = null

    fun onFeatureEntered() {
        modelInstance = ModelStorageManager.ModelInstance(File("model.tflite")).apply { load() }
    }

    override fun onCleared() {
        super.onCleared()
        modelInstance?.release() // Prevent memory leaks/LMK
    }
}
