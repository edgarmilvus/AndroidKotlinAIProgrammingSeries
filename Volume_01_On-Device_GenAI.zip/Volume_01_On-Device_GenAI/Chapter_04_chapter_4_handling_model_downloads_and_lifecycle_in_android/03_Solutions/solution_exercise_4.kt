
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MemoryAwareModelManager @Inject constructor(
    private val context: Context
) : ComponentCallbacks2 {

    private var interpreter: AIInterpreter? = null
    private val mutex = Mutex()
    private var currentPrecision = "High"

    override fun onTrimMemory(level: Int) {
        when (level) {
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE -> {
                clearTensors()
            }
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                switchToQuantizedModel()
            }
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> {
                unloadModel()
            }
        }
    }

    private fun clearTensors() {
        // Logic to clear temporary buffers/caches
        println("Memory Moderate: Clearing AI caches")
    }

    private fun switchToQuantizedModel() {
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                println("Memory Low: Switching to Quantized Model")
                interpreter?.close()
                interpreter = AIInterpreter(File(context.filesDir, "quantized.tflite"))
                currentPrecision = "Low"
            }
        }
    }

    private fun unloadModel() {
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                println("Memory Critical: Unloading Model")
                interpreter?.close()
                interpreter = null
            }
        }
    }

    suspend fun performInference(input: Any) = mutex.withLock {
        val current = interpreter ?: throw Exception("AI disabled due to memory pressure")
        current.runInference(input)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}
    override fun onLowMemory() { unloadModel() }
}
