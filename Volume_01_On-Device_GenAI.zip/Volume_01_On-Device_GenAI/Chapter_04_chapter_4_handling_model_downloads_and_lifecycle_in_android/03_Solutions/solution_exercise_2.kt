
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

// Mock Interpreter for demonstration
class AIInterpreter(modelFile: File) {
    fun close() { /* Native close logic */ }
    fun runInference(input: Any) { /* Inference logic */ }
}

@Singleton
class ModelManager @Inject constructor(private val context: Context) {
    private var interpreter: AIInterpreter? = null
    private val mutex = Mutex()

    suspend fun acquireModel(): AIInterpreter = mutex.withLock {
        // Return cached instance if already warm
        interpreter?.let { return it }

        // Warm-up phase: Load from disk to RAM
        val modelFile = File(context.filesDir, "model.tflite")
        if (!modelFile.exists()) throw Exception("Model not downloaded")
        
        val loadedInterpreter = AIInterpreter(modelFile)
        interpreter = loadedInterpreter
        return loadedInterpreter
    }

    suspend fun releaseModel() = mutex.withLock {
        interpreter?.close()
        interpreter = null
    }

    fun isReady(): Boolean = interpreter != null
}

// ViewModel managing the lifecycle
class AICameraViewModel @Inject constructor(private val modelManager: ModelManager) : androidx.lifecycle.ViewModel() {
    private val _uiState = MutableStateFlow<AIState>(AIState.Loading)
    val uiState = _uiState.asStateFlow()

    fun onScreenEntered() {
        viewModelScope.launch {
            try {
                modelManager.acquireModel()
                _uiState.value = AIState.Ready
            } catch (e: Exception) {
                _uiState.value = AIState.Error(e.message ?: "Init failed")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.launch {
            modelManager.releaseModel()
        }
    }
}

sealed class AIState {
    object Loading : AIState()
    object Ready : AIState()
    data class Error(val msg: String) : AIState()
}

// Compose Wrapper
@Composable
fun ModelReadyWrapper(viewModel: AICameraViewModel, content: @Composable () -> Unit) {
    val state by viewModel.uiState.collectAsState()

    when (state) {
        is AIState.Loading -> LoadingShimmer()
        is AIState.Ready -> content()
        is AIState.Error -> ErrorScreen((state as AIState.Error).msg)
    }
}
