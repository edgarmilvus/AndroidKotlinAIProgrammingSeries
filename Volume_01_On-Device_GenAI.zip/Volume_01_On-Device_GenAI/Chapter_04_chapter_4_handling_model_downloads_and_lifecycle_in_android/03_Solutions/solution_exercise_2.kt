
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.animation.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface ModelLifecycleState {
    object Uninitialized : ModelLifecycleState
    data class Downloading(val progress: Float) : ModelLifecycleState
    object Verifying : ModelLifecycleState
    object Loading : ModelLifecycleState
    object Ready : ModelLifecycleState
    data class Error(val message: String) : ModelLifecycleState
}

class ModelViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<ModelLifecycleState>(ModelLifecycleState.Uninitialized)
    val uiState: StateFlow<ModelLifecycleState> = _uiState.asStateFlow()

    fun initializeModel() {
        viewModelScope.launch {
            try {
                // Simulate Downloading
                for (i in 1..10) {
                    _uiState.value = ModelLifecycleState.Downloading(i / 10f)
                    delay(200)
                }
                // Simulate Verifying
                _uiState.value = ModelLifecycleState.Verifying
                delay(800)
                // Simulate Loading into GPU/RAM
                _uiState.value = ModelLifecycleState.Loading
                delay(1000)
                
                _uiState.value = ModelLifecycleState.Ready
            } catch (e: Exception) {
                _uiState.value = ModelLifecycleState.Error(e.message ?: "Unknown Error")
            }
        }
    }
}

@Composable
fun ModelWarmingScreen(viewModel: ModelViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedContent(targetState = state, label = "model_state") { currentState ->
            when (currentState) {
                is ModelLifecycleState.Uninitialized -> {
                    Button(onClick = { viewModel.initializeModel() }) { Text("Download AI Model") }
                }
                is ModelLifecycleState.Downloading -> {
                    Column {
                        Text("Fetching Model...")
                        LinearProgressIndicator(progress = { currentState.progress })
                    }
                }
                is ModelLifecycleState.Verifying -> Text("Verifying Integrity... 🛡️")
                is ModelLifecycleState.Loading -> Text("Warming up AI Engine... 🚀")
                is ModelLifecycleState.Ready -> Button(onClick = { /* Start Chat */ }) { Text("Start Chatting") }
                is ModelLifecycleState.Error -> Text("Error: ${currentState.message}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
