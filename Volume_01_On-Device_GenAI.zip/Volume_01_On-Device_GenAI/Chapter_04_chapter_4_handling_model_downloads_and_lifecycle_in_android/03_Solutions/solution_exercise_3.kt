
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.WorkerInject
import kotlinx.coroutines.coroutineScope
import java.io.File

data class ModelManifest(val current_version: String, val download_url: String)

@HiltWorker
class ModelUpdateWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val downloader: ModelDownloader // Injected from Exercise 1
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = coroutineScope {
        try {
            val remoteManifest = fetchManifest() // Mock API call
            val localVersion = getLocalVersion()

            if (isNewerVersion(remoteManifest.current_version, localVersion)) {
                val targetFile = File(applicationContext.filesDir, "model_v${remoteManifest.current_version}.tflite")
                val backupFile = File(applicationContext.filesDir, "model_backup.tflite")
                
                // Create backup of current model before updating
                val currentModel = File(applicationContext.filesDir, "model_current.tflite")
                if (currentModel.exists()) currentModel.copyTo(backupFile, overwrite = true)

                val result = downloader.downloadModel(remoteManifest.download_url, "expected_hash", targetFile)
                
                if (result.isSuccess) {
                    // Atomic swap: update the 'current' pointer/file
                    targetFile.copyTo(currentModel, overwrite = true)
                    Result.success()
                } else {
                    // Rollback: restore from backup
                    backupFile.copyTo(currentModel, overwrite = true)
                    Result.retry()
                }
            } else {
                Result.success()
            }
        } catch (e: Exception) {
            Result.failure()
        }
    }

    private fun isNewerVersion(remote: String, local: String): Boolean {
        return remote.split(".").map { it.toInt() } > local.split(".").map { it.toInt() }
    }

    private fun getLocalVersion(): String = "1.0.0" // Mocked
    private suspend fun fetchManifest(): ModelManifest = ModelManifest("2.1.0", "https://api.ai.com/m.tflite")
}

// Scheduling the work
fun scheduleModelUpdate(context: Context) {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.UNMETERED)
        .setRequiresCharging(true)
        .build()

    val updateRequest = PeriodicWorkRequestBuilder<ModelUpdateWorker>(7, java.util.concurrent.TimeUnit.DAYS)
        .setConstraints(constraints)
        .build()

    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "model_update",
        ExistingPeriodicWorkPolicy.KEEP,
        updateRequest
    )
}
