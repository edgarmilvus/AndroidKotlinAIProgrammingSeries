
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class ModelProfile(val minRamGb: Int, val fileName: String) {
    FAST(2, "fast.tflite"),
    CREATIVE(4, "creative.tflite"),
    ANALYTICAL(6, "analytical.tflite")
}

class DynamicModelSwitcher @Inject constructor(private val context: Context) {
    private var activeInterpreter: AIInterpreter? = null
    private val mutex = Mutex()
    
    // Queue for requests during the "Swap Gap"
    private val requestQueue = Channel<suspend (AIInterpreter) -> Unit>(Channel.UNLIMITED)

    init {
        // Background processor for the queue
        CoroutineScope(Dispatchers.Default).launch {
            for (request in requestQueue) {
                val interpreter = mutex.withLock { activeInterpreter }
                interpreter?.let { request(it) }
            }
        }
    }

    suspend fun switchProfile(profile: ModelProfile) = mutex.withLock {
        // 1. Resource Gating
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val availableRamGb = memInfo.totalMem / (1024 * 1024 * 1024)

        val targetProfile = if (availableRamGb < profile.minRamGb) {
            ModelProfile.CREATIVE // Fallback
        } else {
            profile
        }

        // 2. Atomic Swapping: Load new before releasing old
        val newInterpreter = AIInterpreter(File(context.filesDir, targetProfile.fileName))
        
        val oldInterpreter = activeInterpreter
        activeInterpreter = newInterpreter
        
        // 3. Graceful release of old native memory
        oldInterpreter?.close()
    }

    suspend fun runInference(block: suspend (AIInterpreter) -> Unit) {
        mutex.withLock {
            if (activeInterpreter != null) {
                block(activeInterpreter!!)
            } else {
                requestQueue.send(block)
            }
        }
    }
}
