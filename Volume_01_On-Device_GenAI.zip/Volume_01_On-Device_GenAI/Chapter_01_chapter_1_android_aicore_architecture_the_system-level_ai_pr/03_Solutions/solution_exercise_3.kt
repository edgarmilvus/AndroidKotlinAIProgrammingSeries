
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class SummarizationService @Inject constructor(private val model: GenerativeModel) {
    
    private val SYSTEM_PROMPT = """
        Act as a professional editor. 
        Summarize the following text into exactly three concise bullet points. 
        Maintain a neutral, objective tone. 
        Do not include introductory phrases like "Here is the summary".
    """.trimIndent()

    suspend fun summarizeNote(noteText: String): Flow<String> = flow {
        // Basic Token Management: Truncate to ~3000 characters to avoid context window overflow
        val sanitizedInput = if (noteText.length > 3000) {
            noteText.take(3000) + "... [Truncated]"
        } else {
            noteText
        }

        val fullPrompt = "$SYSTEM_PROMPT\n\nText to summarize:\n$sanitizedInput"
        
        model.generateContentStream(fullPrompt).collect { chunk ->
            emit(chunk.text ?: "")
        }
    }.flowOn(Dispatchers.IO)
}

@Composable
fun SummaryCard(viewModel: SummaryViewModel) {
    val summaryText by viewModel.summaryFlow.collectAsStateWithLifecycle(initialValue = "")
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()

    Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Summary", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            
            // Streaming text output
            Text(
                text = summaryText,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.animateContentSize() 
            )
            
            if (isGenerating) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
    }
}
