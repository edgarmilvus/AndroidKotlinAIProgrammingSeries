
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. State Machine Definition
sealed class AIReadinessState {
    object Checking : AIReadinessState()
    object Downloading : AIReadinessState()
    object Ready : AIReadinessState()
    object Unsupported : AIReadinessState()
    data class Error(val message: String) : AIReadinessState()
}

// 2. Hilt Module for Singleton LLM Instance
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        // In a real implementation, this uses LlmInference.createFromOptions()
        return LlmInference.createFromOptions(context, LlmInference.Options.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Simplified path
            .setMaxTokens(1024)
            .build())
    }
}

// 3. ViewModel for Orchestration
@HiltViewModel
class AIReadinessViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val _state = MutableStateFlow<AIReadinessState>(AIReadinessState.Checking)
    val state: StateFlow<AIReadinessState> = _state.asStateFlow()

    init {
        checkReadiness()
    }

    private fun checkReadiness() {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                // Simulate checking AICore system service status
                // In production, this would involve querying the AICore API for model status
                val isSupported = checkHardwareSupport() 
                if (!isSupported) {
                    _state.value = AIReadinessState.Unsupported
                    return@launch
                }

                _state.value = AIReadinessState.Downloading
                // Simulate waiting for weights to be loaded into NPU
                delay(2000) 
                
                _state.value = AIReadinessState.Ready
            } catch (e: Exception) {
                _state.value = AIReadinessState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private fun checkHardwareSupport(): Boolean {
        // Logic to check Android version and NPU availability
        return android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE
    }
}

// 4. Compose UI Integration
@Composable
fun AIReadinessScreen(viewModel: AIReadinessViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (state) {
            is AIReadinessState.Checking -> Text("Initializing AI...")
            is AIReadinessState.Downloading -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Text("AI capabilities are being optimized for your device...")
            }
            is AIReadinessState.Ready -> Text("Gemini Nano is Ready!", color = Color.Green)
            is AIReadinessState.Unsupported -> Text("Your device does not support on-device AI.")
            is AIReadinessState.Error -> Text("Error: ${(state as AIReadinessState.Error).message}")
        }
    }
}
