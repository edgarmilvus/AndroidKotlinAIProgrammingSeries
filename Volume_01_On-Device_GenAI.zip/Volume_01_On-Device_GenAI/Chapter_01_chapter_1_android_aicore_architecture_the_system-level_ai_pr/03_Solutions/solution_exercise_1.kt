
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// --- DI Module ---
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideGenerativeModel(): GenerativeModel {
        // In a real scenario, the API key/config is managed by AICore system service
        return GenerativeModel(
            modelName = "gemini-nano",
            apiKey = "AI_CORE_INTERNAL_KEY" // Handled by system provider
        )
    }
}

// --- Domain Logic ---
enum class AIStatus { RED, YELLOW, GREEN }

class ConnectivityChecker @Inject constructor(
    private val model: GenerativeModel
) {
    suspend fun checkAvailability(): AIStatus = withContext(Dispatchers.IO) {
        try {
            // We attempt a lightweight metadata check or a minimal prompt 
            // to see if the system provider responds.
            model.generateContent("ping") 
            AIStatus.GREEN
        } catch (e: ModelNotAvailableException) {
            // Model is not yet downloaded or AICore is not supported
            AIStatus.RED
        } catch (e: Exception) {
            // Generic exception often implies the model is updating or initializing
            AIStatus.YELLOW
        }
    }
}

// --- ViewModel ---
@HiltViewModel
class AIConnectivityViewModel @Inject constructor(
    private val checker: ConnectivityChecker
) : ViewModel() {
    private val _status = MutableStateFlow(AIStatus.YELLOW)
    val status: StateFlow<AIStatus> = _status.asStateFlow()

    init {
        verifyStatus()
    }

    fun verifyStatus() {
        viewModelScope.launch {
            _status.value = checker.checkAvailability()
        }
    }
}

// --- UI Layer ---
@Composable
fun AICoreStatusScreen(viewModel: AIConnectivityViewModel = hiltViewModel()) {
    val status by viewModel.status.collectAsStateWithLifecycle()

    val color = when (status) {
        AIStatus.RED -> Color.Red
        AIStatus.YELLOW -> Color.Yellow
        AIStatus.GREEN -> Color.Green
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(color, shape = CircleShape)
        )
        Text(text = "AICore Status: ${status.name}", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = { viewModel.verifyStatus() }) {
            Text("Re-check Status")
        }
    }
}
