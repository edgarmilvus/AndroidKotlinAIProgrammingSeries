
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

data class AIMetrics(
    val ttft: Long, // ms
    val tps: Double, // tokens/sec
    val totalTime: Long, // ms
    val ramUsageMb: Long,
    val batteryDrainMa: Int
)

class AIProfiler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun measureInference(llmInference: LlmInference, prompt: String): Flow<AIMetrics> = flow {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val memInfo = ActivityManager.MemoryInfo()

        var firstTokenTime = 0L
        var tokenCount = 0
        val startTime = System.currentTimeMillis()

        llmInference.generateResponseAsync(prompt).collect { token ->
            if (tokenCount == 0) {
                firstTokenTime = System.currentTimeMillis() - startTime
            }
            tokenCount++
        }

        val endTime = System.currentTimeMillis()
        val totalTime = endTime - startTime
        
        activityManager.getMemoryInfo(memInfo)
        
        emit(AIMetrics(
            ttft = firstTokenTime,
            tps = tokenCount.toDouble() / (totalTime / 1000.0),
            totalTime = totalTime,
            ramUsageMb = memInfo.availMem / (1024 * 1024),
            batteryDrainMa = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        ))
    }
}

@Composable
fun ProfilerScreen(viewModel: ProfilerViewModel = hiltViewModel()) {
    val metrics by viewModel.latestMetrics.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp)) {
        Text("AICore Performance Report", style = MaterialTheme.typography.headlineMedium)
        metrics?.let {
            MetricRow("Time to First Token", "${it.ttft} ms")
            MetricRow("Tokens Per Second", "%.2f tps".format(it.tps))
            MetricRow("Total Latency", "${it.totalTime} ms")
            MetricRow("Available RAM", "${it.ramUsageMb} MB")
            MetricRow("Current Draw", "${it.batteryDrainMa} mA")
        } ?: Text("Run benchmark to see results")
        
        Button(onClick = { viewModel.runBenchmark() }) {
            Text("Run Benchmark")
        }
    }
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), 
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.Bold)
    }
}
