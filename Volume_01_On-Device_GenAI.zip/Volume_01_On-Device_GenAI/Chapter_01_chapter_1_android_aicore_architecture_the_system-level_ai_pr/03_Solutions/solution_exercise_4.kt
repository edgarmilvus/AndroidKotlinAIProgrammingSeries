
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

data class AIProfilingMetrics(
    val ttftMs: Long,
    val tps: Double,
    val totalLatencyMs: Long,
    val memoryDeltaMb: Long
)

class AIProfiler @Inject constructor(
    private val model: GenerativeModel,
    @ApplicationContext private val context: Context
) {
    suspend fun profileInference(prompt: String, useCompressedPrompt: Boolean): AIProfilingMetrics {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        
        activityManager.getMemoryInfo(memInfo)
        val startMem = memInfo.availMem

        val finalPrompt = if (useCompressedPrompt) "Sum: $prompt" else "Please provide a detailed summary of: $prompt"
        
        var firstTokenTime = 0L
        var tokenCount = 0
        val startTime = System.currentTimeMillis()

        model.generateContentStream(
            GenerativeModelContent(finalPrompt),
            generationConfig = generationConfig { 
                stopSequences = listOf("\n\n") // Stop generating after two newlines
            }
        ).collect { chunk ->
            if (tokenCount == 0) {
                firstTokenTime = System.currentTimeMillis() - startTime
            }
            tokenCount++
        }

        val endTime = System.currentTimeMillis()
        activityManager.getMemoryInfo(memInfo)
        val endMem = memInfo.availMem

        return AIProfilingMetrics(
            ttftMs = firstTokenTime,
            tps = tokenCount.toDouble() / ((endTime - firstTokenTime) / 1000.0),
            totalLatencyMs = endTime - startTime,
            memoryDeltaMb = (startMem - endMem) / (1024 * 1024)
        )
    }
}
