
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

@HiltViewModel
class SummaryViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val _summaryText = MutableStateFlow("")
    val summaryText: StateFlow<String> = _summaryText.asStateFlow()

    private var inferenceJob: Job? = null

    fun summarizeText(inputText: String) {
        // Cancel any existing inference to free NPU resources immediately
        inferenceJob?.cancel()
        _summaryText.value = ""

        // System Prompt Engineering for conciseness
        val systemPrompt = "You are a professional editor. Summarize the following text in one concise sentence. Text: "
        val fullPrompt = "$systemPrompt $inputText"

        inferenceJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                // Using the streaming API from MediaPipe/AICore
                llmInference.generateResponseAsync(fullPrompt)
                    .collect { token ->
                        _summaryText.update { it + token }
                    }
            } catch (e: CancellationException) {
                // Expected when user deselects text
                Log.d("AI_SUMMARIZER", "Inference cancelled by user")
            } catch (e: Exception) {
                _summaryText.value = "Error generating summary."
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        inferenceJob?.cancel()
    }
}

@Composable
fun SummarizerScreen(viewModel: SummaryViewModel = hiltViewModel()) {
    var input by remember { mutableStateOf("") }
    val summary by viewModel.summaryText.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Paste long text here") }
        )
        Button(onClick = { viewModel.summarizeText(input) }) {
            Text("Summarize")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = summary,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.background(Color.LightGray).padding(8.dp)
        )
    }
}
