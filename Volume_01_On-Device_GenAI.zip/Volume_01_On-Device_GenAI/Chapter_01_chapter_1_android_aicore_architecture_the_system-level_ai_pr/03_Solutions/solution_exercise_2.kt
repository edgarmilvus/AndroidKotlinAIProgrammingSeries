
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

@Singleton
class ModelWarmupManager @Inject constructor(
    private val model: GenerativeModel,
    @ApplicationContext private val context: Context
) {
    private val _isWarmedUp = MutableStateFlow(false)
    val isWarmedUp: StateFlow<Boolean> = _isWarmedUp.asStateFlow()

    suspend fun warmUp() = withContext(Dispatchers.Default) {
        try {
            // A "dummy prompt" forces AICore to move weights from disk to NPU/GPU RAM
            model.generateContent("Warmup: Hello")
            _isWarmedUp.value = true
        } catch (e: Exception) {
            Log.e("Warmup", "Warm-up failed: ${e.message}")
            _isWarmedUp.value = false
        }
    }
}

// WorkManager implementation for background trigger
class WarmupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val warmupManager = EntryPointAccessors.fromApplication(
            applicationContext, WarmupManagerEntryPoint::class.java
        ).warmupManager()
        
        warmupManager.warmUp()
        return Result.success()
    }
}

@Composable
fun AIChatScreen(warmupManager: ModelWarmupManager) {
    val isReady by warmupManager.isWarmedUp.collectAsStateWithLifecycle()

    if (!isReady) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
            Text("Optimizing AI for your device...", modifier = Modifier.padding(top = 80.dp))
        }
    } else {
        ChatInterface() // The actual chat UI
    }
}
