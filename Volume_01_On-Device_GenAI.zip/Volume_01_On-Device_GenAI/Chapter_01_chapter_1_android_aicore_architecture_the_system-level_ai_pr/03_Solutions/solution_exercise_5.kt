
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

interface GenerativeInterface {
    fun generateResponse(prompt: String): Flow<String>
}

class AICoreProvider @Inject constructor(private val model: GenerativeModel) : GenerativeInterface {
    override fun generateResponse(prompt: String) = flow {
        model.generateContentStream(prompt).collect { emit(it.text ?: "") }
    }
}

class TFLiteProvider @Inject constructor() : GenerativeInterface {
    override fun generateResponse(prompt: String) = flow {
        emit(" [TFLite Mode] Simple response for: $prompt") 
    }
}

class CloudFallbackProvider @Inject constructor() : GenerativeInterface {
    override fun generateResponse(prompt: String) = flow {
        emit(" [Cloud Mode] High-precision response for: $prompt")
    }
}

@Singleton
class AIProviderRegistry @Inject constructor(
    private val aiCore: AICoreProvider,
    private val tflite: TFLiteProvider,
    private val cloud: CloudFallbackProvider
) {
    fun getBestProvider(): GenerativeInterface {
        // Logic to detect hardware (Simplified for exercise)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) aiCore else tflite
    }
}

class AIResilienceMiddleware @Inject constructor(
    private val registry: AIProviderRegistry
) {
    fun execute(prompt: String): Flow<String> = flow {
        var currentProvider = registry.getBestProvider()
        
        try {
            currentProvider.generateResponse(prompt).collect { emit(it) }
        } catch (e: Exception) {
            Log.w("AI_Middleware", "Primary provider failed, falling back...")
            // Graceful Degradation: Fallback to TFLite, then Cloud
            val fallback = if (currentProvider is AICoreProvider) {
                TFLiteProvider(registry) // Simplified instantiation
            } else {
                CloudFallbackProvider(registry)
            }
            emit("\n(Switching to optimized mode for stability...)\n")
            fallback.generateResponse(prompt).collect { emit(it) }
        }
    }.flowOn(Dispatchers.IO)
}
