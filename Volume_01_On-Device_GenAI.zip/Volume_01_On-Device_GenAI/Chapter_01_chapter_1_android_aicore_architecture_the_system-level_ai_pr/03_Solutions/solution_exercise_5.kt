
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

interface LlmProvider {
    fun generateResponse(prompt: String): Flow<String>
}

class LocalProvider @Inject constructor(private val llmInference: LlmInference) : LlmProvider {
    override fun generateResponse(prompt: String) = llmInference.generateResponseAsync(prompt)
}

class CloudProvider @Inject constructor(private val apiService: GeminiProApi) : LlmProvider {
    override fun generateResponse(prompt: String) = flow {
        emit(apiService.getCompletion(prompt)) 
    }
}

class AiRouter @Inject constructor(
    private val local: LocalProvider,
    private val cloud: CloudProvider,
    @ApplicationContext private val context: Context
) {
    fun route(prompt: String): Flow<String> {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val isOnline = connectivityManager.activeNetwork != null

        // 1. Complexity Heuristic
        val isComplex = prompt.length > 500 || prompt.contains(Regex("analyze|compare|research", RegexOption.IGNORE_CASE))
        
        // 2. Power State Heuristic
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isPowerSave = powerManager.isPowerSaveMode

        return if (isPowerSave || (!isOnline && !isComplex)) {
            local.generateResponse(prompt)
        } else if (isComplex && isOnline) {
            cloud.generateResponse(prompt)
        } else {
            // 3. Confidence-Based Fallback
            flow {
                val localResult = local.generateResponse(prompt).toList().joinToString("")
                if (isInsufficient(localResult) && isOnline) {
                    emitAll(cloud.generateResponse(prompt))
                } else {
                    emit(localResult)
                }
            }
        }
    }

    private fun isInsufficient(response: String): Boolean {
        val failures = listOf("I don't know", "unable to", "not supported")
        return response.isBlank() || failures.any { response.contains(it, ignoreCase = true) }
    }
}

@Composable
fun HybridChatScreen(viewModel: HybridChatViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column {
        // Badge showing which engine is active
        Badge(text = if (uiState.isCloud) "Cloud (Gemini Pro)" else "Local (Gemini Nano)")
        Text(uiState.response)
    }
}
