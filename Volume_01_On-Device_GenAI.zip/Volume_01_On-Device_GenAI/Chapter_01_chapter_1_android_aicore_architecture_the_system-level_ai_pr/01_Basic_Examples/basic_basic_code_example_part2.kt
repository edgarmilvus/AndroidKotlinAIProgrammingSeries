
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.aicore.demo

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. THE REPOSITORY LAYER
 * This class handles the direct interaction with the AICore system service.
 * It encapsulates the LlmInference object, ensuring that the model is 
 * initialized only once and reused across the app.
 */
@Singleton
class AICoreRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Configuration for the LLM. 
    // In a real AICore environment, the model path is managed by the system,
    // but the API requires a configuration object to define parameters.
    private fun createLlmInference() {
        if (llmInference != null) return

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // System path for AICore
            .setMaxTokens(512)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            .build()

        return try {
            llmInference = LlmInference.createFromOptions(context, options)
            Log.d("AICoreRepo", "AICore successfully initialized.")
        } catch (e: Exception) {
            Log.e("AICoreRepo", "Failed to initialize AICore: ${e.message}")
            null
        }
    }

    /**
     * Generates a response based on the provided prompt.
     * We use a Flow to support streaming responses, which is critical for LLMs
     * to avoid the appearance of the app freezing during long generations.
     */
    fun generateText(prompt: String): Flow<String> = flow {
        if (llmInference == null) {
            createLlmInference()
        }

        val inference = llmInference ?: throw IllegalStateException("AICore unavailable")
        
        // We wrap the prompt in a "System Instruction" to guide the model's behavior.
        val refinedPrompt = "Refine the following text to be professional and concise: $prompt"
        
        // generateResponse is a blocking call in the SDK, so we emit 
        // the final result. For true streaming, use generateResponseAsync.
        val result = inference.generateResponse(refinedPrompt)
        emit(result)
    }.flowOn(Dispatchers.Default) // Ensure AI work happens off the Main Thread

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * 2. THE VIEWMODEL LAYER
 * The ViewModel manages the UI state and handles the Coroutine scope.
 * It transforms the Repository's data stream into a StateFlow for the UI.
 */
@HiltViewModel
class AICoreViewModel @Inject constructor(
    private val repository: AICoreRepository
) : ViewModel() {

    // State management using StateFlow
    private val _uiState = MutableStateFlow(AICoreUiState())
    val uiState: StateFlow<AICoreUiState> = _uiState.asStateFlow()

    fun onInputChanged(newText: String) {
        _uiState.update { it.copy(userInput = newText) }
    }

    fun refineText() {
        val currentInput = _uiState.value.userInput
        if (currentInput.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, result = "") }
            
            repository.generateText(currentInput)
                .catch { e -> 
                    _uiState.update { it.copy(isLoading = false, error = e.localizedMessage) }
                }
                .collect { response ->
                    _uiState.update { it.copy(isLoading = false, result = response) }
                }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Note: In a real app, you might keep the repository alive 
        // if other ViewModels use it.
    }
}

data class AICoreUiState(
    val userInput: String = "",
    val result: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * 3. THE UI LAYER (Jetpack Compose)
 * A modern, reactive UI that observes the ViewModel state.
 */
@AndroidEntryPoint
@Composable
fun AICoreScreen(viewModel: AICoreViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "AI Text Refiner",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = state.userInput,
            onValueChange = { viewModel.onInputChanged(it) },
            label = { Text("Enter raw text...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Button(
            onClick = { viewModel.refineText() },
            enabled = !state.isLoading && state.userInput.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (state.isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Text("Refine with Gemini Nano")
            }
        }

        if (state.error != null) {
            Text(
                text = "Error: ${state.error}",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (state.result.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Refined Result:",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.result,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}
