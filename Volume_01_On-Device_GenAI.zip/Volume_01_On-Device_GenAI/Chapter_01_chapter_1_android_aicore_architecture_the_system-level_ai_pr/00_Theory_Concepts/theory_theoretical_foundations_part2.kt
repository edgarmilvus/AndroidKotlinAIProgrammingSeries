
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the configuration for a Gemini Nano session.
 * Using @Serializable for potential persistence or remote config.
 */
@Serializable
data class ModelConfig(
    val temperature: Float = 0.7f,
    val topK: Int = 40,
    val maxTokens: Int = 1024
)

/**
 * AICoreProvider abstracts the system-level service.
 * It manages the lifecycle of the LlmInference engine.
 */
@Singleton
class AICoreProvider @Inject constructor() {
    
    // The underlying MediaPipe LlmInference is the bridge to AICore
    private var llmInference: LlmInference? = null

    /**
     * Initializes the model. This is the 'onCreate' of the AI lifecycle.
     * It must be called on a background thread as it triggers NPU memory allocation.
     */
    suspend fun initialize(config: ModelConfig) = withContext(Dispatchers.Default) {
        if (llmInference == null) {
            // In a real scenario, LlmInference.createFromOptions 
            // communicates via AIDL to the AICore system service.
            llmInference = LlmInference.createFromOptions(
                options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath("/system/aicore/gemini_nano.bin") // System path managed by AICore
                    .setMaxTokens(config.maxTokens)
                    .setTemperature(config.temperature)
                    .build()
            )
        }
    }

    /**
     * Generates a response using a Cold Flow.
     * This mirrors the token-by-token emission of the LLM.
     */
    fun generateResponse(prompt: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("AICore not initialized")
        
        // generateResponse is a callback-based API in MediaPipe; 
        // we use callbackFlow or a custom flow wrapper to convert it to a stream.
        engine.generateResponseAsync(prompt) { partialResult, done ->
            emit(partialResult)
            if (done) {
                // Flow completion is handled by the flow builder
            }
        }
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * Example of using Context Receivers (Experimental) to provide AI capabilities
 * to business logic without leaking the provider instance.
 */
context(AICoreProvider)
suspend fun summarizeText(text: String): String {
    return generateResponse("Summarize this: $text")
        .take(10) // Take first 10 chunks for brevity
        .reduce { accumulator, value -> accumulator + value }
}
