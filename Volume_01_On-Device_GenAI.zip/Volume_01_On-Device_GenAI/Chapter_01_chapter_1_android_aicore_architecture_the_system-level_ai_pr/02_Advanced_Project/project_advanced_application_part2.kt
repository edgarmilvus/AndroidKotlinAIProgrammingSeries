
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.aicore.summarizer

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the UI state for the Summarization screen.
 * Using a sealed class ensures the UI handles all possible AI states.
 */
sealed class SummaryState {
    object Idle : SummaryState()
    object Processing : SummaryState()
    data class Success(val summary: String) : SummaryState()
    data class Error(val message: String) : SummaryState()
}

/**
 * Repository handling the interaction with Android AICore.
 * It abstracts the MediaPipe LlmInference API.
 */
@Singleton
class AICoreRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the LLM with hardware-aware options
    private fun initLlmInference() {
        if (llmInference != null) return

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // System path provided by AICore
            .setMaxTokens(512)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Generates a summary using a streaming approach to avoid blocking the main thread
     * and to provide immediate feedback to the user.
     */
    fun summarizeText(input: String): Flow<String> = flow {
        try {
            initLlmInference()
            val prompt = "Summarize the following text concisely:\n\n$input\n\nSummary:"
            
            // generateResponse is a blocking call in the SDK, 
            // so we wrap it in a flow and use a specific dispatcher.
            val result = llmInference?.generateResponse(prompt) 
                ?: throw IllegalStateException("AICore failed to initialize")
            
            emit(result)
        } catch (e: Exception) {
            Log.e("AICoreRepo", "Inference Error", e)
            throw e
        }
    }.flowOn(Dispatchers.Default) // Ensure AI compute happens on Default (CPU/NPU)
}

/**
 * ViewModel utilizing MVI pattern to manage AI interaction.
 */
@HiltViewModel
class SummarizationViewModel @Inject constructor(
    private val repository: AICoreRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummaryState>(SummaryState.Idle)
    val uiState: StateFlow<SummaryState> = _uiState.asStateFlow()

    /**
     * Orchestrates the summarization process.
     * Uses structured concurrency to ensure that if the ViewModel is cleared,
     * the AI inference is cancelled immediately.
     */
    fun onSummarizeClicked(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SummaryState.Processing
            
            try {
                // Collecting the result from the repository
                repository.summarizeText(text)
                    .catch { e -> 
                        _uiState.value = SummaryState.Error(e.localizedMessage ?: "Unknown AI Error") 
                    }
                    .collect { finalSummary ->
                        _uiState.value = SummaryState.Success(finalSummary)
                    }
            } catch (e: Exception) {
                _uiState.value = SummaryState.Error("Failed to connect to AICore")
            }
        }
    }
}
