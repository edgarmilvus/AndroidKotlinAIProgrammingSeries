
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VectorSearchViewModel @Inject constructor(
    private val repository: VectorRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<String>>(emptyList())
    val searchResults: StateFlow<List<String>> = _searchResults.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    /**
     * Simulates the end-to-end flow:
     * User Input -> AI Embedding Generation -> Vector Search -> UI Update
     */
    fun performSearch(queryText: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            
            // 1. Generate embedding for the query (Simulated here)
            // In production: val queryVector = mediaPipeEmbedder.embed(queryText)
            val queryVector = simulateEmbeddingGeneration(queryText)

            // 2. Search the local vector store on a background thread
            val results = kotlinx.coroutines.withContext(Dispatchers.Default) {
                repository.searchSimilarTexts(queryVector)
            }

            _searchResults.value = results
            _isProcessing.value = false
        }
    }

    fun addKnowledge(text: String) {
        viewModelScope.launch {
            val vector = simulateEmbeddingGeneration(text)
            repository.saveEmbedding(text, vector)
        }
    }

    // Mock function to simulate an AI embedding model (e.g., Gemini Nano)
    private fun simulateEmbeddingGeneration(text: String): FloatArray {
        // In a real scenario, this would be a 384 or 768 dimensional vector
        // based on the model used. Here we use a small 8-dim mock vector.
        return FloatArray(8) { (text.hashCode() + it).toFloat() / 100f }
    }
}
