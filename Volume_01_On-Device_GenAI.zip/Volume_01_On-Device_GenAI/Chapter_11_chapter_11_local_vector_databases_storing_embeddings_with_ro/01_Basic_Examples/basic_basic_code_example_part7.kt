
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part7.kt
// Description: Basic Code Example
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun VectorSearchScreen(viewModel: VectorSearchViewModel) {
    var inputText by remember { mutableStateOf("") }
    var queryText by remember { mutableStateOf("") }
    
    val results by viewModel.searchResults.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Text(text = "On-Device Vector DB", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(16.dp))

        // Section: Add Knowledge
        OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Add knowledge to DB") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                viewModel.addKnowledge(inputText)
                inputText = ""
            },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Store Embedding")
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 24.dp))

        // Section: Semantic Search
        OutlinedTextField(
            value = queryText,
            onValueChange = { queryText = it },
            label = { Text("Search semantically...") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.performSearch(queryText) },
            modifier = Modifier.padding(vertical = 8.dp),
            enabled = !isProcessing
        ) {
            Text(if (isProcessing) "Searching..." else "Find Similar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Results:", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(results) { result ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(text = result, modifier = Modifier.padding(8.dp))
                }
            }
        }
    }
}
