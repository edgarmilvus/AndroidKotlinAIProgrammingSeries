
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.vectorstore

import android.content.Context
import androidx.room.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

// --- 1. DATA LAYER: ENTITY & CONVERTERS ---

/**
 * Represents a piece of text and its corresponding high-dimensional embedding.
 */
@Entity(tableName = "embeddings_table")
data class EmbeddingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val vector: FloatArray // Room doesn't support FloatArray natively
)

/**
 * Converters are critical. They tell Room how to turn a FloatArray into 
 * a format SQLite can store (in this case, a comma-separated string).
 */
class VectorConverters {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String {
        return value.joinToString(",")
    }

    @TypeConverter
    fun toFloatArray(value: String): FloatArray {
        return value.split(",").map { it.toFloat() }.toFloatArray()
    }
}

// --- 2. DATA LAYER: DAO ---

@Dao
interface EmbeddingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmbedding(embedding: EmbeddingEntity)

    @Query("SELECT * FROM embeddings_table")
    fun getAllEmbeddings(): Flow<List<EmbeddingEntity>>
}

@Database(entities = [EmbeddingEntity::class], version = 1)
@TypeConverters(VectorConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun embeddingDao(): EmbeddingDao
}

// --- 3. DOMAIN LAYER: REPOSITORY ---

@Singleton
class VectorRepository @Inject constructor(
    private val dao: EmbeddingDao
) {
    // Store a new text and its vector
    suspend fun saveEmbedding(text: String, vector: FloatArray) {
        dao.insertEmbedding(EmbeddingEntity(content = text, vector = vector))
    }

    /**
     * Performs a local vector search by calculating Cosine Similarity 
     * between the query vector and all stored vectors.
     */
    suspend fun searchSimilar(queryVector: FloatArray, topK: Int = 3): List<Pair<String, Float>> {
        return withContext(Dispatchers.Default) {
            val allEmbeddings = dao.getAllEmbeddings().first()
            
            allEmbeddings.map { entity ->
                val similarity = cosineSimilarity(queryVector, entity.vector)
                entity.content to similarity
            }
            .sortedByDescending { it.second } // Highest similarity first
            .take(topK)
        }
    }

    /**
     * Mathematical implementation of Cosine Similarity:
     * (A · B) / (||A|| * ||B||)
     */
    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

// --- 4. UI LAYER: VIEWMODEL ---

@HiltViewModel
@AndroidEntryPoint
class EmbeddingViewModel @Inject constructor(
    private val repository: VectorRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<Pair<String, Float>>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    fun addNote(text: String, vector: FloatArray) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveEmbedding(text, vector)
        }
    }

    fun performSearch(queryVector: FloatArray) {
        viewModelScope.launch {
            // Move heavy math to Dispatchers.Default to avoid UI jank
            val results = repository.searchSimilar(queryVector)
            _searchResults.value = results
        }
    }
}
