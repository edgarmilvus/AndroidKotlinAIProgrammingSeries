
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Data Layer: Entity and TypeConverter
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val vector: FloatArray
)

class VectorConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(value.size * 4)
        value.forEach { buffer.putFloat(it) }
        return buffer.array()
    }

    @TypeConverter
    fun toFloatArray(value: ByteArray): FloatArray {
        val buffer = ByteBuffer.wrap(value)
        val floatArray = FloatArray(value.size / 4)
        for (i in floatArray.indices) floatArray[i] = buffer.float
        return floatArray
    }
}

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Query("SELECT * FROM notes")
    suspend fun getAllNotes(): List<Note>
}

// 2. Embedding Integration
@Singleton
class EmbeddingManager @Inject constructor(
    private val textEmbedder: TextEmbedder 
) {
    fun generateEmbedding(text: String): FloatArray {
        return textEmbedder.embed(text).embedding
    }
}

// 3. Search Logic in ViewModel
@HiltViewModel
class NoteViewModel @Inject constructor(
    private val noteDao: NoteDao,
    private val embeddingManager: EmbeddingManager
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<Note>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    fun performSearch(query: String) {
        viewModelScope.launch(Dispatchers.Default) {
            val queryVector = embeddingManager.generateEmbedding(query)
            val allNotes = noteDao.getAllNotes()

            val rankedNotes = allNotes.map { note ->
                note to cosineSimilarity(queryVector, note.vector)
            }.sortedByDescending { it.second }
             .take(5)
             .map { it.first }

            _searchResults.value = rankedNotes
        }
    }

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

// 4. UI Layer
@Composable
fun NoteSearchScreen(viewModel: NoteViewModel = hiltViewModel()) {
    var query by remember { mutableStateOf("") }
    val results by viewModel.searchResults.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search concepts...") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = { viewModel.performSearch(query) }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
            }
        )
        LazyColumn {
            items(results) { note ->
                Text(text = "${note.title}: ${note.content}", modifier = Modifier.padding(8.dp))
            }
        }
    }
}
