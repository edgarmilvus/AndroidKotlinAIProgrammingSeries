
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

// 1. Recursive Character Splitting with Overlap
object DocumentChunker {
    fun chunkText(text: String, chunkSize: Int = 500, overlap: Int = 50): List<String> {
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            val end = minOf(start + chunkSize, text.length)
            chunks.add(text.substring(start, end))
            if (end == text.length) break
            start += (chunkSize - overlap)
        }
        return chunks
    }
}

// 2. Hierarchical Room Schema
@Entity(tableName = "documents")
data class Document(@PrimaryKey val id: Int, val filename: String)

@Entity(
    tableName = "chunks",
    foreignKeys = [ForeignKey(entity = Document::class, parentColumns = ["id"], childColumns = ["docId"], onDelete = ForeignKey.CASCADE)]
)
data class Chunk(
    @PrimaryKey(autoGenerate = true) val chunkId: Int = 0,
    val docId: Int,
    val index: Int, // Position in document
    val text: String,
    val vector: FloatArray
)

// 3. Contextual Retrieval with Neighbor Expansion
@Dao
interface ChunkDao {
    @Query("SELECT * FROM chunks WHERE chunkId IN (:ids)")
    suspend fun getChunksByIds(ids: List<Int>): List<Chunk>

    @Query("SELECT * FROM chunks WHERE docId = :docId AND index IN (:indices)")
    suspend fun getChunksByIndices(docId: Int, indices: List<Int>): List<Chunk>
}

class ChunkRepository @Inject constructor(private val chunkDao: ChunkDao) {
    suspend fun retrieveContext(topChunks: List<Chunk>): List<Chunk> {
        val finalChunks = mutableSetOf<Chunk>()
        
        topChunks.forEach { match ->
            finalChunks.add(match)
            // Neighbor Expansion: Fetch index - 1 and index + 1
            val neighbors = chunkDao.getChunksByIndices(
                match.docId, 
                listOf(match.index - 1, match.index + 1)
            )
            finalChunks.addAll(neighbors)
        }
        return finalChunks.sortedBy { it.index }
    }
}
