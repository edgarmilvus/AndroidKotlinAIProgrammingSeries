
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.system.measureNanoTime

// --- Updated Entity ---
@Entity(tableName = "document_embeddings")
data class DocumentEmbedding(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val embedding: FloatArray,
    val category: String,
    val timestamp: Long
)

// --- Updated DAO ---
interface DocumentDao {
    @Query("SELECT * FROM document_embeddings")
    suspend fun getAllEmbeddings(): List<DocumentEmbedding>

    @Query("SELECT * FROM document_embeddings WHERE category = :cat AND timestamp >= :start AND timestamp <= :end")
    suspend fun getFilteredEmbeddings(cat: String, start: Long, end: Long): List<DocumentEmbedding>
}

// --- Hybrid Repository ---
class HybridSearchRepository(private val documentDao: DocumentDao) {

    suspend fun hybridSearch(
        queryVector: FloatArray, 
        category: String, 
        startTime: Long, 
        endTime: Long
    ): List<DocumentEmbedding> = withContext(Dispatchers.Default) {
        
        var filteredList: List<DocumentEmbedding>
        
        val timeTaken = measureNanoTime {
            // SQL Pre-filtering (reduces N)
            filteredList = documentDao.getFilteredEmbeddings(category, startTime, endTime)
            
            // Vector Ranking (only on the subset)
            filteredList = filteredList
                .map { it to calculateCosineSimilarity(queryVector, it.embedding) }
                .sortedByDescending { it.second }
                .map { it.first }
        }
        
        Log.d("SearchPerf", "Hybrid Search took: ${timeTaken / 1_000_000}ms for ${filteredList.size} items")
        filteredList
    }

    private fun calculateCosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        // ... (Same implementation as Exercise 2) ...
        return 0f 
    }
}
