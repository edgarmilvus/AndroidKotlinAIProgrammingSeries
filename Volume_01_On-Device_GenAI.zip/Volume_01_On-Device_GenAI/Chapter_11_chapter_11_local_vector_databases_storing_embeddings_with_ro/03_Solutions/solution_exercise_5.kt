
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// 1. Coarse-to-Fine Filtering Implementation
@Entity(tableName = "optimized_vectors")
data class OptimizedVector(
    @PrimaryKey val id: Int,
    val fullVector: FloatArray, // 384 dimensions
    val coarseVector: FloatArray // First 32 dimensions
)

class VectorSearcher @Inject constructor(private val dao: VectorDao) {
    
    suspend fun search(query: String): List<OptimizedVector> {
        val fullQueryVec = embeddingManager.generateEmbedding(query)
        val coarseQueryVec = fullQueryVec.take(32).toFloatArray()

        // Step 1: Coarse Filter (Fast scan on 32 dims)
        val candidates = dao.getAllVectors().filter { 
            fastCosineSimilarity(coarseQueryVec, it.coarseVector) > 0.7f 
        }.take(500) // Narrow down to 500 candidates

        // Step 2: Fine Filter (Precise scan on 384 dims)
        return candidates.map { it to cosineSimilarity(fullQueryVec, it.fullVector) }
            .sortedByDescending { it.second }
            .map { it.first }
    }

    private fun fastCosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dot = 0.0f
        for (i in vecA.indices) dot += vecA[i] * vecB[i]
        return dot // Simplified for coarse filtering
    }
}

// 2. Benchmarking Suite
class VectorBenchmark(private val searcher: VectorSearcher) {
    fun runBenchmark() {
        val startTime = System.currentTimeMillis()
        
        // Simulate 20,000 vectors
        val results = runBlocking { searcher.search("benchmark query") }
        
        val endTime = System.currentTimeMillis()
        Log.d("Benchmark", "Search took ${endTime - startTime}ms for 20k entries")
    }
}
