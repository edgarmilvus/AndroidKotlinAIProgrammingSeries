
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.room.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NoteManager @Inject constructor(
    private val documentDao: DocumentDao,
    private val textEmbedder: TextEmbedder
) {
    // We use a wrapper to handle the transaction logic
    suspend fun saveNote(note: DocumentEmbedding) = withContext(Dispatchers.IO) {
        try {
            val existingNote = documentDao.getNoteById(note.id)
            
            if (existingNote == null || existingNote.text != note.text) {
                // Text changed or new note: Regenerate embedding
                val newVector = textEmbedder.generateEmbedding(note.text)
                val updatedNote = note.copy(embedding = newVector)
                
                // Perform atomic update
                performAtomicSave(updatedNote)
            } else {
                // Text is identical: Just save (or skip) to avoid unnecessary AI compute
                performAtomicSave(note)
            }
        } catch (e: Exception) {
            Log.e("NoteManager", "Embedding failed: ${e.message}")
            throw EmbeddingException("Could not generate vector for note: ${e.localizedMessage}")
        }
    }

    private suspend fun performAtomicSave(note: DocumentEmbedding) {
        // Room @Transaction ensures both text and vector are updated together
        documentDao.insertOrUpdateInTransaction(note)
    }

    suspend fun reindexAll() = withContext(Dispatchers.Default) {
        val allNotes = documentDao.getAllEmbeddings()
        allNotes.forEach { note ->
            try {
                val newVector = textEmbedder.generateEmbedding(note.text)
                documentDao.updateEmbedding(note.id, newVector)
            } catch (e: Exception) {
                Log.e("Reindex", "Failed to reindex note ${note.id}")
            }
        }
    }
}

// DAO additions
interface DocumentDao {
    @Query("SELECT * FROM document_embeddings WHERE id = :id")
    suspend fun getNoteById(id: Int): DocumentEmbedding?

    @Transaction
    suspend fun insertOrUpdateInTransaction(note: DocumentEmbedding) {
        insert(note) // Assuming insert is an @Insert(onConflict = OnConflictStrategy.REPLACE)
    }

    @Query("UPDATE document_embeddings SET embedding = :vector WHERE id = :id")
    suspend fun updateEmbedding(id: Int, vector: FloatArray)
}

class EmbeddingException(message: String) : Exception(message)
