
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// 1. Batch Processing with WorkManager
@HiltWorker
class EmbeddingWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val contactDao: ContactDao,
    private val embeddingManager: EmbeddingManager
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val contactsWithoutVectors = contactDao.getContactsMissingEmbeddings()
        
        contactsWithoutVectors.forEach { contact ->
            // Throttling: Small delay to prevent NPU overheating during large batches
            delay(10) 
            val vector = embeddingManager.generateEmbedding(contact.bio)
            contactDao.updateVector(contact.id, vector)
        }
        Result.success()
    }
}

// 2. Similarity Ranking and Filtering
@HiltViewModel
class ContactViewModel @Inject constructor(
    private val contactDao: ContactDao
) : ViewModel() {

    fun findSimilarProfessionals(targetContact: Contact): Flow<List<Contact>> = flow {
        val allContacts = contactDao.getAllContacts()
        val threshold = 0.75f // Distance threshold

        val similar = allContacts
            .filter { it.id != targetContact.id }
            .map { it to euclideanDistance(targetContact.vector, it.vector) }
            .filter { it.second < threshold } // Lower distance = higher similarity
            .sortedBy { it.second }
            .map { it.first }
        
        emit(similar)
    }.flowOn(Dispatchers.Default)

    private fun euclideanDistance(vecA: FloatArray, vecB: FloatArray): Float {
        var sum = 0.0f
        for (i in vecA.indices) {
            val diff = vecA[i] - vecB[i]
            sum += diff * diff
        }
        return sqrt(sum)
    }
}

// 3. DI Singleton for TextEmbedder
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideTextEmbedder(@ApplicationContext context: Context): TextEmbedder {
        return TextEmbedder.createFromOptions(context, TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("embedder.tflite").build())
            .build())
    }
}
