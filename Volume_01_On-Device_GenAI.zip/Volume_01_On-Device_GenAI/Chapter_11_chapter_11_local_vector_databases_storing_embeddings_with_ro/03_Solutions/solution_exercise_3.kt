
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. Dual Storage Strategy
@Entity(tableName = "docs")
data class DocEntity(@PrimaryKey val id: Int, val text: String)

@Fts4(contentEntity = DocEntity::class)
@Entity(tableName = "docs_fts")
data class DocFtsEntity(val text: String)

@Entity(tableName = "doc_vectors")
data class DocVectorEntity(@PrimaryKey val docId: Int, val vector: FloatArray)

// 2. Hybrid Query Pipeline
class HybridSearchRepository @Inject constructor(
    private val docDao: DocDao,
    private val embeddingManager: EmbeddingManager,
    private val geminiNano: GeminiNanoClient 
) {
    suspend fun hybridSearch(query: String): String = coroutineScope {
        // Parallel Execution
        val ftsDeferred = async(Dispatchers.IO) { docDao.searchFts(query) }
        val vecDeferred = async(Dispatchers.Default) {
            val queryVec = embeddingManager.generateEmbedding(query)
            val allVecs = docDao.getAllVectors()
            allVecs.map { it to cosineSimilarity(queryVec, it.vector) }
                .sortedByDescending { it.second }
                .map { it.first.docId }
        }

        val ftsResults = ftsDeferred.await()
        val vecResults = vecDeferred.await()

        // 3. Reciprocal Rank Fusion (RRF)
        val k = 60
        val scores = mutableMapOf<Int, Float>()

        ftsResults.forEachIndexed { index, id ->
            scores[id] = scores.getOrDefault(id, 0f) + 1f / (k + index + 1)
        }
        vecResults.forEachIndexed { index, id ->
            scores[id] = scores.getOrDefault(id, 0f) + 1f / (k + index + 1)
        }

        val topIds = scores.entries.sortedByDescending { it.value }.take(3).map { it.key }
        val context = docDao.getDocsByIds(topIds).joinToString("\n") { it.text }

        // 4. Context Windowing for Gemini Nano
        geminiNano.generateResponse("Query: $query\n\nContext:\n$context")
    }
}
