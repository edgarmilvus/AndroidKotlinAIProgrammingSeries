
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.layout.*

// --- ViewModel ---
@OptIn(FlowPreview::class)
@HiltViewModel
class NoteViewModel @Inject constructor(
    private val repository: VectorSearchRepository,
    private val textEmbedder: TextEmbedder // Wrapper for MediaPipe
) : ViewModel() {

    private val _queryText = MutableStateFlow("")
    val queryText = _queryText.asStateFlow()

    private val _suggestions = MutableStateFlow<List<DocumentEmbedding>>(emptyList())
    val suggestions = _suggestions.asStateFlow()

    init {
        viewModelScope.launch {
            _queryText
                .debounce(500) // Wait for user to stop typing
                .filter { it.length > 3 }
                .distinctUntilChanged()
                .collect { text ->
                    val vector = textEmbedder.generateEmbedding(text)
                    _suggestions.value = repository.findMostSimilar(vector, limit = 3)
                }
        }
    }

    fun onTextChanged(newText: String) {
        _queryText.value = newText
    }
}

// --- Compose UI ---
@Composable
fun SemanticNoteScreen(viewModel: NoteViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val text by viewModel.queryText.collectAsState()
    val suggestions by viewModel.suggestions.collectAsState()

    Column(modifier = androidx.compose.ui.Modifier.fillMaxSize().padding(16.dp)) {
        TextField(
            value = text,
            onValueChange = { viewModel.onTextChanged(it) },
            label = { Text("Write your note...") },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )

        Spacer(modifier = androidx.compose.ui.Modifier.height(24.dp))
        Text("Related Notes", style = MaterialTheme.typography.titleMedium)

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(suggestions) { note ->
                Card(modifier = androidx.compose.ui.Modifier.width(150.dp)) {
                    Text(note.text, modifier = androidx.compose.ui.Modifier.padding(8.dp), maxLines = 3)
                }
            }
        }
    }
}
