
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.localvector.search

import android.content.Context
import androidx.room.*
import dagger.BindsInstance
import dagger.Module
import dagger.InstallIn
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.entrant.EntryPoint
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import java.nio.ByteBuffer
import kotlin.math.sqrt

/**
 * 1. DATA LAYER: Room Entity and Converters
 * We store embeddings as ByteArrays to reduce SQLite overhead.
 */
@Entity(tableName = "semantic_notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val category: String,
    @ColumnInfo(name = "embedding_blob") val embedding: ByteArray 
)

class VectorConverters {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(value.size * 4)
        value.forEach { buffer.putFloat(it) }
        return buffer.array()
    }

    @TypeConverter
    fun toFloatArray(value: ByteArray): FloatArray {
        val buffer = ByteBuffer.wrap(value)
        val floatArray = FloatArray(value.size / 4)
        for (i in floatArray.indices) {
            floatArray[i] = buffer.float
        }
        return floatArray
    }
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM semantic_notes WHERE category = :category")
    suspend fun getNotesByCategory(category: String): List<NoteEntity>

    @Query("SELECT * FROM semantic_notes")
    suspend fun getAllNotes(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)
}

/**
 * 2. DOMAIN LAYER: The Semantic Search Repository
 * Orchestrates the NPU (Embedding) and CPU (Ranking) flow.
 */
@Singleton
class SemanticSearchRepository @Inject constructor(
    private val noteDao: NoteDao,
    private val textEmbedder: TextEmbedder // Injected MediaPipe instance
) {
    /**
     * Performs a semantic search.
     * @param query The natural language search string.
     * @param category Optional coarse filter to reduce the search space (Optimization).
     */
    fun searchSemantic(query: String, category: String? = null): Flow<List<NoteEntity>> = flow {
        // STEP 1: Generate query embedding on NPU/GPU
        // We use withContext(Dispatchers.Default) because MediaPipe calls are blocking
        val queryVector = withContext(Dispatchers.Default) {
            val result: TextEmbedderResult = textEmbedder.embed(query)
            result.embeddingResult().embeddings().get(0).floatArray
        }

        // STEP 2: Candidate Retrieval from Room (I/O)
        val candidates = withContext(Dispatchers.IO) {
            if (category != null) {
                noteDao.getNotesByCategory(category)
            } else {
                noteDao.getAllNotes()
            }
        }

        // STEP 3: Vector Ranking (CPU Intensive)
        // Parallelize the similarity calculation across CPU cores
        val rankedResults = withContext(Dispatchers.Default) {
            candidates.parallelStream().map { note ->
                val noteVector = VectorConverters().toFloatArray(note.embedding)
                val score = cosineSimilarity(queryVector, noteVector)
                note to score
            }.filter { it.second > 0.7f } // Relevance threshold
             .sorted { a, b -> b.second.compareTo(a.second) }
             .map { it.first }
             .toList()
        }

        emit(rankedResults)
    }.flowOn(Dispatchers.Default)

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * 3. PRESENTATION LAYER: ViewModel with MVI-like State
 */
@AndroidEntryPoint
class SearchViewModel @Inject constructor(
    private val repository: SemanticSearchRepository
) : androidx.lifecycle.ViewModel() {

    private val _searchState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchState = _searchState.asStateFlow()

    fun performSearch(query: String, category: String? = null) {
        viewModelScope.launch {
            _searchState.value = SearchUiState.Loading
            try {
                repository.searchSemantic(query, category)
                    .catch { e -> _searchState.value = SearchUiState.Error(e.message ?: "Unknown Error") }
                    .collect { results ->
                        _searchState.value = SearchUiState.Success(results)
                    }
            } catch (e: Exception) {
                _searchState.value = SearchUiState.Error(e.localizedMessage)
            }
        }
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val notes: List<NoteEntity>) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}

/**
 * 4. DI MODULE: Hilt configuration for MediaPipe and Room
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideTextEmbedder(@BindsInstance context: Context): TextEmbedder {
        val options = com.google.mediapipe.tasks.text.textembedder.TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(com.google.mediapipe.tasks.core.BaseOptions.builder()
                .setModelAssetPath("embedding_model.tflite")
                .build())
            .build()
        return TextEmbedder.createFromOptions(context, options)
    }
}
