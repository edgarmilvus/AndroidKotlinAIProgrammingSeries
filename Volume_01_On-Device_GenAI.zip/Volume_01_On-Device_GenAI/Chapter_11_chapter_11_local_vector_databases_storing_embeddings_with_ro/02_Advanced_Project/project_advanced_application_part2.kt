
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.vectorstore

import android.content.Context
import androidx.room.*
import dagger.BindsInstance
import dagger.Module
import dagger.InstallIn
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * 1. DATA LAYER: Room Entity and TypeConverter
 * Since SQLite doesn't support FloatArray, we store the vector as a BLOB or String.
 * For performance, a BLOB/ByteArray is preferred.
 */
@Entity(tableName = "semantic_documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val embedding: FloatArray // Handled by VectorConverter
)

class VectorConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String = value.joinToString(",")

    @TypeConverter
    fun toFloatArray(value: String): FloatArray = value.split(",").map { it.toFloat() }.toFloatArray()
}

@Dao
interface DocumentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity)

    @Query("SELECT * FROM semantic_documents")
    suspend fun getAllDocuments(): List<DocumentEntity>
}

@Database(entities = [DocumentEntity::class], version = 1)
@TypeConverters(VectorConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
}

/**
 * 2. REPOSITORY LAYER: Hardware-Aware Vector Orchestration
 */
@Singleton
class SemanticSearchRepository @Inject constructor(
    private val dao: DocumentDao,
    private val context: Context
) {
    // MediaPipe TextEmbedder configured for GPU/NPU
    private val textEmbedder = TextEmbedder.createFromOptions(
        TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("embedding_model.tflite").build())
            .setDelegate(Delegate.GPU) // Force GPU acceleration for vectorization
            .build()
    )

    suspend fun generateEmbedding(text: String): FloatArray = withContext(Dispatchers.Default) {
        textEmbedder.embed(text).embedding
    }

    /**
     * Performs a local Cosine Similarity search.
     * Formula: (A · B) / (||A|| * ||B||)
     */
    suspend fun searchSimilarDocuments(query: String, limit: Int = 5): List<DocumentEntity> = 
        withContext(Dispatchers.Default) {
            val queryVector = generateEmbedding(query)
            val allDocs = dao.getAllDocuments()

            allDocs.map { doc ->
                doc to cosineSimilarity(queryVector, doc.embedding)
            }
            .filter { it.second > 0.7f } // Similarity threshold
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
        }

    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * 3. VIEWMODEL LAYER: MVI/MVVM State Management
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: SemanticSearchRepository
) : androidx.lifecycle.ViewModel() {

    private val _searchState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchState: StateFlow<SearchUiState> = _searchState

    fun performSemanticSearch(query: String) {
        viewModelScope.launch {
            _searchState.value = SearchUiState.Loading
            try {
                // Structured concurrency: ensure the search is cancelled if ViewModel is cleared
                val results = repository.searchSimilarDocuments(query)
                _searchState.value = SearchUiState.Success(results)
            } catch (e: Exception) {
                _searchState.value = SearchUiState.Error(e.message ?: "Unknown Error")
            }
        }
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val documents: List<DocumentEntity>) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}
