
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.app.Application
import androidx.lifecycle.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// --- Domain Layer ---
interface TokenCounter {
    fun countTokens(text: String): Int
}

@Singleton
class BpeTokenCounter @Inject constructor() : TokenCounter {
    override fun countTokens(text: String): Int {
        if (text.isBlank()) return 0
        // Heuristic: Legal text is dense; using a slightly higher multiplier
        return (text.split(Regex("\\s+")).size * 1.4).toInt()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object TokenModule {
    @Provides @Singleton fun provideTokenCounter(): TokenCounter = BpeTokenCounter()
}

// --- ViewModel Layer ---
@HiltViewModel
class ContextMonitorViewModel @Inject constructor(
    private val tokenCounter: TokenCounter
) : ViewModel() {
    private val systemPrompt = "You are a professional legal assistant. Summarize the following text accurately."
    private val hardLimit = 2048
    private val systemPromptTokens = tokenCounter.countTokens(systemPrompt)

    private val _inputText = MutableStateFlow("")
    val inputText = _inputText.asStateFlow()

    // Reactive pipeline to calculate remaining capacity
    val contextState: StateFlow<ContextState> = _inputText
        .debounce(300) // Prevent UI lag on every keystroke
        .mapLatest { text ->
            val currentTokens = tokenCounter.countTokens(text)
            val totalUsed = systemPromptTokens + currentTokens
            val remaining = hardLimit - totalUsed
            val percentage = (totalUsed.toFloat() / hardLimit).coerceIn(0f, 1f)
            
            ContextState(
                remainingCapacity = remaining,
                usagePercentage = percentage,
                isLimitExceeded = totalUsed > hardLimit,
                currentTokens = currentTokens
            )
        }
        .flowOn(Dispatchers.Default) // Offload tokenization from Main thread
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ContextState())

    fun onTextChanged(newText: String) {
        _inputText.value = newText
    }
}

data class ContextState(
    val remainingCapacity: Int = 0,
    val usagePercentage: Float = 0f,
    val isLimitExceeded: Boolean = false,
    val currentTokens: Int = 0
)
