
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*

object TokenEstimator {
    // Heuristic: Average English word is ~1.3 tokens
    fun estimateTokens(text: String): Int = 
        (text.split(Regex("\\s+")).size * 1.3).toInt()
}

class PromptValidator(private val maxTokenLimit: Int) {
    fun validateAndTruncate(systemPrompt: String, context: String, query: String): String {
        val systemTokens = TokenEstimator.estimateTokens(systemPrompt)
        val queryTokens = TokenEstimator.estimateTokens(query)
        val contextTokens = TokenEstimator.estimateTokens(context)
        
        val total = systemTokens + queryTokens + contextTokens
        
        if (total <= maxTokenLimit) {
            return "System: $systemPrompt\nContext: $context\nUser: $query"
        }

        // Smart Truncation: Keep system and query, truncate middle of context
        val availableContextTokens = maxTokenLimit - systemTokens - queryTokens
        if (availableContextTokens <= 0) throw IllegalArgumentException("System prompt and query exceed limit")

        val words = context.split(" ")
        val keepCount = (availableContextTokens / 1.3).toInt()
        
        // Keep first 40% and last 60% of the allowed budget to preserve start/end context
        val startCount = (keepCount * 0.4).toInt()
        val endCount = keepCount - startCount
        
        val truncatedContext = words.take(startCount).joinToString(" ") + 
                               " ... [Truncated] ... " + 
                               words.takeLast(endCount).joinToString(" ")

        return "System: $systemPrompt\nContext: $truncatedContext\nUser: $query"
    }
}

@Composable
fun TokenUsageScreen(validator: PromptValidator) {
    var text by remember { mutableStateOf("") }
    val systemPrompt = "You are a helpful legal assistant."
    val query = "Summarize this."
    
    val currentTokens = TokenEstimator.estimateTokens(systemPrompt + text + query)
    val progress = currentTokens.toFloat() / 2048f // Assuming 2k limit

    Column(modifier = androidx.compose.ui.Modifier.padding(16.dp)) {
        TextField(value = text, onValueChange = { text = it }, label = { Text("Paste Article") })
        Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
        LinearProgressIndicator(progress = progress.coerceIn(0f, 1f))
        Text("Token Usage: ${currentTokens} / 2048")
    }
}
