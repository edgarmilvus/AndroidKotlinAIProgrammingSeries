
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import java.util.*

enum class Role { SYSTEM, USER, MODEL }

data class ChatMessage(val role: Role, val content: String)

data class ContextWindowConfig(
    val maxTokenLimit: Int,
    val systemPrompt: String
)

class ConversationBufferRepository(private val config: ContextWindowConfig) {
    // Using a MutableList to act as our buffer; index 0 is always the System Prompt
    private val _buffer = MutableStateFlow<List<ChatMessage>>(
        listOf(ChatMessage(Role.SYSTEM, config.systemPrompt))
    )
    val buffer: StateFlow<List<ChatMessage>> = _buffer.asStateFlow()

    fun addMessage(role: Role, content: String) {
        val currentList = _buffer.value.toMutableList()
        currentList.add(ChatMessage(role, content))
        
        // Prune context to fit within token limits
        val prunedList = pruneContext(currentList)
        _buffer.value = prunedList
    }

    private fun pruneContext(messages: MutableList<ChatMessage>): List<ChatMessage> {
        // Simple heuristic: 1 token ≈ 0.75 words (or wordCount * 1.3)
        fun calculateTokens(msgs: List<ChatMessage>) = 
            msgs.sumOf { it.content.split(Regex("\\s+")).size * 1.3 }.toInt()

        // While we exceed the limit, remove the oldest message 
        // that is NOT the system prompt (index 0).
        while (calculateTokens(messages) > config.maxTokenLimit && messages.size > 1) {
            messages.removeAt(1) 
        }
        return messages
    }

    fun getFullPrompt(): String {
        return _buffer.value.joinToString("\n") { "${it.role}: ${it.content}" }
    }
}

class ChatViewModel(private val repository: ConversationBufferRepository) : ViewModel() {
    val conversationHistory = repository.buffer

    fun sendMessage(text: String) {
        repository.addMessage(Role.USER, text)
        // Simulate model response
        repository.addMessage(Role.MODEL, "This is a simulated response to: $text")
    }
}
