
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.room.*
import kotlinx.coroutines.*

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sessionId: String,
    val role: String,
    val content: String,
    val priority: String // "HIGH" or "LOW"
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE sessionId = :sid ORDER BY id ASC")
    suspend fun getMessagesForSession(sid: String): List<MessageEntity>

    @Insert
    suspend fun insert(message: MessageEntity)

    @Query("DELETE FROM messages WHERE sessionId = :sid AND priority = 'LOW'")
    suspend fun deleteVolatileMessages(sid: String)
}

class SessionRepository(private val dao: MessageDao, private val llmEngine: LlmInferenceEngine) {
    
    suspend fun getOptimizedPrompt(sessionId: String, systemPrompt: String): String {
        val history = dao.getMessagesForSession(sessionId)
        
        // Recursive Summarization Trigger
        if (history.size > 50) {
            summarizeAndCompress(sessionId, history)
        }

        // Reuse logic from Exercise 3 for prompt construction
        return constructPromptFromEntities(systemPrompt, dao.getMessagesForSession(sessionId))
    }

    private suspend fun summarizeAndCompress(sessionId: String, history: List<MessageEntity>) {
        withContext(Dispatchers.Default) {
            val rawText = history.joinToString("\n") { "${it.role}: ${it.content}" }
            val summaryRequest = "Summarize the following conversation into key facts: $rawText"
            
            val summary = llmEngine.generateResponse(summaryRequest)
            
            // Save summary as HIGH priority and wipe old volatile history
            dao.insert(MessageEntity(sessionId = sessionId, role = "System", content = summary, priority = "HIGH"))
            dao.deleteVolatileMessages(sessionId)
        }
    }

    private fun constructPromptFromEntities(sys: String, entities: List<MessageEntity>): String {
        // Implementation similar to Exercise 3...
        return "Formatted Prompt"
    }
}
