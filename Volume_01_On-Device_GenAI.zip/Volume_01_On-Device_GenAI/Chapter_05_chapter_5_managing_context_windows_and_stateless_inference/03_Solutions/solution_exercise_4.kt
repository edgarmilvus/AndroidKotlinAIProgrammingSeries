
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

class SummarizationWorker(appContext: Context, workerParams: WorkerParameters) : 
    CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val historyToSummarize = inputData.getString("history_block") ?: return@withContext Result.failure()
        
        try {
            // Simulate LLM call for summarization
            val summary = performSelfSummarization(historyToSummarize)
            
            // Update the database: replace old messages with a single SUMMARY message
            saveSummaryToDb(summary)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private suspend fun performSelfSummarization(text: String): String {
        val prompt = "Extract all specific dates, names, and technical constraints. " +
                     "Maintain a bulleted list of facts. Summarize: $text"
        // In reality, call Gemini Nano / MediaPipe here
        delay(1000) 
        return "Summary: User is building a Kotlin app; prefers Hilt; target API 34."
    }

    private fun saveSummaryToDb(summary: String) { /* Room logic to insert SUMMARY msg */ }
}

class CompressionManager(private val context: Context, private val tokenCounter: TokenCounter) {
    private val threshold = 1500 // 80% of 2048
    
    fun checkAndTriggerCompression(currentHistory: List<ChatMessage>) {
        val totalTokens = currentHistory.sumOf { tokenCounter.countTokens(it.content) }
        
        if (totalTokens > threshold) {
            val oldestBlock = currentHistory.take(currentHistory.size / 5)
                .joinToString("\n") { it.content }
            
            val data = workDataOf("history_block" to oldestBlock)
            val request = OneTimeWorkRequestBuilder<SummarizationWorker>()
                .setInputData(data)
                .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
                .build()
            
            WorkManager.getInstance(context).enqueueUniqueWork(
                "context_compression", ExistingWorkPolicy.REPLACE, request
            )
        }
    }
}
