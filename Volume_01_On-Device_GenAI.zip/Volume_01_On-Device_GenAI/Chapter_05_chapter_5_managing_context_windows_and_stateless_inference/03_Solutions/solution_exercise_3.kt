
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

enum class Priority { HIGH, LOW }

data class ChatMessage(
    val role: String,
    val content: String,
    val priority: Priority = Priority.LOW
)

class ContextOverflowException(message: String) : Exception(message)

class PriorityContextManager(
    private val systemInstruction: String,
    private val maxTokenLimit: Int
) {
    private val messages = mutableListOf<ChatMessage>()

    fun addMessage(msg: ChatMessage) = messages.add(msg)

    fun constructPrompt(): String {
        val systemTokens = TokenEstimator.estimateTokens(systemInstruction)
        val pinnedMessages = messages.filter { it.priority == Priority.HIGH }
        val pinnedTokens = pinnedMessages.sumOf { TokenEstimator.estimateTokens(it.content) }

        if (systemTokens + pinnedTokens > maxTokenLimit) {
            throw ContextOverflowException("Pinned facts exceed the total token budget!")
        }

        val remainingBudget = maxTokenLimit - systemTokens - pinnedTokens
        val volatileMessages = messages.filter { it.priority == Priority.LOW }
        
        // Sliding window for volatile messages only
        var volatileTokensAcc = 0
        val keptVolatile = mutableListOf<ChatMessage>()
        
        // Iterate backwards to keep the most recent volatile messages
        for (msg in volatileMessages.reversed()) {
            val tokens = TokenEstimator.estimateTokens(msg.content)
            if (volatileTokensAcc + tokens <= remainingBudget) {
                keptVolatile.add(0, msg)
                volatileTokensAcc += tokens
            } else break
        }

        return buildString {
            appendLine("System: $systemInstruction")
            pinnedMessages.forEach { appendLine("${it.role}: ${it.content}") }
            keptVolatile.forEach { appendLine("${it.role}: ${it.content}") }
            append("Assistant: ")
        }
    }
}
