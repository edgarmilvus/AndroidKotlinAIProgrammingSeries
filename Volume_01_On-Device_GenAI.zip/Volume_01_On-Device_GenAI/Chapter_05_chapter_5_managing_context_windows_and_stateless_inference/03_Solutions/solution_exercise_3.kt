
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.room.*
import kotlinx.coroutines.flow.*

enum class Priority { LOW, MEDIUM, HIGH }

@Entity(tableName = "messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String,
    val content: String,
    val priority: Priority,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Query("UPDATE messages SET priority = :priority WHERE id = :id")
    suspend fun updatePriority(id: Int, priority: Priority)
}

class PruningEngine(private val maxTokenLimit: Int) {
    
    fun assembleContext(messages: List<ChatMessageEntity>): String {
        val tokens = mutableMapOf<Int, Int>()
        messages.forEach { tokens[it.id] = (it.content.split(" ").size * 1.3).toInt() }

        val highPriority = messages.filter { it.priority == Priority.HIGH }
        val others = messages.filter { it.priority != Priority.HIGH }
            .sortedByDescending { it.timestamp } // Get most recent first

        val finalContext = mutableListOf<ChatMessageEntity>()
        var currentTokenCount = 0

        // 1. Always add High Priority (Anchors)
        highPriority.forEach { msg ->
            finalContext.add(msg)
            currentTokenCount += tokens[msg.id] ?: 0
        }

        // 2. Fill remaining space with most recent Medium/Low messages
        for (msg in others) {
            val msgTokens = tokens[msg.id] ?: 0
            if (currentTokenCount + msgTokens <= maxTokenLimit) {
                finalContext.add(msg)
                currentTokenCount += msgTokens
            }
        }

        // 3. Sort by timestamp to restore chronological order for the LLM
        return finalContext.sortedBy { it.timestamp }.joinToString("\n") { 
            val prefix = if (it.priority == Priority.HIGH) "[MEMORY]" else "[HISTORY]"
            "$prefix ${it.role}: ${it.content}"
        }
    }
}
