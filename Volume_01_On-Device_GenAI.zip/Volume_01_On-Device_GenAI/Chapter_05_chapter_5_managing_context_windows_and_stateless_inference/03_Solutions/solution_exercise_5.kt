
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import kotlinx.serialization.*
import kotlinx.serialization.json.Json

@Serializable
data class SessionState(
    val sessionId: String,
    val compressedSummary: String,
    val activeContextWindow: List<ChatMessage>
)

class SessionManager @Inject constructor(
    private val db: AppDatabase,
    private val llmEngine: LlmEngine // Hypothetical AICore wrapper
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun saveSession(state: SessionState) {
        val serialized = json.encodeToString(state)
        db.sessionDao().insertSession(serialized)
    }

    suspend fun loadSession(sessionId: String): SessionState? {
        val data = db.sessionDao().getSession(sessionId) ?: return null
        return json.decodeFromString<SessionState>(data)
    }

    suspend fun warmUpModel(state: SessionState) {
        // "Heartbeat" request: sends the context without asking a question
        // This primes the KV cache on the NPU/GPU
        val warmUpPrompt = "Context Re-hydration: ${state.compressedSummary} " +
                           "${state.activeContextWindow.joinToString { it.content }}"
        
        try {
            llmEngine.processPrompt(warmUpPrompt) 
            // We don't need the output, just the processing phase
        } catch (e: Exception) {
            // Handle NPU initialization errors
        }
    }
}

// Integration with Android Lifecycle
class AppLifecycleObserver @Inject constructor(
    private val sessionManager: SessionManager,
    private val currentSession: StateFlow<SessionState?>
) : androidx.lifecycle.DefaultLifecycleObserver {

    override fun onStop(owner: androidx.lifecycle.LifecycleOwner) {
        CoroutineScope(Dispatchers.IO).launch {
            currentSession.value?.let { sessionManager.saveSession(it) }
        }
    }
}
