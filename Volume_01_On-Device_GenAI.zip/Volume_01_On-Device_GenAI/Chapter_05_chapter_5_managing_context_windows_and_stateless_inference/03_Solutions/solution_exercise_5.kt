
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.os.PowerManager
import android.content.Context
import kotlin.system.measureTimeMillis

class PromptTemplateEngine(private val context: Context) {
    
    enum class TemplateStyle { NAIVE, STRUCTURED }

    fun buildPrompt(
        style: TemplateStyle, 
        instruction: String, 
        history: String, 
        query: String
    ): String {
        return when (style) {
            TemplateStyle.NAIVE -> "System: $instruction\n$history\nUser: $query"
            TemplateStyle.STRUCTURED -> """
                ### Instruction:
                $instruction
                
                ### Context:
                $history
                
                ### User Query:
                $query
                
                ### Assistant Response:
            """.trimIndent()
        }
    }

    fun getOptimalStyle(): TemplateStyle {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        // Check thermal status (API 29+)
        val status = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.currentThermalStatus
        } else 0

        // If device is overheating, use NAIVE (shorter) to reduce NPU prefill load
        return if (status >= PowerManager.THERMAL_STATUS_MODERATE) {
            TemplateStyle.NAIVE 
        } else {
            TemplateStyle.STRUCTURED
        }
    }
}

// Benchmark Utility
suspend fun benchmarkInference(engine: LlmInferenceEngine, prompt: String) {
    var firstTokenReceived = false
    val startTime = System.currentTimeMillis()
    
    engine.generateResponseStreaming(prompt) { token ->
        if (!firstTokenReceived) {
            val ttft = System.currentTimeMillis() - startTime
            println("Time to First Token (TTFT): ${ttft}ms")
            firstTokenReceived = true
        }
    }
}
