
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Gradle Dependencies
// implementation("com.google.ai.client.generativeai:generativeai:0.7.0")
// implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
// implementation("com.google.dagger:hilt-android:2.51")

/**
 * ContextReceiver allows us to attach AI capabilities to any class 
 * without polluting the constructor, similar to how 'this' works in Fragments.
 */
context(AIContext)
fun String.toPrompt(): String {
    return "User: $this\nAI: "
}

data class Message(val role: String, val content: String)

class AIContext(
    val modelName: String = "gemini-nano",
    val maxContextTokens: Int = 4096
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val aiCoreClient: AICoreClient // Hypothetical AICore Wrapper
) : ViewModel() {

    // The 'State' that the stateless LLM lacks
    private val _conversationHistory = MutableStateFlow<List<Message>>(emptyList())
    val conversationHistory = _conversationHistory.asStateFlow()

    /**
     * Implements the "Sliding Window" theory.
     * Ensures we don't exceed the Context Window limit.
     */
    private fun pruneHistory(history: List<Message>): List<Message> {
        // In a real scenario, you would count actual tokens.
        // Here we simulate by limiting the number of messages.
        return history.takeLast(10) 
    }

    fun sendMessage(userText: String): Flow<String> = flow {
        val currentHistory = pruneHistory(_conversationHistory.value)
        
        // Construct the stateless prompt: History + New Input
        val fullPrompt = currentHistory.joinToString("\n") { "${it.role}: ${it.content}" } 
            + "\nUser: $userText\nAI: "

        // Stream tokens from AICore
        aiCoreClient.generateContentStream(fullPrompt)
            .collect { token ->
                emit(token)
            }
    }.onCompletion {
        // Update state only after successful generation
        _conversationHistory.update { it + Message("User", userText) }
    }.flowOn(Dispatchers.Default)
}
