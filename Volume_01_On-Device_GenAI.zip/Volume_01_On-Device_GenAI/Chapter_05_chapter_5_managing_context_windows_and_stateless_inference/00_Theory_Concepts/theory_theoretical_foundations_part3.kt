
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the "Context Window" state.
 * In a real-world scenario, this would track token counts to prevent OOM.
 */
@Serializable
data class ConversationContext(
    val history: List<ChatMessage>,
    val systemInstruction: String,
    val maxTokens: Int = 2048
)

@Serializable
data class ChatMessage(val role: String, val content: String)

/**
 * The AIManager acts as the bridge to AICore.
 * It implements the "CameraX" philosophy by abstracting the NPU complexity.
 */
@Singleton
class AIManager @Inject constructor(
    private val aiCoreClient: AiCoreClient // System service wrapper
) {
    /**
     * Generates a response using a Flow to handle the "Decode Phase" of inference.
     * This prevents UI blocking and allows for real-time token streaming.
     */
    fun generateResponse(context: ConversationContext): Flow<String> = flow {
        // 1. Serialization: Convert context to the format Gemini Nano expects
        val serializedPrompt = Json.encodeToString(context)
        
        // 2. Inference: Call the system service
        // The aiCoreClient handles the IPC and NPU orchestration
        aiCoreClient.streamText(serializedPrompt)
            .collect { token ->
                emit(token) // Stream tokens as they emerge from the KV Cache
            }
    }.flowOn(Dispatchers.Default) // Ensure NPU orchestration doesn't block Main thread
}

/**
 * Use of Context Receivers (Theoretical Kotlin 2.x) to provide AI capabilities
 * without tight coupling.
 */
context(AIManager)
suspend fun UserInteractionHandler.processQuery(query: String, history: List<ChatMessage>) {
    val context = ConversationContext(
        history = history + ChatMessage("user", query),
        systemInstruction = "You are a helpful Android assistant."
    )
    
    // 'this' refers to AIManager due to the context receiver
    this.generateResponse(context).collect { token ->
        updateUi(token)
    }
}

// Mock for the System Service
interface AiCoreClient {
    fun streamText(prompt: String): Flow<String>
}
