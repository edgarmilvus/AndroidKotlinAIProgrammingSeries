
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.context

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Represents a single turn in the conversation.
 */
data class ChatMessage(
    val role: Role,
    val content: String,
    val tokenCount: Int = 0
) {
    enum class Role { SYSTEM, USER, ASSISTANT }
}

/**
 * State for the MVI UI layer.
 */
data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isProcessing: Boolean = false,
    val currentTokenUsage: Int = 0,
    val error: String? = null
)

/**
 * ContextWindowManager handles the logic of pruning and token budgeting.
 * This is the "Brain" of the stateless inference management.
 */
@Singleton
class ContextWindowManager @Inject constructor() {
    private val MAX_TOKEN_BUDGET = 2048 // Gemini Nano typical limit for stable performance
    private val SYSTEM_PROMPT_RESERVE = 256 
    
    // Approximation of tokenization (In production, use a BPE tokenizer library)
    private fun estimateTokens(text: String): Int = (text.length / 4) + 1

    fun preparePrompt(history: List<ChatMessage>, systemInstruction: String): String {
        val systemTokens = estimateTokens(systemInstruction)
        var availableBudget = MAX_TOKEN_BUDGET - systemTokens
        
        val prunedHistory = mutableListOf<ChatMessage>()
        var currentTotal = 0
        
        // Iterate backwards to keep the most recent messages (Sliding Window)
        for (msg in history.reversed()) {
            val tokens = estimateTokens(msg.content)
            if (currentTotal + tokens <= availableBudget) {
                prunedHistory.add(0, msg)
                currentTotal += tokens
            } else {
                break // Budget exceeded, stop adding older messages
            }
        }
        
        // Construct the final prompt string for the stateless LLM
        return buildString {
            append("System: $systemInstruction\n\n")
            prunedHistory.forEach { msg ->
                append("${msg.role}: ${msg.content}\n")
            }
            append("User: ") // The prompt ends here for the model to complete
        }
    }

    fun calculateCurrentUsage(history: List<ChatMessage>): Int {
        return history.sumOf { estimateTokens(it.content) }
    }
}

/**
 * Repository handling the hardware-aware orchestration.
 */
@Singleton
class OnDeviceLLMRepository @Inject constructor(
    private val contextManager: ContextWindowManager
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with GPU/NPU acceleration
    fun initializeModel(modelPath: String) {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            .setTopK(40)
            .build()
        
        llmInference = LlmInference.createFromOptions(options)
    }

    suspend fun generateResponse(
        systemInstruction: String, 
        history: List<ChatMessage>, 
        userInput: String
    ): Flow<String> = flow {
        val fullHistory = history + ChatMessage(ChatMessage.Role.USER, userInput)
        val formattedPrompt = contextManager.preparePrompt(fullHistory, systemInstruction)
        
        // Use Dispatchers.Default for heavy CPU/NPU coordination
        withContext(Dispatchers.Default) {
            try {
                // generateResponse is a streaming call in MediaPipe
                llmInference?.generateResponse(formattedPrompt)?.let { response ->
                    emit(response)
                }
            } catch (e: Exception) {
                Log.e("LLM_REPO", "Inference Error", e)
                throw e
            }
        }
    }.flowOn(Dispatchers.Default)
}

/**
 * ViewModel implementing MVI pattern for AI interaction.
 */
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: OnDeviceLLMRepository,
    private val contextManager: ContextWindowManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val systemInstruction = "You are a helpful Android assistant. Be concise and technical."

    fun sendMessage(text: String) {
        viewModelScope.launch {
            // 1. Update UI to show user message and loading state
            val userMsg = ChatMessage(ChatMessage.Role.USER, text)
            _uiState.update { it.copy(
                messages = it.messages + userMsg,
                isProcessing = true,
                currentTokenUsage = contextManager.calculateCurrentUsage(it.messages + userMsg)
            )}

            try {
                var assistantResponse = ""
                
                // 2. Execute hardware-aware inference
                repository.generateResponse(systemInstruction, _uiState.value.messages, text)
                    .collect { chunk ->
                        assistantResponse += chunk
                        // Update UI in real-time for streaming effect
                        updateStreamingResponse(assistantResponse)
                    }

                // 3. Finalize the assistant message in history
                val finalAssistantMsg = ChatMessage(ChatMessage.Role.ASSISTANT, assistantResponse)
                _uiState.update { it.copy(
                    messages = it.messages + finalAssistantMsg,
                    isProcessing = false,
                    currentTokenUsage = contextManager.calculateCurrentUsage(it.messages + finalAssistantMsg)
                )}

            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessing = false, error = e.localizedMessage) }
            }
        }
    }

    private fun updateStreamingResponse(text: String) {
        _uiState.update { state ->
            val updatedMessages = state.messages.toMutableList()
            if (updatedMessages.isNotEmpty() && updatedMessages.last().role == ChatMessage.Role.ASSISTANT) {
                updatedMessages[updatedMessages.size - 1] = ChatMessage(ChatMessage.Role.ASSISTANT, text)
            } else {
                updatedMessages.add(ChatMessage(ChatMessage.Role.ASSISTANT, text))
            }
            state.copy(messages = updatedMessages)
        }
    }
}
