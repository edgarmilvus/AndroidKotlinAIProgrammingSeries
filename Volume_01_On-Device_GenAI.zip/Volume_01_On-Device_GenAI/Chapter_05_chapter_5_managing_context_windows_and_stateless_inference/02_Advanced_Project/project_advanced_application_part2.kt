
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.ondevice.context

import android.content.Context
import android.util.Log
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference

// --- Domain Models ---
data class ChatMessage(val role: String, val content: String, val tokens: Int)
data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isProcessing: Boolean = false,
    val currentContextSize: Int = 0,
    val errorMessage: String? = null
)

// --- Context Management Logic ---
/**
 * Manages the sliding window of tokens to prevent LLM context overflow.
 * Implements a "Priority-Based Pruning" strategy.
 */
@Singleton
class ContextWindowManager @Inject constructor() {
    private val MAX_TOKEN_LIMIT = 2048 // Typical limit for Nano-class models
    private val SYSTEM_PROMPT_RESERVE = 256 // Reserve space for system instructions
    private val USER_QUERY_RESERVE = 512 // Reserve space for the new query

    fun optimizeContext(
        systemPrompt: String, 
        history: List<ChatMessage>, 
        newQuery: String
    ): String {
        val availableTokens = MAX_TOKEN_LIMIT - SYSTEM_PROMPT_RESERVE - USER_QUERY_RESERVE
        var currentTokens = 0
        val optimizedHistory = mutableListOf<ChatMessage>()

        // Iterate backwards: keep the most recent messages first
        for (msg in history.reversed()) {
            if (currentTokens + msg.tokens <= availableTokens) {
                optimizedHistory.add(0, msg)
                currentTokens += msg.tokens
            } else {
                break // Stop adding once we hit the limit
            }
        }

        // Construct the final stateless prompt
        return buildString {
            append("System: $systemPrompt\n\n")
            optimizedHistory.forEach { append("${it.role}: ${it.content}\n") }
            append("User: $newQuery\nAssistant: ")
        }
    }

    fun estimateTokens(text: String): Int = text.length / 4 // Simplified heuristic for demo
}

// --- Repository Layer ---
@Singleton
class GenAiRepository @Inject constructor(
    private val contextManager: ContextWindowManager,
    @Inject private val llmInference: LlmInference
) {
    private val systemInstruction = "You are a concise Android technical assistant. Answer in bullet points."

    suspend fun generateResponse(
        history: List<ChatMessage>, 
        query: String
    ): Flow<String> = flow {
        // 1. Hardware-aware orchestration: Move to Default dispatcher for heavy computation
        withContext(Dispatchers.Default) {
            val fullPrompt = contextManager.optimizeContext(systemInstruction, history, query)
            
            // 2. Stateless Inference call to AICore/MediaPipe
            // Using generateResponse (streaming) to improve perceived latency
            llmInference.generateResponseAsync(fullPrompt) { partialResult, done ->
                // This is a callback-based API; we emit to the flow
                // In a real implementation, use callbackFlow { ... }
            }
            
            // Simulating streaming for architectural clarity
            val response = llmInference.generateResponse(fullPrompt)
            emit(response)
        }
    }.flowOn(Dispatchers.Default)
}

// --- ViewModel Layer ---
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: GenAiRepository,
    private val contextManager: ContextWindowManager
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    fun sendMessage(text: String) {
        val userMsg = ChatMessage("User", text, contextManager.estimateTokens(text))
        
        // Update UI immediately (Optimistic Update)
        _uiState.update { it.copy(
            messages = it.messages + userMsg, 
            isProcessing = true 
        )}

        viewModelScope.launch {
            try {
                repository.generateResponse(_uiState.value.messages, text)
                    .collect { responseText ->
                        val assistantMsg = ChatMessage("Assistant", responseText, contextManager.estimateTokens(responseText))
                        _uiState.update { it.copy(
                            messages = it.messages + assistantMsg,
                            isProcessing = false,
                            currentContextSize = it.messages.sumOf { m -> m.tokens }
                        )}
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = e.localizedMessage, isProcessing = false) }
            }
        }
    }
}

// --- Hilt Module for Hardware Orchestration ---
@Module
@InstallIn(SingletonComponent::class)
object GenAiModule {
    @Provides
    @Singleton
    fun provideLlmInference(@androidContext: Context): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin")
            .setTemperature(0.7f)
            .setMaxTokens(1024)
            // Hardware acceleration: AICore automatically handles NPU/GPU 
            // but we can specify constraints here if using TFLite directly.
            .build()
        return LlmInference.createFromOptions(options)
    }
}
