
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.ondeviceai.chat

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DATA MODEL: Represents a single turn in the conversation.
 */
data class ChatMessage(
    val role: Role,
    val content: String
)

enum class Role { USER, MODEL }

/**
 * REPOSITORY: Handles the heavy lifting of the LLM.
 * This class is a Singleton because initializing the LlmInference 
 * engine is expensive (loads weights into VRAM/RAM).
 */
@Singleton
class GeminiNanoRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model. In a real app, this should be called 
    // during a splash screen or a background worker.
    init {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to the .bin model file
            .setMaxTokens(1024) // Max tokens for the generated output
            .setTemperature(0.7f) // Control randomness
            .setTopK(40)
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Performs stateless inference. 
     * @param fullPrompt The concatenated history + current prompt.
     */
    suspend fun generateResponse(fullPrompt: String): String = withContext(Dispatchers.Default) {
        return@withContext try {
            // This call is blocking; hence the use of Dispatchers.Default
            llmInference?.generateResponse(fullPrompt) ?: "Model not initialized"
        } catch (e: Exception) {
            Log.e("GeminiNanoRepo", "Inference Error: ${e.message}")
            "Error generating response."
        }
    }
}

/**
 * VIEWMODEL: Manages the Context Window and UI State.
 */
@AndroidEntryPoint
class ChatViewModel @Inject constructor(
    private val repository: GeminiNanoRepository
) : ViewModel() {

    // StateFlow to hold the list of messages for the UI
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Track if the model is currently thinking
    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    /**
     * The primary logic for managing the context window.
     */
    fun sendMessage(userText: String) {
        viewModelScope.launch {
            // 1. Add user message to state
            val userMsg = ChatMessage(Role.USER, userText)
            _messages.update { it + userMsg }
            
            _isTyping.value = true

            // 2. CONTEXT MANAGEMENT: Construct the prompt
            // We convert the history list into a single string for the stateless model.
            val formattedPrompt = constructStatelessPrompt(_messages.value)

            // 3. Perform Inference on a background thread
            val responseText = repository.generateResponse(formattedPrompt)

            // 4. Add model response to state
            val modelMsg = ChatMessage(Role.MODEL, responseText)
            _messages.update { it + modelMsg }
            
            _isTyping.value = false
        }
    }

    /**
     * Transforms the list of messages into a prompt the LLM understands.
     * Implements a basic "Sliding Window" by taking only the last 10 messages.
     */
    private fun constructStatelessPrompt(history: List<ChatMessage>): String {
        // Limit history to prevent exceeding the context window (Simplified token management)
        val windowSize = 10 
        val recentHistory = history.takeLast(windowSize)

        return recentHistory.joinToString(separator = "\n") { msg ->
            val prefix = if (msg.role == Role.USER) "User: " else "AI: "
            "$prefix${msg.content}"
        } + "\nAI: " // Append the final trigger for the model to respond
    }
}

/**
 * UI: Jetpack Compose Screen.
 */
@Composable
fun ChatScreen(viewModel: ChatViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isTyping by viewModel.isTyping.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages) { msg ->
                Text(
                    text = "${if (msg.role == Role.USER) "You" else "Gemini"}: ${msg.content}",
                    modifier = Modifier.padding(vertical = 4.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            if (isTyping) {
                item { Text("Gemini is thinking...", style = MaterialTheme.typography.bodySmall) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message...") }
            )
            Button(
                onClick = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Send")
            }
        }
    }
}
