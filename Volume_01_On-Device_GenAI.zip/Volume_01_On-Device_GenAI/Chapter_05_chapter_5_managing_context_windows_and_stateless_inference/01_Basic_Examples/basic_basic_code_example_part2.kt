
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Singleton
import javax.inject.Inject as HiltInject

/**
 * Data model representing a single turn in the conversation.
 */
data class ChatMessage(
    val role: Role,
    val text: String
)

enum class Role { USER, AI }

/**
 * Repository responsible for the lifecycle of the LLM and performing inference.
 * Marked as Singleton to avoid reloading the multi-gigabyte model into RAM multiple times.
 */
@Singleton
class ChatRepository @HiltInject constructor(
    private val context: Context
) {
    // The LlmInference object is the entry point for Gemini Nano / local models.
    private var llmInference: LlmInference? = null

    init {
        setupModel()
    }

    private fun setupModel() {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to the local .bin model
            .setMaxTokens(1024) // Maximum tokens the model can generate in one response
            .setTemperature(0.7f) // Balance between randomness and determinism
            .setTopK(40)
            .build()
        
        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Performs stateless inference. 
     * @param fullContext The entire conversation history formatted as a single string.
     */
    suspend fun generateResponse(fullContext: String): String = withContext(Dispatchers.Default) {
        try {
            // This is a blocking call; hence the use of Dispatchers.Default
            llmInference?.generateResponse(fullContext) ?: "Model not initialized"
        } catch (e: Exception) {
            "Error during inference: ${e.localizedMessage}"
        }
    }

    fun close() {
        llmInference?.close()
    }
}

/**
 * ViewModel that manages the Context Window.
 * It transforms a list of messages into a formatted prompt for the stateless model.
 */
@AndroidEntryPoint
class ChatViewModel @HiltInject constructor(
    private val repository: ChatRepository
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        viewModelScope.launch {
            // 1. Update UI with User Message
            val userMsg = ChatMessage(Role.USER, userText)
            _messages.value = _messages.value + userMsg
            
            _isTyping.value = true

            // 2. Construct the Context Window
            // Since the model is stateless, we must pass the entire history.
            val prompt = buildStatelessPrompt(_messages.value)

            // 3. Perform Inference
            val aiResponse = repository.generateResponse(prompt)

            // 4. Update UI with AI Message
            _messages.value = _messages.value + ChatMessage(Role.AI, aiResponse)
            _isTyping.value = false
        }
    }

    /**
     * Transforms the message list into a format the LLM understands.
     * Example: "User: Hello\nAI: Hi there!\nUser: How are you?"
     */
    private fun buildStatelessPrompt(history: List<ChatMessage>): String {
        return history.joinToString(separator = "\n") { msg ->
            val prefix = if (msg.role == Role.USER) "User: " else "AI: "
            "$prefix${msg.text}"
        } + "\nAI:" // Append the final trigger to prompt the model to respond
    }
}

/**
 * Jetpack Compose UI for the Chat Interface.
 */
@Composable
fun ChatScreen(viewModel: ChatViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isTyping by viewModel.isTyping.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages) { msg ->
                Text(
                    text = "${msg.role}: ${msg.text}",
                    modifier = Modifier.padding(vertical = 4.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            if (isTyping) {
                item { Text("AI is thinking...", style = MaterialTheme.typography.bodySmall) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask something...") }
            )
            Button(onClick = {
                viewModel.sendMessage(inputText)
                inputText = ""
            }) {
                Text("Send")
            }
        }
    }
}
