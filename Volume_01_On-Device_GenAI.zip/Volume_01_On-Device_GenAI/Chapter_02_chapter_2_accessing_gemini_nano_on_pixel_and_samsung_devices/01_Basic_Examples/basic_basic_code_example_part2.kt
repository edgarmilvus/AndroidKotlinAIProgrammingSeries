
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.nanodemo.ai

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject as HiltInject
import javax.inject.Singleton

/**
 * 1. Repository Layer: Encapsulates AICore interaction.
 * We use a Singleton to avoid re-initializing the GenerativeModel, 
 * which can be expensive.
 */
@Singleton
class NanoRepository @HiltInject constructor() {
    
    // Gemini Nano is accessed via the 'gemini-nano' model identifier.
    // Note: In a real production app, the API key would be handled 
    // via a secure backend or the Google AI Studio.
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano", 
        apiKey = "YOUR_API_KEY_HERE" 
    )

    suspend fun generateSummary(inputText: String): Result<String> = withContext(Dispatchers.Default) {
        runCatching {
            Log.d("NanoRepo", "Starting inference on ${Thread.currentThread().name}")
            
            // Constructing the prompt for a specific task (Summarization)
            val prompt = content {
                text("Please summarize the following text concisely: $inputText")
            }
            
            // generateContent is a suspending function that communicates with AICore
            val response = generativeModel.generateContent(prompt)
            response.text ?: throw Exception("Model returned an empty response")
        }
    }
}

/**
 * 2. ViewModel Layer: Manages UI State and Coroutine Scopes.
 */
@AndroidEntryPoint
class NanoViewModel @HiltInject constructor(
    private val repository: NanoRepository
) : ViewModel() {

    // UI State representation
    private val _uiState = MutableStateFlow<NanoUiState>(NanoUiState.Idle)
    val uiState: StateFlow<NanoUiState> = _uiState.asStateFlow()

    fun summarizeText(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            _uiState.value = NanoUiState.Loading
            
            // Offload the heavy lifting to the Repository (Dispatchers.Default)
            val result = repository.generateSummary(text)
            
            _uiState.value = result.fold(
                onSuccess = { NanoUiState.Success(it) },
                onFailure = { NanoUiState.Error(it.message ?: "Unknown Error") }
            )
        }
    }
}

sealed class NanoUiState {
    object Idle : NanoUiState()
    object Loading : NanoUiState()
    data class Success(val output: String) : NanoUiState()
    data class Error(val message: String) : NanoUiState()
}

/**
 * 3. UI Layer: Jetpack Compose Screen.
 */
@Composable
fun NanoSummarizerScreen(viewModel: NanoViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var inputState by remember { mutableStateOf("") }
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "Gemini Nano Summarizer", style = MaterialTheme.typography.headlineMedium)
        
        OutlinedTextField(
            value = inputState,
            onValueChange = { inputState = it },
            label = { Text("Enter text to summarize") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 5
        )

        Button(
            onClick = { viewModel.summarizeText(inputState) },
            modifier = Modifier.fillMaxWidth(),
            enabled = uiState !is NanoUiState.Loading
        ) {
            Text(if (uiState is NanoUiState.Loading) "Processing..." else "Summarize")
        }

        when (val state = uiState) {
            is NanoUiState.Success -> {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(text = state.output, modifier = Modifier.padding(16.dp))
                }
            }
            is NanoUiState.Error -> {
                Text(text = "Error: ${state.message}", color = MaterialTheme.colorScheme.error)
            }
            else -> {}
        }
    }
}
