
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.nanochat.data

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository responsible for communicating with the on-device Gemini Nano model.
 * It leverages the Google AI Edge SDK to interface with the Android AICore service.
 */
@Singleton
class GeminiNanoRepository @Inject constructor() {

    // Initialize the GenerativeModel. 
    // "gemini-nano" is the identifier for the on-device model provided by AICore.
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano",
        // API Key is often handled by AICore internally for on-device models, 
        // but the SDK requires a string. For AICore-managed Nano, 
        // the system handles authentication via the Google Play Services layer.
        apiKey = "YOUR_API_KEY_OR_AICORE_TOKEN", 
        generationConfig = generationConfig {
            temperature = 0.7f // Controls randomness: 0.0 is deterministic, 1.0 is highly creative
            topK = 40          // Limits the vocabulary to the top K most likely tokens
            topP = 0.95f       // Nucleus sampling: considers tokens with cumulative probability P
            maxOutputTokens = 1024
        }
    )

    /**
     * Generates a response based on the provided prompt.
     * Returns a Flow to allow the UI to display tokens as they are generated (streaming).
     */
    fun generateResponse(prompt: String): Flow<String> = flow {
        try {
            // Create the content object for the model
            val inputContent = content { text(prompt) }
            
            // generateContentStream provides a flow of response chunks
            generativeModel.generateContentStream(inputContent).collect { chunk ->
                // Extract the text from the chunk and emit it to the flow
                chunk.text?.let { emit(it) }
            }
        } catch (e: Exception) {
            emit("Error: ${e.localizedMessage ?: "An unknown error occurred while accessing AICore."}")
        }
    }.flowOn(Dispatchers.Default) // CRITICAL: Ensure AI inference happens off the Main Thread
}
