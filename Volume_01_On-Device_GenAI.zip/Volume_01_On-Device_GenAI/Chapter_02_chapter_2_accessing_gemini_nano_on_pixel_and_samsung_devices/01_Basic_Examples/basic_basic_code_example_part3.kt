
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.nanochat.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nanochat.data.GeminiNanoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State representing the current status of the chat interface.
 */
data class ChatUiState(
    val userInput: String = "",
    val responseText: String = "",
    val isGenerating: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class GeminiViewModel @Inject constructor(
    private val repository: GeminiNanoRepository
) : ViewModel() {

    // StateFlow to hold the UI state, ensuring the UI is always reactive.
    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    /**
     * Updates the current text in the input field.
     */
    fun onInputChange(newValue: String) {
        _uiState.update { it.copy(userInput = newValue) }
    }

    /**
     * Triggers the Gemini Nano inference process.
     */
    fun sendPrompt() {
        val prompt = _uiState.value.userInput
        if (prompt.isBlank()) return

        viewModelScope.launch {
            // 1. Prepare UI for generation
            _uiState.update { 
                it.copy(
                    responseText = "", 
                    isGenerating = true, 
                    errorMessage = null 
                ) 
            }

            // 2. Collect the stream from the repository
            repository.generateResponse(prompt)
                .catch { e ->
                    _uiState.update { it.copy(errorMessage = e.message, isGenerating = false) }
                }
                .collect { token ->
                    // 3. Append each new token to the existing response text
                    _uiState.update { 
                        it.copy(responseText = it.responseText + token) 
                    }
                }

            // 4. Mark generation as complete
            _uiState.update { it.copy(isGenerating = false) }
        }
    }
}
