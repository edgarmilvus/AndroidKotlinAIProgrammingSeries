
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

class NewsSummarizer @Inject constructor(
    private val generativeModel: GenerativeModel
) {
    suspend fun summarizeLongArticle(text: String): Result<String> = withContext(Dispatchers.Default) {
        try {
            // 1. Chunking: Split text into ~750 word segments
            val chunks = text.split(Regex("(?<=\\.\\s)")).chunked(50) // Simplified chunking by sentence
            
            if (chunks.size == 1) {
                return@withContext Result.success(generateSummary(chunks[0].joinToString(" "), "final"))
            }

            // 2. Intermediate Summarization
            val intermediateSummaries = chunks.map { chunk ->
                generateSummary(chunk.joinToString(" "), "intermediate")
            }

            // 3. Final Recursive Summarization
            val finalSummary = generateSummary(intermediateSummaries.joinToString("\n"), "final")
            Result.success(finalSummary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun generateSummary(content: String, type: String): String {
        val prompt = if (type == "intermediate") {
            "Summarize the following section of a news article into 2 key bullet points: $content"
        } else {
            "Based on these intermediate summaries, provide a final 3-bullet point TL;DR of the entire article in Markdown format: $content"
        }
        return generativeModel.generateContent(prompt).text ?: ""
    }
}

// ViewModel Integration
@HiltViewModel
class SummaryViewModel @Inject constructor(private val summarizer: NewsSummarizer) : ViewModel() {
    private val _progress = MutableStateFlow(0f)
    val progress = _progress.asStateFlow()
    
    private val _result = MutableStateFlow("")
    val result = _result.asStateFlow()

    fun processArticle(article: String) {
        viewModelScope.launch {
            _progress.value = 0.1f
            summarizer.summarizeLongArticle(article)
                .onSuccess { 
                    _result.value = it 
                    _progress.value = 1.0f
                }
                .onFailure { /* Handle Error */ }
        }
    }
}
