
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeAIException
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.launch

class ToneViewModel : ViewModel() {
    private val generativeModel = GenerativeModel(modelName = "gemini-nano", apiKey = "AICORE")

    var originalText by mutableStateOf("")
    var rewrittenText by mutableStateOf("")
    var isProcessing by mutableStateOf(false)

    fun rewriteText(tone: String) {
        viewModelScope.launch {
            isProcessing = true
            try {
                // Few-Shot Prompting: Providing examples to guide the model's latent space
                val prompt = """
                    You are a communication expert. Rewrite the user's text to be $tone.
                    
                    Example (Professional):
                    Input: "Hey, I'm late with the report, my bad."
                    Output: "Please accept my apologies; the report is delayed and I am working to finalize it."
                    
                    Example (Friendly):
                    Input: "Send me the files now."
                    Output: "Whenever you have a moment, would you mind sending those files over? Thanks!"
                    
                    User Input: "$originalText"
                    Rewritten ($tone):
                """.trimIndent()

                val response = generativeModel.generateContent(prompt)
                rewrittenText = response.text ?: "Could not rewrite text."
            } catch (e: GenerativeAIException) {
                rewrittenText = "AI Error: ${e.message}. Please check if AICore is updated."
            } catch (e: Exception) {
                rewrittenText = "Unexpected error occurred."
            } finally {
                isProcessing = false
            }
        }
    }
}

@Composable
fun ToneShifterScreen(viewModel: ToneViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val tones = listOf("Professional", "Friendly", "Urgent")
    var selectedTone by remember { mutableStateOf(tones[0]) }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = viewModel.originalText,
            onValueChange = { viewModel.originalText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Draft text") }
        )

        Row(modifier = Modifier.padding(vertical = 8.dp)) {
            tones.forEach { tone ->
                FilterChip(
                    selected = selectedTone == tone,
                    onClick = { selectedTone = tone },
                    label = { Text(tone) },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }

        Button(
            onClick = { viewModel.rewriteText(selectedTone) },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.isProcessing
        ) {
            Text(if (viewModel.isProcessing) "Rewriting..." else "Rewrite")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Original:", style = MaterialTheme.typography.labelLarge)
        Text(viewModel.originalText, modifier = Modifier.padding(bottom = 8.dp))
        
        Divider()
        
        Text("Rewritten:", style = MaterialTheme.typography.labelLarge)
        Text(viewModel.rewrittenText, color = MaterialTheme.colorScheme.primary)
    }
}
