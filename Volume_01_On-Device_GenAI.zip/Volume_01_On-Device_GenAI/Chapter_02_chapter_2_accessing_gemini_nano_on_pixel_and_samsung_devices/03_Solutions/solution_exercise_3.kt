
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidModule
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers

@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideGenerativeModel(): GenerativeModel {
        return GenerativeModel(modelName = "gemini-nano", apiKey = "AICORE")
    }
}

@Singleton
class PiiMaskingService @Inject constructor(
    private val model: GenerativeModel
) {
    /**
     * Masks PII from the input text.
     * Returns a Flow to ensure the heavy LLM processing happens off the main thread.
     */
    fun maskPii(text: String): Flow<String> = flow {
        val prompt = """
            Act as a deterministic PII filter. Identify all emails, phone numbers, and credit card numbers.
            Replace them with the labels [EMAIL], [PHONE], or [CC].
            Do not change any other words, punctuation, or the meaning of the sentence.
            If no PII is found, return the text exactly as it is.
            
            Text: $text
            Masked Text:
        """.trimIndent()

        try {
            val response = model.generateContent(prompt)
            emit(response.text ?: text)
        } catch (e: Exception) {
            emit("Error masking PII: ${e.localizedMessage}")
        }
    }.flowOn(Dispatchers.Default) // Ensure CPU-intensive LLM logic doesn't block UI
}

// Example usage in a ViewModel
class SecurityViewModel @Inject constructor(
    private val piiService: PiiMaskingService
) : androidx.lifecycle.ViewModel() {
    fun processMessage(message: String) {
        androidx.lifecycle.viewModelScope.launch {
            piiService.maskPii(message).collect { maskedText ->
                // Update UI or send to cloud analytics
                println("Safe Text: $maskedText")
            }
        }
    }
}
