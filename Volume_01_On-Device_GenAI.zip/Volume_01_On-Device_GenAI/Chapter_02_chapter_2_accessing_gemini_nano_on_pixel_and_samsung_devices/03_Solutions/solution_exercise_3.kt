
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. Room Database Setup
@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val content: String,
    val tags: String // Comma separated tags
)

@Dao
interface JournalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: JournalEntry)
}

// 2. AI Repository with Few-Shot Prompting
class JournalRepository @Inject constructor(
    private val model: GenerativeModel,
    private val dao: JournalDao
) {
    fun analyzeSentimentStream(text: String): Flow<String> = flow {
        val prompt = """
            Analyze the mood of the text. Return ONLY a comma-separated list of tags.
            Input: I had a great day at the park! Tags: Happy, Energetic.
            Input: I am feeling overwhelmed by work. Tags: Stressed, Anxious.
            Input: I can't believe I finished the project on time. Tags: Proud, Relieved.
            Input: $text Tags:
        """.trimIndent()

        model.generateContentStream(prompt).collect { response ->
            emit(response.text ?: "")
        }
    }.flowOn(Dispatchers.IO)

    suspend fun saveEntry(content: String, tags: String) {
        dao.insertEntry(JournalEntry(content = content, tags = tags))
    }
}

// 3. ViewModel utilizing Streaming Flow
@HiltViewModel
class JournalViewModel @Inject constructor(private val repo: JournalRepository) : ViewModel() {
    private val _currentTags = MutableStateFlow("")
    val currentTags = _currentTags.asStateFlow()

    fun analyzeAndSave(content: String) {
        viewModelScope.launch {
            repo.analyzeSentimentStream(content)
                .collect { partialText ->
                    _currentTags.value = partialText
                }
            
            // Save the final accumulated tags to Room
            repo.saveEntry(content, _currentTags.value)
        }
    }
}
