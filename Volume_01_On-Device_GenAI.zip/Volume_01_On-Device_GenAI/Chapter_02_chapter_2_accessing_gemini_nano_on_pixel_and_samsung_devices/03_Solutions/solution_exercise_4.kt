
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {
    private val generativeModel = GenerativeModel(modelName = "gemini-nano", apiKey = "AICORE")
    
    // Maintain the chat session
    private val chatSession = generativeModel.startChat(
        history = listOf(
            content(role = "user") { text("You are a helpful fitness coach.") },
            content(role = "model") { text("I am ready to help you reach your fitness goals!") }
        )
    )

    var messages = remember { mutableStateListOf<ChatMessage>() }
    var currentAiResponse by mutableStateOf("")

    fun sendMessage(userText: String) {
        messages.add(ChatMessage(userText, isUser = true))
        
        viewModelScope.launch {
            // Pruning logic: If history > 10 messages, we would typically 
            // summarize the history or remove old turns. 
            // Nano's context is limited; here we simulate a simple window.
            if (messages.size > 10) {
                // In a real app, you'd implement a sliding window or summary prompt
            }

            try {
                val responseStream = chatSession.generateContentStream(userText)
                
                // Add a placeholder for the AI response
                messages.add(ChatMessage("", isUser = false))
                val aiMessageIndex = messages.size - 1

                responseStream.collect { chunk ->
                    val newText = chunk.text ?: ""
                    messages[aiMessageIndex] = messages[aiMessageIndex].copy(text = 
                        messages[aiMessageIndex].text + newText
                    )
                }
            } catch (e: Exception) {
                messages.add(ChatMessage("Error: ${e.localizedMessage}", isUser = false))
            }
        }
    }
}

data class ChatMessage(val text: String, val isUser: Boolean)

@Composable
fun FitnessChatScreen(viewModel: ChatViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var input by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(viewModel.messages) { msg ->
                Text(
                    text = if (msg.isUser) "You: ${msg.text}" else "Coach: ${msg.text}",
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = if (msg.isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                )
            }
        }
        Row {
            TextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f))
            Button(onClick = { viewModel.sendMessage(input); input = "" }) {
                Text("Send")
            }
        }
    }
}
