
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

sealed interface ChatMessage {
    val text: String
    data class User(override val text: String) : ChatMessage
    data class Ai(override val text: String) : ChatMessage
    data class System(override val text: String) : ChatMessage
}

class ChatManager @Inject constructor(private val model: GenerativeModel) {
    private val systemInstruction = "You are a helpful, concise Android Guide. Use a friendly tone."
    private val historyBuffer = mutableListOf<Content>()
    private val MAX_HISTORY = 10

    suspend fun sendMessage(userText: String): String {
        // 1. Maintain Sliding Window
        if (historyBuffer.size > MAX_HISTORY) {
            // Remove oldest pair (User + AI), but always keep the system prompt if it's at index 0
            historyBuffer.removeAt(1) 
            historyBuffer.removeAt(1)
        }

        // 2. Initialize Chat with current buffer
        val chat = model.startChat(history = historyBuffer)
        val response = chat.sendMessage(userText)
        
        // 3. Update buffer for next turn
        historyBuffer.add(Content.Text(userText))
        historyBuffer.add(Content.Text(response.text ?: ""))
        
        return response.text ?: "I'm sorry, I couldn't process that."
    }

    fun setSystemPrompt(prompt: String) {
        historyBuffer.clear()
        historyBuffer.add(Content.Text(prompt))
    }
}

@Composable
fun ChatScreen(viewModel: ChatViewModel = hiltViewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    Column {
        LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            items(messages) { msg ->
                ChatBubble(msg) // Custom UI component
            }
        }
        // Input field and Send button...
    }
}
