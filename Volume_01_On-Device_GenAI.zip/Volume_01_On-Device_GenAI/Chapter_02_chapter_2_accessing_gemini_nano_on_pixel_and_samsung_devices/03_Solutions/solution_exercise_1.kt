
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Abstraction for flexibility (allows swapping Nano for Pro/Cloud)
interface TextRefiner {
    suspend fun refineText(input: String, tone: String): Result<String>
}

// 2. Gemini Nano Implementation
class GeminiNanoTextRefiner @Inject constructor(
    private val generativeModel: GenerativeModel 
) : TextRefiner {
    override suspend fun refineText(input: String, tone: String): Result<String> {
        return try {
            // System Prompt strategy: Strict instructions to avoid conversational filler
            val prompt = """
                You are a professional email editor. 
                Rewrite the following text to be $tone. 
                Maintain the original meaning but improve grammar and etiquette.
                Output ONLY the rewritten text. Do not include introductory remarks like "Here is the version".
                
                Text: $input
            """.trimIndent()
            
            val response = generativeModel.generateContent(prompt)
            Result.success(response.text ?: "Could not refine text.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// 3. ViewModel managing state
@HiltViewModel
class EmailViewModel @Inject constructor(
    private val refiner: TextRefiner
) : ViewModel() {
    private val _uiState = MutableStateFlow(EmailUiState())
    val uiState = _uiState.asStateFlow()

    fun onInputChanged(text: String) { _uiState.update { it.copy(input = text) } }
    fun onToneSelected(tone: String) { _uiState.update { it.copy(selectedTone = tone) } }

    fun refine() {
        val currentInput = _uiState.value.input
        val currentTone = _uiState.value.selectedTone
        
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = refiner.refineText(currentInput, currentTone)
            _uiState.update { it.copy(
                output = result.getOrDefault("Error: ${result.exceptionOrNull()?.message}"),
                isLoading = false
            )}
        }
    }
}

data class EmailUiState(
    val input: String = "",
    val selectedTone: String = "Professional",
    val output: String = "",
    val isLoading: Boolean = false
)

// 4. Compose UI
@Composable
fun SmartComposeScreen(viewModel: EmailViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tones = listOf("Professional", "Friendly", "Urgent")

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = state.input,
            onValueChange = viewModel::onInputChanged,
            label = { Text("Rough Notes") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Row(Modifier.padding(vertical = 8.dp)) {
            tones.forEach { tone ->
                FilterChip(
                    selected = state.selectedTone == tone,
                    onClick = { viewModel.onToneSelected(tone) },
                    label = { Text(tone) },
                    modifier = Modifier.padding(end = 4.dp)
                )
            }
        }

        Button(
            onClick = viewModel::refine,
            enabled = !state.isLoading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (state.isLoading) CircularProgressIndicator(size = 20.dp) else Text("Refine")
        }

        Text(
            text = state.output,
            modifier = Modifier.padding(top = 16.dp).weight(1f),
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
