
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SummarizerViewModel : ViewModel() {
    // Initialize Gemini Nano
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano", 
        apiKey = "NOT_REQUIRED_FOR_AICORE" // AICore handles auth internally on-device
    )

    private val _uiState = MutableStateFlow(SummarizerUiState())
    val uiState: StateFlow<SummarizerUiState> = _uiState

    fun summarizeText(inputText: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, summary = emptyList())
            
            // Zero-Shot Prompting: Explicit constraints for Gemini Nano
            val prompt = """
                Summarize the following text into exactly three concise bullet points. 
                Do not include introductory phrases like "Here is the summary" or "The main points are".
                Output only the bullet points.
                
                Text: $inputText
            """.trimIndent()

            try {
                val response = generativeModel.generateContent(prompt)
                val resultText = response.text ?: "No summary generated."
                // Split by newline and filter out empty lines to create a list for LazyColumn
                val bulletPoints = resultText.lines().filter { it.isNotBlank() }.take(3)
                _uiState.value = _uiState.value.copy(isLoading = false, summary = bulletPoints)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, summary = listOf("Error: ${e.localizedMessage}"))
            }
        }
    }
}

data class SummarizerUiState(
    val isLoading: Boolean = false,
    val summary: List<String> = emptyList()
)

@Composable
fun QuickSumScreen(viewModel: SummarizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var textInput by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = textInput,
            onValueChange = { textInput = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            label = { Text("Paste article here...") }
        )
        
        Button(
            onClick = { viewModel.summarizeText(textInput) },
            modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth(),
            enabled = !state.isLoading && textInput.isNotBlank()
        ) {
            Text("Summarize")
        }

        if (state.isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(androidx.compose.ui.Alignment.CenterHorizontally))
        }

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(state.summary) { point ->
                Text(text = "• $point", modifier = Modifier.padding(vertical = 4.dp))
            }
        }
    }
}
