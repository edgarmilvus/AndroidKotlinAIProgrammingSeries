
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.util.Log
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// Dummy TFLite implementation for exercise purposes
class TfliteFallbackModel {
    fun suggestNextSentence(input: String): String {
        return " (Suggested by TFLite: Keep going!)"
    }
}

@Singleton
class HybridAiEngine @Inject constructor(
    private val nanoModel: GenerativeModel,
    private val tfliteModel: TfliteFallbackModel
) {
    // Telemetry data
    private var nanoCount = 0
    private var tfliteCount = 0

    suspend fun getSmartCompose(input: String): String {
        val startTime = System.currentTimeMillis()
        
        // 1. Attempt Gemini Nano with a strict timeout
        val nanoResult = withTimeoutOrNull(2000L) {
            try {
                val response = nanoModel.generateContent("Suggest the next sentence for: $input")
                response.text
            } catch (e: Exception) {
                null // Trigger fallback on exception
            }
        }

        val endTime = System.currentTimeMillis()
        val latency = endTime - startTime

        return if (nanoResult != null) {
            nanoCount++
            Log.d("AI_TELEMETRY", "Nano Success | Latency: ${latency}ms")
            nanoResult
        } else {
            tfliteCount++
            Log.d("AI_TELEMETRY", "TFLite Fallback | Latency: ${latency}ms")
            tfliteModel.suggestNextSentence(input)
        }
    }

    fun getTelemetryReport(): String {
        return "Nano Requests: $nanoCount, TFLite Requests: $tfliteCount"
    }
}
