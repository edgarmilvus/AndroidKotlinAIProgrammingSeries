
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

data class AiMetrics(
    val ttft: Long,
    val tps: Double,
    val totalLatency: Long,
    val availableRam: Long
)

class PerformanceProfiler @Inject constructor(
    private val model: GenerativeModel,
    private val activityManager: ActivityManager
) {
    suspend fun benchmarkPrompt(prompt: String): AiMetrics {
        val memoryBefore = getAvailableRam()
        val startTime = System.currentTimeMillis()
        var firstTokenTime = 0L
        var tokenCount = 0
        
        model.generateContentStream(prompt).collect { response ->
            if (firstTokenTime == 0L) {
                firstTokenTime = System.currentTimeMillis() - startTime
            }
            tokenCount += response.text?.length ?: 0
        }
        
        val endTime = System.currentTimeMillis()
        val totalLatency = endTime - startTime
        val generationTime = endTime - (startTime + firstTokenTime)
        
        val tps = if (generationTime > 0) {
            (tokenCount.toDouble() / (generationTime / 1000.0))
        } else 0.0

        return AiMetrics(
            ttft = firstTokenTime,
            tps = tps,
            totalLatency = totalLatency,
            availableRam = memoryBefore
        )
    }

    private fun getAvailableRam(): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem
    }
}

// Usage in ViewModel to detect thermal throttling
fun runStressTest() {
    viewModelScope.launch(Dispatchers.Default) {
        val results = (1..20).map {
            profiler.benchmarkPrompt("Write a 100-word story about a robot.")
        }
        // Plot results: If TPS drops significantly from result[0] to result[19], 
        // thermal throttling is occurring.
    }
}
