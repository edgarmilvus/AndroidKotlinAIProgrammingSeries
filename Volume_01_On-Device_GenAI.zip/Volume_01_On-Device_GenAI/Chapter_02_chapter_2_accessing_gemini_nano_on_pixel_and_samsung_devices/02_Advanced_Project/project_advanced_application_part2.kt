
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.nanopro.summarizer

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import dagger.BindsInstance
import dagger.Module
import dagger.InstallIn
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Sealed class representing the UI State for the Summarizer.
 * This follows the MVI pattern to ensure a single source of truth.
 */
sealed class SummaryUiState {
    object Idle : SummaryUiState()
    object Loading : SummaryUiState()
    data class Success(val summary: String, val isStreaming: Boolean = true) : SummaryUiState()
    data class Error(val message: String) : SummaryUiState()
}

/**
 * Repository Interface to decouple the AI implementation from the business logic.
 * This allows for easy mocking during unit tests.
 */
interface NanoAiRepository {
    fun generateSummary(text: String): Flow<Result<String>>
}

/**
 * Production implementation of the NanoAiRepository.
 * Orchestrates the interaction with AICore and Gemini Nano.
 */
@Singleton
class NanoAiRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : NanoAiRepository {

    // Configure the Gemini Nano model. 
    // In a real Pixel/Samsung environment, AICore provides the model weights.
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano",
        apiKey = "NOT_REQUIRED_FOR_AICORE", // AICore uses system-level auth
        generationConfig = generationConfig {
            temperature = 0.3f // Lower temperature for factual summarization
            topK = 40
            topP = 0.9f
            maxOutputTokens = 512
        }
    )

    override fun generateSummary(text: String): Flow<Result<String>> = flow {
        try {
            // Prompt Engineering: Using a System-Instruction style prompt for Nano
            val prompt = """
                You are a professional executive assistant. 
                Summarize the following text into a concise paragraph and a bulleted list of action items.
                Ensure the tone is professional and neutral.
                
                TEXT TO SUMMARIZE:
                ---
                $text
                ---
                
                SUMMARY AND ACTION ITEMS:
            """.trimIndent()

            // Use generateContentStream for real-time UI updates (perceived latency reduction)
            generativeModel.generateContentStream(prompt).collect { chunk ->
                chunk.text?.let { emit(Result.success(it)) }
            }
        } catch (e: Exception) {
            Log.e("NanoAiRepo", "Inference failed", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.Default) // Ensure AI processing happens off the Main thread
}

/**
 * ViewModel managing the state and interaction logic.
 * Implements structured concurrency to ensure requests are cancelled when VM is cleared.
 */
@HiltViewModel
class SummaryViewModel @Inject constructor(
    private val repository: NanoAiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummaryUiState>(SummaryUiState.Idle)
    val uiState: StateFlow<SummaryUiState> = _uiState.asStateFlow()

    fun summarizeText(input: String) {
        if (input.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SummaryUiState.Loading
            
            val fullSummary = StringBuilder()
            
            repository.generateSummary(input)
                .catch { e -> 
                    _uiState.value = SummaryUiState.Error(e.localizedMessage ?: "Unknown AI Error") 
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { chunk ->
                            fullSummary.append(chunk)
                            _uiState.value = SummaryUiState.Success(
                                summary = fullSummary.toString(),
                                isStreaming = true
                            )
                        },
                        onFailure = { e ->
                            _uiState.value = SummaryUiState.Error(e.localizedMessage ?: "Inference Error")
                        }
                    )
                }
            
            // Mark streaming as complete
            _uiState.update { 
                if (it is SummaryUiState.Success) it.copy(isStreaming = false) else it 
            }
        }
    }
}

/**
 * Hilt Module for providing the Repository implementation.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class AiModule {
    @Binds
    @Singleton
    abstract fun bindNanoAiRepository(impl: NanoAiRepositoryImpl): NanoAiRepository
}
