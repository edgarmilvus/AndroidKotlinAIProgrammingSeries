
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.nanosummarizer.ai

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as javaxInject
import javax.inject.Singleton

/**
 * Represents the UI state for the summarization process.
 * Using a sealed interface ensures exhaustive state handling in Compose.
 */
sealed interface SummarizationState {
    object Idle : SummarizationState
    object Loading : SummarizationState
    data class Success(val summary: String) : SummarizationState
    data class Error(val message: String) : SummarizationState
}

/**
 * NanoModelManager handles the low-level AICore interaction.
 * It ensures the model is initialized once and manages the hardware-specific configuration.
 */
@Singleton
class NanoModelManager @javaxInject constructor(
    @ApplicationContext private val context: Context
) {
    private var generativeModel: GenerativeModel? = null

    // Initialize the model. AICore handles the routing to NPU/GPU internally.
    suspend fun getModel(): GenerativeModel = withContext(Dispatchers.Default) {
        generativeModel ?: run {
            Log.d("NanoManager", "Initializing Gemini Nano via AICore...")
            // In a real scenario, you would use the AICore specific client
            val model = GenerativeModel(
                modelName = "gemini-nano", 
                apiKey = "LOCAL_AICORE_TOKEN" // AICore uses internal tokens/permissions
            )
            generativeModel = model
            model
        }
    }
}

/**
 * Repository layer to abstract the AI logic from the ViewModel.
 * Implements structured concurrency to handle streaming tokens.
 */
@ViewModelScoped
class SummarizerRepository @javaxInject constructor(
    private val modelManager: NanoModelManager
) {
    fun summarizeText(input: String): Flow<String> = flow {
        val model = modelManager.getModel()
        
        // Prompt engineering is critical for local models with smaller parameter counts
        val prompt = "Summarize the following text concisely in 3 bullet points. " +
                     "Focus on key action items. Text: $input"

        // We use generateContentStream to provide immediate feedback to the user
        model.generateContentStream(prompt).collect { chunk ->
            chunk.text?.let { emit(it) }
        }
    }.flowOn(Dispatchers.Default) // Ensure the LLM execution happens off the Main thread
}

/**
 * ViewModel implementing MVI-like state management.
 * Orchestrates the flow from user input to NPU execution and UI update.
 */
@HiltViewModel
@AndroidEntryPoint
class SummarizerViewModel @javaxInject constructor(
    private val repository: SummarizerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummarizationState>(SummarizationState.Idle)
    val uiState: StateFlow<SummarizationState> = _uiState.asStateFlow()

    private var summarizationJob: Job? = null

    fun onSummarizeClicked(text: String) {
        if (text.isBlank()) return

        // Cancel any existing summarization job to prevent race conditions
        summarizationJob?.cancel()

        summarizationJob = viewModelScope.launch {
            _uiState.value = SummarizationState.Loading
            
            val fullSummary = StringBuilder()
            try {
                // Collecting the stream from the repository
                repository.summarizeText(text)
                    .catch { e ->
                        Log.e("SummarizerVM", "AI Error: ${e.message}")
                        _uiState.value = SummarizationState.Error("Failed to access AICore: ${e.localizedMessage}")
                    }
                    .collect { token ->
                        fullSummary.append(token)
                        // Update UI in real-time as tokens are generated (Streaming)
                        _uiState.value = SummarizationState.Success(fullSummary.toString())
                    }
            } catch (e: Exception) {
                _uiState.value = SummarizationState.Error("Unexpected error: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        summarizationJob?.cancel()
    }
}
