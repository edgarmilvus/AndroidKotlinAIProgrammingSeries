
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Define a context for AI operations using Context Receivers
// This allows any function with this context to access AI capabilities
interface AIContext {
    suspend fun generateResponse(prompt: String): Flow<String>
}

// 2. The actual implementation interacting with AICore
@Singleton
class GeminiNanoClient @Inject constructor() : AIContext {
    
    // In a real scenario, this would be the MediaPipe/AICore wrapper
    override suspend fun generateResponse(prompt: String): Flow<String> = flow {
        // Simulate the token streaming process from AICore
        val simulatedResponse = "This is a streamed response from Gemini Nano."
        simulatedResponse.split(" ").forEach { token ->
            kotlinx.coroutines.delay(100) // Simulate NPU inference latency
            emit("$token ")
        }
    }
}

// 3. A Use Case that leverages the AIContext
class SummarizeTextUseCase @Inject constructor() {
    
    // Using context receiver: this function can only be called 
    // within a scope that provides AIContext
    context(AIContext)
    suspend fun execute(text: String): Flow<String> {
        val prompt = "Summarize the following text concisely: $text"
        return generateResponse(prompt)
    }
}

// 4. ViewModel integration using Hilt and StateFlow
@kotlinx.coroutines.experimental.ExperimentalCoroutinesApi
class AIViewModel @Inject constructor(
    private val summarizeUseCase: SummarizeTextUseCase,
    private val aiClient: GeminiNanoClient // Provided as the AIContext
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow("")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    fun onSummarizeClicked(input: String) {
        androidx.lifecycle.viewModelScope.launch {
            // We wrap the call to provide the required AIContext
            with(aiClient) {
                summarizeUseCase.execute(input)
                    .collect { token ->
                        _uiState.update { it + token }
                    }
            }
        }
    }
}
