
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Context Definition: Using Context Receivers to provide AI capabilities
// This ensures that any function calling 'generateResponse' has access to the AIContext
interface AIContext {
    val modelInstance: GenerativeModel
    val vectorStore: LocalVectorStore
}

@Serializable
data class ResearchSnippet(
    val content: String,
    val source: String,
    val score: Float
)

@Singleton
class ResearchAssistantOrchestrator @Inject constructor(
    private val aiCoreClient: AICoreClient // Wrapper around Google's AICore SDK
) {
    /**
     * The core RAG pipeline.
     * We use a Flow to stream the response back to the UI, 
     * mirroring the asynchronous nature of LLM token generation.
     */
    context(AIContext)
    fun askResearchQuestion(query: String): Flow<String> = flow {
        // Step 1: Embedding & Retrieval
        // Analogy: Like a Room query, we fetch the most relevant 'rows' of knowledge
        val relevantDocs = vectorStore.searchSimilar(query, limit = 3)
        
        // Step 2: Prompt Augmentation
        val augmentedPrompt = buildAugmentedPrompt(query, relevantDocs)
        
        // Step 3: Generation via Gemini Nano
        // We stream the response to avoid UI blocking and reduce perceived latency
        modelInstance.generateContentStream(augmentedPrompt)
            .collect { chunk ->
                emit(chunk.text ?: "")
            }
    }

    private fun buildAugmentedPrompt(query: String, docs: List<ResearchSnippet>): String {
        val contextBlock = docs.joinToString("\n\n") { 
            "Source [${it.source}]: ${it.content}" 
        }
        return """
            You are a Private Research Assistant. Use the following local context to answer the query.
            If the answer is not in the context, state that you don't have enough local information.
            
            Context:
            $contextBlock
            
            User Query: $query
            Answer:
        """.trimIndent()
    }
}

// Mocking the Vector Store for theoretical completeness
interface LocalVectorStore {
    suspend fun searchSimilar(query: String, limit: Int): List<ResearchSnippet>
}

// Example of how the ViewModel would trigger this using Hilt and a provided context
// Note: Context receivers are currently in Beta/Experimental in Kotlin 2.x
class ResearchViewModel @Inject constructor(
    private val orchestrator: ResearchAssistantOrchestrator,
    private val aiContext: AIContext // Provided via Hilt
) : ViewModel() {
    
    private val _uiState = MutableStateFlow<String>("")
    val uiState = _uiState.asStateFlow()

    fun onQuerySubmitted(query: String) {
        viewModelScope.launch {
            // We execute the orchestrator function within the required AIContext
            with(aiContext) {
                orchestrator.askResearchQuestion(query)
                    .collect { token ->
                        _uiState.update { it + token }
                    }
            }
        }
    }
}
