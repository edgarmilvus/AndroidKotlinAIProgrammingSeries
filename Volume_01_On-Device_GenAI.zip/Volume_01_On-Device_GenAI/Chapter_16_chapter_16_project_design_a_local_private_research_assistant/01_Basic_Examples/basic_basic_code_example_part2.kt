
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.researchassistant.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * LlmInferenceManager handles the low-level interaction with the MediaPipe GenAI SDK.
 * It is marked as @Singleton because loading an LLM into memory is extremely expensive;
 * we must avoid re-initializing the model on every request.
 */
@Singleton
class LlmInferenceManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    init {
        setupModel()
    }

    private fun setupModel() {
        // The path to the model file on the device's internal storage.
        // In a production app, you would check if the file exists and download it if not.
        val modelPath = "${context.filesDir}/model.bin"

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024) // Limit response length to prevent memory overflow
            .setTopK(40)        // Diversifies the output
            .setTemperature(0.7f) // Balance between randomness and determinism
            .build()

        try {
            llmInference = LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            // Log error: Model file might be missing or incompatible with hardware
            e.printStackTrace()
        }
    }

    /**
     * Generates a response based on the provided prompt.
     * This is a blocking call, so it MUST be called from a background thread.
     */
    fun generateResponse(prompt: String): String {
        val inference = llmInference ?: return "Error: Model not initialized."
        return try {
            // generateResponse is a synchronous call that blocks the thread
            inference.generateResponse(prompt)
        } catch (e: Exception) {
            "Inference failed: ${e.localizedMessage}"
        }
    }

    /**
     * Resource cleanup to prevent memory leaks.
     */
    fun close() {
        llmInference?.close()
        llmInference = null
    }
}
