
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.*

// 1. Persona Definition
sealed class ResearchPersona(val name: String, val systemInstruction: String, val suggestedStarter: String) {
    object SkepticalPeerReviewer : ResearchPersona(
        "Skeptical Peer Reviewer",
        "You are a rigorous academic reviewer. Challenge assumptions, demand evidence, and point out logical fallacies in the following text: {{user_query}}",
        "Review this hypothesis for flaws..."
    )
    object ExecutiveSummarizer : ResearchPersona(
        "Executive Summarizer",
        "You are a C-suite assistant. Distill the following information into three high-impact bullet points focusing on ROI and risk: {{user_query}}",
        "Summarize this report for the CEO..."
    )
    object CreativeBrainstormer : ResearchPersona(
        "Creative Brainstormer",
        "You are an innovative strategist. Expand the following idea into five wild, non-obvious directions: {{user_query}}",
        "Brainstorm new uses for this technology..."
    )
}

// 2. Template Resolver
@Singleton
class PromptTemplateResolver @Inject constructor() {
    fun resolve(persona: ResearchPersona, query: String, context: String = ""): String {
        return persona.systemInstruction
            .replace("{{user_query}}", query)
            .replace("{{context}}", context)
    }
}

// 3. Hilt Module
@Module
@InstallIn(SingletonComponent::class)
object PromptModule {
    @Provides
    @Singleton
    fun provideTemplateResolver(): PromptTemplateResolver = PromptTemplateResolver()
}

// 4. ViewModel & Compose Integration
@HiltViewModel
class ResearchViewModel @Inject constructor(
    private val templateResolver: PromptTemplateResolver
) : ViewModel() {
    private val _currentPersona = MutableStateFlow<ResearchPersona>(ResearchPersona.ExecutiveSummarizer)
    val currentPersona: StateFlow<ResearchPersona> = _currentPersona.asStateFlow()

    fun setPersona(persona: ResearchPersona) {
        _currentPersona.value = persona
    }

    fun preparePrompt(userInput: String): String {
        return templateResolver.resolve(_currentPersona.value, userInput)
    }
}
