
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlin.math.sqrt

class ResearchRetriever(private val textEmbedder: TextEmbedder) {
    private val documentStore = mutableListOf<DocumentChunk>()
    private val invertedIndex = mutableMapOf<String, MutableList<Int>>()

    data class DocumentChunk(val id: Int, val text: String, val embedding: FloatArray)

    fun addDocument(text: String) {
        val id = documentStore.size
        val embedding = textEmbedder.embed(text) // MediaPipe call
        documentStore.add(DocumentChunk(id, text, embedding))
        
        // Build Inverted Index
        text.lowercase().split(Regex("\\W+")).forEach { word ->
            if (word.length > 3) {
                invertedIndex.getOrPut(word) { mutableListOf() }.add(id)
            }
        }
    }

    fun retrieve(query: String): List<String> {
        val queryEmbedding = textEmbedder.embed(query)
        val queryWords = query.lowercase().split(Regex("\\W+"))
        
        val scores = mutableMapOf<Int, Double>()

        // 1. Keyword Scoring (Simple frequency)
        queryWords.forEach { word ->
            invertedIndex[word]?.forEach { docId ->
                scores[docId] = scores.getOrDefault(docId, 0.0) + 1.0
            }
        }

        // 2. Semantic Scoring (Cosine Similarity)
        documentStore.forEach { chunk ->
            val similarity = cosineSimilarity(queryEmbedding, chunk.embedding)
            scores[chunk.id] = scores.getOrDefault(chunk.id, 0.0) + (similarity * 2.0) // Weight semantic higher
        }

        // 3. Rerank and return top 3
        return scores.entries
            .sortedByDescending { it.value }
            .take(3)
            .map { documentStore[it.key].text }
    }

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Double {
        var dotProduct = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}
