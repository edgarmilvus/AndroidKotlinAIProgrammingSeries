
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.app.ActivityManager
import android.content.Context

data class ChatMessage(val role: String, val content: String)

class ConversationBuffer(
    private val context: Context,
    private val maxTokens: Int = 4096
) {
    private val history = mutableListOf<ChatMessage>()
    private var systemPrompt: String = "You are a helpful research assistant."

    // Heuristic: 1 token approx 4 characters
    private fun estimateTokens(text: String): Int = text.length / 4

    fun addMessage(role: String, content: String) {
        history.add(ChatMessage(role, content))
        manageWindow()
    }

    private fun manageWindow() {
        var currentTokens = estimateTokens(systemPrompt) + 
                           history.sumOf { estimateTokens(it.content) }

        if (currentTokens > maxTokens) {
            // 1. Memory Pressure Check
            val adjustedMax = getDynamicMaxTokens()
            if (currentTokens > adjustedMax) {
                summarizeOldMessages()
            } else {
                pruneOldest()
            }
        }
    }

    private fun pruneOldest() {
        // Keep system prompt and most recent 5 messages
        if (history.size > 10) {
            val recent = history.takeLast(5)
            history.clear()
            history.addAll(recent)
        }
    }

    private fun summarizeOldMessages() {
        // Recursive Summarization Logic
        val toSummarize = history.take(history.size / 2)
        val summaryText = "Summary of previous talk: ${toSummarize.joinToString { it.content }}" 
        // In reality, call Gemini Nano here to summarize
        
        history.clear()
        history.add(ChatMessage("system", summaryText))
        history.addAll(history.drop(history.size / 2))
    }

    private fun getDynamicMaxTokens(): Int {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        return if (memoryInfo.lowMemory) maxTokens / 2 else maxTokens
    }

    fun getFinalPrompt(): String {
        return "$systemPrompt\n" + history.joinToString("\n") { "${it.role}: ${it.content}" }
    }
}
