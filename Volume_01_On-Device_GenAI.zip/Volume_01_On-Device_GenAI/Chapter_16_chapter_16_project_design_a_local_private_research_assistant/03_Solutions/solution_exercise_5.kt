
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.flow.*

// 1. AI Gateway Interface
interface GenAiProvider {
    fun generateResponse(prompt: String): Flow<String>
}

class LocalGenAiProvider : GenAiProvider {
    override fun generateResponse(prompt: String): Flow<String> = flow {
        emit("Local Nano: Processing privately... ")
        // AICore implementation here
    }
}

class CloudGenAiProvider : GenAiProvider {
    override fun generateResponse(prompt: String): Flow<String> = flow {
        emit("Cloud Pro: Processing with high reasoning... ")
        // Google AI SDK implementation here
    }
}

// 2. Router/Orchestrator
class GenAiRouter(
    private val localProvider: LocalGenAiProvider,
    private val cloudProvider: CloudGenAiProvider,
    private val privacyLog: PrivacyLogDao
) {
    sealed class RoutingDecision {
        object UseLocal : RoutingDecision()
        object RequestCloudConsent : RoutingDecision()
    }

    fun determineRoute(query: String): RoutingDecision {
        val complexKeywords = listOf("analyze", "synthesize", "compare all", "deep dive")
        return if (complexKeywords.any { query.contains(it, ignoreCase = true) }) {
            RoutingDecision.RequestCloudConsent
        } else {
            RoutingDecision.UseLocal
        }
    }

    suspend fun execute(query: String, userConsented: Boolean = false): Flow<String> {
        return if (userConsented) {
            privacyLog.logCloudAccess(query)
            cloudProvider.generateResponse(query)
        } else {
            localProvider.generateResponse(query)
        }
    }
}

// 3. Privacy Audit Log (Room)
@Entity(tableName = "privacy_logs")
data class PrivacyLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val prompt: String
)

@Dao
interface PrivacyLogDao {
    @Insert
    suspend fun logCloudAccess(prompt: String)
}
