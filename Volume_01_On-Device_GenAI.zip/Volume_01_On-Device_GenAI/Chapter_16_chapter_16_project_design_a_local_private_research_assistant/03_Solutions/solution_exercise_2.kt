
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.room.*
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlin.math.sqrt

// 1. Room Entity and TypeConverter
@Entity(tableName = "document_chunks")
data class TextChunk(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val embedding: FloatArray
)

class VectorConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String = value.joinToString(",")
    @TypeConverter
    fun toFloatArray(value: String): FloatArray = value.split(",").map { it.toFloat() }.toFloatArray()
}

@Dao
interface ChunkDao {
    @Insert
    suspend fun insertChunks(chunks: List<TextChunk>)
    @Query("SELECT * FROM document_chunks")
    suspend fun getAllChunks(): List<TextChunk>
}

// 2. RAG Service
class LocalRAGService(private val chunkDao: ChunkDao, private val textEmbedder: TextEmbedder) {
    
    suspend fun indexDocument(text: String) {
        val chunks = text.chunked(500, 50) // 500 chars with 50 overlap
        val processedChunks = chunks.map { content ->
            val vector = textEmbedder.embed(content) // MediaPipe embedding
            TextChunk(text = content, embedding = vector)
        }
        chunkDao.insertChunks(processedChunks)
    }

    suspend fun retrieveContext(query: String, topK: Int = 3): String {
        val queryVector = textEmbedder.embed(query)
        val allChunks = chunkDao.getAllChunks()
        
        return allChunks
            .map { it to cosineSimilarity(queryVector, it.embedding) }
            .sortedByDescending { it.second }
            .take(topK)
            .joinToString("\n") { it.first.text }
    }

    private fun cosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        var dotProduct = 0f
        var normA = 0f
        var normB = 0f
        for (i in v1.indices) {
            dotProduct += v1[i] * v2[i]
            normA += v1[i] * v1[i]
            normB += v2[i] * v2[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}
