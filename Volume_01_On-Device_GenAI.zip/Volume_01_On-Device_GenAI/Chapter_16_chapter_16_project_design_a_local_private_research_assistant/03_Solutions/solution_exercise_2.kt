
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

class DocumentProcessor(
    private val maxChunkSize: Int = 1000, 
    private val overlapPercentage: Double = 0.15
) {
    fun processDocument(text: String): List<String> {
        val chunks = mutableListOf<String>()
        var remainingText = text

        while (remainingText.isNotEmpty()) {
            val chunk = splitRecursively(remainingText)
            chunks.add(chunk)
            
            // Calculate overlap size
            val overlapSize = (chunk.length * overlapPercentage).toInt()
            
            // Move the pointer back by the overlap amount to maintain context
            val nextStartIndex = (remainingText.length - (remainingText.length - chunk.length)) + (chunk.length - overlapSize)
            
            if (nextStartIndex >= remainingText.length || chunk.length == remainingText.length) break
            remainingText = remainingText.substring(nextStartIndex)
        }
        return chunks
    }

    private fun splitRecursively(text: String): String {
        if (text.length <= maxChunkSize) return text

        // 1. Try splitting by paragraphs
        val paragraphs = text.split("\n\n")
        if (paragraphs.size > 1) {
            return findBestFit(paragraphs)
        }

        // 2. Try splitting by sentences
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        if (sentences.size > 1) {
            return findBestFit(sentences)
        }

        // 3. Fallback to word splitting
        val words = text.split(" ")
        return findBestFit(words)
    }

    private fun findBestFit(parts: List<String>): String {
        var currentChunk = StringBuilder()
        for (part in parts) {
            if (currentChunk.length + part.length <= maxChunkSize) {
                currentChunk.append(part).append(" ")
            } else {
                break
            }
        }
        return currentChunk.toString().trim()
    }

    fun estimateTokens(text: String): Int {
        val wordCount = text.split(Regex("\\s+")).size
        return (wordCount * 1.3).toInt()
    }
}
