
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class Message(val text: String, val isUser: Boolean, val isStreaming: Boolean = false)

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    fun sendMessage(query: String, repository: ChatRepository) {
        viewModelScope.launch {
            // Add user message
            _messages.value += Message(query, isUser = true)
            
            // Add empty assistant message to start streaming
            val assistantMsgIndex = _messages.value.size
            _messages.value += Message("", isUser = false, isStreaming = true)

            repository.streamResponse(query).collect { token ->
                updateLastMessage(token)
            }
            
            // Mark as finished
            finalizeStream()
        }
    }

    private fun updateLastMessage(newToken: String) {
        val currentList = _messages.value.toMutableList()
        val lastMsg = currentList.last()
        currentList[currentList.size - 1] = lastMsg.copy(text = lastMsg.text + newToken)
        _messages.value = currentList
    }

    private fun finalizeStream() {
        val currentList = _messages.value.toMutableList()
        val lastMsg = currentList.last()
        currentList[currentList.size - 1] = lastMsg.copy(isStreaming = false)
        _messages.value = currentList
    }
}

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()

    LazyColumn {
        itemsIndexed(messages) { index, message ->
            // Optimization: Only the last message is likely streaming
            val isLast = index == messages.size - 1
            ChatBubble(message = message, isStreaming = isLast && message.isStreaming)
        }
    }
}

@Composable
fun ChatBubble(message: Message, isStreaming: Boolean) {
    Text(
        text = message.text,
        modifier = Modifier.padding(8.dp),
        // In a real app, use a Markdown library here
        style = MaterialTheme.typography.bodyMedium
    )
}
