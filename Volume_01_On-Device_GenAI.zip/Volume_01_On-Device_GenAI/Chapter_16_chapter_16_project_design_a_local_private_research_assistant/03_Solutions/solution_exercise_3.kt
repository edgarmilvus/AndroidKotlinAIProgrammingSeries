
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import dagger.hilt.android.AndroidEntryPoint

data class ChatMessage(val role: Role, val content: String) {
    enum class Role { USER, ASSISTANT }
}

@Singleton
class ConversationManager @Inject constructor(
    private val aiCoreWrapper: AICoreWrapper // Mock of the actual Gemini Nano interface
) {
    private val windowSize = 5
    private val history = mutableListOf<ChatMessage>()
    private var memoryBlock = ""
    private val mutex = Mutex()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    suspend fun addMessage(message: ChatMessage) = mutex.withLock {
        history.add(message)
        if (history.size > windowSize) {
            triggerSummarization()
        }
    }

    private fun triggerSummarization() {
        scope.launch {
            mutex.withLock {
                // Take the oldest messages that are outside the window
                val toSummarize = history.take(history.size - windowSize)
                val summaryText = summarizeWithNano(toSummarize)
                
                // Update the persistent memory block
                memoryBlock = if (memoryBlock.isEmpty()) summaryText 
                               else "Previous context: $memoryBlock. New context: $summaryText"
                
                // Remove summarized messages from active history
                val remaining = history.takeLast(windowSize).toMutableList()
                history.clear()
                history.addAll(remaining)
            }
        }
    }

    private suspend fun summarizeWithNano(messages: List<ChatMessage>): String {
        val textToSummarize = messages.joinToString("\n") { "${it.role}: ${it.content}" }
        return aiCoreWrapper.generateResponse("Summarize the following conversation concisely: $textToSummarize")
    }

    suspend fun getFullContextPrompt(currentQuery: String): String = mutex.withLock {
        val historyString = history.joinToString("\n") { "${it.role}: ${it.content}" }
        return buildString {
            if (memoryBlock.isNotEmpty()) appendLine("### Long-term Memory ###\n$memoryBlock\n")
            appendLine("### Recent Conversation ###\n$historyString\n")
            appendLine("### Current Query ###\n$currentQuery")
        }
    }
}

// Interface for AI interaction
interface AICoreWrapper {
    suspend fun generateResponse(prompt: String): String
}
