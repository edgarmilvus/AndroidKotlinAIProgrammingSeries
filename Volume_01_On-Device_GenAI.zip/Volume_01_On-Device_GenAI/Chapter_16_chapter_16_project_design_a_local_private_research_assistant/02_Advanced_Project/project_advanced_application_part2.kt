
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.research.assistant.ai

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the UI State of the Research Assistant.
 * Using a Sealed Class to ensure exhaustive state handling in Compose.
 */
sealed class ResearchUiState {
    object Idle : ResearchUiState()
    object Processing : ResearchUiState()
    data class Success(val response: String) : ResearchUiState()
    data class Error(val message: String) : ResearchUiState()
}

/**
 * Repository handling the heavy lifting of LLM orchestration.
 * This class is a Singleton to prevent reloading the model into VRAM/NPU memory multiple times.
 */
@Singleton
class LocalResearchRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with hardware-specific options
    suspend fun initializeModel() = withContext(Dispatchers.Default) {
        if (llmInference != null) return@withContext

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to local model
            .setMaxTokens(1024)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Executes a RAG-style query. 
     * @param contextText The retrieved relevant chunks from the local database.
     * @param query The user's specific question.
     */
    suspend fun generateResponse(contextText: String, query: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // Construct a Prompt Template for the Research Assistant
        val prompt = """
            You are a Private Research Assistant. Use the following context to answer the question.
            If the answer is not in the context, state that you don't know.
            
            CONTEXT:
            $contextText
            
            QUESTION: 
            $query
            
            ANSWER:
        """.trimIndent()

        // Use generateResponse (streaming) to provide a better UX
        // Dispatchers.Default is critical here as LlmInference blocks the calling thread
        withContext(Dispatchers.Default) {
            engine.generateResponseAsync(prompt)
                .collect { partialResponse ->
                    emit(partialResponse)
                }
        }
    }.flowOn(Dispatchers.Default)
}

@HiltViewModel
class ResearchAssistantViewModel @Inject constructor(
    private val repository: LocalResearchRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ResearchUiState>(ResearchUiState.Idle)
    val uiState: StateFlow<ResearchUiState> = _uiState.asStateFlow()

    private var inferenceJob: Job? = null

    fun askResearchQuestion(query: String, localDocs: List<String>) {
        // Cancel any existing inference to free up NPU resources immediately
        inferenceJob?.cancel()

        inferenceJob = viewModelScope.launch {
            _uiState.value = ResearchUiState.Processing
            
            try {
                // 1. Ensure model is loaded into memory
                repository.initializeModel()

                // 2. Simulate RAG: Chunking and selecting top-k relevant documents
                // In a real app, this would be a Vector Database lookup (e.g., ObjectBox or Room)
                val relevantContext = localDocs.take(3).joinToString("\n---\n")

                // 3. Stream the response from the LLM
                var fullResponse = ""
                repository.generateResponse(relevantContext, query)
                    .catch { e -> 
                        _uiState.value = ResearchUiState.Error("Inference failed: ${e.localizedMessage}") 
                    }
                    .collect { chunk ->
                        fullResponse += chunk
                        _uiState.value = ResearchUiState.Success(fullResponse)
                    }

            } catch (e: Exception) {
                _uiState.value = ResearchUiState.Error("Critical error: ${e.localizedMessage}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Ensure resources are cleaned up when ViewModel is destroyed
        inferenceJob?.cancel()
    }
}
