
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.research.assistant.core

import android.content.Context
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ActivityRetainedScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as InjectDagger
import javax.inject.Singleton

/**
 * Hardware-aware Configuration for AI Models.
 * Determines whether to use NPU, GPU, or CPU based on device capabilities.
 */
enum class ComputeDelegate {
    NPU, GPU, CPU
}

/**
 * State representing the Research Assistant's UI.
 */
data class ResearchUiState(
    val query: String = "",
    val response: String = "",
    val isProcessing: Boolean = false,
    val error: String? = null,
    val activeDelegate: ComputeDelegate = ComputeDelegate.CPU
)

/**
 * Sealed class for MVI Intents.
 */
sealed class ResearchIntent {
    data class UpdateQuery(val query: String) : ResearchIntent()
    object SubmitQuery : ResearchIntent()
    object ClearResearch : ResearchIntent()
}

/**
 * Repository responsible for the RAG (Retrieval Augmented Generation) pipeline.
 * It orchestrates the flow between the Vector Store and Gemini Nano.
 */
@Singleton
class ResearchRepository @InjectDagger constructor(
    @ApplicationContext private val context: Context
) {
    private val TAG = "ResearchRepo"
    
    // In a real app, these would be wrapped in a dedicated ModelManager
    private var geminiNano: GenerativeModel? = null 
    private var embeddingModel: TextEmbedder? = null

    init {
        initializeModels()
    }

    private fun initializeModels() {
        // Logic to initialize Gemini Nano via AICore and MediaPipe TextEmbedder
        // This is where hardware acceleration (GPU/NPU) is configured
        Log.d(TAG, "Initializing AI Models with NPU acceleration...")
    }

    /**
     * The core RAG pipeline: 
     * 1. Embed query -> 2. Search Local Docs -> 3. Prompt Gemini Nano
     */
    fun synthesizeAnswer(query: String): Flow<String> = flow {
        emit("Searching local documents...")
        
        // Step 1: Generate embedding for the query using TFLite (CPU/GPU)
        val queryVector = withContext(Dispatchers.Default) {
            generateEmbedding(query)
        }

        // Step 2: Semantic search in local vector store
        val contextChunks = withContext(Dispatchers.IO) {
            performVectorSearch(queryVector)
        }

        // Step 3: Construct Augmented Prompt
        val augmentedPrompt = """
            You are a Private Research Assistant. Use the following local context to answer the query.
            If the answer is not in the context, state that you don't know.
            
            CONTEXT:
            $contextChunks
            
            QUERY:
            $query
            
            ANSWER:
        """.trimIndent()

        emit("Synthesizing answer...")

        // Step 4: Stream response from Gemini Nano
        geminiNano?.generateContentStream(augmentedPrompt)?.collect { chunk ->
            emit(chunk.text ?: "")
        } ?: throw Exception("Gemini Nano not initialized")
        
    }.flowOn(Dispatchers.Default)

    private fun generateEmbedding(text: String): FloatArray {
        // Simulated TFLite embedding logic
        return FloatArray(768) { 0.1f } 
    }

    private fun performVectorSearch(vector: FloatArray): String {
        // Simulated Cosine Similarity search in a local Room/SQLite DB
        return "Found relevant section in 'Project_X_Specs.pdf': The system uses a 12V rail."
    }
}

/**
 * ViewModel implementing MVI pattern to manage the AI lifecycle.
 */
@HiltViewModel
class ResearchViewModel @InjectDagger constructor(
    private val repository: ResearchRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ResearchUiState())
    val uiState: StateFlow<ResearchUiState> = _uiState.asStateFlow()

    /**
     * Handles user intents using structured concurrency.
     * Ensures that if the ViewModel is cleared, the AI inference stops immediately.
     */
    fun handleIntent(intent: ResearchIntent) {
        when (intent) {
            is ResearchIntent.UpdateQuery -> {
                _uiState.update { it.copy(query = intent.query) }
            }
            is ResearchIntent.SubmitQuery -> {
                processResearchQuery()
            }
            is ResearchIntent.ClearResearch -> {
                _uiState.update { ResearchUiState() }
            }
        }
    }

    private fun processResearchQuery() {
        val currentQuery = _uiState.value.query
        if (currentQuery.isBlank()) return

        _uiState.update { it.copy(isProcessing = true, response = "", error = null) }

        // Launching in viewModelScope ensures the job is cancelled on ViewModel clear
        viewModelScope.launch {
            try {
                repository.synthesizeAnswer(currentQuery)
                    .catch { e -> 
                        _uiState.update { it.copy(error = e.message, isProcessing = false) } 
                    }
                    .collect { partialResponse ->
                        _uiState.update { it.copy(response = it.response + partialResponse) }
                    }
            } finally {
                _uiState.update { it.copy(isProcessing = false) }
            }
        }
    }
}
