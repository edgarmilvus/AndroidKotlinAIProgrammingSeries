
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import java.io.File

// 1. Template Engine
sealed class PromptTemplate {
    abstract fun format(instruction: String, input: String, response: String): String

    object InstructionFormat : PromptTemplate() {
        override fun format(instruction: String, input: String, response: String) =
            "Instruction: $instruction\nInput: $input\nResponse: $response"
    }

    object ChatFormat : PromptTemplate() {
        override fun format(instruction: String, input: String, response: String) =
            "User: $instruction $input\nAssistant: $response"
    }
}

// 2. Data Sanitization
object DataSanitizer {
    private val EMAIL_REGEX = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
    private val PHONE_REGEX = Regex("\\b\\d{10,12}\\b")

    fun sanitize(text: String): String {
        return text.replace(EMAIL_REGEX, "[EMAIL]")
                   .replace(PHONE_REGEX, "[PHONE]")
    }
}

// 3. Validation Logic
class DatasetValidator(private val maxTokens: Int = 2048) {
    fun isValid(text: String): Boolean {
        // Simplified tokenization (1 word approx 1.3 tokens)
        val estimatedTokens = text.split(" ").size * 1.3
        return estimatedTokens <= maxTokens
    }

    fun truncate(text: String): String {
        return text.take(maxTokens * 4) // Rough character approximation
    }
}

// 4. Export Utility
class LoRADataPipeline(private val template: PromptTemplate) {
    private val validator = DatasetValidator()

    fun processAndExport(rawData: List<RawInteraction>, outputFile: File) {
        outputFile.bufferedWriter().use { writer ->
            rawData.forEach { item ->
                val cleanInstruction = DataSanitizer.sanitize(item.instruction)
                val cleanInput = DataSanitizer.sanitize(item.input)
                val cleanResponse = DataSanitizer.sanitize(item.response)

                val formatted = template.format(cleanInstruction, cleanInput, cleanResponse)

                if (validator.isValid(formatted)) {
                    writer.write("\"$formatted\"\n")
                } else {
                    writer.write("\"${validator.truncate(formatted)}\"\n")
                }
            }
        }
    }
}

data class RawInteraction(val instruction: String, val input: String, val response: String)
