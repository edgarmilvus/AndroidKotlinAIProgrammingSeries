
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext

sealed class BrandPersona(val adapterFileName: String, val systemPrompt: String) {
    object Corporate : BrandPersona("corp_lora.bin", "You are a professional corporate executive. Use formal language.")
    object Trendy : BrandPersona("genz_lora.bin", "You are a Gen-Z social media expert. Use slang and emojis.")
    object Luxury : BrandPersona("luxury_lora.bin", "You are a high-end luxury concierge. Be elegant and exclusive.")
}

@HiltViewModel
class PersonaViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val adapterManager: LoRAAdapterManager
) : ViewModel() {

    private val _currentPersona = MutableStateFlow<BrandPersona>(BrandPersona.Corporate)
    val currentPersona: StateFlow<BrandPersona> = _currentPersona

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var llmInference: LlmInference? = null

    fun switchPersona(persona: BrandPersona) {
        viewModelScope.launch {
            _isLoading.value = true
            _currentPersona.value = persona
            
            // Async swap using Default dispatcher to avoid UI stutter
            withContext(Dispatchers.Default) {
                llmInference?.close()
                val adapterPath = adapterManager.prepareAdapter(persona.adapterFileName)
                
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath("/data/local/tmp/base_model.bin")
                    .setLoraPath(adapterPath)
                    .build()
                
                llmInference = LlmInference.createFromOptions(context, options)
            }
            _isLoading.value = false
        }
    }

    fun generateCopy(userPrompt: String): String {
        val persona = _currentPersona.value
        val augmentedPrompt = "${persona.systemPrompt}\n\nUser Request: $userPrompt"
        return llmInference?.generateResponse(augmentedPrompt) ?: "Model loading..."
    }

    override fun onCleared() {
        super.onCleared()
        llmInference?.close()
    }
}
