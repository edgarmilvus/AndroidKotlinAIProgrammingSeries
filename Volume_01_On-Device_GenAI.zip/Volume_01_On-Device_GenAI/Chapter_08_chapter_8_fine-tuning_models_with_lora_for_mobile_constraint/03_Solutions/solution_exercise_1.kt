
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.os.FileUtils
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton
import java.io.File

@Singleton
class LoRAAdapterManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // Moves adapter from assets to internal storage for Mmap efficiency
    suspend fun prepareAdapter(fileName: String): String = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, fileName)
        if (!targetFile.exists()) {
            context.assets.open(fileName).use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
        }
        targetFile.absolutePath
    }
}

@ViewModelScoped
class MedicalInferenceEngine @Inject constructor(
    private val adapterManager: LoRAAdapterManager,
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null
    private val baseModelPath = "/data/local/tmp/base_model.bin" // Example path
    private val medicalAdapterPath = "med_lora.bin"

    suspend fun initialize(useSpecialistMode: Boolean) = withContext(Dispatchers.Default) {
        // Close existing instance to free memory and avoid leaks
        llmInference?.close()

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(baseModelPath)
            .apply {
                if (useSpecialistMode) {
                    val path = adapterManager.prepareAdapter(medicalAdapterPath)
                    // MediaPipe LoRA configuration
                    setLoraPath(path) 
                }
            }
            .build()
        
        llmInference = LlmInference.createFromOptions(context, options)
    }

    fun generateResponse(prompt: String): String {
        return llmInference?.generateResponse(prompt) ?: "Model not initialized"
    }

    fun release() {
        llmInference?.close()
        llmInference = null
    }
}

@HiltViewModel
class MedicalChatViewModel @Inject constructor(
    private val engine: MedicalInferenceEngine
) : ViewModel() {
    private val _isSpecialistMode = MutableStateFlow(false)
    val isSpecialistMode: StateFlow<Boolean> = _isSpecialistMode

    private val _uiState = MutableStateFlow("Ready")
    val uiState: StateFlow<String> = _uiState

    fun toggleSpecialistMode() {
        viewModelScope.launch {
            _isSpecialistMode.value = !_isSpecialistMode.value
            _uiState.value = "Loading Adapter..."
            try {
                engine.initialize(_isSpecialistMode.value)
                _uiState.value = "Ready"
            } catch (e: Exception) {
                _uiState.value = "Error loading model: ${e.message}"
            }
        }
    }

    fun sendPrompt(prompt: String): String = engine.generateResponse(prompt)

    override fun onCleared() {
        super.onCleared()
        engine.release()
    }
}
