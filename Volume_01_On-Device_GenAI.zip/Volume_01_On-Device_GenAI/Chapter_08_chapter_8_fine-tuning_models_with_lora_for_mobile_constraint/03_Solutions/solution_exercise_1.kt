
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.dagger.hilt.android.qualifiers.ApplicationContext
import com.google.dagger.hilt.android.inject.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// 1. Adapter Registry
enum class Persona(val fileName: String) {
    PROFESSIONAL("professional.tflite"),
    CREATIVE("creative.tflite")
}

class LoRAAdapterRegistry @Inject constructor(@ApplicationContext private val context: Context) {
    fun getAdapterPath(persona: Persona): String {
        return "${context.filesDir}/adapters/${persona.fileName}"
    }
}

// 2. Model Manager (MediaPipe Wrapper)
@Singleton
class ModelManager @Inject constructor(
    private val registry: LoRAAdapterRegistry
) {
    // Simulated MediaPipe LlmInference instance
    private var llmInference: Any? = null 

    suspend fun swapAdapter(persona: Persona) = withContext(Dispatchers.Default) {
        val path = registry.getAdapterPath(persona)
        // In a real MediaPipe implementation, you would call:
        // llmInference?.setLoraAdapter(path) 
        // Simulating the weight mapping latency
        kotlinx.coroutines.delay(300) 
        println("Successfully mapped adapter from $path into memory")
    }
}

// 3. ViewModel for State Management
@HiltViewModel
class PersonaViewModel @Inject constructor(
    private val modelManager: ModelManager
) : ViewModel() {
    private val _currentPersona = MutableStateFlow(Persona.PROFESSIONAL)
    val currentPersona: StateFlow<Persona> = _currentPersona.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun switchPersona(persona: Persona) {
        viewModelScope.launch {
            _isLoading.value = true
            modelManager.swapAdapter(persona)
            _currentPersona.value = persona
            _isLoading.value = false
        }
    }
}

// 4. UI Integration (Jetpack Compose)
@AndroidEntryPoint
class PersonaActivity : androidx.activity.ComponentActivity() {
    // ... onCreate implementation ...
}

@androidx.compose.runtime.Composable
fun PersonaScreen(viewModel: PersonaViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val persona by viewModel.currentPersona.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    androidx.compose.material3.Column {
        if (isLoading) {
            androidx.compose.material3.CircularProgressIndicator()
        }
        androidx.compose.material3.Row {
            Persona.values().forEach { p ->
                androidx.compose.material3.FilterChip(
                    selected = (p == persona),
                    onClick = { viewModel.switchPersona(p) },
                    label = { androidx.compose.material3.Text(p.name) }
                )
            }
        }
    }
}
