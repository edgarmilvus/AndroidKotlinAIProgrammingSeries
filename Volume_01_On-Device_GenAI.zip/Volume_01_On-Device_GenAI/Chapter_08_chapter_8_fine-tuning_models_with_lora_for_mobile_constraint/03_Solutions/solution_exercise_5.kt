
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.nio.ByteBuffer
import javax.inject.Inject
import javax.inject.Singleton

enum class TaskType { TRANSLATE, SUMMARIZE, SENTIMENT, GENERAL }

@Singleton
class AdapterCache @Inject constructor(private val context: Context) {
    // Cache for the A and B matrices in native memory
    private val cache = mutableMapOf<TaskType, ByteBuffer>()

    suspend fun getAdapterBuffer(type: TaskType): ByteBuffer = withContext(Dispatchers.IO) {
        cache.getOrPut(type) {
            val file = context.assets.open("lora_${type.name.lowercase()}.bin")
            val bytes = file.readBytes()
            ByteBuffer.allocateDirect(bytes.size).apply {
                put(bytes)
                flip()
            }
        }
    }
}

@Singleton
class OmniRouter @Inject constructor(
    private val context: Context,
    private val cache: AdapterCache
) {
    private var llmInference: LlmInference? = null
    private val swapMutex = Mutex()

    // Lightweight intent classifier
    fun classifyIntent(text: String): TaskType {
        return when {
            text.contains("summarize", ignoreCase = true) -> TaskType.SUMMARIZE
            text.contains("translate", ignoreCase = true) -> TaskType.TRANSLATE
            text.contains("feel", ignoreCase = true) -> TaskType.SENTIMENT
            else -> TaskType.GENERAL
        }
    }

    suspend fun hotSwapAdapter(type: TaskType) = swapMutex.withLock {
        withContext(Dispatchers.Default) {
            val buffer = cache.getAdapterBuffer(type)
            
            // We don't close the base model, we only re-init the session 
            // with the new adapter buffer from the cache
            llmInference?.close()
            
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath("/data/local/tmp/base_model.bin")
                .setLoraBuffer(buffer) // Hypothetical API for direct buffer loading
                .build()
                
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    fun generate(prompt: String): String {
        return llmInference?.generateResponse(prompt) ?: "Routing..."
    }
}

// ViewModel integration with predictive loading
class OmniViewModel(private val router: OmniRouter) : ViewModel() {
    private var loadingJob: Job? = null

    fun onTextChanged(text: String) {
        val intent = router.classifyIntent(text)
        
        // Debounce: Only swap if intent is stable for 500ms
        loadingJob?.cancel()
        loadingJob = viewModelScope.launch {
            delay(500)
            router.hotSwapAdapter(intent)
        }
    }
}
