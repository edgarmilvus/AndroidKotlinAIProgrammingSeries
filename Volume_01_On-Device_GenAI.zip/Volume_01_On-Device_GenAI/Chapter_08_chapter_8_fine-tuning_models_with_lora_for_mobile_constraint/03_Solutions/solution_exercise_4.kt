
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import java.io.File

data class BenchmarkResult(
    val config: String,
    val ttft: Long,
    val tps: Double,
    val peakRss: Long
)

class AIBenchmarker(private val context: Context) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    suspend fun runBenchmark(
        configName: String, 
        prompts: List<String>, 
        inferenceCall: suspend (String) -> String
    ): BenchmarkResult {
        // 1. Warm-up phase
        repeat(2) { inferenceCall("Warm up prompt") }

        var totalTtft = 0L
        var totalTokens = 0
        var totalDuration = 0L

        prompts.forEach { prompt ->
            var firstTokenTime = 0L
            val startTime = System.nanoTime()
            
            // Simulated streaming response to capture TTFT
            val response = inferenceCall(prompt) { token ->
                if (firstTokenTime == 0L) {
                    firstTokenTime = System.nanoTime() - startTime
                }
            }
            
            val endTime = System.nanoTime()
            val durationMs = (endTime - startTime) / 1_000_000
            
            totalTtft += firstTokenTime / 1_000_000
            totalTokens += response.split(" ").size
            totalDuration += durationMs
        }

        val peakRss = getPeakRss()
        return BenchmarkResult(
            config = configName,
            ttft = totalTtft / prompts.size,
            tps = (totalTokens.toDouble() / prompts.size) / (totalDuration.toDouble() / prompts.size / 1000),
            peakRss = peakRss
        )
    }

    private fun getPeakRss(): Long {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return memInfo.availMem // Simplified; in real use, use Debug.MemoryInfo
    }

    fun exportToCsv(results: List<BenchmarkResult>, file: File) {
        file.bufferedWriter().use { out ->
            out.write("Config,TTFT_ms,TPS,PeakRSS_bytes\n")
            results.forEach { 
                out.write("${it.config},${it.ttft},${it.tps},${it.peakRss}\n") 
            }
        }
    }
}
