
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.system.measureTimeMillis

class ModelRepository @Inject constructor(
    private val modelManager: ModelManager
) {
    private val adapterCache = LruCache<String, Boolean>(2) // Cache for loaded state
    private val swapMutex = Mutex()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    suspend fun hotSwapAdapter(adapterId: String) {
        // Prevent race conditions if user navigates rapidly
        swapMutex.withLock {
            if (adapterCache.get(adapterId) == true) {
                Log.d("AI-104", "Adapter $adapterId restored from cache")
                return@withLock
            }

            val timeTaken = measureTimeMillis {
                modelManager.swapAdapter(adapterId)
            }
            
            Log.i("Telemetry", "Adapter $adapterId loaded in ${timeTaken}ms")
            adapterCache.put(adapterId, true)
        }
    }
}

class NavigationAdapterObserver(
    private val repository: ModelRepository,
    private val scope: CoroutineScope
) : androidx.lifecycle.LifecycleEventObserver {
    
    override fun onStateChanged(source: androidx.lifecycle.LifecycleOwner, event: androidx.lifecycle.Lifecycle.Event) {
        // Logic would be tied to Navigation Controller destination changes
        // This is a simplified simulation of the trigger
    }

    fun onDestinationChanged(destinationId: Int) {
        scope.launch {
            when (destinationId) {
                R.id.codeEditorFragment -> repository.hotSwapAdapter("coding-lora-v2")
                R.id.dashboardFragment -> repository.hotSwapAdapter("general-purpose")
            }
        }
    }
}
