
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LiteInferenceEngine @Inject constructor(
    @ApplicationContext private val context: Context
) : ComponentCallbacks2 {

    private var llmInference: LlmInference? = null
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun initializeModel(useGpu: Boolean) {
        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath("/data/local/tmp/int4_base.bin")
                .apply {
                    if (useGpu) {
                        // Attempt to enable GPU delegate for FP16 LoRA acceleration
                        setDelegate(LlmInference.Delegate.GPU)
                    }
                }
                .build()
            
            llmInference = LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e("LiteEngine", "GPU Delegate failed, falling back to CPU", e)
            initializeModel(useGpu = false) // Recursive fallback to CPU (XNNPACK)
        }
    }

    fun getMemoryMetrics(): MemoryStats {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return MemoryStats(
            availableRam = memInfo.availMem,
            lowMemory = memInfo.lowMemory,
            threshold = memInfo.threshold
        )
    }

    // Implementation of ComponentCallbacks2 for LMKD prevention
    override fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            Log.w("LiteEngine", "Critical memory pressure! Releasing LLM weights.")
            releaseResources()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}
    override fun onLowMemory() { releaseResources() }

    private fun releaseResources() {
        llmInference?.close()
        llmInference = null
        System.gc() // Suggest GC to reclaim native buffers
    }

    data class MemoryStats(val availableRam: Long, val lowMemory: Boolean, val threshold: Long)
}
