
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.lora.advanced

import android.content.Context
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as InjectHilt
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/**
 * Domain Model representing a LoRA Adapter.
 * In a real world app, these would be downloaded from a remote server.
 */
data class LoraAdapter(
    val id: String,
    val domain: String,
    val filePath: String,
    val rank: Int,
    val alpha: Float
)

/**
 * MVI State for the AI Assistant
 */
data class AssistantState(
    val currentAdapter: LoraAdapter? = null,
    val responseText: String = "",
    val isProcessing: Boolean = false,
    val error: String? = null
)

/**
 * MVI Intents to drive the logic
 */
sealed class AssistantIntent {
    data class SwitchAdapter(val adapter: LoraAdapter) : AssistantIntent()
    data class SendPrompt(val prompt: String) : AssistantIntent()
}

/**
 * REPOSITORY: Manages the lifecycle of the LLM and its adapters.
 * This layer handles the hardware orchestration (NPU/GPU).
 */
@Singleton
class LoraInferenceRepository @InjectHilt constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Hardware-aware configuration
    private fun createLlmOptions(adapterPath: String): LlmInference.LlmInferenceOptions {
        return LlmInference.LlmInferenceOptions.builder()
            .setModelPath(adapterPath) // In MediaPipe, the adapter is often bundled or pointed to
            .setMaxTokens(1024)
            .setTopK(40)
            .setTemperature(0.7f)
            // Note: MediaPipe handles GPU/NPU delegation internally based on 
            // the TFLite delegate configuration of the underlying model.
            .build()
    }

    /**
     * Swaps the active LoRA adapter. 
     * This is a heavy operation as it re-initializes the inference engine.
     */
    suspend fun loadAdapter(adapter: LoraAdapter): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            Log.d("LoRA_Repo", "Loading adapter for domain: ${adapter.domain}")
            
            // Close previous instance to free NPU memory
            llmInference?.close()
            
            // Initialize new instance with the specific adapter path
            llmInference = LlmInference.createFromOptions(context, createLlmOptions(adapter.filePath))
            
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("LoRA_Repo", "Failed to load LoRA adapter", e)
            Result.failure(e)
        }
    }

    /**
     * Executes inference using the currently loaded adapter.
     */
    suspend fun generateResponse(prompt: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("No adapter loaded")
        
        // We use a flow to stream the response (Token-by-token)
        // This prevents the UI from freezing and improves perceived latency
        engine.generateResponseAsync(prompt) { partialResult, done ->
            // This callback is called by the MediaPipe native layer
            // We emit the partial result to the flow
        }
        
        // For simplicity in this example, we use the synchronous call 
        // but wrap it in a flow to simulate streaming
        val result = withContext(Dispatchers.Default) {
            engine.generateResponse(prompt)
        }
        emit(result)
    }.flowOn(Dispatchers.Default)
}

/**
 * VIEWMODEL: Orchestrates the state and handles intents.
 */
@HiltViewModel
class AssistantViewModel @InjectHilt constructor(
    private val repository: LoraInferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _state = MutableStateFlow(AssistantState())
    val state: StateFlow<AssistantState> = _state.asStateFlow()

    fun handleIntent(intent: AssistantIntent) {
        when (intent) {
            is AssistantIntent.SwitchAdapter -> switchAdapter(intent.adapter)
            is AssistantIntent.SendPrompt -> sendPrompt(intent.prompt)
        }
    }

    private fun switchAdapter(adapter: LoraAdapter) {
        viewModelScope.launch {
            _state.update { it.copy(isProcessing = true, error = null) }
            
            val result = repository.loadAdapter(adapter)
            
            result.fold(
                onSuccess = {
                    _state.update { it.copy(currentAdapter = adapter, isProcessing = false) }
                },
                onFailure = { e ->
                    _state.update { it.copy(error = e.message, isProcessing = false) }
                }
            )
        }
    }

    private fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _state.update { it.copy(isProcessing = true, responseText = "") }
            
            repository.generateResponse(prompt)
                .catch { e ->
                    _state.update { it.copy(error = e.message, isProcessing = false) }
                }
                .collect { chunk ->
                    _state.update { it.copy(responseText = it.responseText + chunk) }
                }
            
            _state.update { it.copy(isProcessing = false) }
        }
    }
}

/**
 * HILT MODULE: Dependency Injection Setup
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideLoraRepository(@ApplicationContext context: Context): LoraInferenceRepository {
        return LoraInferenceRepository(context)
    }
}
