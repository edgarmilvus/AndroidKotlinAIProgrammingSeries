
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.kt
// Description: Advanced Application
// ==========================================

// Gradle Dependencies (Kotlin DSL)
// implementation("com.google.mediapipe:tasks-genai:0.10.14")
// implementation("com.google.dagger:hilt-android:2.50")
// implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
// implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

package com.genai.ondevice.lora

import android.content.Context
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.scopes.ActivityRetainedScoped
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as HiltInject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/**
 * Represents a LoRA Adapter configuration.
 * The [adapterPath] points to the .bin or .tflite file containing the low-rank weights.
 */
data class LoRAAdapter(
    val id: String,
    val personaName: String,
    val adapterPath: String,
    val temperature: Float = 0.7f
)

sealed class GenAiState {
    object Idle : GenAiState()
    object LoadingAdapter : GenAiState()
    data class Generating(val partialText: String) : GenAiState()
    data class Success(val result: String) : GenAiState()
    data class Error(val message: String) : GenAiState()
}

/**
 * Repository responsible for the low-level orchestration of the LLM and LoRA weights.
 * Implements hardware-aware initialization to prefer NPU/GPU.
 */
@Singleton
class OnDeviceGenAiRepository @HiltInject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null
    private var currentAdapterId: String? = null

    // Hardware-aware options for the LLM
    private fun createLlmOptions(adapterPath: String): LlmInference.LlmInferenceOptions {
        return LlmInference.LlmInferenceOptions.builder()
            .setModelPath(adapterPath) 
            // In a real LoRA scenario, the modelPath may point to a combined 
            // base+adapter file or a specific MediaPipe bundle.
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            .setRandomSeed(42)
            // Hardware acceleration is handled internally by MediaPipe's 
            // GPU delegate if available on the device.
            .build()
    }

    suspend fun switchAdapter(adapter: LoRAAdapter): Result<Unit> = withContext(Dispatchers.Default) {
        try {
            if (currentAdapterId == adapter.id) return@withContext Result.success(Unit)
            
            Log.d("LoRA_Repo", "Switching to adapter: ${adapter.personaName}")
            
            // Close previous instance to free NPU/GPU memory
            llmInference?.close()
            
            // Initialize new inference engine with the specific LoRA-tuned model
            llmInference = LlmInference.createFromOptions(context, createLlmOptions(adapter.adapterPath))
            currentAdapterId = adapter.id
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateResponse(prompt: String, onTokenReceived: (String) -> Unit): Result<String> = withContext(Dispatchers.Default) {
        val engine = llmInference ?: return@withContext Result.failure(IllegalStateException("Model not initialized"))
        
        try {
            val fullResponse = StringBuilder()
            // Using the streaming API for better UX
            engine.generateResponseAsync(prompt) { partialResult, done ->
                fullResponse.append(partialResult)
                onTokenReceived(fullResponse.toString())
            }
            Result.success(fullResponse.toString())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * ViewModel implementing MVI pattern to handle AI persona switching and inference.
 */
@HiltViewModel
@AndroidEntryPoint
class GenAiViewModel @HiltInject constructor(
    private val repository: OnDeviceGenAiRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<GenAiState>(GenAiState.Idle)
    val uiState: StateFlow<GenAiState> = _uiState.asStateFlow()

    private val _activeAdapter = MutableStateFlow<LoRAAdapter?>(null)
    val activeAdapter: StateFlow<LoRAAdapter?> = _activeAdapter.asStateFlow()

    fun setPersona(adapter: LoRAAdapter) {
        viewModelScope.launch {
            _uiState.value = GenAiState.LoadingAdapter
            repository.switchAdapter(adapter)
                .onSuccess {
                    _activeAdapter.value = adapter
                    _uiState.value = GenAiState.Idle
                }
                .onFailure { _uiState.value = GenAiState.Error(it.message ?: "Failed to load adapter") }
        }
    }

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _uiState.value = GenAiState.Generating("")
            
            repository.generateResponse(prompt) { partialText ->
                // Update state on Main thread for Compose UI
                _uiState.value = GenAiState.Generating(partialText)
            }.onSuccess { finalResult ->
                _uiState.value = GenAiState.Success(finalResult)
            }.onFailure {
                _uiState.value = GenAiState.Error(it.message ?: "Inference failed")
            }
        }
    }
}
