
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidModule
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Metadata for a LoRA Adapter.
 * This describes the 'delta' that will be applied to the base Gemini Nano model.
 */
@Serializable
data class LoraAdapterConfig(
    val adapterId: String,
    val rank: Int,
    val alpha: Float,
    val targetModules: List<String>,
    val weightFileUri: String
)

/**
 * Define a context for AI operations. 
 * This allows us to use 'context(AiCoreScope)' in our business logic.
 */
interface AiCoreScope {
    val client: AiCoreClient
    val currentAdapter: StateFlow<LoraAdapterConfig?>
}

/**
 * Implementation of the AI Scope, managed as a Singleton via Hilt.
 */
@Singleton
class AiCoreManager @Inject constructor(
    @ApplicationContext private val context: Context
) : AiCoreScope {
    override val client: AiCoreClient = AiCoreClient.create(context)
    
    private val _currentAdapter = MutableStateFlow<LoraAdapterConfig?>(null)
    override val currentAdapter: StateFlow<LoraAdapterConfig?> = _currentAdapter.asStateFlow()

    suspend fun loadAdapter(config: LoraAdapterConfig) = withContext(Dispatchers.IO) {
        // Analogous to a Room migration: we are applying a delta to the base model
        client.applyAdapter(config.adapterId, config.weightFileUri)
        _currentAdapter.value = config
    }

    suspend fun unloadAdapter() = withContext(Dispatchers.IO) {
        client.clearAdapters()
        _currentAdapter.value = null
    }
}

/**
 * Business Logic Layer using Context Receivers.
 * This function cannot be called unless an AiCoreScope is provided in the context.
 */
context(AiCoreScope)
suspend fun generateSpecializedResponse(prompt: String): Flow<String> {
    val adapter = currentAdapter.value 
        ?: throw IllegalStateException("No LoRA adapter loaded for this task")

    return client.generateText(
        prompt = prompt,
        adapterId = adapter.adapterId
    ).map { token ->
        // Post-process tokens (e.g., cleaning up AI artifacts)
        token.trim()
    }.flowOn(Dispatchers.Default)
}

/**
 * ViewModel integrating the AI pipeline.
 */
@kotlinx.coroutines.experimental.ExperimentalCoroutinesApi
class AiViewModel @Inject constructor(
    private val aiManager: AiCoreManager
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState = _uiState.asStateFlow()

    fun onRunInference(prompt: String) {
        androidx.lifecycle.viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            
            try {
                // We provide aiManager as the context for the generateSpecializedResponse function
                with(aiManager) {
                    generateSpecializedResponse(prompt)
                        .collect { token ->
                            _uiState.value = AiUiState.Success(token)
                        }
                }
            } catch (e: Exception) {
                _uiState.value = AiUiState.Error(e.message ?: "Unknown AI Error")
            }
        }
    }
}

sealed class AiUiState {
    object Idle : AiUiState()
    object Loading : AiUiState()
    data class Success(val text: String) : AiUiState()
    data class Error(val message: String) : AiUiState()
}

/**
 * Hilt Module to provide the AI infrastructure.
 */
@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides
    @Singleton
    fun provideAiCoreManager(@ApplicationContext context: Context): AiCoreManager {
        return AiCoreManager(context)
    }
}

// Mock for the AICore Client SDK
class AiCoreClient {
    companion object {
        fun create(context: Context) = AiCoreClient()
    }
    suspend fun applyAdapter(id: String, uri: String) { /* Binder IPC to AICore */ }
    suspend fun clearAdapters() { /* Binder IPC to AICore */ }
    fun generateText(prompt: String, adapterId: String): Flow<String> = flow {
        emit("This ")
        emit("is ")
        emit("a ")
        emit("LoRA-tuned ")
        emit("response.")
    }
}
