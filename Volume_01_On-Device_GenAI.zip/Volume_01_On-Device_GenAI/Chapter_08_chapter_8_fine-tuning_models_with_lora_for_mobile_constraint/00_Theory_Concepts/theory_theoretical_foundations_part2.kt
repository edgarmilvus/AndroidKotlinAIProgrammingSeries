
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Define the adapter configuration using Serialization
@Serializable
data class LoraAdapterConfig(
    val adapterId: String,
    val rank: Int,
    val alpha: Float,
    val targetModules: List<String>,
    val version: Int
)

// 2. Context Receiver for AI Operations
// This ensures any function using 'ModelScope' has access to the session
interface ModelScope {
    val session: AiCoreSession
}

// 3. The AI Provider Manager
@Singleton
class AiCoreManager @Inject constructor(
    private val aicoreClient: AiCoreClient 
) {
    private val _sessionState = MutableStateFlow<SessionStatus>(SessionStatus.Idle)
    val sessionState: StateFlow<SessionStatus> = _sessionState.asStateFlow()

    // Analogous to Room migration: we verify the adapter version 
    // against the base model version provided by AICore
    suspend fun loadAdapter(config: LoraAdapterConfig): Result<Unit> = withContext(Dispatchers.Default) {
        try {
            _sessionState.value = SessionStatus.Loading
            
            // The 'why': We offload the heavy weight-merging 
            // (W0 + AB) to the system-level AICore service
            aicoreClient.loadLoraAdapter(
                id = config.adapterId,
                rank = config.rank,
                alpha = config.alpha
            )
            
            _sessionState.value = SessionStatus.Ready
            Result.success(Unit)
        } catch (e: Exception) {
            _sessionState.value = SessionStatus.Error(e.message ?: "Unknown Error")
            Result.failure(e)
        }
    }
}

// 4. High-level inference using Context Receivers
// This function can only be called when a ModelScope is provided
context(ModelScope)
fun generateResponse(prompt: String): Flow<String> = flow {
    // Use the session provided by the context receiver
    val responseFlow = session.generateText(prompt)
    responseFlow.collect { token ->
        emit(token)
    }
}.flowOn(Dispatchers.Default)

// 5. Integration with Hilt and ViewModel
sealed class SessionStatus {
    object Idle : SessionStatus()
    object Loading : SessionStatus()
    object Ready : SessionStatus()
    data class Error(val message: String) : SessionStatus()
}

class AiViewModel @Inject constructor(
    private val aiCoreManager: AiCoreManager
) : ViewModel() {
    
    fun runInference(prompt: String) {
        viewModelScope.launch {
            // We create a temporary implementation of ModelScope 
            // to satisfy the context receiver requirement
            val currentSession = aiCoreManager.getActiveSession() 
            val scope = object : ModelScope {
                override val session = currentSession
            }
            
            with(scope) {
                generateResponse(prompt).collect { token ->
                    // Update UI state
                }
            }
        }
    }
}
