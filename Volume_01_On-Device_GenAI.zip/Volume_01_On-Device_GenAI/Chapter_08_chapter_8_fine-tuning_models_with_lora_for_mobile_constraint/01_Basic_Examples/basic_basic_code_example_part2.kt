
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository responsible for managing the On-Device LLM with LoRA adapters.
 * 
 * @param context The application context for file access.
 */
@Singleton
class LoRAInferenceRepository @Inject constructor(
    private val context: Context
) {
    private var llmInference: LlmInference? = null

    /**
     * Initializes the LLM with a base model and an optional LoRA adapter.
     * 
     * @param baseModelPath Path to the .bin base model (e.g., Gemma 2B).
     * @param loraAdapterPath Path to the .lora file containing specialized weights.
     */
    fun initializeModel(baseModelPath: String, loraAdapterPath: String?) {
        val optionsBuilder = LlmInferenceOptions.builder()
            .setModelPath(baseModelPath)
            .setMaxTokens(512)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(42)

        // If a LoRA adapter is provided, we attach it to the base model.
        // MediaPipe handles the weight fusion internally during inference.
        loraAdapterPath?.let {
            optionsBuilder.setLoraPath(it)
        }

        // Warning: LlmInference.create is a heavy blocking operation.
        // It should be called from a background thread.
        llmInference = LlmInference.createFromOptions(context, optionsBuilder.build())
    }

    /**
     * Executes inference using a streaming Flow.
     * This provides a "typing" effect in the UI.
     */
    fun generateResponse(prompt: String): Flow<String> = flow {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // We use the generateResponse method which returns a partial result
        // as the model computes tokens.
        try {
            // Note: In current MediaPipe versions, streaming is handled via a callback
            // or a simplified blocking call. Here we wrap the logic for Compose.
            val result = inference.generateResponse(prompt)
            emit(result)
        } catch (e: Exception) {
            emit("Error: ${e.localizedMessage}")
        }
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}
