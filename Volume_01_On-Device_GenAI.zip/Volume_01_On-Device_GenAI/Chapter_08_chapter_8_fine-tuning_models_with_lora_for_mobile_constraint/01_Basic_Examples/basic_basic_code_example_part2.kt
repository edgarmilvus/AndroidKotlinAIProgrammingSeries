
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.util.Log
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject.AndroidViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Configuration for the LoRA adapter.
 * In a real scenario, adapterPath would point to a .bin or .tflite file 
 * containing the low-rank matrices A and B.
 */
data class LloraConfig(
    val baseModelPath: String,
    val adapterPath: String,
    val maxTokens: Int = 512,
    val temperature: Float = 0.7f
)

/**
 * Repository responsible for managing the LLM lifecycle.
 * Using @Singleton to ensure we don't load the multi-GB model multiple times.
 */
@Singleton
class LloraRepository @Inject constructor(private val context: Context) {
    private var llmInference: LlmInference? = null

    // Initialize the model with the LoRA adapter
    suspend fun initializeModel(config: LloraConfig) = withContext(Dispatchers.Default) {
        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(config.baseModelPath)
                // The 'adapterPath' is the key LoRA component. 
                // MediaPipe integrates the adapter weights into the base model at runtime.
                .setLrAdapterPath(config.adapterPath) 
                .setMaxTokens(config.maxTokens)
                .setTemperature(config.temperature)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            Log.d("LloraRepo", "Model and LoRA adapter loaded successfully.")
        } catch (e: Exception) {
            Log.e("LloraRepo", "Failed to load LoRA model: ${e.message}")
            throw e
        }
    }

    // Generate response using the fine-tuned model
    suspend fun generateResponse(prompt: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // Use the streaming API to avoid blocking the UI and provide a better UX
        engine.generateResponseAsync(prompt).collect { partialResponse ->
            emit(partialResponse)
        }
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * ViewModel to bridge the Repository and the Compose UI.
 */
@AndroidEntryPoint
class LloraViewModel @Inject constructor(
    private val repository: LloraRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<LloraUiState>(LloraUiState.Idle)
    val uiState: StateFlow<LloraUiState> = _uiState.asStateFlow()

    private val _chatHistory = MutableStateFlow<String>("")
    val chatHistory: StateFlow<String> = _chatHistory.asStateFlow()

    fun setupModel(basePath: String, adapterPath: String) {
        viewModelScope.launch {
            _uiState.value = LloraUiState.Loading
            try {
                repository.initializeModel(LloraConfig(basePath, adapterPath))
                _uiState.value = LloraUiState.Ready
            } catch (e: Exception) {
                _uiState.value = LloraUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _chatHistory.value += "\nUser: $prompt\nAI: "
            
            repository.generateResponse(prompt)
                .collect { chunk ->
                    _chatHistory.value += chunk
                }
            
            _chatHistory.value += "\n"
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close()
    }
}

sealed class LloraUiState {
    object Idle : LloraUiState()
    object Loading : LloraUiState()
    object Ready : LloraUiState()
    data class Error(val message: String) : LloraUiState()
}

/**
 * Modern Jetpack Compose UI for interacting with the LoRA-tuned model.
 */
@Composable
fun LloraChatScreen(viewModel: LloraViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val history by viewModel.chatHistory.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = androidx.compose.ui.Modifier.fillMaxSize().padding(16.dp)) {
        when (state) {
            is LloraUiState.Idle -> {
                Button(onClick = { 
                    viewModel.setupModel("/data/local/tmp/base_model.bin", "/data/local/tmp/medical_adapter.bin") 
                }) {
                    Text("Initialize Medical LoRA Model")
                }
            }
            is LloraUiState.Loading -> CircularProgressIndicator()
            is LloraUiState.Error -> Text("Error: ${(state as LloraUiState.Error).message}", color = androidx.compose.ui.graphics.Color.Red)
            is LloraUiState.Ready -> {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                    label = { Text("Ask the specialist...") }
                )
                Button(
                    onClick = { 
                        viewModel.sendPrompt(inputText)
                        inputText = "" 
                    },
                    modifier = androidx.compose.ui.Modifier.align(androidx.compose.ui.Alignment.End)
                ) {
                    Text("Send")
                }
                Text(text = history, modifier = androidx.compose.ui.Modifier.verticalScroll(rememberScrollState()))
            }
        }
    }
}
