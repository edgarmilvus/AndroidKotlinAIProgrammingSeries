
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.genai.data.LLMRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * UI State wrapper to handle the different phases of the AI request.
 */
sealed class AIState {
    object Idle : AIState()
    object Loading : AIState()
    data class Success(val response: String) : AIState()
    data class Error(val message: String) : AIState()
}

@HiltViewModel
class LLMViewModel @Inject constructor(
    private val repository: LLMRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AIState>(AIState.Idle)
    val uiState: StateFlow<AIState> = _uiState.asStateFlow()

    /**
     * Triggers the AI inference process.
     * uses Dispatchers.Default to move the heavy computation off the Main thread.
     */
    fun askAI(prompt: String, modelPath: String) {
        viewModelScope.launch {
            _uiState.value = AIState.Loading
            
            try {
                // Switch to the Default dispatcher for CPU-intensive AI work
                val result = withContext(Dispatchers.Default) {
                    // 1. Ensure model is loaded
                    repository.initializeModel(modelPath)
                    // 2. Perform blocking inference
                    repository.generateResponse(prompt)
                }
                _uiState.value = AIState.Success(result)
            } catch (e: Exception) {
                _uiState.value = AIState.Error(e.localizedMessage ?: "An unknown error occurred")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Clean up resources when ViewModel is destroyed
        repository.close()
    }
}
