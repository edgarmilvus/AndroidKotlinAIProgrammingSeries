
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.llm

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelScope
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. LLM Repository: Handles the low-level MediaPipe LlmInference lifecycle.
 * We use a Singleton to avoid reloading the heavy model into RAM multiple times.
 */
@Singleton
class LlmRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the LLM. In a real app, the model path would be dynamic.
    fun initializeModel(modelPath: String) {
        if (llmInference == null) {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(512) // Limit output length to prevent ANRs/OOM
                .setTopK(40)       // Diversifies the response
                .setTemperature(0.7f) // Balance between randomness and determinism
                .build()
            
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    /**
     * Performs a synchronous inference call. 
     * Must be called from a background thread (Dispatchers.Default).
     */
    fun generateResponse(prompt: String): String {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")
        return try {
            // generateResponse is a blocking call
            inference.generateResponse(prompt)
        } catch (e: Exception) {
            Log.e("LlmRepository", "Inference failed", e)
            "Error: ${e.localizedMessage}"
        }
    }

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * 2. ViewModel: Manages the UI state and orchestrates the Coroutine flow.
 */
@HiltViewModel
class LlmViewModel @Inject constructor(
    private val repository: LlmRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LlmUiState())
    val uiState: StateFlow<LlmUiState> = _uiState.asStateFlow()

    fun onPromptSubmitted(prompt: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, response = "")
            
            // Move execution to Default dispatcher for CPU-intensive AI work
            val result = withContext(Dispatchers.Default) {
                repository.generateResponse(prompt)
            }
            
            _uiState.value = _uiState.value.copy(isLoading = false, response = result)
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close() // Prevent memory leaks
    }
}

data class LlmUiState(
    val response: String = "",
    val isLoading: Boolean = false
)

/**
 * 3. UI Layer: Modern Jetpack Compose interface.
 */
@AndroidEntryPoint
@Composable
fun LlmChatScreen(viewModel: LlmViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by viewModel.uiState.collectAsState()
    var promptText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(text = "On-Device GenAI", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = promptText,
            onValueChange = { promptText = it },
            label = { Text("Ask the local LLM...") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.onPromptSubmitted(promptText) },
            enabled = !state.isLoading && promptText.isNotBlank(),
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(if (state.isLoading) "Thinking..." else "Generate")
        }

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        if (state.isLoading) {
            CircularProgressIndicator()
        } else {
            Text(
                text = state.response,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
