
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.data

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * LLMRepository manages the lifecycle of the MediaPipe LLM Inference engine.
 * It handles the loading of the .bin model file and provides a thread-safe
 * method to generate responses.
 */
@Singleton
class LLMRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    /**
     * Initializes the LLM engine. 
     * This must be called before [generateResponse].
     * @param modelPath The absolute path to the .bin model file on the device.
     */
    fun initializeModel(modelPath: String) {
        if (llmInference != null) return // Avoid redundant initialization

        val options = LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024) // Maximum length of the generated response
            .setTopK(40)        // Limits the vocabulary to the top K most likely tokens
            .setTemperature(0.7f) // Controls randomness: 0.0 is deterministic, 1.0 is creative
            .setRandomSeed(42)    // Ensures reproducible results for testing
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Synchronously generates a response from the LLM.
     * This is a blocking call and MUST be executed on a background thread.
     */
    fun generateResponse(prompt: String): String {
        val engine = llmInference ?: throw IllegalStateException("Model not initialized. Call initializeModel first.")
        return engine.generateResponse(prompt)
    }

    /**
     * Clears the model from memory. Critical for avoiding OOM errors 
     * when the AI feature is no longer needed.
     */
    fun close() {
        llmInference?.close()
        llmInference = null
    }
}
