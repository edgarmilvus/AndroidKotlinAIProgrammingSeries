
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import javax.inject.Singleton

/**
 * The AI Repository abstracts the MediaPipe API.
 * It handles the conversion from Callback-based API to Kotlin Flow.
 */
class AiRepository @javax.inject.Inject constructor(
    private val llmInference: LlmInference
) {
    /**
     * Generates a response as a stream of tokens.
     * Just like with CameraX's ImageAnalysis, we are processing a stream 
     * of data in real-time.
     */
    fun generateResponseStream(prompt: String): Flow<String> = callbackFlow {
        // The MediaPipe API uses a callback for streaming
        llmInference.generateResponseAsync(prompt) { partialResult, done ->
            // Send the partial token to the Flow collector
            trySend(partialResult)
            if (done) {
                channel.close()
            }
        }
        
        // Ensure the channel stays open until the LLM is done
        awaitClose { 
            // Cleanup logic if the API supported cancellation
        }
    }.flowOn(Dispatchers.Default) // Ensure inference doesn't block the main thread
}

/**
 * Hilt Module to provide the LlmInference instance.
 * This is where the "Model Loading" happens.
 */
@Module
@InstallIn(SingletonComponent::class)
object AiModule {

    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        // LlmInference.Options defines the configuration for the model.
        // In a real scenario, the model path would point to the 
        // Gemini Nano weights provided by AICore.
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Simplified path
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            .setTopK(40)
            .build()
            
        return LlmInference.createFromOptions(context, options)
    }
}
