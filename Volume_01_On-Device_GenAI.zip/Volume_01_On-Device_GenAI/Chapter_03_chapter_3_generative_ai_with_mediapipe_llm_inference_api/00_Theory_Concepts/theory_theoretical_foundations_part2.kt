
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Singleton

// 1. Define a wrapper to handle the LLM Lifecycle
@Singleton
class LlmEngine @javax.inject.Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var inferenceEngine: LlmInference? = null

    // Initialize the engine. Analogy: Like Room.databaseBuilder().build()
    suspend fun initialize() = withContext(Dispatchers.Default) {
        if (inferenceEngine == null) {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath("/data/local/tmp/gemini_nano.bin") // Path managed by AICore
                .setMaxTokens(1024)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()
            
            inferenceEngine = LlmInference.createFromOptions(context, options)
        }
    }

    // Use Flow to stream tokens back to the UI
    fun generateResponse(prompt: String): Flow<String> = flow {
        val engine = inferenceEngine ?: throw IllegalStateException("Engine not initialized")
        
        // MediaPipe's generateResponse is a blocking call that can be bridged to Flow
        engine.generateResponse(prompt) { partialResult, done ->
            emit(partialResult)
        }
    }.flowOn(Dispatchers.Default)
}

// 2. Use Context Receivers (Kotlin 2.x) for Prompt Engineering
// This ensures 'PromptBuilder' can only be used when an LlmEngine is present in scope
context(LlmEngine)
fun buildStructuredPrompt(userInput: String): String {
    return "User: $userInput\nAssistant: "
}

// 3. Hilt Module for providing the Engine
@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides
    @Singleton
    fun provideLlmEngine(@ApplicationContext context: Context): LlmEngine {
        return LlmEngine(context)
    }
}
