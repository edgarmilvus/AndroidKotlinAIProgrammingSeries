
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// --- DI Module ---
@Module
@InstallIn(SingletonComponent::class)
object GenAiModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/asset/gemma-2b-it-cpu-int4.bin") // Path to model in assets
            .setMaxTokens(128)
            .setTemperature(0.7f)
            .build()
        return LlmInference.createFromOptions(context, options)
    }
}

// --- Manager ---
@Singleton
class GenAiManager @Inject constructor(private val llmInference: LlmInference) {
    fun getQuickReplies(userInput: String): List<String> {
        val systemPrompt = "You are a helpful e-commerce assistant. Given the following user message, " +
                "provide 3 short, professional suggested replies. Format: Reply 1 | Reply 2 | Reply 3. " +
                "User: $userInput"
        
        // Synchronous call: must be wrapped in Dispatchers.Default by the ViewModel
        val response = llmInference.generateResponse(systemPrompt)
        return response.split("|").map { it.trim() }.filter { it.isNotEmpty() }
    }
}

// --- ViewModel ---
@HiltViewModel
class QuickReplyViewModel @Inject constructor(private val genAiManager: GenAiManager) : ViewModel() {
    var uiState by mutableStateOf(QuickReplyState())
        private set

    fun onGenerateReplies(input: String) {
        viewModelScope.launch(Dispatchers.Default) {
            uiState = uiState.copy(isLoading = true)
            try {
                val replies = genAiManager.getQuickReplies(input)
                uiState = uiState.copy(suggestions = replies, isLoading = false)
            } catch (e: Exception) {
                uiState = uiState.copy(isLoading = false)
            }
        }
    }
}

data class QuickReplyState(val suggestions: List<String> = emptyList(), val isLoading: Boolean = false)

// --- UI ---
@Composable
fun QuickReplyScreen(viewModel: QuickReplyViewModel = hiltViewModel()) {
    var text by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Message Support") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.onGenerateReplies(text) },
            enabled = !viewModel.uiState.isLoading,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(if (viewModel.uiState.isLoading) "Thinking..." else "Get Suggestions")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            viewModel.uiState.suggestions.forEach { reply ->
                SuggestionChip(onClick = { /* Use reply */ }, label = { Text(reply) })
            }
        }
    }
}
