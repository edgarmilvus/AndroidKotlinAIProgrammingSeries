
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Hilt Module for Singleton LlmInference
@Module
@InstallIn(SingletonComponent::class)
object LlmModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/model.bin") // Path should be configured via BuildConfig or assets
            .setMaxTokens(512)
            .build()
        return LlmInference.createFromOptions(context, options)
    }
}

// 2. ViewModel to handle prompting logic
@HiltViewModel
class KnowledgeBaseViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    var query by mutableStateOf("")
    var response by mutableStateOf("")
    var isProcessing by mutableStateOf(false)

    fun askQuestion() {
        if (query.isBlank()) return
        
        viewModelScope.launch(Dispatchers.Default) {
            isProcessing = true
            try {
                // Wrapping the user query in a system prompt template
                val prompt = "You are a technical assistant. Answer the following question based on the manual: $query"
                val result = llmInference.generateResponse(prompt)
                response = result
            } catch (e: Exception) {
                response = "Error: ${e.localizedMessage}"
            } finally {
                isProcessing = false
            }
        }
    }
}

// 3. Jetpack Compose UI
@Composable
fun KnowledgeBaseScreen(viewModel: KnowledgeBaseViewModel = hiltViewModel()) {
    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = viewModel.query,
            onValueChange = { viewModel.query = it },
            label = { Text("Ask the manual...") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.askQuestion() },
            enabled = !viewModel.isProcessing,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(if (viewModel.isProcessing) "Thinking..." else "Ask")
        }
        Text(
            text = viewModel.response,
            modifier = Modifier.verticalScroll(rememberScrollState())
        )
    }
}
