
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// --- Room Setup ---
@Entity(tableName = "notes")
data class Note(@PrimaryKey(autoGenerate = true) val id: Int = 0, val content: String)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE content LIKE '%' || :query || '%' LIMIT 3")
    suspend fun searchNotes(query: String): List<Note>
}

// --- RAG Logic ---
class RagManager @Inject constructor(
    private val noteDao: NoteDao,
    private val llmInference: LlmInference
) {
    suspend fun askKnowledgeBase(userQuery: String): String {
        // 1. Retrieval
        val relevantNotes = noteDao.searchNotes(userQuery)
        
        // 2. Token Budgeting (Simple character limit for this exercise)
        val contextText = relevantNotes.joinToString("\n") { "Note #${it.id}: ${it.content}" }
            .take(3000) 

        // 3. Augmented Prompt
        val augmentedPrompt = """
            You are a personal assistant. Use the following retrieved notes to answer the user's question. 
            If the answer is not in the notes, say "I don't know based on your notes."
            Cite the note number used.
            
            Notes:
            $contextText
            
            Question: $userQuery
            Answer:
        """.trimIndent()

        return llmInference.generateResponse(augmentedPrompt)
    }
}
