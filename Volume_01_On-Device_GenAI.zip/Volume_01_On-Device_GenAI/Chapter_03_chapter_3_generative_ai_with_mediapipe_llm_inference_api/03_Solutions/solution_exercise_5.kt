
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

enum class ModelType(val path: String) {
    FAST("/models/fast_model.bin"),
    REASONING("/models/reasoning_model.bin")
}

@Singleton
class ModelManager @Inject constructor(@ApplicationContext private val context: Context) {
    private var activeInference: LlmInference? = null
    private var activeType: ModelType? = null

    suspend fun getModel(type: ModelType): LlmInference = withContext(Dispatchers.IO) {
        if (activeType == type) return@withContext activeInference!!

        // CRITICAL: Unload previous model to free native memory
        activeInference?.close()
        
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(type.path)
            .build()
        
        val inference = LlmInference.createFromOptions(context, options)
        activeInference = inference
        activeType = type
        inference
    }
}

@HiltViewModel
class OrchestratorViewModel @Inject constructor(
    private val modelManager: ModelManager
) : ViewModel() {

    var loadingStatus by mutableStateOf<String?>(null)
    var finalResponse by mutableStateOf("")

    fun processQuery(query: String) {
        viewModelScope.launch(Dispatchers.Default) {
            // 1. Routing Phase
            loadingStatus = "Analyzing query..."
            val fastModel = modelManager.getModel(ModelType.FAST)
            val routingResult = fastModel.generateResponse("Is this query simple or complex? Answer only one word. Query: $query")

            if (routingResult.contains("simple", ignoreCase = true)) {
                finalResponse = fastModel.generateResponse(query)
                loadingStatus = null
            } else {
                // 2. Escalation Phase
                loadingStatus = "Switching to Deep Reasoning mode..."
                val reasoningModel = modelManager.getModel(ModelType.REASONING)
                finalResponse = reasoningModel.generateResponse(query)
                loadingStatus = null
            }
        }
    }
}
