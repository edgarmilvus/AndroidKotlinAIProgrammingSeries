
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// --- Manager ---
@Singleton
class SummarizerManager @Inject constructor(private val llmInference: LlmInference) {
    
    fun summarizeStreaming(text: String): Flow<String> = callbackFlow {
        // Context Window Management: Simple truncation to ~2000 words
        val truncatedText = if (text.split(" ").size > 2000) {
            text.split(" ").take(2000).joinToString(" ")
        } else text

        val prompt = "Summarize the following text into exactly three bullet points. " +
                "Focus on the main conclusions. Text: $truncatedText"

        llmInference.generateResponseAsync(prompt) { partialResult, done ->
            trySend(partialResult)
            if (done) {
                channel.close()
            }
        }
        awaitClose { /* No-op: LlmInference is managed by Hilt Singleton */ }
    }
    
    fun closeEngine() {
        llmInference.close()
    }
}

// --- ViewModel ---
@HiltViewModel
class SummarizerViewModel @Inject constructor(private val manager: SummarizerManager) : ViewModel() {
    private val _summary = MutableStateFlow("")
    val summary: StateFlow<String> = _summary.asStateFlow()

    fun summarize(input: String) {
        viewModelScope.launch {
            _summary.value = ""
            manager.summarizeStreaming(input).collect { chunk ->
                _summary.value += chunk
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // In a real production app, if the manager isn't a singleton, 
        // we close it here to release native TFLite buffers.
        // manager.closeEngine() 
    }
}

// --- UI ---
@Composable
fun SummarizerScreen(viewModel: SummarizerViewModel = hiltViewModel()) {
    val summary by viewModel.summary.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = inputText, 
            onValueChange = { inputText = it }, 
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )
        Button(onClick = { viewModel.summarize(inputText) }) {
            Text("TL;DR")
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(top = 16.dp)) {
            item {
                Text(text = summary, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
