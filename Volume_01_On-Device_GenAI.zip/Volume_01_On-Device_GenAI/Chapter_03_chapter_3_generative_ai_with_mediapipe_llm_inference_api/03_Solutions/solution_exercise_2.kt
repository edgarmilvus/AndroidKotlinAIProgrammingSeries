
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

sealed class SummarizationState {
    object Idle : SummarizationState()
    object Processing : SummarizationState()
    data class Success(val summary: String) : SummarizationState()
    data class Error(val message: String) : SummarizationState()
}

@HiltViewModel
class SummarizerViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummarizationState>(SummarizationState.Idle)
    val uiState = _uiState.asStateFlow()

    fun summarizeText(input: String) {
        viewModelScope.launch(Dispatchers.Default) {
            _uiState.value = SummarizationState.Processing
            try {
                // 1. Safe Truncation (Approximate token limit via characters)
                val truncatedText = if (input.length > 6000) input.take(6000) else input
                
                // 2. Few-Shot Constraint Prompting
                val prompt = """
                    Summarize the following text into exactly three concise bullet points.
                    
                    Example:
                    Text: The Android OS is based on Linux. It is developed by Google. It powers billions of devices.
                    Summary:
                    - Based on the Linux kernel.
                    - Developed by Google.
                    - Powers billions of devices worldwide.
                    
                    Text: $truncatedText
                    Summary:
                """.trimIndent()

                val result = llmInference.generateResponse(prompt)
                _uiState.value = SummarizationState.Success(result)
            } catch (e: Exception) {
                _uiState.value = SummarizationState.Error("Model failed: ${e.localizedMessage}")
            }
        }
    }
}
