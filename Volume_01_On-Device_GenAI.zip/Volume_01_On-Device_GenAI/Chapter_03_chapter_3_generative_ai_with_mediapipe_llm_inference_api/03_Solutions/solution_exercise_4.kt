
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val _streamedText = MutableStateFlow("")
    val streamedText = _streamedText.asStateFlow()

    private var currentJob: Job? = null

    fun sendMessage(query: String) {
        currentJob?.cancel() // Cancel existing generation
        _streamedText.value = ""

        currentJob = viewModelScope.launch {
            generateStreamingResponse(query)
                .collect { token ->
                    _streamedText.value += token
                }
        }
    }

    private fun generateStreamingResponse(query: String): Flow<String> = callbackFlow {
        llmInference.generateResponseAsync(query) { partialResult, done ->
            // MediaPipe's async API provides the accumulated result so far
            // We calculate the delta to send only the new token
            val currentText = _streamedText.value
            val newToken = partialResult.removePrefix(currentText)
            
            trySend(newToken)
            
            if (done) {
                channel.close()
            }
        }
        awaitClose { /* MediaPipe doesn't have a specific 'stop' call per request, 
                          but closing the flow handles the Kotlin side */ }
    }.flowOn(Dispatchers.Default)

    fun cancelGeneration() {
        currentJob?.cancel()
    }
}

@Composable
fun StreamingChatScreen(viewModel: ChatViewModel = hiltViewModel()) {
    val text by viewModel.streamedText.collectAsStateWithLifecycle()

    Column {
        Text(
            text = text,
            modifier = Modifier.animateContentSize() // Smoothly expand text area
        )
        Button(onClick = { viewModel.cancelGeneration() }) {
            Text("Stop Generation")
        }
    }
}
