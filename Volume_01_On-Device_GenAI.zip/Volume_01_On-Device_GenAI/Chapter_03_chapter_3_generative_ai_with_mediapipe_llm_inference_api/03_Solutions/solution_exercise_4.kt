
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

data class BenchmarkMetrics(
    val ttftMs: Long,
    val tps: Double,
    val memoryUsedMb: Long
)

class PerformanceBenchmarker @Inject constructor(
    private val context: Context,
    private val llmInference: LlmInference
) {
    fun runBenchmark(prompt: String): BenchmarkMetrics {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val startMem = memInfo.availMem

        var firstTokenTime = 0L
        var totalTokens = 0
        val startTime = System.nanoTime()

        llmInference.generateResponseAsync(prompt) { partial, done ->
            if (firstTokenTime == 0L) {
                firstTokenTime = (System.nanoTime() - startTime) / 1_000_000
            }
            totalTokens++
            if (done) {
                val endTime = System.nanoTime()
                val durationSec = (endTime - startTime) / 1_000_000_000.0
                val tps = totalTokens / durationSec
                
                activityManager.getMemoryInfo(memInfo)
                val memUsed = (startMem - memInfo.availMem) / (1024 * 1024)
                
                // Result would be passed back via a callback or Flow
            }
        }
        // Note: In actual implementation, use a CompletableDeferred to return the metrics
        return BenchmarkMetrics(0, 0.0, 0) 
    }
}
