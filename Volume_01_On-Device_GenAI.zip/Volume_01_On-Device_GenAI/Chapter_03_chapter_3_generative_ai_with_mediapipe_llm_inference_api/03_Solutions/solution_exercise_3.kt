
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

data class ChatMessage(val role: Role, val content: String)
enum class Role { USER, ASSISTANT }
data class Persona(val name: String, val traits: String, val goal: String)

@Singleton
class ConversationRepository @Inject constructor() {
    private val history = mutableListOf<ChatMessage>()
    
    fun addMessage(message: ChatMessage) { history.add(message) }
    
    fun getSlidingWindow(windowSize: Int = 10): List<ChatMessage> {
        return history.takeLast(windowSize)
    }
}

@Singleton
class RoleplayManager @Inject constructor(
    private val llmInference: LlmInference,
    private val repository: ConversationRepository
) {
    private val currentPersona = Persona("Grumpy Baker", "irritable, short-tempered", "Sell bread but act annoyed")

    fun generatePersonaResponse(userInput: String): String {
        val window = repository.getSlidingWindow()
        
        // Dynamic Prompt Construction
        val prompt = buildString {
            append("System: You are ${currentPersona.name}. Traits: ${currentPersona.traits}. Goal: ${currentPersona.goal}\n")
            window.forEach { msg ->
                append("${msg.role}: ${msg.content}\n")
            }
            append("User: $userInput\nAssistant: ")
        }

        val response = llmInference.generateResponse(prompt)
        repository.addMessage(ChatMessage(Role.USER, userInput))
        repository.addMessage(ChatMessage(Role.ASSISTANT, response))
        return response
    }
}
