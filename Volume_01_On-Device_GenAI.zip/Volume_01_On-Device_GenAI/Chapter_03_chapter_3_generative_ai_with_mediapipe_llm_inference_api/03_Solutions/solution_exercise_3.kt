
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

enum class ReplyTone(val instruction: String) {
    PROFESSIONAL("Use a formal, polite, and professional tone."),
    CASUAL("Use a friendly, relaxed, and casual tone.")
}

data class Message(val sender: String, val text: String)

@HiltViewModel
class SmartReplyViewModel @Inject constructor(
    private val llmInference: LlmInference
) : ViewModel() {

    private val conversationHistory = mutableListOf<Message>()
    var currentTone = MutableStateFlow(ReplyTone.PROFESSIONAL)
    
    private val _suggestions = MutableStateFlow<List<String>>(emptyList())
    val suggestions = _suggestions.asStateFlow()

    fun addMessage(message: Message) {
        conversationHistory.add(message)
        // Keep only last 3 messages for context window efficiency
        if (conversationHistory.size > 3) conversationHistory.removeAt(0)
        generateSuggestions()
    }

    fun toggleTone(tone: ReplyTone) {
        currentTone.value = tone
        generateSuggestions()
    }

    private fun generateSuggestions() {
        viewModelScope.launch(Dispatchers.Default) {
            val historyString = conversationHistory.joinToString("\n") { "${it.sender}: ${it.text}" }
            val prompt = """
                ${currentTone.value.instruction}
                Based on the conversation below, suggest 3 short replies (under 15 words each).
                Separate each suggestion with a pipe symbol (|).
                
                Conversation:
                $historyString
                Suggested Replies:
            """.trimIndent()

            val rawResponse = llmInference.generateResponse(prompt)
            // Post-processing: Split by pipe and clean whitespace
            val parsedReplies = rawResponse.split("|")
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .take(3)
            
            _suggestions.value = parsedReplies
        }
    }
}
