
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.analysis

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.ViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. LLM Inference Manager: Wraps the MediaPipe API.
 * Handles the low-level configuration and hardware delegation.
 */
@Singleton
class LlmInferenceManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model lazily to avoid blocking app startup
    suspend fun initializeModel(modelPath: String) = withContext(Dispatchers.IO) {
        if (llmInference != null) return@withContext

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .setTemperature(0.7f) // Balance between creativity and precision
            .setTopK(40)
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
        Log.d("LLM_MANAGER", "Model initialized successfully on hardware.")
    }

    /**
     * Generates a response using a streaming approach to avoid UI freezes.
     * Uses Dispatchers.Default for heavy CPU/GPU orchestration.
     */
    fun generateResponse(prompt: String): Flow<String> = flow {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // MediaPipe's generateResponse can be blocking or callback-based.
        // We wrap the streaming logic into a Kotlin Flow.
        val result = inference.generateResponse(prompt)
        emit(result)
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * 2. Repository: Handles business logic, prompt engineering, and text chunking.
 */
@Singleton
class DocumentAnalysisRepository @Inject constructor(
    private val llmManager: LlmInferenceManager
) {
    // System prompt to constrain the LLM to act as an action-item extractor
    private val SYSTEM_PROMPT = "You are a professional assistant. Extract only the action items " +
            "and deadlines from the following text. Format as a bulleted list. " +
            "If no action items exist, say 'No actions found'.\n\nText: "

    suspend fun extractActionItems(rawText: String): Flow<String> {
        // Logic for handling context window limits (Chunking)
        // In a real app, if rawText > 4096 tokens, we would split it here.
        val finalPrompt = "$SYSTEM_PROMPT $rawText"
        return llmManager.generateResponse(finalPrompt)
    }

    suspend fun ensureModelLoaded(path: String) {
        llmManager.initializeModel(path)
    }
}

/**
 * 3. ViewModel: Manages UI state and structured concurrency.
 */
@HiltViewModel
class AnalysisViewModel @Inject constructor(
    private val repository: DocumentAnalysisRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AnalysisUiState>(AnalysisUiState.Idle)
    val uiState: StateFlow<AnalysisUiState> = _uiState.asStateFlow()

    fun analyzeDocument(text: String, modelPath: String) {
        viewModelScope.launch {
            _uiState.value = AnalysisUiState.Loading
            
            try {
                // Ensure model is ready before starting inference
                repository.ensureModelLoaded(modelPath)
                
                var accumulatedText = ""
                repository.extractActionItems(text).collect { chunk ->
                    accumulatedText += chunk
                    _uiState.value = AnalysisUiState.Success(accumulatedText)
                }
            } catch (e: Exception) {
                Log.e("ANALYSIS_VM", "Inference failed", e)
                _uiState.value = AnalysisUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }
}

sealed class AnalysisUiState {
    object Idle : AnalysisUiState()
    object Loading : AnalysisUiState()
    data class Success(val result: String) : AnalysisUiState()
    data class Error(val message: String) : AnalysisUiState()
}

/**
 * 4. Hilt Module for DI
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    // LlmInferenceManager is provided as a Singleton to prevent 
    // reloading the multi-gigabyte model on every screen rotation.
}
