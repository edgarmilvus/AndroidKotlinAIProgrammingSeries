
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.genai.summarizer

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.provided.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton as HiltSingleton

/**
 * 1. Hardware Orchestration Layer
 * This repository manages the heavy LlmInference instance.
 * On-device LLMs are memory-heavy; we must ensure only one instance exists.
 */
@HiltSingleton
class LlmRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null
    private val modelPath = "/data/local/tmp/gemini_nano.bin" // Path to the .bin model

    // Initialize the model. This is a blocking call and must be handled on a background thread.
    suspend fun initializeModel() = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(1024)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()
            
            llmInference = LlmInference.createFromOptions(context, options)
            Log.d("LlmRepo", "Model loaded successfully on hardware accelerator.")
        }
    }

    /**
     * Generates a summary using a structured prompt.
     * Uses a Flow to allow for potential streaming updates.
     */
    fun summarizeText(input: String): Flow<Result<String>> = flow {
        try {
            val inference = llmInference ?: throw IllegalStateException("Model not initialized")
            
            // Constructing a 'System Prompt' for the local model to ensure consistency
            val prompt = "Summarize the following text concisely in 3 bullet points:\n\n$input"
            
            // MediaPipe's generateResponse is synchronous. 
            // We move it to Dispatchers.Default to avoid blocking the calling thread.
            val response = withContext(Dispatchers.Default) {
                inference.generateResponse(prompt)
            }
            emit(Result.success(response))
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * 2. State Management Layer (ViewModel)
 * Implements MVI pattern to handle UI states: Idle, Loading, Success, Error.
 */
sealed class SummarizerUiState {
    object Idle : SummarizerUiState()
    object Loading : SummarizerUiState()
    data class Success(val summary: String) : SummarizerUiState()
    data class Error(val message: String) : SummarizerUiState()
}

@HiltViewModel
class SummarizerViewModel @Inject constructor(
    private val repository: LlmRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<SummarizerUiState>(SummarizerUiState.Idle)
    val uiState: StateFlow<SummarizerUiState> = _uiState.asStateFlow()

    fun onSummarizeClicked(text: String) {
        if (text.isBlank()) return

        // Structured Concurrency: launch in viewModelScope to prevent leaks
        viewModelScope.launch {
            _uiState.value = SummarizerUiState.Loading
            
            try {
                // Ensure model is ready before inference
                repository.initializeModel()
                
                repository.summarizeText(text)
                    .collect { result ->
                        result.fold(
                            onSuccess = { summary ->
                                _uiState.value = SummarizerUiState.Success(summary)
                            },
                            onFailure = { error ->
                                _uiState.value = SummarizerUiState.Error(error.localizedMessage ?: "Unknown Error")
                            }
                        )
                    }
            } catch (e: Exception) {
                _uiState.value = SummarizerUiState.Error("Initialization failed: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Clean up native memory to prevent leaks
        repository.close()
    }
}

/**
 * 3. Dependency Injection Module
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @HiltSingleton
    fun provideLlmRepository(@ApplicationContext context: Context): LlmRepository {
        return LlmRepository(context)
    }
}
