
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

/**
 * Dependencies for a production-ready Vector Repository
 * implementation "androidx.room:room-runtime:2.6.1"
 * implementation "org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0"
 * implementation "com.google.android.gms:play-services-aicore:1.0.0-alpha" // Hypothetical
 */

// Value class to ensure type safety between raw floats and embeddings
@JvmInline
value class Embedding(val values: FloatArray)

interface VectorSearchRepository {
    /**
     * Converts text to a vector and finds the most similar items.
     * @param query The user input text
     * @param k The number of nearest neighbors to return
     */
    fun findSimilar(query: String, k: Int = 5): Flow<List<SearchResult>>

    /**
     * Indexes a piece of content. This involves:
     * 1. Generating an embedding via AICore.
     * 2. Storing the vector in the index.
     * 3. Linking the vector to the original content ID.
     */
    suspend fun indexContent(contentId: String, text: String)
}

data class SearchResult(
    val contentId: String,
    val score: Float, // Cosine similarity score
    val text: String
)
