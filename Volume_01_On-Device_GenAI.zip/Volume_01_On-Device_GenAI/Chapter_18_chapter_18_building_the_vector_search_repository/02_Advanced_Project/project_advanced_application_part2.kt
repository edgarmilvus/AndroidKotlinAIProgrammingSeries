
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.vectorsearch.core

import android.content.Context
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import kotlin.math.sqrt

/**
 * Data model representing a semantic document.
 * [vector] holds the high-dimensional embedding.
 * [metadata] holds the actual content and ID.
 */
data class SemanticDocument(
    val id: String,
    val content: String,
    val vector: FloatArray
)

/**
 * Result wrapper for search queries including the similarity score.
 */
data class SearchResult(
    val document: SemanticDocument,
    val score: Float // Cosine similarity score (0.0 to 1.0)
)

/**
 * Hardware-aware Embedding Generator.
 * Orchestrates the MediaPipe TextEmbedder to run on NPU/GPU.
 */
@Singleton
class EmbeddingGenerator @Inject constructor(
    private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null

    init {
        initializeEmbedder()
    }

    private fun initializeEmbedder() {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                BaseOptions.builder()
                    // CRITICAL: Force GPU/NPU delegation for low latency
                    .setDelegate(Delegate.GPU) 
                    .setModelAssetPath("universal_sentence_encoder.tflite")
                    .build()
            )
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    fun generateEmbedding(text: String): FloatArray {
        return textEmbedder?.embed(text)?.result() 
            ?: throw IllegalStateException("Embedder not initialized")
    }
}

/**
 * The Vector Repository: Handles the mathematical heavy lifting of 
 * similarity search and vector storage.
 */
@Singleton
class VectorSearchRepository @Inject constructor(
    private val embeddingGenerator: EmbeddingGenerator
) {
    // In-memory store for demonstration; in production, use a memory-mapped file or Vector DB
    private val vectorStore = mutableListOf<SemanticDocument>()
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * Adds a document to the repository by first generating its embedding.
     */
    suspend fun addDocument(id: String, content: String) = withContext(Dispatchers.Default) {
        val vector = embeddingGenerator.generateEmbedding(content)
        vectorStore.add(SemanticDocument(id, content, vector))
    }

    /**
     * Performs a Cosine Similarity search across the vector space.
     * Time Complexity: O(N * D) where N is number of docs and D is dimensionality.
     */
    fun search(query: String, limit: Int = 5): Flow<List<SearchResult>> = flow {
        val queryVector = embeddingGenerator.generateEmbedding(query)
        
        // Parallelize similarity calculation using chunks for large datasets
        val results = vectorStore.asSequence()
            .map { doc ->
                val similarity = calculateCosineSimilarity(queryVector, doc.vector)
                SearchResult(doc, similarity)
            }
            .sortedByDescending { it.score }
            .take(limit)
            .toList()
        
        emit(results)
    }.flowOn(Dispatchers.Default)

    /**
     * Mathematical implementation of Cosine Similarity.
     * Formula: (A · B) / (||A|| * ||B||)
     */
    private fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel implementing MVI-lite pattern to handle search state.
 */
@HiltViewModel
class SemanticSearchViewModel @Inject constructor(
    private val repository: VectorSearchRepository
) : androidx.lifecycle.ViewModel() {

    private val _searchState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchState: StateFlow<SearchUiState> = _searchState.asStateFlow()

    fun onQueryChanged(query: String) {
        if (query.isBlank()) {
            _searchState.value = SearchUiState.Idle
            return
        }

        viewModelScope.launch {
            _searchState.value = SearchUiState.Loading
            repository.search(query)
                .catch { e -> _searchState.value = SearchUiState.Error(e.message ?: "Unknown Error") }
                .collect { results ->
                    _searchState.value = SearchUiState.Success(results)
                }
        }
    }

    fun indexDocument(id: String, content: String) {
        viewModelScope.launch {
            repository.addDocument(id, content)
        }
    }
}

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val results: List<SearchResult>) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}

@Module
@InstallIn(SingletonComponent::class)
object VectorModule {
    @Provides
    @Singleton
    fun provideEmbeddingGenerator(@BindsInstance context: Context) = EmbeddingGenerator(context)
}
