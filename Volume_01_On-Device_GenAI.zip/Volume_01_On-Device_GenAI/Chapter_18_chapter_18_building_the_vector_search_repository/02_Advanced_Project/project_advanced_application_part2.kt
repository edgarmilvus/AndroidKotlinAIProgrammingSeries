
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.vectorsearch

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.text.text_embedder.TextEmbedder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate

// --- Data Layer ---

data class VectorDocument(
    val id: String,
    val content: String,
    val embedding: FloatArray
)

@Singleton
class VectorSearchRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null

    // Hardware-aware initialization of the Embedding Model
    suspend fun initializeEmbedder() = withContext(Dispatchers.Default) {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder()
                // Force GPU/NPU acceleration for embedding generation
                .setDelegate(Delegate.GPU) 
                .setModelAssetPath("embedding_model.tflite")
                .build())
            .build()
        textEmbedder = TextEmbedder.createFromOptions(context, options)
    }

    fun generateEmbedding(text: String): FloatArray {
        return textEmbedder?.embed(text) ?: throw IllegalStateException("Embedder not initialized")
    }

    /**
     * Performs a Cosine Similarity search across the local vector store.
     * In a production app, this would be a SQL query using a vector extension 
     * or a specialized library like FAISS (via JNI).
     */
    suspend fun findNearestNeighbors(queryEmbedding: FloatArray, documents: List<VectorDocument>, topK: Int = 3): List<VectorDocument> = withContext(Dispatchers.Default) {
        documents
            .map { doc -> doc to cosineSimilarity(queryEmbedding, doc.embedding) }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble())).toFloat()
    }
}

// --- Presentation Layer (MVI Pattern) ---

sealed class SearchUiState {
    object Idle : SearchUiState()
    object Loading : SearchUiState()
    data class Success(val results: List<VectorDocument>, val generatedAnswer: String) : SearchUiState()
    data class Error(val message: String) : SearchUiState()
}

@HiltViewModel
class SemanticSearchViewModel @Inject constructor(
    private val repository: VectorSearchRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    // Mock local database of documents
    private val localKnowledgeBase = listOf<VectorDocument>() 

    fun performSemanticSearch(query: String) {
        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            try {
                // 1. Initialize model if needed
                repository.initializeEmbedder()

                // 2. Generate embedding for the user query (Compute Intensive)
                val queryVector = withContext(Dispatchers.Default) {
                    repository.generateEmbedding(query)
                }

                // 3. Vector Search (NPU/GPU optimized via Repository)
                val contextDocs = repository.findNearestNeighbors(queryVector, localKnowledgeBase)

                // 4. RAG Integration: Combine context and query for Gemini Nano
                val augmentedPrompt = buildAugmentedPrompt(query, contextDocs)
                val finalAnswer = callGeminiNano(augmentedPrompt)

                _uiState.value = SearchUiState.Success(contextDocs, finalAnswer)
            } catch (e: Exception) {
                _uiState.value = SearchUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private fun buildAugmentedPrompt(query: String, docs: List<VectorDocument>): String {
        val context = docs.joinToString("\n") { it.content }
        return "Context: $context\n\nQuestion: $query\n\nAnswer using only the provided context:"
    }

    private suspend fun callGeminiNano(prompt: String): String = withContext(Dispatchers.Default) {
        // Integration with AICore / Gemini Nano would happen here
        "This is a simulated response from Gemini Nano based on the retrieved vectors."
    }
}
