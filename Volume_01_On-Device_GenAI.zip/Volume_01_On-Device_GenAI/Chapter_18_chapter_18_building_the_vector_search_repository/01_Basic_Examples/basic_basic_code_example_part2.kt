
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Data model representing a piece of text and its mathematical representation.
 */
data class VectorItem(
    val text: String,
    val embedding: FloatArray
)

/**
 * The Repository handles the "heavy lifting" of AI inference and vector math.
 */
@Singleton
class VectorSearchRepository @Inject constructor(context: Context) {
    
    // Initialize MediaPipe TextEmbedder
    private val textEmbedder: TextEmbedder = TextEmbedder.createFromOptions(
        context,
        TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(
                com.google.mediapipe.tasks.core.BaseOptions.builder()
                    .setModelAssetPath("universal_sentence_encoder.tflite") // Model must be in assets
                    .build()
            )
            .build()
    )

    private val vectorStore = mutableListOf<VectorItem>()

    /**
     * Converts text to a vector and saves it to the local store.
     */
    suspend fun addTextToRepository(text: String) = withContext(Dispatchers.Default) {
        val result: TextEmbedderResult = textEmbedder.embed(text)
        val embedding = result.embeddingResult().embeddings().get(0).floatArray()
        vectorStore.add(VectorItem(text, embedding))
    }

    /**
     * Performs a semantic search by comparing the query vector 
     * against all stored vectors using Cosine Similarity.
     */
    suspend fun search(query: String): List<Pair<String, Float>> = withContext(Dispatchers.Default) {
        val queryResult = textEmbedder.embed(query)
        val queryVector = queryResult.embeddingResult().embeddings().get(0).floatArray()

        vectorStore.map { item ->
            val similarity = calculateCosineSimilarity(queryVector, item.embedding)
            item.text to similarity
        }.sortedByDescending { it.second } // Highest similarity first
    }

    /**
     * Cosine Similarity = (A · B) / (||A|| * ||B||)
     * Measures the cosine of the angle between two vectors. 
     * 1.0 = identical direction, 0.0 = orthogonal, -1.0 = opposite.
     */
    private fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel manages the UI state and ensures AI work happens off the Main Thread.
 */
@HiltViewModel
class VectorViewModel @Inject constructor(
    private val repository: VectorSearchRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<Pair<String, Float>>>(emptyList())
    val searchResults: StateFlow<List<Pair<String, Float>>> = _searchResults.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun seedData() {
        viewModelScope.launch {
            _isProcessing.value = true
            repository.addTextToRepository("The capital of France is Paris.")
            repository.addTextToRepository("A golden retriever is a friendly dog.")
            repository.addTextToRepository("The Android SDK 34 introduces new accessibility features.")
            repository.addTextToRepository("Kotlin is a modern language for JVM.")
            _isProcessing.value = false
        }
    }

    fun performSearch(query: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val results = repository.search(query)
            _searchResults.value = results
            _isProcessing.value = false
        }
    }
}

/**
 * Simple Compose UI to interact with the Vector Repository.
 */
@AndroidEntryPoint
@Composable
fun VectorSearchScreen(viewModel: VectorViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var queryText by remember { mutableStateOf("") }
    val results by viewModel.searchResults.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Semantic Search", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = queryText,
            onValueChange = { queryText = it },
            label = { Text("Search (e.g., 'Tell me about puppies')") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.performSearch(queryText) },
            modifier = Modifier.padding(vertical = 8.dp),
            enabled = !isProcessing
        ) {
            Text(if (isProcessing) "Processing..." else "Search")
        }

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        LazyColumn {
            items(results) { (text, score) ->
                ListItem(
                    headlineContent = { Text(text) },
                    supportingContent = { Text("Similarity Score: ${"%.4f".format(score)}") }
                )
            }
        }
    }
}
