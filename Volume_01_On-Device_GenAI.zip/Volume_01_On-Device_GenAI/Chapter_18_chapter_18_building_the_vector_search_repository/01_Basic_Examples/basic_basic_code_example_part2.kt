
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.ondeviceai.vectorsearch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * 1. DATA MODEL
 * Represents a piece of content and its corresponding embedding.
 * In a real app, the 'id' would link to a database row in Room.
 */
data class VectorItem(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val embedding: FloatArray
) {
    // Override equals/hashCode because FloatArray uses referential equality
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VectorItem) return false
        return id == other.id
    }
    override fun hashCode(): Int = id.hashCode()
}

/**
 * 2. SEARCH ENGINE (The Mathematical Core)
 * This class handles the heavy lifting of linear algebra.
 */
@Singleton
class VectorSearchEngine @Inject constructor() {

    /**
     * Calculates the Cosine Similarity between two vectors.
     * Result is between -1.0 and 1.0.
     */
    fun calculateCosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        require(vectorA.size == vectorB.size) { "Vectors must have the same dimensionality" }

        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f

        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }

        val denominator = sqrt(normA) * sqrt(normB)
        return if (denominator == 0.0f) 0.0f else dotProduct / denominator
    }
}

/**
 * 3. THE REPOSITORY
 * Manages the storage and retrieval of vectors.
 * In this basic example, we use an in-memory list. In production, 
 * this would interface with a SQLite/Room database storing BLOBs of floats.
 */
@Singleton
class VectorRepository @Inject constructor(
    private val searchEngine: VectorSearchEngine
) {
    // Mock database of embeddings
    private val vectorStore = mutableListOf<VectorItem>()

    /**
     * Adds a new item to the local vector store.
     */
    fun addVector(content: String, embedding: FloatArray) {
        vectorStore.add(VectorItem(content = content, embedding = embedding))
    }

    /**
     * Performs a semantic search.
     * @param queryVector The embedding of the user's search query.
     * @param topK The number of results to return.
     */
    suspend fun search(queryVector: FloatArray, topK: Int = 5): List<Pair<VectorItem, Float>> = 
        withContext(Dispatchers.Default) {
            // 1. Calculate similarity for every item in the store (Linear Scan)
            vectorStore.map { item ->
                val similarity = searchEngine.calculateCosineSimilarity(queryVector, item.embedding)
                item to similarity
            }
            // 2. Sort by similarity descending (highest similarity first)
            .sortedByDescending { it.second }
            // 3. Take the top K results
            .take(topK)
        }
}

/**
 * 4. THE VIEWMODEL
 * Bridges the UI and the Repository. Handles threading and state.
 */
class SearchViewModel @Inject constructor(
    private val repository: VectorRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<Pair<VectorItem, Float>>>(emptyList())
    val searchResults: StateFlow<List<Pair<VectorItem, Float>>> = _searchResults

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching

    /**
     * Simulates the end-to-end process:
     * Input Text -> (Mock) Embedding -> Vector Search -> UI Update
     */
    fun performSearch(queryText: String) {
        viewModelScope.launch {
            _isSearching.value = true
            
            // SIMULATION: In a real app, you would call MediaPipe or Gemini Nano here
            // to convert 'queryText' into a FloatArray.
            val mockQueryVector = simulateEmbeddingGeneration(queryText)

            // Perform the search on Dispatchers.Default (via the repository)
            val results = repository.search(mockQueryVector)
            
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    /**
     * Mock function to simulate a GenAI embedding model.
     * Real models usually return 384, 768, or 1536 dimensions.
     */
    private fun simulateEmbeddingGeneration(text: String): FloatArray {
        // We create a deterministic pseudo-random vector based on the text hash
        val random = Random(text.hashCode().toLong())
        return FloatArray(128) { random.nextFloat() }
    }

    /**
     * Pre-populate the repository with some dummy data for the demo.
     */
    fun seedData() {
        val samples = listOf(
            "The golden retriever is a friendly dog",
            "The skyscraper reaches the clouds",
            "Puppies love to play with balls",
            "The architecture of the Burj Khalifa is stunning",
            "Cats are independent pets"
        )
        samples.forEach { text ->
            repository.addVector(text, simulateEmbeddingGeneration(text))
        }
    }
}

/**
 * 5. JETPACK COMPOSE UI
 */
@Composable
fun VectorSearchScreen(viewModel: SearchViewModel) {
    var query by remember { mutableStateOf("") }
    val results by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "On-Device Semantic Search", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search (e.g., 'puppies')") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.performSearch(query) },
            modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth(),
            enabled = !isSearching
        ) {
            Text(if (isSearching) "Searching..." else "Semantic Search")
        }

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        LazyColumn {
            items(results) { (item, score) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = item.content, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = "Similarity: ${"%.4f".format(score)}", 
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

// Hilt Application and Activity setup omitted for brevity, 
// but assume @HiltAndroidApp and @AndroidEntryPoint are used.
