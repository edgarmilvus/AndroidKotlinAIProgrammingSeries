
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

@Fts4(contentEntity = EmailEntity::class)
@Entity(tableName = "emails_fts")
data class EmailFtsEntity(val content: String)

class HybridSearchRepository(
    private val ftsDao: EmailFtsDao,
    private val vectorRepo: SemanticRepository
) {
    suspend fun hybridSearch(query: String, semanticWeight: Float = 1.0f, lexicalWeight: Float = 1.0f): List<EmailEntity> = withContext(Dispatchers.Default) {
        // 1. Lexical Path (FTS5)
        val lexicalResults = ftsDao.searchKeyword(query) // Returns sorted list
        
        // 2. Semantic Path (Vector)
        val semanticResults = vectorRepo.findSimilarNotes(query) // Returns sorted list

        // 3. Reciprocal Rank Fusion (RRF)
        val scores = mutableMapOf<Int, Float>()
        val k = 60f

        lexicalResults.forEachIndexed { rank, email ->
            val currentScore = scores.getOrDefault(email.id, 0f)
            scores[email.id] = currentScore + (lexicalWeight / (k + rank + 1))
        }

        semanticResults.forEachIndexed { rank, email ->
            val currentScore = scores.getOrDefault(email.id, 0f)
            scores[email.id] = currentScore + (semanticWeight / (k + rank + 1))
        }

        // Return emails sorted by fused score
        scores.entries
            .sortedByDescending { it.value }
            .map { entry -> fetchEmailById(entry.key) }
    }

    private suspend fun fetchEmailById(id: Int): EmailEntity = ftsDao.getEmailById(id)
}
