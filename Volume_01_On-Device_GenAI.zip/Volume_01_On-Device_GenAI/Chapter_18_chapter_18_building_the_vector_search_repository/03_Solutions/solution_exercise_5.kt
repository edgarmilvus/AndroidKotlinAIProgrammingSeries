
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

data class HybridResult(val doc: DocumentEntity, val score: Float, val matchType: MatchType)
enum class MatchType { KEYWORD, SEMANTIC, HYBRID }

class HybridSearchRepository(
    private val documentDao: DocumentDao,
    private val vectorRepo: VectorSearchRepository
) {
    suspend fun hybridSearch(query: String, queryVector: FloatArray): List<HybridResult> {
        // Path A: Keyword Search (SQL LIKE)
        val keywordResults = documentDao.searchKeywords("%$query%") // Assume DAO has this
        
        // Path B: Semantic Search
        val semanticResults = vectorRepo.searchSimilarDocuments(queryVector, limit = 20)

        // Reciprocal Rank Fusion (RRF)
        val k = 60f
        val scores = mutableMapOf<Int, Float>()
        val metadata = mutableMapOf<Int, MatchType>()

        // Rank keyword results: 1/ (k + rank)
        keywordResults.forEachIndexed { index, doc ->
            scores[doc.id] = scores.getOrDefault(doc.id, 0f) + (1f / (k + index + 1))
            metadata[doc.id] = MatchType.KEYWORD
        }

        // Rank semantic results: 1/ (k + rank)
        semanticResults.forEachIndexed { index, (doc, _) ->
            scores[doc.id] = scores.getOrDefault(doc.id, 0f) + (1f / (k + index + 1))
            metadata[doc.id] = if (metadata.containsKey(doc.id)) MatchType.HYBRID else MatchType.SEMANTIC
        }

        // Merge and return
        return scores.map { (id, score) ->
            val doc = documentDao.getDocumentById(id)!!
            HybridResult(doc, score, metadata[id]!!)
        }.sortedByDescending { it.score }
    }
}

@Composable
fun HybridResultItem(result: HybridResult) {
    Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Text(result.doc.text, modifier = Modifier.weight(1f))
        
        // UI Badge based on match type
        Surface(
            color = when(result.matchType) {
                MatchType.KEYWORD -> Color.Blue
                MatchType.SEMANTIC -> Color.Green
                MatchType.HYBRID -> Color.Magenta
            },
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                text = result.matchType.name,
                modifier = Modifier.padding(horizontal = 4.dp),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
