
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import androidx.work.*
import java.io.File

// Entity to link Image URI to its Vector
@Entity(tableName = "image_vectors")
data class ImageVectorEntity(
    @PrimaryKey val uri: String,
    val embedding: FloatArray
)

// Background Worker for Gallery Indexing
class GalleryIndexingWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val imageEmbedder = ImageEmbedderWrapper(applicationContext) 
            val galleryImages = fetchGalleryUris() // Helper to get all image URIs

            galleryImages.forEach { uri ->
                val bitmap = loadBitmapFromUri(uri)
                val vector = imageEmbedder.embed(bitmap)
                // Store in Room (assuming NoteDao/Database from Ex 1)
                database.imageDao().insert(ImageVectorEntity(uri.toString(), vector))
            }
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}

class CrossModalRepository(
    private val imageDao: ImageVectorDao,
    private val textEmbedder: TextEmbedderWrapper
) {
    suspend fun searchImages(query: String, topK: Int = 10): List<String> = withContext(Dispatchers.Default) {
        val queryVector = textEmbedder.embed(query)
        val allImageVectors = imageDao.getAllVectors() // Returns List<ImageVectorEntity>

        allImageVectors
            .map { it.uri to dotProduct(queryVector, it.embedding) } // Assuming pre-normalized vectors
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    private fun dotProduct(vecA: FloatArray, vecB: FloatArray): Float {
        var sum = 0f
        for (i in vecA.indices) sum += vecA[i] * vecB[i]
        return sum
    }
}
