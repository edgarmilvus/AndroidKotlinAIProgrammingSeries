
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class ChunkingEngine {
    fun recursiveChunk(text: String, chunkSize: Int = 500, overlap: Int = 50): List<String> {
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            val end = (start + chunkSize).coerceAtMost(text.length)
            chunks.add(text.substring(start, end))
            start += (chunkSize - overlap)
        }
        return chunks
    }
}

class RAGRepository(
    private val vectorStore: SemanticRepository, 
    private val geminiNano: GeminiNanoClient // AICore Wrapper
) {
    suspend fun answerQuestion(question: String): RAGResponse = withContext(Dispatchers.Default) {
        // 1. Retrieval
        val relevantChunks = vectorStore.findSimilarNotes(question, topK = 3)
        
        if (relevantChunks.isEmpty()) {
            return@withContext RAGResponse("I couldn't find any relevant information in the manual.", emptyList())
        }

        // 2. Augmentation (Prompt Engineering)
        val context = relevantChunks.joinToString("\n\n") { it.content }
        val prompt = """
            Context: 
            $context
            
            Question: $question
            
            Instruction: Answer the question using ONLY the provided context. 
            If the answer is not present, say "I don't know". Do not use external knowledge.
        """.trimIndent()

        // 3. Generation
        val answer = geminiNano.generateText(prompt)
        RAGResponse(answer, relevantChunks)
    }
}

data class RAGResponse(val answer: String, val sources: List<NoteEntity>)
