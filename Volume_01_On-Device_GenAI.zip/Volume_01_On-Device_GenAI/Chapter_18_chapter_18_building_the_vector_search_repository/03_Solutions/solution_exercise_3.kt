
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// Hilt Module for Dependency Injection
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideTextEmbedder(@ApplicationContext context: Context): TextEmbedder {
        val options = TextEmbedder.TextEmbedderOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("universal_sentence_encoder.tflite").build())
            .build()
        return TextEmbedder.createFromOptions(context, options)
    }
}

// ViewModel handling the pipeline
@HiltViewModel
class NoteSearchViewModel @Inject constructor(
    private val embedder: TextEmbedder,
    private val repository: VectorSearchRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults

    data class SearchResult(val note: DocumentEntity, val score: Float)

    fun performSearch(query: String) {
        viewModelScope.launch(Dispatchers.Default) {
            // 1. Convert query text to vector
            val queryVector = embedder.embed(query).embedding
            
            // 2. Perform vector search in repository
            val results = repository.searchSimilarDocuments(queryVector)
            
            // 3. Map to UI state
            _searchResults.value = results.map { (doc, score) -> 
                SearchResult(doc, score) 
            }
        }
    }
}

// Compose UI Integration
@Composable
fun SemanticSearchScreen(viewModel: NoteSearchViewModel = hiltViewModel()) {
    var query by remember { mutableStateOf("") }
    val results by viewModel.searchResults.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search notes semantically...") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = { viewModel.performSearch(query) }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
            }
        )
        
        LazyColumn {
            items(results) { result ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(result.note.text, modifier = Modifier.weight(1f))
                    Text(
                        text = "${(result.score * 100).toInt()}% match",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
