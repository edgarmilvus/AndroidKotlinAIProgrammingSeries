
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

class VectorQuantizer(private val min: Float, private val max: Float) {
    fun quantize(vector: FloatArray): ByteArray {
        val bytes = ByteArray(vector.size)
        for (i in vector.indices) {
            val normalized = (vector[i] - min) / (max - min)
            bytes[i] = (normalized * 255).toInt().coerceIn(0, 255).toByte()
        }
        return bytes
    }

    fun dequantize(bytes: ByteArray): FloatArray {
        val floats = FloatArray(bytes.size)
        for (i in bytes.indices) {
            val unsignedByte = bytes[i].toInt() and 0xFF
            floats[i] = (unsignedByte / 255f) * (max - min) + min
        }
        return floats
    }
}

class IVFIndex(private val centroids: List<FloatArray>) {
    private val clusters = mutableMapOf<Int, MutableList<Int>>() // Centroid ID -> List of Vector IDs

    fun addVector(vectorId: Int, vector: FloatArray) {
        val nearestCentroid = findNearestCentroid(vector)
        clusters.getOrPut(nearestCentroid) { mutableListOf() }.add(vectorId)
    }

    private fun findNearestCentroid(vector: FloatArray): Int {
        return centroids.indices.maxByOrNull { i -> 
            dotProduct(vector, centroids[i]) 
        } ?: 0
    }

    fun search(queryVector: FloatArray, allVectors: List<FloatArray>, topK: Int): List<Int> {
        val centroidId = findNearestCentroid(queryVector)
        val candidateIds = clusters[centroidId] ?: return emptyList()
        
        return candidateIds
            .map { id -> id to dotProduct(queryVector, allVectors[id]) }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }
    
    private fun dotProduct(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) sum += a[i] * b[i]
        return sum
    }
}
