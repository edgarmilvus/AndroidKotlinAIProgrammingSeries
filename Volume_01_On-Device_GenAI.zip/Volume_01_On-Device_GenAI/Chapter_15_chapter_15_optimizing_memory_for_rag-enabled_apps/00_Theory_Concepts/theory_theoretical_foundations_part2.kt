
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Context Receiver definition to ensure AI operations 
 * only happen within a managed AI scope.
 */
interface AIModelContext {
    val modelHandle: Any // Reference to the loaded Gemini Nano instance
    fun releaseResources()
}

@Singleton
class RAGMemoryManager @Inject constructor(
    private val vectorDb: LocalVectorDatabase,
    private val embeddingModel: EmbeddingModel,
    private val aiCoreClient: AICoreClient
) {
    // Use a limited parallelism dispatcher to prevent CPU thrashing
    private val aiDispatcher = Dispatchers.Default.limitedParallelism(2)

    /**
     * Processes a RAG query with strict memory constraints.
     * Uses Flow to stream results, reducing peak heap usage.
     */
    fun generateRAGResponse(query: String): Flow<String> = flow {
        withContext(aiDispatcher) {
            // 1. Embedding Stage: Convert query to vector
            // We use a 'runCatching' block to handle potential OOMs during tensor allocation
            val queryVector = runCatching { 
                embeddingModel.embed(query) 
            }.getOrElse { 
                throw MemoryPressureException("Failed to allocate tensor for embedding") 
            }

            // 2. Retrieval Stage: Fetch top-k relevant chunks
            // We limit 'k' to avoid bloating the KV cache
            val contextChunks = vectorDb.searchSimilar(queryVector, k = 3)
            val augmentedPrompt = buildAugmentedPrompt(query, contextChunks)

            // 3. Generation Stage: Stream tokens from AICore
            aiCoreClient.generateStream(augmentedPrompt)
                .collect { token ->
                    emit(token)
                }
        }
    }.flowOn(aiDispatcher)

    private fun buildAugmentedPrompt(query: String, chunks: List<String>): String {
        // Memory optimization: Truncate chunks to fit within a safe token limit
        // to prevent the KV cache from exploding.
        val truncatedContext = chunks.joinToString("\n") { it.take(500) }
        return "Context:\n$truncatedContext\n\nQuestion: $query\nAnswer:"
    }
}

/**
 * Custom exception to handle AI-specific memory pressure
 */
class MemoryPressureException(message: String) : Exception(message)

// Implementation of the AIModelContext using Kotlin 2.x context receivers
context(AIModelContext)
fun performInference(prompt: String) {
    // This function can only be called where AIModelContext is available
    println("Using model handle: ${modelHandle} to process $prompt")
}
