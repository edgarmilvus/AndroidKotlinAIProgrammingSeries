
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

@Singleton
class LocalVectorStore @Inject constructor() {
    private val dimension = 384 // Dimension for All-MiniLM-L6-v2
    private val maxMemoryBytes = 50 * 1024 * 1024 // 50MB Budget
    private val floatSize = 4 // 4 bytes per float
    
    // Track how many vectors are currently stored
    private var vectorCount = 0
    
    // Allocate memory in the native heap to avoid GC overhead
    private val vectorBuffer: ByteBuffer = ByteBuffer.allocateDirect(maxMemoryBytes)
        .order(ByteOrder.nativeOrder())

    /**
     * Adds a vector to the native buffer if space permits.
     * Returns true if successful, false if memory budget is exceeded.
     */
    fun addVector(vector: FloatArray): Boolean {
        require(vector.size == dimension) { "Vector dimension must be $dimension" }
        
        val bytesNeeded = dimension * floatSize
        if ((vectorCount * bytesNeeded) + bytesNeeded > maxMemoryBytes) {
            return false // Budget exceeded
        }

        // Position the buffer at the end of the existing vectors
        vectorBuffer.position(vectorCount * bytesNeeded)
        
        // Bulk put from FloatArray to ByteBuffer
        // Note: asFloatBuffer() provides a view for easier float manipulation
        vectorBuffer.asFloatBuffer().put(vector)
        
        vectorCount++
        return true
    }

    /**
     * Performs a Cosine Similarity search directly on the ByteBuffer.
     * Returns the index of the most similar vector.
     */
    fun findMostSimilar(queryVector: FloatArray): Int {
        require(queryVector.size == dimension) { "Query vector dimension must be $dimension" }
        
        var bestIndex = -1
        var maxSimilarity = -1.0f

        // Pre-calculate query norm for cosine similarity
        val queryNorm = sqrt(queryVector.fold(0f) { acc, v -> acc + v * v })

        for (i in 0 until vectorCount) {
            val offset = i * dimension * floatSize
            var dotProduct = 0f
            var vectorNormSq = 0f

            // Access the native buffer directly without creating a FloatArray object
            for (d in 0 until dimension) {
                val value = vectorBuffer.getFloat(offset + (d * floatSize))
                dotProduct += value * queryVector[d]
                vectorNormSq += value * value
            }

            val similarity = dotProduct / (queryNorm * sqrt(vectorNormSq))
            
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                bestIndex = i
            }
        }

        return bestIndex
    }

    fun getStoredCount() = vectorCount
}
