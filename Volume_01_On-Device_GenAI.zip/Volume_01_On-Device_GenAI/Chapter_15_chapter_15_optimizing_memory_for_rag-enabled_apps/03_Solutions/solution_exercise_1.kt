
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.util.LruCache
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

data class CachedContext(
    val embedding: FloatArray,
    val chunks: List<String>
)

@Singleton
class SemanticCacheManager @Inject constructor() {
    // Limit cache to 50 entries to prevent OOM
    private val cache = LruCache<Int, CachedContext>(50)
    private val similarityThreshold = 0.95f

    fun getCachedContext(queryEmbedding: FloatArray): List<String>? {
        // Iterate through cache values to find a semantically similar query
        val snapshot = cache.snapshot().values
        for (entry in snapshot) {
            if (cosineSimilarity(queryEmbedding, entry.embedding) >= similarityThreshold) {
                return entry.chunks
            }
        }
        return null
    }

    fun putContext(key: Int, queryEmbedding: FloatArray, chunks: List<String>) {
        cache.put(key, CachedContext(queryEmbedding, chunks))
    }

    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return if (normA == 0f || normB == 0f) 0f 
               else dotProduct / (sqrt(normA) * sqrt(normB))
    }
}
