
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.io.File

class MmapVectorIndex(private val indexFile: File, private val dimensions: Int) : AutoCloseable {
    private val raf = RandomAccessFile(indexFile, "r")
    private val buffer: MappedByteBuffer = raf.channel.map(
        FileChannel.MapMode.READ_ONLY, 0, raf.length()
    )

    fun getVector(index: Int): FloatArray {
        val floatArray = FloatArray(dimensions)
        val position = index * dimensions * 4 // 4 bytes per float
        
        // Read from buffer without loading whole file into heap
        for (i in 0 until dimensions) {
            floatArray[i] = buffer.getFloat(position + (i * 4))
        }
        return floatArray
    }

    fun calculateCosineSimilarity(queryVector: FloatArray, index: Int): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        val position = index * dimensions * 4

        for (i in 0 until dimensions) {
            val vectorVal = buffer.getFloat(position + (i * 4))
            val queryVal = queryVector[i]
            
            dotProduct += queryVal * vectorVal
            normA += queryVal * queryVal
            normB += vectorVal * vectorVal
        }
        return dotProduct / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
    }

    override fun close() {
        raf.close()
        // Note: MappedByteBuffer cleaning is handled by GC/OS, 
        // but closing the channel is best practice.
    }
}

// Utility to save embeddings to binary file
fun saveEmbeddingsToBinary(file: File, vectors: List<FloatArray>) {
    file.outputStream().use { os ->
        val buffer = java.nio.ByteBuffer.allocate(4096)
        vectors.forEach { vector ->
            vector.forEach { float ->
                if (buffer.remaining() < 4) {
                    os.write(buffer.array(), 0, buffer.position())
                    buffer.clear()
                }
                buffer.putFloat(float)
            }
        }
        os.write(buffer.array(), 0, buffer.position())
    }
}
