
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlin.math.roundToInt

class QuantizedVectorStore {
    data class QuantizedVector(
        val data: ByteArray,
        val scale: Float,
        val zeroPoint: Byte
    )

    private val storage = mutableListOf<QuantizedVector>()
    private val dimension = 384

    /**
     * Quantizes a FloatArray into a QuantizedVector using Linear Quantization.
     * Formula: q = round(f / scale) + zeroPoint
     */
    fun addVector(vector: FloatArray) {
        var min = Float.MAX_VALUE
        var max = Float.MIN_VALUE
        
        for (v in vector) {
            if (v < min) min = v
            if (v > max) max = v
        }

        // Calculate scale: map [min, max] to [0, 255]
        val scale = (max - min) / 255f
        val zeroPoint = (0f - min / scale).roundToInt().coerceIn(-128, 127).toByte()

        val quantizedData = ByteArray(dimension) { i ->
            val q = ((vector[i] / scale) + zeroPoint).roundToInt()
            q.coerceIn(-128, 127).toByte()
        }

        storage.add(QuantizedVector(quantizedData, scale, zeroPoint))
    }

    /**
     * Calculates similarity using the quantized dot product.
     */
    fun calculateSimilarity(q1: QuantizedVector, q2: QuantizedVector): Float {
        var dotProduct = 0L // Use Long to prevent overflow during summation
        
        for (i in 0 until dimension) {
            // Convert signed bytes to unsigned integers (0-255) for the math
            val v1 = q1.data[i].toInt() and 0xFF
            val v2 = q2.data[i].toInt() and 0xFF
            dotProduct += (v1 * v2)
        }

        // De-quantize the result: The dot product of quantized vectors 
        // is proportional to the dot product of the original floats.
        return dotProduct.toFloat() * (q1.scale * q2.scale)
    }
    
    fun getMemoryUsageBytes(): Long {
        return storage.sumOf { it.data.size + 4 + 1 }.toLong()
    }
}
