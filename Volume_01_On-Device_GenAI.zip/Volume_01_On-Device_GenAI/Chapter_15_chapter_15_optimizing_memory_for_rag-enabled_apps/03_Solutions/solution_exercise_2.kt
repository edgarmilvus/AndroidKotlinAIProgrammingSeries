
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import kotlin.math.roundToInt

class QuantizedVectorStore {
    data class QuantizedVector(val data: ByteArray, val min: Float, val max: Float)

    fun quantize(vector: FloatArray): QuantizedVector {
        val min = vector.minOrNull() ?: 0f
        val max = vector.maxOrNull() ?: 1f
        val range = max - min
        
        val quantized = ByteArray(vector.size) { i ->
            if (range == 0f) 0.toByte() 
            else {
                // Map [min, max] to [-128, 127]
                val scaled = ((vector[i] - min) / range) * 255f - 128f
                scaled.roundToInt().coerceIn(-128, 127).toByte()
            }
        }
        return QuantizedVector(quantized, min, max)
    }

    fun dequantize(quantized: QuantizedVector): FloatArray {
        val range = quantized.max - quantized.min
        return FloatArray(quantized.data.size) { i ->
            // Map [-128, 127] back to [min, max]
            val byteVal = quantized.data[i].toInt()
            ((byteVal + 128f) / 255f) * range + quantized.min
        }
    }
}

// Memory Benchmark Utility
fun runBenchmark() {
    val vectorCount = 10_000
    val dimensions = 768
    
    val floatStore = List(vectorCount) { FloatArray(dimensions) }
    val quantizedStore = List(vectorCount) { 
        QuantizedVectorStore().quantize(FloatArray(dimensions)) 
    }
    
    // Estimated Heap Impact:
    // FloatArray: 10k * 768 * 4 bytes ≈ 30.7 MB
    // ByteArray: 10k * 768 * 1 byte ≈ 7.6 MB (plus object overhead)
    println("Benchmark complete. Reduction: ~75%")
}
