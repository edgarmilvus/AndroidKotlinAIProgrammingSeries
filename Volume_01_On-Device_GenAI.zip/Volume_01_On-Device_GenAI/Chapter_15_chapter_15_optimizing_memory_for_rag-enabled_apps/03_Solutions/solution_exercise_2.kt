
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

data class DocumentChunk(
    val text: String,
    val score: Float
)

class ContextManager(
    private val maxTokens: Int = 2048,
    private val reservedTokens: Int = 256
) {
    // Heuristic: 1 token approx 4 characters for English
    private fun estimateTokens(text: String): Int = text.length / 4

    /**
     * Constructs the final prompt by packing documents based on a token budget.
     */
    fun constructPrompt(
        systemPrompt: String,
        userQuery: String,
        retrievedDocs: List<DocumentChunk>
    ): String {
        val systemTokens = estimateTokens(systemPrompt)
        val queryTokens = estimateTokens(userQuery)
        
        // Calculate remaining budget for retrieved documents
        var remainingBudget = maxTokens - reservedTokens - systemTokens - queryTokens
        
        if (remainingBudget < 0) {
            // Emergency: System prompt and query already exceed budget
            return "Error: Context budget exceeded by core prompt components."
        }

        val sb = StringBuilder()
        sb.append("System: $systemPrompt\n\n")
        sb.append("Context:\n")

        // Sort documents by score descending (highest relevance first)
        val sortedDocs = retrievedDocs.sortedByDescending { it.score }

        for (doc in sortedDocs) {
            val docTokens = estimateTokens(doc.text)
            
            if (docTokens <= remainingBudget) {
                // Document fits entirely
                sb.append("- ${doc.text}\n")
                remainingBudget -= docTokens
            } else if (remainingBudget > 50) { 
                // Document is too large, apply "Middle-Out" truncation
                val truncatedText = truncateMiddle(doc.text, remainingBudget)
                sb.append("- $truncatedText [TRUNCATED]\n")
                remainingBudget = 0 // Budget exhausted
            }
            
            if (remainingBudget <= 0) break
        }

        sb.append("\nUser Query: $userQuery")
        return sb.toString()
    }

    /**
     * Keeps the beginning and end of a string to preserve context 
     * while fitting into the remaining token budget.
     */
    private fun truncateMiddle(text: String, tokenBudget: Int): String {
        val charBudget = tokenBudget * 4
        if (text.length <= charBudget) return text
        
        val half = charBudget / 2
        return text.take(half) + "... [truncated] ..." + text.takeLast(half)
    }
}
