
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import android.util.LruCache
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.sqrt

class TieredVectorStore(
    private val context: Context,
    private val l1Capacity: Int = 100 
) {
    // L1: Fast JVM Heap Cache
    private val l1Cache = object : LruCache<Int, FloatArray>(l1Capacity) {
        override fun sizeOf(key: Int, value: FloatArray): Int = 1
    }

    private var l2MappedBuffer: MappedByteBuffer? = null
    private val vectorDimension = 384
    private val floatSize = 4

    init {
        setupL2Store()
    }

    private fun setupL2Store() {
        val file = File(context.filesDir, "vectors.bin")
        if (file.exists()) {
            val raf = RandomAccessFile(file, "r")
            val channel = raf.channel
            // mmap: Map the file directly into virtual memory
            l2MappedBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            raf.close()
        }
    }

    fun search(query: FloatArray): Int {
        val buffer = l2MappedBuffer ?: return -1
        val totalVectors = buffer.capacity() / (vectorDimension * floatSize)
        
        var bestIndex = -1
        var maxSimilarity = -1.0f
        val queryNorm = sqrt(query.fold(0f) { acc, v -> acc + v * v })

        for (i in 0 until totalVectors) {
            // Check L1 first for "hot" vectors
            val vector = l1Cache.get(i) ?: calculateSimilarityFromL2(i, query, queryNorm)
            
            // Note: calculateSimilarityFromL2 returns the similarity score
            // If we got a vector from L1, we must calculate similarity manually
            val similarity = if (vector != null) {
                computeCosine(vector, query, queryNorm)
            } else {
                // This is a simplification; in a real app, we'd separate 
                // the similarity logic from the retrieval logic.
                -1.0f // Placeholder for the L2 result logic below
            }
            
            // For the sake of this exercise, let's use a unified L2 search 
            // and promote the winner to L1.
        }
        
        // Refined Search Logic:
        return performOptimizedSearch(query, queryNorm, totalVectors)
    }

    private fun performOptimizedSearch(query: FloatArray, queryNorm: Float, totalVectors: Int): Int {
        var bestIndex = -1
        var maxSim = -1.0f
        val buffer = l2MappedBuffer ?: return -1

        for (i in 0 until totalVectors) {
            val offset = i * vectorDimension * floatSize
            var dotProduct = 0f
            var normSq = 0f
            
            for (d in 0 until vectorDimension) {
                val v = buffer.getFloat(offset + (d * floatSize))
                dotProduct += v * query[d]
                normSq += v * v
            }
            
            val sim = dotProduct / (queryNorm * sqrt(normSq))
            if (sim > maxSim) {
                maxSim = sim
                bestIndex = i
            }
        }

        // Promote the winner to L1 Cache
        bestIndex?.let { idx ->
            val winner = FloatArray(vectorDimension)
            val offset = idx * vectorDimension * floatSize
            for (d in 0 until vectorDimension) {
                winner[d] = buffer.getFloat(offset + (d * floatSize))
            }
            l1Cache.put(idx, winner)
        }

        return bestIndex
    }

    private fun computeCosine(v1: FloatArray, v2: FloatArray, v2Norm: Float): Float {
        var dot = 0f
        var n1Sq = 0f
        for (i in v1.indices) {
            dot += v1[i] * v2[i]
            n1Sq += v1[i] * v1[i]
        }
        return dot / (sqrt(n1Sq) * v2Norm)
    }
}
