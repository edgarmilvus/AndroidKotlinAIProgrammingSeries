
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

data class DocumentChunk(val text: String, val similarityScore: Float, val tokenCount: Int)

class ContextPruner(private val maxTokens: Int) {
    
    fun pruneContext(
        systemPrompt: String,
        userQuery: String,
        retrievedChunks: List<DocumentChunk>
    ): String {
        // Calculate fixed overhead (approximate tokens)
        val fixedTokens = (systemPrompt.length / 4) + (userQuery.length / 4)
        val availableTokens = maxTokens - fixedTokens
        
        // Use Sequence to avoid intermediate list allocations during filtering/mapping
        val prunedText = retrievedChunks
            .asSequence()
            .sortedByDescending { it.similarityScore } // Keep most relevant
            .takeWhileRunningTokenCount(availableTokens) 
            .map { it.text }
            .joinToString(separator = "\n\n")

        return "System: $systemPrompt\n\nContext:\n$prunedText\n\nUser: $userQuery"
    }

    // Custom extension to handle cumulative token counting in a sequence
    private fun Sequence<DocumentChunk>.takeWhileRunningTokenCount(limit: Int): Sequence<DocumentChunk> {
        return sequence {
            var currentTokens = 0
            for (chunk in this@takeWhileRunningTokenCount) {
                if (currentTokens + chunk.tokenCount <= limit) {
                    yield(chunk)
                    currentTokens += chunk.tokenCount
                } else {
                    break // Stop as soon as we hit the limit
                }
            }
        }
    }
}
