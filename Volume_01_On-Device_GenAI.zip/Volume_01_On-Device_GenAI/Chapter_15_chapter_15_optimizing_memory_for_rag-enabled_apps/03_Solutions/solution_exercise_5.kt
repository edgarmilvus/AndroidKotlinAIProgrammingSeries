
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

sealed class MemoryStrategy {
    data class Config(val chunkCount: Int, val useQuantization: Boolean, val contextLimit: Int)
    
    object HIGH_PERFORMANCE : MemoryStrategy() {
        val config = Config(chunkCount = 10, useQuantization = false, contextLimit = 4096)
    }
    object BALANCED : MemoryStrategy() {
        val config = Config(chunkCount = 5, useQuantization = false, contextLimit = 2048)
    }
    object LOW_MEMORY : MemoryStrategy() {
        val config = Config(chunkCount = 3, useQuantization = true, contextLimit = 1024)
    }
}

@Singleton
class AdaptiveRAGCoordinator @Inject constructor(
    private val context: Context
) {
    private val _currentStrategy = MutableStateFlow<MemoryStrategy>(MemoryStrategy.HIGH_PERFORMANCE)
    val currentStrategy: StateFlow<MemoryStrategy> = _currentStrategy.asStateFlow()

    fun updateMemoryState() {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val strategy = when {
            memoryInfo.lowMemory -> MemoryStrategy.LOW_MEMORY
            memoryInfo.availMem < 1_000_000_000L -> MemoryStrategy.BALANCED
            else -> MemoryStrategy.HIGH_PERFORMANCE
        }
        
        _currentStrategy.value = strategy
    }
    
    fun getRAGConfig(): MemoryStrategy.Config {
        return when (val s = _currentStrategy.value) {
            is MemoryStrategy.HIGH_PERFORMANCE -> s.config
            is MemoryStrategy.BALANCED -> s.config
            is MemoryStrategy.LOW_MEMORY -> s.config
        }
    }
}
