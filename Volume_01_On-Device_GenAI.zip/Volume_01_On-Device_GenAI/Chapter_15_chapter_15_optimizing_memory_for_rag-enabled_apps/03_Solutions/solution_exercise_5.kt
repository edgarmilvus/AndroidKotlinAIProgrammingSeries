
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

interface RagStrategy {
    val kNeighbors: Int
    val maxTokens: Int
    val useQuantization: Boolean
    val cacheSizeMb: Int
}

class LowMemoryStrategy : RagStrategy {
    override val kNeighbors = 2
    override val maxTokens = 1024
    override val useQuantization = true
    override val cacheSizeMb = 0
}

class MediumMemoryStrategy : RagStrategy {
    override val kNeighbors = 5
    override val maxTokens = 2048
    override val useQuantization = true
    override val cacheSizeMb = 10
}

class HighMemoryStrategy : RagStrategy {
    override val kNeighbors = 15
    override val maxTokens = 4096
    override val useQuantization = false
    override val cacheSizeMb = 50
}

@Singleton
class RagOrchestrator @Inject constructor(
    @ApplicationContext private val context: Context
) : ComponentCallbacks2 {

    var currentStrategy: RagStrategy = determineInitialStrategy()
        private set

    private fun determineInitialStrategy(): RagStrategy {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val totalRamGb = memoryInfo.totalMem / (1024 * 1024 * 1024)
        
        return when {
            totalRamGb < 4 -> LowMemoryStrategy()
            totalRamGb < 8 -> MediumMemoryStrategy()
            else -> HighMemoryStrategy()
        }
    }

    override fun onTrimMemory(level: Int) {
        // If the OS signals critical memory pressure, downgrade immediately
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            if (currentStrategy !is LowMemoryStrategy) {
                currentStrategy = LowMemoryStrategy()
                clearCaches()
            }
        }
    }

    private fun clearCaches() {
        // Logic to clear L1 caches, flush buffers, etc.
        println("Emergency memory cleanup triggered: Strategy downgraded to LOW")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}
    
    override fun onLowMemory() {
        currentStrategy = LowMemoryStrategy()
        clearCaches()
    }
}
