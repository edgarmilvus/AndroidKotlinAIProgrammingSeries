
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.rag.memory

import android.content.Context
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Singleton
import javax.inject.Inject
import com.google.mediapipe.tasks.text.text_embedder.TextEmbedder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate

/**
 * Represents the state of the RAG system to be consumed by Jetpack Compose.
 */
data class RagUiState(
    val query: String = "",
    val response: String = "",
    val isProcessing: Boolean = false,
    val memoryPressure: MemoryPressure = MemoryPressure.LOW,
    val error: String? = null
)

enum class MemoryPressure { LOW, MEDIUM, HIGH }

/**
 * MemoryOptimizedEmbeddingEngine handles the lifecycle of the TFLite embedding model.
 * It uses GPU delegation to offload computation from the CPU and implements 
 * a 'lazy-load/explicit-release' pattern to save RAM.
 */
@Singleton
class MemoryOptimizedEmbeddingEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var textEmbedder: TextEmbedder? = null

    // Hardware-aware configuration
    private fun createBaseOptions() = BaseOptions.builder()
        .setDelegate(Delegate.GPU) // Prioritize GPU for lower latency and CPU RAM relief
        .setModelAssetPath("embedding_model.tflite")
        .build()

    suspend fun embedText(text: String): FloatArray = withContext(Dispatchers.Default) {
        if (textEmbedder == null) {
            Log.d("RAG_MEM", "Initializing Embedding Model into RAM...")
            textEmbedder = TextEmbedder.createFromOptions(context, 
                com.google.mediapipe.tasks.text.text_embedder.TextEmbedder.TextEmbedderOptions.builder()
                    .setBaseOptions(createBaseOptions())
                    .build()
            )
        }
        
        // Perform embedding
        val result = textEmbedder?.embed(text) 
            ?: throw IllegalStateException("Embedder failed to initialize")
        
        result.embedding()
    }

    fun releaseResources() {
        Log.d("RAG_MEM", "Releasing Embedding Model to free RAM")
        textEmbedder?.close()
        textEmbedder = null
    }
}

/**
 * LocalVectorStore simulates a memory-mapped vector database.
 * In a production app, this would interface with SQLite-vec or a custom binary file.
 */
@Singleton
class LocalVectorStore @Inject constructor() {
    // Simulated in-memory store with a capacity limit to prevent OOM
    private val vectorCache = mutableMapOf<Int, FloatArray>()
    private val documentChunks = mutableMapOf<Int, String>()

    fun addDocument(id: Int, text: String, vector: FloatArray) {
        vectorCache[id] = vector
        documentChunks[id] = text
    }

    fun search(queryVector: FloatArray, topK: Int = 3): List<String> {
        // Implementation of Cosine Similarity: (A . B) / (||A|| ||B||)
        return vectorCache.entries
            .map { (id, vector) ->
                val score = cosineSimilarity(queryVector, vector)
                id to score
            }
            .sortedByDescending { it.second }
            .take(topK)
            .mapNotNull { documentChunks[it.first] }
    }

    private fun cosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in v1.indices) {
            dotProduct += v1[i] * v2[i]
            normA += v1[i] * v1[i]
            normB += v2[i] * v2[i]
        }
        return dotProduct / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble())).toFloat()
    }
}

/**
 * RAGRepository orchestrates the flow between the Embedding Engine, Vector Store, 
 * and the LLM (Gemini Nano).
 */
@Singleton
class RAGRepository @Inject constructor(
    private val embeddingEngine: MemoryOptimizedEmbeddingEngine,
    private val vectorStore: LocalVectorStore
) {
    // Simulate Gemini Nano AICore interface
    private suspend fun callGeminiNano(prompt: String): String {
        delay(1000) // Simulate inference latency
        return "Based on the provided context: $prompt\n\nAnswer: The on-device memory is optimized via GPU delegation."
    }

    suspend fun executeRagQuery(query: String): Result<String> = withContext(Dispatchers.Default) {
        try {
            // 1. Vectorize the user query (GPU Accelerated)
            val queryVector = embeddingEngine.embedText(query)

            // 2. Retrieve top-K relevant chunks (Memory-efficient search)
            val contextChunks = vectorStore.search(queryVector)
            val augmentedContext = contextChunks.joinToString("\n---\n")

            // 3. Construct the prompt (Memory-aware: pruning long contexts)
            val finalPrompt = "Context:\n$augmentedContext\n\nQuestion: $query\n\nAnswer concisely:"

            // 4. Generate response via Gemini Nano
            val response = callGeminiNano(finalPrompt)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun clearMemory() {
        embeddingEngine.releaseResources()
    }
}

/**
 * RAGViewModel implements the MVI pattern to ensure predictable state transitions.
 * It manages structured concurrency to prevent memory leaks during configuration changes.
 */
@HiltViewModel
class RAGViewModel @Inject constructor(
    private val repository: RAGRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(RagUiState())
    val uiState: StateFlow<RagUiState> = _uiState.asStateFlow()

    fun onQueryEntered(query: String) {
        _uiState.update { it.copy(query = query) }
    }

    fun performSearch() {
        val currentQuery = _uiState.value.query
        if (currentQuery.isBlank()) return

        // Use viewModelScope for structured concurrency
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, error = null) }
            
            val result = repository.executeRagQuery(currentQuery)
            
            result.onSuccess { response ->
                _uiState.update { it.copy(response = response, isProcessing = false) }
            }.onFailure { error ->
                _uiState.update { it.copy(error = error.message, isProcessing = false) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Critical for memory optimization: release heavy AI models when ViewModel is destroyed
        repository.clearMemory()
    }
}
