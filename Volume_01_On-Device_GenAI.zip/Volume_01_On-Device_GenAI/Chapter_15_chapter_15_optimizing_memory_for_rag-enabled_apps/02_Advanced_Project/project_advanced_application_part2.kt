
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.rag.memory

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

/**
 * Represents the current memory pressure level of the device.
 * Used to dynamically scale the RAG context window.
 */
sealed class MemoryPressure {
    object Optimal : MemoryPressure()    // High RAM available: Maximize Top-K
    object Warning : MemoryPressure()    // Moderate RAM: Reduce Top-K, truncate docs
    object Critical : MemoryPressure()   // Low RAM: Minimal context, high compression
}

/**
 * Hardware-aware service to monitor system RAM and determine the 
 * optimal context window for the LLM.
 */
@Singleton
class MemoryPressureMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun getCurrentPressure(): MemoryPressure {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val availablePercent = memoryInfo.availMem.toDouble() / memoryInfo.totalMem.toDouble()
        
        return when {
            availablePercent > 0.30 -> MemoryPressure.Optimal
            availablePercent > 0.15 -> MemoryPressure.Warning
            else -> MemoryPressure.Critical
        }
    }
}

/**
 * Repository handling the Vector Search and Embedding logic.
 * Orchestrates the use of NPU/GPU delegates via MediaPipe.
 */
@Singleton
class RagRepository @Inject constructor(
    private val memoryMonitor: MemoryPressureMonitor
) {
    // Simulate a vector database search
    suspend fun retrieveDocuments(query: String, pressure: MemoryPressure): List<String> = withContext(Dispatchers.Default) {
        // Hardware-aware orchestration: 
        // In a real scenario, the Embedding model would be initialized with 
        // GPU or NPU delegates here to offload the CPU.
        
        val topK = when (pressure) {
            is MemoryPressure.Optimal -> 5
            is MemoryPressure.Warning -> 3
            is MemoryPressure.Critical -> 1
        }
        
        // Simulate vector search latency and retrieval
        delay(100) 
        List(topK) { "Relevant document fragment $it for query: $query" }
    }
}

/**
 * ViewModel implementing MVI pattern to handle the RAG flow.
 * Manages structured concurrency to ensure AI tasks are cancelled on ViewModel clear.
 */
@HiltViewModel
class RagViewModel @Inject constructor(
    private val repository: RagRepository,
    private val memoryMonitor: MemoryPressureMonitor
) : ViewModel() {

    private val _uiState = MutableStateFlow<RagUiState>(RagUiState.Idle)
    val uiState: StateFlow<RagUiState> = _uiState.asStateFlow()

    fun processQuery(userQuery: String) {
        viewModelScope.launch {
            _uiState.value = RagUiState.Loading
            
            try {
                // 1. Check current memory pressure before starting the pipeline
                val pressure = memoryMonitor.getCurrentPressure()
                
                // 2. Retrieve documents based on memory pressure (Structured Concurrency)
                val contextDocs = repository.retrieveDocuments(userQuery, pressure)
                
                // 3. Construct the prompt (Memory-aware truncation)
                val finalPrompt = buildOptimizedPrompt(userQuery, contextDocs, pressure)
                
                // 4. Call Gemini Nano / AICore (Simulated)
                val response = callOnDeviceLLM(finalPrompt)
                
                _uiState.value = RagUiState.Success(response)
            } catch (e: Exception) {
                _uiState.value = RagUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private fun buildOptimizedPrompt(query: String, docs: List<String>, pressure: MemoryPressure): String {
        val contextString = when (pressure) {
            is MemoryPressure.Optimal -> docs.joinToString("\n")
            is MemoryPressure.Warning -> docs.joinToString("\n") { it.take(200) } // Truncate each doc
            is MemoryPressure.Critical -> docs.firstOrNull()?.take(100) ?: "" // Only first doc, heavily truncated
        }
        return "Context: $contextString\n\nQuestion: $query\n\nAnswer:"
    }

    private suspend fun callOnDeviceLLM(prompt: String): String = withContext(Dispatchers.Default) {
        // This is where the AICore / Gemini Nano integration happens.
        // The prompt size here directly impacts the KV Cache memory usage.
        delay(500) 
        "This is a generated response based on the optimized prompt."
    }
}

sealed class RagUiState {
    object Idle : RagUiState()
    object Loading : RagUiState()
    data class Success(val response: String) : RagUiState()
    data class Error(val message: String) : RagUiState()
}

@Module
@InstallIn(SingletonComponent::class)
object RagModule {
    // Hilt provides the necessary dependencies here
}
