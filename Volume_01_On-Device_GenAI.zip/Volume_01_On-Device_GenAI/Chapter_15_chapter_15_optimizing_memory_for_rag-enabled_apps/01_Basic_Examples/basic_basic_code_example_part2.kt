
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.math.sqrt

/**
 * Data model for a local document chunk.
 * In a production app, these would be stored in a Room database or a Vector DB.
 */
data class DocumentChunk(
    val id: Int,
    val text: String,
    val embedding: FloatArray
)

/**
 * Repository handling the 'Retrieval' phase of RAG.
 * Focuses on memory-efficient vector comparison.
 */
class RAGRepository @Inject constructor() {
    // Simulated local knowledge base (In-memory for this example)
    private val knowledgeBase = listOf(
        DocumentChunk(1, "Gemini Nano is designed for on-device tasks to ensure privacy.", floatArrayOf(0.1f, 0.8f, 0.2f)),
        DocumentChunk(2, "AICore manages the lifecycle of on-device models on Android.", floatArrayOf(0.4f, 0.2f, 0.9f)),
        DocumentChunk(3, "RAG reduces hallucinations by providing factual context to the LLM.", floatArrayOf(0.7f, 0.1f, 0.3f))
    )

    /**
     * Performs a simple Cosine Similarity search to find the most relevant chunk.
     * This is executed on Dispatchers.Default to avoid blocking the UI.
     */
    suspend fun retrieveRelevantContext(queryEmbedding: FloatArray): String = withContext(Dispatchers.Default) {
        knowledgeBase
            .map { chunk -> chunk to cosineSimilarity(queryEmbedding, chunk.embedding) }
            .maxByOrNull { it.second }
            ?.first?.text ?: "No relevant context found."
    }

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/**
 * ViewModel orchestrating the RAG flow.
 * Handles the 'Augmentation' and 'Generation' phases.
 */
@HiltViewModel
class RAGViewModel @Inject constructor(
    private val repository: RAGRepository
) : ViewModel() {

    // State management for the UI
    private val _uiState = MutableStateFlow<RAGUiState>(RAGUiState.Idle)
    val uiState: StateFlow<RAGUiState> = _uiState.asStateFlow()

    // Initialize LlmInference (Simplified for example)
    private var llmInference: LlmInference? = null

    init {
        setupLlm()
    }

    private fun setupLlm() {
        // In a real scenario, load the model from assets or AICore
        // llmInference = LlmInference.createFromOptions(options)
    }

    fun askQuestion(userQuery: String) {
        viewModelScope.launch {
            _uiState.value = RAGUiState.Loading
            
            try {
                // 1. Embedding Phase (Simulated)
                // In reality, use a MediaPipe TextEmbedder here.
                val queryEmbedding = floatArrayOf(0.12f, 0.75f, 0.22f) 

                // 2. Retrieval Phase
                // Offload to Repository (Dispatchers.Default)
                val context = repository.retrieveRelevantContext(queryEmbedding)

                // 3. Augmentation Phase
                // We carefully construct the prompt to avoid memory overflow.
                val augmentedPrompt = buildPrompt(userQuery, context)

                // 4. Generation Phase
                // Perform inference on a background thread.
                val response = generateResponse(augmentedPrompt)
                
                _uiState.value = RAGUiState.Success(response)
            } catch (e: Exception) {
                _uiState.value = RAGUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private suspend fun generateResponse(prompt: String): String = withContext(Dispatchers.Default) {
        // Simulate LLM inference delay
        kotlinx.coroutines.delay(1000) 
        // return llmInference?.generateResponse(prompt) ?: "LLM not initialized"
        "Based on the context: $prompt \n\nAnswer: Gemini Nano is an efficient local model."
    }

    private fun buildPrompt(query: String, context: String): String {
        // Memory Optimization: Use a StringBuilder and limit context length
        return StringBuilder().apply {
            append("Context: ${context.take(500)}\n\n") // Truncate to prevent memory spikes
            append("Question: $query\n\n")
            append("Answer concisely based on the context provided:")
        }.toString()
    }

    override fun onCleared() {
        super.onCleared()
        // CRITICAL: Close the interpreter to release native memory
        llmInference?.close()
        llmInference = null
    }
}

sealed class RAGUiState {
    object Idle : RAGUiState()
    object Loading : RAGUiState()
    data class Success(val answer: String) : RAGUiState()
    data class Error(val message: String) : RAGUiState()
}
