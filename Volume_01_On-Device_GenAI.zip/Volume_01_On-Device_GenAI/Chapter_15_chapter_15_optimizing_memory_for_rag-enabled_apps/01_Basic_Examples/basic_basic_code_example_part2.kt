
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import kotlin.math.sqrt

/**
 * VectorStore manages the local knowledge base.
 * It uses a flat FloatArray to minimize object overhead and GC pressure.
 */
class VectorStore(private val vectorDimension: Int) {
    // We store all vectors in one giant array: [v1_0, v1_1... v1_n, v2_0, v2_1... v2_n]
    private var vectorBuffer = FloatArray(0)
    private val documentMap = mutableListOf<String>()

    /**
     * Adds a document and its embedding to the store.
     * @param text The raw text of the note.
     * @param embedding The vector representation of the text.
     */
    fun addDocument(text: String, embedding: FloatArray) {
        require(embedding.size == vectorDimension) { "Embedding dimension mismatch!" }
        
        // Expand the buffer to accommodate the new vector
        val newBuffer = FloatArray(vectorBuffer.size + vectorDimension)
        System.arraycopy(vectorBuffer, 0, newBuffer, 0, vectorBuffer.size)
        System.arraycopy(embedding, 0, newBuffer, vectorBuffer.size, vectorDimension)
        
        vectorBuffer = newBuffer
        documentMap.add(text)
    }

    /**
     * Performs a Cosine Similarity search to find the most relevant document.
     * Memory optimization: We iterate through the flat array to avoid object allocation.
     */
    fun findMostRelevant(queryEmbedding: FloatArray): String? {
        if (documentMap.isEmpty()) return null

        var bestScore = -1.0f
        var bestIndex = -1

        val numDocs = documentMap.size
        
        for (i in 0 until numDocs) {
            val offset = i * vectorDimension
            var dotProduct = 0.0f
            var normA = 0.0f
            var normB = 0.0f

            for (j in 0 until vectorDimension) {
                val valA = queryEmbedding[j]
                val valB = vectorBuffer[offset + j]
                dotProduct += valA * valB
                normA += valA * valA
                normB += valB * valB
            }

            val similarity = dotProduct / (sqrt(normA) * sqrt(normB))
            if (similarity > bestScore) {
                bestScore = similarity
                bestIndex = i
            }
        }

        return if (bestIndex != -1) documentMap[bestIndex] else null
    }
    
    fun clear() {
        vectorBuffer = FloatArray(0)
        documentMap.clear()
    }
}
