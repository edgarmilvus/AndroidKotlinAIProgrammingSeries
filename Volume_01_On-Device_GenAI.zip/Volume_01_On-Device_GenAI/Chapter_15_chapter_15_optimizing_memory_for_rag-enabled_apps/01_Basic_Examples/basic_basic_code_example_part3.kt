
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * Manages the TFLite embedding model.
 * Uses Direct ByteBuffers to interface with the native TFLite C++ core.
 */
class EmbeddingManager(context: Context) {
    private var interpreter: Interpreter? = null
    private val dimension = 384 // Example: MobileBERT dimension

    init {
        val modelFile = loadModelFile(context, "embedding_model.tflite")
        val options = Interpreter.Options().apply {
            setNumThreads(4) // Utilize multi-core CPUs for embedding generation
            // Use NNAPI for hardware acceleration on supported devices
            useNNAPI = true 
        }
        interpreter = Interpreter(modelFile, options)
    }

    private fun loadModelFile(context: Context, modelName: String): ByteBuffer {
        val fileInputStream = context.assets.open(modelName)
        val fileChannel = fileInputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    /**
     * Converts a string into a vector.
     * In a real app, this would involve a Tokenizer.
     */
    fun embed(text: String): FloatArray {
        val inputBuffer = ByteBuffer.allocateDirect(1 * 128 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        // (Simplified) Tokenization logic would go here to fill inputBuffer
        
        val outputBuffer = ByteBuffer.allocateDirect(1 * dimension * 4).apply {
            order(ByteOrder.nativeOrder())
        }

        interpreter?.run(inputBuffer, outputBuffer)

        val result = FloatArray(dimension)
        outputBuffer.rewind()
        outputBuffer.asFloatBuffer().get(result)
        return result
    }

    fun close() {
        interpreter?.close()
        interpreter = null
    }
}
