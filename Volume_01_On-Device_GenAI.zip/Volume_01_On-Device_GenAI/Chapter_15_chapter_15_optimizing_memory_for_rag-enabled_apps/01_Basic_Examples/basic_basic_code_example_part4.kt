
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class RAGViewModel @Inject constructor(
    private val embeddingManager: EmbeddingManager,
    private val vectorStore: VectorStore,
    private val geminiNano: GeminiNanoClient // Hypothetical wrapper for AICore
) : ViewModel() {

    private val _uiState = MutableStateFlow<RAGUiState>(RAGUiState.Idle)
    val uiState: StateFlow<RAGUiState> = _uiState.asStateFlow()

    fun processQuery(query: String) {
        viewModelScope.launch {
            _uiState.value = RAGUiState.Loading
            
            try {
                // 1. Generate embedding for the query on a background thread
                val queryVector = withContext(Dispatchers.Default) {
                    embeddingManager.embed(query)
                }

                // 2. Retrieve the most relevant context from the VectorStore
                val context = withContext(Dispatchers.Default) {
                    vectorStore.findMostRelevant(queryVector)
                }

                // 3. Construct the augmented prompt
                val augmentedPrompt = if (context != null) {
                    "Use the following context to answer the question.\nContext: $context\n\nQuestion: $query"
                } else {
                    "Question: $query"
                }

                // 4. Generate response using Gemini Nano via AICore
                val response = withContext(Dispatchers.Default) {
                    geminiNano.generateResponse(augmentedPrompt)
                }

                _uiState.value = RAGUiState.Success(response)
            } catch (e: Exception) {
                _uiState.value = RAGUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        embeddingManager.close()
    }
}

sealed class RAGUiState {
    object Idle : RAGUiState()
    object Loading : RAGUiState()
    data class Success(val response: String) : RAGUiState()
    data class Error(val message: String) : RAGUiState()
}
