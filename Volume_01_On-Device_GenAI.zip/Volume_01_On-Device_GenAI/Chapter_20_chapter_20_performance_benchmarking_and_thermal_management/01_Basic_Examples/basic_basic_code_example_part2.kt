
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.os.PowerManager
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.system.measureTimeMillis

/**
 * Data class representing a single benchmark snapshot.
 */
data class BenchmarkResult(
    val latencyMs: Long = 0,
    val thermalStatus: String = "Unknown",
    val isThrottling: Boolean = false
)

/**
 * Repository responsible for interacting with the Hardware (PowerManager) 
 * and the AI Model (Simulated for this example).
 */
class PerformanceRepository(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    // A Flow that emits the current thermal status of the device
    val thermalStatusFlow: Flow<Int> = callbackFlow {
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            trySend(status)
        }
        powerManager.addThermalStatusListener(listener)
        
        // Emit current status immediately upon collection
        trySend(powerManager.currentThermalStatus)

        awaitClose {
            powerManager.removeThermalStatusListener(listener)
        }
    }.flowOn(Dispatchers.Default)

    /**
     * Simulates an AI Inference task. 
     * In a real scenario, this would call MediaPipe or AICore.
     */
    suspend fun runInference(input: String): String {
        return kotlinx.coroutines.withContext(Dispatchers.Default) {
            // Simulate heavy computation
            delay((100..500).random().toLong()) 
            "Processed: $input"
        }
    }

    fun getThermalStatusDescription(status: Int): String {
        return when (status) {
            PowerManager.THERMAL_STATUS_NONE -> "None (Cool)"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            else -> "Unknown"
        }
    }
}

/**
 * ViewModel managing the benchmarking logic and UI state.
 */
class BenchmarkViewModel(private val repository: PerformanceRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(BenchmarkResult())
    val uiState: StateFlow<BenchmarkResult> = _uiState.asStateFlow()

    init {
        // Continuously monitor thermal status in the background
        viewModelScope.launch {
            repository.thermalStatusFlow.collect { status ->
                _uiState.update { it.copy(
                    thermalStatus = repository.getThermalStatusDescription(status),
                    isThrottling = status >= PowerManager.THERMAL_STATUS_MODERATE
                )}
            }
        }
    }

    fun performBenchmark(input: String) {
        viewModelScope.launch {
            // 1. Measure the execution time of the inference
            val latency = measureTimeMillis {
                repository.runInference(input)
            }

            // 2. Update the state with the result
            _uiState.update { it.copy(latencyMs = latency) }
        }
    }
}

/**
 * Compose UI to visualize performance metrics.
 */
@Composable
fun BenchmarkScreen(viewModel: BenchmarkViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "GenAI Performance Monitor", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Current Thermal Status: ${state.thermalStatus}")
                Text(
                    text = if (state.isThrottling) "⚠️ Throttling Active" else "✅ Thermal Stable",
                    color = if (state.isThrottling) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Last Inference Latency: ${state.latencyMs} ms")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.performBenchmark("Hello Gemini!") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Run Inference Benchmark")
        }
    }
}
