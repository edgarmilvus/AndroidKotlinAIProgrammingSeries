
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.genai.performance.benchmark

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.system.measureNanoTime

/**
 * Data class representing a single inference benchmark snapshot.
 * We capture nanoTime for precision and the thermal state to correlate performance drops.
 */
data class BenchmarkResult(
    val iteration: Int,
    val latencyMs: Double,
    val tokensPerSecond: Double,
    val thermalStatus: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * ThermalManager: Observes the device's thermal state using PowerManager.
 * This is critical because AI workloads trigger thermal throttling quickly.
 */
@Singleton
class ThermalManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    
    // StateFlow to emit thermal changes in real-time
    private val _thermalState = MutableStateFlow(getThermalStatusString())
    val thermalState: StateFlow<String> = _thermalState.asStateFlow()

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusListener { status ->
                _thermalState.value = mapThermalStatus(status)
            }
        }
    }

    private fun getThermalStatusString(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mapThermalStatus(powerManager.currentThermalStatus)
        } else {
            "Unsupported API"
        }
    }

    private fun mapThermalStatus(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "None (Cool)"
        PowerManager.THERMAL_STATUS_LIGHT -> "Light"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
        PowerManager.THERMAL_STATUS_SEVERE -> "Severe (Throttling)"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Critical (High Risk)"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency (Shutdown Risk)"
        else -> "Unknown"
    }
}

/**
 * PerformanceMonitor: The core engine that wraps AI inference calls.
 * It uses a high-resolution timer to measure execution time.
 */
@Singleton
class PerformanceMonitor @Inject constructor(
    private val thermalManager: ThermalManager
) {
    /**
     * Wraps a suspending AI inference block and measures its performance.
     * @param tokensGenerated The number of tokens produced by the LLM in this run.
     * @param block The actual inference logic (e.g., Gemini Nano call).
     */
    suspend fun <T> measureInference(
        tokensGenerated: Int,
        block: suspend () -> T
    ): Pair<T, BenchmarkResult> {
        val iterationCount = 0 // In a real app, track this via a counter
        
        // Use System.nanoTime() for precision. System.currentTimeMillis() is too coarse.
        var result: T
        val nanoTime = measureNanoTime {
            result = block()
        }

        val latencyMs = nanoTime / 1_000_000.0
        val tps = if (tokensGenerated > 0) (tokensGenerated * 1000.0) / latencyMs else 0.0
        
        val benchmark = BenchmarkResult(
            iteration = iterationCount,
            latencyMs = latencyMs,
            tokensPerSecond = tps,
            thermalStatus = thermalManager.thermalState.value
        )
        
        return Pair(result, benchmark)
    }
}

/**
 * BenchmarkViewModel: Orchestrates the AI workload and manages the UI state.
 * Uses Dispatchers.Default to ensure the Main thread remains responsive (preventing ANRs).
 */
@HiltViewModel
class BenchmarkViewModel @Inject constructor(
    private val performanceMonitor: PerformanceMonitor,
    private val thermalManager: ThermalManager
) : ViewModel() {

    private val _results = MutableStateFlow<List<BenchmarkResult>>(emptyList())
    val results: StateFlow<List<BenchmarkResult>> = _results.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    val currentThermalState = thermalManager.thermalState

    fun runBenchmark() {
        viewModelScope.launch {
            _isProcessing.value = true
            
            // Move the heavy AI workload to the Default dispatcher (CPU-bound)
            withContext(Dispatchers.Default) {
                try {
                    // Simulate 5 iterations of LLM inference
                    repeat(5) { i ->
                        val (output, benchmark) = performanceMonitor.measureInference(tokensGenerated = 50) {
                            simulateLlmInference()
                        }
                        
                        // Update results list on the Main thread
                        withContext(Dispatchers.Main) {
                            _results.value = _results.value + benchmark
                        }
                    }
                } catch (e: Exception) {
                    Log.e("BenchmarkVM", "Inference failed", e)
                }
            }
            
            _isProcessing.value = false
        }
    }

    // Mocking an LLM call (e.g., Gemini Nano / TFLite)
    private suspend fun simulateLlmInference(): String {
        // Simulate variable latency based on "thermal load"
        val delayTime = (200..800).random().toLong()
        delay(delayTime) 
        return "Generated AI Response"
    }
}

/**
 * BenchmarkScreen: Jetpack Compose UI to visualize performance.
 */
@AndroidEntryPoint
@Composable
fun BenchmarkScreen(viewModel: BenchmarkViewModel = ViewModelProvider(
    // In a real Hilt setup, use hiltViewModel()
) { BenchmarkViewModel(PerformanceMonitor(ThermalManager(context)), ThermalManager(context)) }.get()) {
    // Note: The ViewModelProvider above is a simplification for the example. 
    // Use hiltViewModel() in production.
    
    val results by viewModel.results.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val thermalState by viewModel.currentThermalState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "AI Performance Benchmarker", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (thermalState.contains("Severe")) 
                    MaterialTheme.colorScheme.errorContainer 
                    else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Current Thermal State: $thermalState", style = MaterialTheme.typography.bodyLarge)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.runBenchmark() },
            enabled = !isProcessing,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isProcessing) "Running Inference..." else "Start Benchmark")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Results", style = MaterialTheme.typography.titleMedium)
        
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(results.reversed()) { result ->
                BenchmarkRow(result)
            }
        }
    }
}

@Composable
fun BenchmarkRow(result: BenchmarkResult) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "Lat: ${"%.2f".format(result.latencyMs)}ms", modifier = Modifier.weight(1f))
        Text(text = "TPS: ${"%.2f".format(result.tokensPerSecond)}", modifier = Modifier.weight(1f))
        Text(text = result.thermalStatus, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
    }
    Divider()
}
