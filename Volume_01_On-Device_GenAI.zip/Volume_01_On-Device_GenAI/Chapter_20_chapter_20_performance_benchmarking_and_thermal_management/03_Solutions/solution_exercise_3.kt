
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.os.Debug
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.util.Collections

enum class DelegateType { CPU_1, CPU_4, GPU, NNAPI }

class TFLiteBenchmarkSuite(private val modelBuffer: java.nio.ByteBuffer) {

    fun runBenchmark(type: DelegateType): BenchmarkResult {
        val options = Interpreter.Options().apply {
            when (type) {
                DelegateType.CPU_1 -> setNumThreads(1)
                DelegateType.CPU_4 -> setNumThreads(4)
                DelegateType.GPU -> addDelegate(GpuDelegate())
                DelegateType.NNAPI -> addDelegate(NnApiDelegate())
            }
        }

        val interpreter = Interpreter(modelBuffer, options)
        val latencies = mutableListOf<Long>()
        
        // 1. Warm-up Phase (Discard first 10)
        repeat(10) { 
            interpreter.run(dummyInput, dummyOutput) 
        }

        // 2. Measurement Phase
        repeat(50) {
            val start = System.nanoTime()
            interpreter.run(dummyInput, dummyOutput)
            latencies.add(System.nanoTime() - start)
        }

        // 3. Memory Tracking
        val memoryInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(memoryInfo)
        val peakRss = memoryInfo.totalPss // Proportional Set Size (approx RSS)

        interpreter.close()
        return calculateStats(latencies, peakRss)
    }

    private fun calculateStats(latencies: MutableList<Long>, rss: Int): BenchmarkResult {
        Collections.sort(latencies)
        val mean = latencies.average() / 1_000_000
        val median = latencies[latencies.size / 2] / 1_000_000
        val p99 = latencies[(latencies.size * 0.99).toInt()] / 1_000_000
        
        return BenchmarkResult(mean, median, p99, rss)
    }

    data class BenchmarkResult(val mean: Double, val median: Long, val p99: Long, val rssKb: Int)
}
