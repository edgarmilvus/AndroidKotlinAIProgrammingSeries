
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Strategy Interface
interface InferenceStrategy {
    val maxTokens: Int
    val promptCompressionLevel: Float // 0.0 (none) to 1.0 (aggressive)
    val preferredDelegate: DelegateType
}

// 2. Concrete Strategies
class PerformanceStrategy : InferenceStrategy {
    override val maxTokens = 2048
    override val promptCompressionLevel = 0.0f
    override val preferredDelegate = DelegateType.NNAPI
}

class BalancedStrategy : InferenceStrategy {
    override val maxTokens = 512
    override val promptCompressionLevel = 0.3f
    override val preferredDelegate = DelegateType.GPU
}

class PowerSaverStrategy : InferenceStrategy {
    override val maxTokens = 128
    override val promptCompressionLevel = 0.7f
    override val preferredDelegate = DelegateType.CPU_1
}

// 3. Strategy Controller
@Singleton
class StrategyController @Inject constructor(
    private val thermalService: ThermalManagementService,
    private val batteryMonitor: BatteryMonitor // Hypothetical battery observer
) {
    val activeStrategy: StateFlow<InferenceStrategy> = combine(
        thermalService.thermalState,
        batteryMonitor.batteryLevel // Flow<Int>
    ) { thermal, battery ->
        when {
            thermal is ThermalState.Critical || battery < 15 -> PowerSaverStrategy()
            thermal is ThermalState.Severe -> PowerSaverStrategy()
            thermal is ThermalState.Moderate || battery < 30 -> BalancedStrategy()
            else -> PerformanceStrategy()
        }
    }.stateIn(
        scope = GlobalScope, // In production, use a custom ApplicationScope
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PerformanceStrategy()
    )
}

// 4. Integration in Inference Engine
class AdaptiveInferenceEngine @Inject constructor(
    private val strategyController: StrategyController
) {
    suspend fun generate(prompt: String) {
        val strategy = strategyController.activeStrategy.value
        
        val compressedPrompt = compressPrompt(prompt, strategy.promptCompressionLevel)
        val result = runInference(
            prompt = compressedPrompt,
            maxTokens = strategy.maxTokens,
            delegate = strategy.preferredDelegate
        )
        // ...
    }
    
    private fun compressPrompt(p: String, level: Float): String {
        return if (level > 0.5f) p.take(500) else p // Simple truncation for example
    }
}
