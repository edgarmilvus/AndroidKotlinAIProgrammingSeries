
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.benchmark.macro.JUnit4
import androidx.benchmark.macro.MacrobenchmarkRule
import androidx.benchmark.macro.junit4.MacrobenchmarkRule
import androidx.benchmark.macro.scope.crossinline
import androidx.test.uiautomator.By
import androidx.test.uiautomator.Until

@RunWith(JUnit4::class)
class LongContextMemoryBenchmark {
    @get:Rule
    val benchmarkRule = MacrobenchmarkRule()

    @Test
    fun benchmarkMemoryPressure() = benchmarkRule.measureRepeated(
        packageName = "com.example.genai.app",
        metrics = listOf(MemoryUsageMetric()), // Custom or Standard Memory Metric
        iterations = 5,
        setupBlock = {
            pressHome()
        }
    ) {
        startActivityAndWait()

        // 1. Simulate uploading a large PDF
        val uploadButton = device.findObject(By.res("com.example.genai.app:id/btn_upload"))
        uploadButton.click()
        device.wait(Until.hasObject(By.res("com.example.genai.app:id/status_ready")), 10_000)

        // 2. Simulate a sequence of 10 complex prompts
        val inputField = device.findObject(By.res("com.example.genai.app:id/chat_input"))
        val sendButton = device.findObject(By.res("com.example.genai.app:id/btn_send"))

        for (i in 1..10) {
            inputField.text = "Analyze the document and provide a detailed summary of point $i"
            sendButton.click()
            
            // Wait for the AI to stop streaming (look for the 'Send' button to become enabled again)
            device.wait(Until.findObject(By.res("com.example.genai.app:id/btn_send")), 30_000)
        }
    }
}
