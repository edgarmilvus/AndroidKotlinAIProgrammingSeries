
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import androidx.compose.runtime.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class NativeMemoryAnalyzer(private val context: Context) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun getNativeMemoryUsage(): Long {
        val memInfo = activityManager.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))[0]
        // nativePss is the proportional set size of the native heap
        return memInfo.totalPss.toLong() 
    }

    suspend fun runLeakTest(modelLoader: suspend (Boolean) -> Unit): List<Long> {
        val samples = mutableListOf<Long>()
        
        // Baseline
        samples.add(getNativeMemoryUsage())

        repeat(10) {
            modelLoader(true)  // Load model
            delay(500)
            modelLoader(false) // Unload model
            delay(500)
            samples.add(getNativeMemoryUsage())
        }
        return samples
    }
}

@Composable
fun MemoryMonitorGraph(memorySamples: List<Long>) {
    if (memorySamples.isEmpty()) return

    val maxMem = memorySamples.maxOrNull() ?: 1L
    val minMem = memorySamples.minOrNull() ?: 0L
    val range = (maxMem - minMem).coerceAtLeast(1L)

    Canvas(modifier = Modifier.fillMaxWidth().height(200.dp).padding(16.dp)) {
        val widthStep = size.width / (memorySamples.size - 1)
        val heightScale = size.height / range

        for (i in 0 until memorySamples.size - 1) {
            drawLine(
                color = Color.Blue,
                start = Offset(
                    x = i * widthStep,
                    y = size.height - ((memorySamples[i] - minMem) * heightScale).toFloat()
                ),
                end = Offset(
                    x = (i + 1) * widthStep,
                    y = size.height - ((memorySamples[i + 1] - minMem) * heightScale).toFloat()
                ),
                strokeWidth = 3f
            )
        }
    }
}
