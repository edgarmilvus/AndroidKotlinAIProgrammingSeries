
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Sealed class for Thermal States
sealed class ThermalState {
    object Normal : ThermalState()
    object Moderate : ThermalState()
    object Severe : ThermalState()
    object Critical : ThermalState()
}

@Singleton
class ThermalManagementService @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    
    private val _thermalState = MutableStateFlow<ThermalState>(ThermalState.Normal)
    val thermalState: StateFlow<ThermalState> = _thermalState.asStateFlow()

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { status ->
        _thermalState.value = when (status) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalState.Normal
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalState.Normal
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalState.Moderate
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalState.Severe
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalState.Critical
            else -> ThermalState.Normal
        }
    }

    fun register() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.addThermalStatusListener(thermalListener)
        }
    }

    fun unregister() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            powerManager.removeThermalStatusListener(thermalListener)
        }
    }
}

// 2. Compose UI Integration
@Composable
fun ThermalWarningBanner(thermalService: ThermalManagementService) {
    val state by thermalService.thermalState.collectAsState()

    when (state) {
        is ThermalState.Moderate -> {
            // Subtle notification
            androidx.compose.material3.Text("Device warming up...", color = androidx.compose.ui.graphics.Color.Yellow)
        }
        is ThermalState.Severe -> {
            // Persistent Banner
            androidx.compose.material3.Card(
                colors = androidx.compose.material3.CardDefaults.cardColors(
                    containerColor = androidx.compose.ui.graphics.Color.Red.copy(alpha = 0.2f)
                )
            ) {
                androidx.compose.material3.Text(
                    "AI performance reduced due to device temperature", 
                    modifier = androidx.compose.ui.Modifier.padding(8.dp)
                )
            }
        }
        is ThermalState.Critical -> {
            // Full screen overlay or Modal
            androidx.compose.material3.AlertDialog(
                onDismissRequest = {},
                title = { androidx.compose.material3.Text("Cool Down Required") },
                text = { androidx.compose.material3.Text("The device is too hot. AI inference paused for safety.") },
                confirmButton = { /* Handle cool down */ }
            )
        }
        else -> { /* No UI needed for Normal */ }
    }
}
