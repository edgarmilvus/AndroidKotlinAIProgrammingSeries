
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import android.os.PowerManager
import androidx.lifecycle.*
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android. inject
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. State Mapping
sealed class ThermalState {
    object Normal : ThermalState()
    object Light : ThermalState()
    object Moderate : ThermalState()
    object Severe : ThermalState()
    object Critical : ThermalState()
}

// 2. Thermal Listener Manager
@Singleton
class ThermalObserver @Inject constructor(
    private val powerManager: PowerManager
) {
    private val _thermalState = MutableStateFlow<ThermalState>(ThermalState.Normal)
    val thermalState = _thermalState.asStateFlow()

    private val listener = PowerManager.OnThermalStatusChangedListener { status ->
        _thermalState.value = when (status) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalState.Normal
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalState.Light
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalState.Moderate
            PowerManager.THERMAL_STATUS_SEVERE -> ThermalState.Severe
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalState.Critical
            else -> ThermalState.Normal
        }
    }

    fun register() = powerManager.addThermalStatusListener(listener)
    fun unregister() = powerManager.removeThermalStatusListener(listener)
}

// 3. Lifecycle-aware integration and UI
@AndroidEntryPoint
class ThermalActivity : androidx.activity.ComponentActivity() {
    @Inject lateinit var thermalObserver: ThermalObserver

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                thermalObserver.register()
                try {
                    // UI Logic handled in Compose
                } finally {
                    thermalObserver.unregister()
                }
            }
        }
    }
}

@Composable
fun ThermalWarningBanner(thermalStateFlow: StateFlow<ThermalState>) {
    val state by thermalStateFlow.collectAsStateWithLifecycle()

    if (state is ThermalState.Severe || state is ThermalState.Critical) {
        Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Device is overheating! AI performance may be reduced.",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
