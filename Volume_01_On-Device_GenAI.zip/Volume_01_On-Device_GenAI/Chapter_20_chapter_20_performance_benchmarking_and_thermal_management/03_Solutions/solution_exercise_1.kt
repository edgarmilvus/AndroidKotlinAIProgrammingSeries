
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.util.Log
import androidx.compose.runtime.*
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.*

// 1. Metrics Data Model
data class InferenceMetrics(
    val ttftMs: Long = 0,
    val tps: Double = 0.0,
    val totalLatencyMs: Long = 0,
    val tokenCount: Int = 0
)

// 2. Performance Monitor Singleton
@Singleton
class PerformanceMonitor @Inject constructor() {
    private val _metrics = MutableStateFlow(InferenceMetrics())
    val metrics: StateFlow<InferenceMetrics> = _metrics.asStateFlow()

    private var startTime = 0L
    private var firstTokenTime = 0L
    private var tokenCount = 0

    fun startTracking() {
        startTime = System.nanoTime()
        firstTokenTime = 0L
        tokenCount = 0
        _metrics.value = InferenceMetrics()
    }

    fun onTokenReceived() {
        tokenCount++
        if (firstTokenTime == 0L) {
            firstTokenTime = System.nanoTime()
            val ttft = (firstTokenTime - startTime) / 1_000_000
            _metrics.update { it.copy(ttftMs = ttft) }
        }
    }

    fun stopTracking() {
        val endTime = System.nanoTime()
        val totalLatency = (endTime - startTime) / 1_000_000
        
        // TPS = (Total Tokens - 1) / (Total Time - TTFT)
        // We subtract 1 because the first token is the TTFT boundary
        val generationDurationNs = endTime - firstTokenTime
        val tps = if (generationDurationNs > 0) {
            (tokenCount - 1).toDouble() / (generationDurationNs / 1_000_000_000.0)
        } else 0.0

        _metrics.update { 
            it.copy(totalLatencyMs = totalLatency, tps = tps, tokenCount = tokenCount) 
        }
    }
}

// 3. Interceptor Wrapper (Example for Gemini Nano/TFLite)
class InferenceServiceWrapper @Inject constructor(
    private val performanceMonitor: PerformanceMonitor,
    private val actualAiService: ActualAiService // Hypothetical AI Service
) {
    suspend fun generateTextStreaming(prompt: String, onToken: (String) -> Unit) {
        performanceMonitor.startTracking()
        try {
            actualAiService.stream(prompt).collect { token ->
                performanceMonitor.onTokenReceived()
                onToken(token)
            }
        } finally {
            performanceMonitor.stopTracking()
        }
    }
}

// 4. Compose Developer Overlay
@Composable
fun PerformanceOverlay(monitor: PerformanceMonitor) {
    val metrics by monitor.metrics.collectAsState()

    androidx.compose.material3.Surface(
        color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.7f),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
        modifier = androidx.compose.ui.Modifier.padding(16.dp)
    ) {
        androidx.compose.foundation.layout.Column(modifier = androidx.compose.ui.Modifier.padding(8.dp)) {
            androidx.compose.material3.Text("TTFT: ${metrics.ttftMs}ms", color = androidx.compose.ui.graphics.Color.Green)
            androidx.compose.material3.Text("TPS: ${"%.2f".format(metrics.tps)}", color = androidx.compose.ui.graphics.Color.Green)
            androidx.compose.material3.Text("Total: ${metrics.totalLatencyMs}ms", color = androidx.compose.ui.graphics.Color.Green)
            androidx.compose.material3.Text("Tokens: ${metrics.tokenCount}", color = androidx.compose.ui.graphics.Color.Green)
        }
    }
}
