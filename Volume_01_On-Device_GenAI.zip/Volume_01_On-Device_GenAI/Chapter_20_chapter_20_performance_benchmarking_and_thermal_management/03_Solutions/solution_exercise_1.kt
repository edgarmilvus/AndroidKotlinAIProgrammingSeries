
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

// 1. Data Persistence Layer
@Entity(tableName = "latency_metrics")
data class LatencyMetric(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ttftMs: Long,
    val tps: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface LatencyDao {
    @Insert
    suspend fun insertMetric(metric: LatencyMetric)
}

@Database(entities = [LatencyMetric::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun latencyDao(): LatencyDao
}

// 2. Telemetry Wrapper
class GenAiTelemetryManager(private val dao: LatencyDao) {
    private val _currentMetrics = MutableStateFlow<TelemetryState>(TelemetryState.Idle)
    val currentMetrics = _currentMetrics.asStateFlow()

    sealed class TelemetryState {
        object Idle : TelemetryState()
        data class Measuring(val ttft: Long = 0, val tps: Double = 0.0) : TelemetryState()
    }

    suspend fun <T> trackInference(inferenceFlow: Flow<T>): Flow<T> = flow {
        val startTime = System.nanoTime()
        var firstTokenTime = 0L
        var tokenCount = 0
        
        inferenceFlow.collect { token ->
            if (tokenCount == 0) {
                firstTokenTime = System.nanoTime()
                val ttft = TimeUnit.NANOSECONDS.toMillis(firstTokenTime - startTime)
                _currentMetrics.value = GenAiTelemetryManager.TelemetryState.Measuring(ttft = ttft)
            }
            
            tokenCount++
            val currentTime = System.nanoTime()
            val elapsedSinceFirst = TimeUnit.NANOSECONDS.toMillis(currentTime - firstTokenTime)
            
            if (elapsedSinceFirst > 0) {
                val tps = tokenCount.toDouble() / (elapsedSinceFirst / 1000.0)
                _currentMetrics.value = GenAiTelemetryManager.TelemetryState.Measuring(
                    ttft = TimeUnit.NANOSECONDS.toMillis(firstTokenTime - startTime),
                    tps = tps
                )
            }
            emit(token)
        }

        // Final persistence after stream completes
        val finalState = _currentMetrics.value as? TelemetryState.Measuring
        finalState?.let {
            dao.insertMetric(LatencyMetric(ttftMs = it.ttft, tps = it.tps))
        }
    }
}

// 3. Compose Developer Overlay
@Composable
fun DeveloperLatencyOverlay(metricsFlow: StateFlow<GenAiTelemetryManager.TelemetryState>) {
    val state by metricsFlow.collectAsStateWithLifecycle()

    if (state is GenAiTelemetryManager.TelemetryState.Measuring) {
        val data = state as GenAiTelemetryManager.TelemetryState.Measuring
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            Column(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("TTFT: ${data.ttft}ms", color = Color.Green, style = MaterialTheme.typography.labelSmall)
                Text("TPS: ${"%.2f".format(data.tps)}", color = Color.Green, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
