
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.performance.orchestration

import android.content.Context
import android.os.PowerManager
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.system.measureNanoTime

/**
 * Represents the hardware delegate strategy based on thermal pressure.
 */
enum class ComputeDelegate {
    NPU_ACCELERATED, // Maximum efficiency, high heat potential
    GPU_ACCELERATED, // High performance, moderate heat
    CPU_FALLBACK     // Lowest performance, safest thermal profile
}

/**
 * Data class to capture benchmarking metrics for a single inference cycle.
 */
data class InferenceMetrics(
    val latencyMs: Long,
    val tokensPerSecond: Double,
    val timeToFirstTokenMs: Long,
    val delegateUsed: ComputeDelegate,
    val thermalStatus: Int
)

/**
 * Repository responsible for monitoring system thermal state.
 */
@Singleton
class ThermalMonitoringRepository @Inject constructor(
    private val powerManager: PowerManager
) {
    // Emit thermal status updates every 2 seconds
    fun observeThermalStatus(): Flow<Int> = flow {
        while (true) {
            emit(powerManager.currentThermalStatus)
            delay(2000) 
        }
    }.flowOn(Dispatchers.Default).distinctUntilChanged()
}

/**
 * The Orchestrator handles the logic of mapping thermal states to hardware delegates
 * and executing the GenAI model with performance benchmarking.
 */
@Singleton
class InferenceOrchestrator @Inject constructor(
    private val thermalRepository: ThermalMonitoringRepository
) {
    private val TAG = "InferenceOrchestrator"

    // Maps Android Thermal Status to the optimal ComputeDelegate
    private fun resolveDelegate(status: Int): ComputeDelegate {
        return when (status) {
            PowerManager.THERMAL_STATUS_NONE, 
            PowerManager.THERMAL_STATUS_LIGHT -> ComputeDelegate.NPU_ACCELERATED
            PowerManager.THERMAL_STATUS_MODERATE -> ComputeDelegate.GPU_ACCELERATED
            else -> ComputeDelegate.CPU_FALLBACK // SEVERE or CRITICAL
        }
    }

    /**
     * Executes GenAI inference with hardware-aware orchestration.
     * @param prompt The input text for the LLM.
     * @param modelRunner A lambda simulating the actual MediaPipe/Gemini Nano call.
     */
    suspend fun executeAdaptiveInference(
        prompt: String,
        modelRunner: suspend (delegate: ComputeDelegate) -> String
    ): Pair<String, InferenceMetrics> = withContext(Dispatchers.Default) {
        
        // 1. Determine current thermal state and resolve delegate
        val currentStatus = thermalRepository.observeThermalStatus().first()
        val delegate = resolveDelegate(currentStatus)
        Log.d(TAG, "Thermal Status: $currentStatus -> Using Delegate: $delegate")

        var resultText = ""
        var ttft = 0L // Time to First Token
        
        // 2. Benchmark the inference process
        val totalNanoTime = measureNanoTime {
            // In a real scenario, the modelRunner would initialize the TFLite 
            // interpreter with the specific delegate (NPU/GPU/CPU).
            resultText = modelRunner(delegate)
            
            // Simulating TTFT measurement: In a streaming API, this would be 
            // the time from request to the first chunk emitted.
            ttft = (0..50).random().toLong() // Mocked TTFT for demonstration
        }

        val latencyMs = totalNanoTime / 1_000_000
        val tokenCount = resultText.split(" ").size.toDouble()
        val tps = if (latencyMs > 0) (tokenCount / (latencyMs / 1000.0)) else 0.0

        val metrics = InferenceMetrics(
            latencyMs = latencyMs,
            tokensPerSecond = tps,
            timeToFirstTokenMs = ttft,
            delegateUsed = delegate,
            thermalStatus = currentStatus
        )

        Pair(resultText, metrics)
    }
}

/**
 * ViewModel that exposes the GenAI functionality to the Jetpack Compose UI.
 */
@HiltViewModel
class GenAIViewModel @Inject constructor(
    private val orchestrator: InferenceOrchestrator
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<GenAIUiState>(GenAIUiState.Idle)
    val uiState: StateFlow<GenAIUiState> = _uiState.asStateFlow()

    fun generateResponse(prompt: String) {
        viewModelScope.launch {
            _uiState.value = GenAIUiState.Loading
            
            try {
                // The modelRunner lambda represents the actual interaction with Gemini Nano/MediaPipe
                val (response, metrics) = orchestrator.executeAdaptiveInference(prompt) { delegate ->
                    simulateModelInference(prompt, delegate)
                }
                
                _uiState.value = GenAIUiState.Success(response, metrics)
            } catch (e: Exception) {
                _uiState.value = GenAIUiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    private suspend fun simulateModelInference(prompt: String, delegate: ComputeDelegate): String {
        // Simulate varying latency based on delegate
        val delayTime = when (delegate) {
            ComputeDelegate.NPU_ACCELERATED -> 500L
            ComputeDelegate.GPU_ACCELERATED -> 800L
            ComputeDelegate.CPU_FALLBACK -> 2000L
        }
        delay(delayTime) 
        return "This is a simulated response for '$prompt' using $delegate."
    }
}

sealed class GenAIUiState {
    object Idle : GenAIUiState()
    object Loading : GenAIUiState()
    data class Success(val text: String, val metrics: InferenceMetrics) : GenAIUiState()
    data class Error(val message: String) : GenAIUiState()
}

/**
 * Hilt Module for providing Android System Services.
 */
@Module
@InstallIn(SingletonComponent::class)
object HardwareModule {
    @Provides
    @Singleton
    fun providePowerManager(@BindsInstance context: Context): PowerManager {
        return context.getSystemService(Context.POWER_SERVICE) as PowerManager
    }
}
