
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.genai.performance.thermal

import android.content.Context
import android.os.PowerManager
import android.util.Log
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifetime.ViewModelInject
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Defines the operational strategy based on thermal pressure.
 */
sealed class InferenceStrategy {
    object HighPerformance : InferenceStrategy() // GPU/NPU Max Clock
    object Balanced : InferenceStrategy()        // GPU with limited threads
    object PowerSaver : InferenceStrategy()      // CPU only / Reduced Precision
    object CriticalCooling : InferenceStrategy() // Heavy throttling / Forced delays
}

/**
 * Hardware-aware monitor that tracks Android Thermal Status.
 */
@Singleton
class ThermalMonitor @Inject constructor(
    private val powerManager: PowerManager
) {
    // Convert Android PowerManager.THERMAL_STATUS to our internal Strategy
    val thermalStrategy: Flow<InferenceStrategy> = callbackFlow {
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            val strategy = when (status) {
                PowerManager.THERMAL_STATUS_NONE, 
                PowerManager.THERMAL_STATUS_LIGHT -> InferenceStrategy.HighPerformance
                PowerManager.THERMAL_STATUS_MODERATE -> InferenceStrategy.Balanced
                PowerManager.THERMAL_STATUS_SEVERE -> InferenceStrategy.PowerSaver
                else -> InferenceStrategy.CriticalCooling
            }
            trySend(strategy)
        }
        powerManager.addThermalStatusListener(listener)
        awaitClose { powerManager.removeThermalStatusListener(listener) }
    }.stateIn(CoroutineScope(Dispatchers.Default), SharingStarted.WhileSubscribed(5000), InferenceStrategy.HighPerformance)
}

/**
 * Repository handling the actual AI Model deployment and execution.
 */
@Singleton
class AIInferenceRepository @Inject constructor() {
    private var currentDelegate = "GPU"

    suspend fun runInference(prompt: String, strategy: InferenceStrategy): String = withContext(Dispatchers.Default) {
        // Hardware Orchestration Logic
        val delayMs = when (strategy) {
            is InferenceStrategy.HighPerformance -> 0L
            is InferenceStrategy.Balanced -> 50L
            is InferenceStrategy.PowerSaver -> 200L
            is InferenceStrategy.CriticalCooling -> 500L
        }

        // Simulate hardware delegate switching
        updateHardwareDelegate(strategy)
        
        // Artificial "Cooling Gap" to prevent SoC thermal runaway
        if (delayMs > 0) delay(delayMs)

        Log.d("AI_REPO", "Executing inference using $currentDelegate with cooling gap ${delayMs}ms")
        
        // Mocking Gemini Nano / TFLite execution
        "Processed response for: $prompt [Mode: ${strategy::class.simpleName}]"
    }

    private fun updateHardwareDelegate(strategy: InferenceStrategy) {
        currentDelegate = when (strategy) {
            is InferenceStrategy.HighPerformance -> "NPU/GPU (Max)"
            is InferenceStrategy.Balanced -> "GPU (Optimized)"
            is InferenceStrategy.PowerSaver -> "CPU (Low Power)"
            is InferenceStrategy.CriticalCooling -> "CPU (Throttled)"
        }
    }
}

/**
 * ViewModel implementing the MVI flow to handle AI requests with thermal awareness.
 */
@AndroidEntryPoint
class AIViewModel @Inject constructor(
    private val thermalMonitor: ThermalMonitor,
    private val repository: AIInferenceRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<AIUiState>(AIUiState.Idle)
    val uiState: StateFlow<AIUiState> = _uiState.asStateFlow()

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _uiState.value = AIUiState.Loading
            
            // Collect the most recent thermal strategy before executing
            val currentStrategy = thermalMonitor.thermalStrategy.first()
            
            try {
                val result = repository.runInference(prompt, currentStrategy)
                _uiState.value = AIUiState.Success(result, currentStrategy)
            } catch (e: Exception) {
                _uiState.value = AIUiState.Error(e.message ?: "Unknown Error")
            }
        }
    }

    sealed class AIUiState {
        object Idle : AIUiState()
        object Loading : AIUiState()
        data class Success(val data: String, val strategy: InferenceStrategy) : AIUiState()
        data class Error(val message: String) : AIUiState()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object ThermalModule {
    @Provides
    @Singleton
    fun providePowerManager(@BindsInstance context: Context): PowerManager = 
        context.getSystemService(Context.POWER_SERVICE) as PowerManager
}
