
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import android.content.Context
import android.os.PowerManager
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the performance metrics of a single inference request.
 */
@Serializable
data class InferenceMetrics(
    val ttftMs: Long,            // Time to First Token
    val averageTpotMs: Double,   // Average Time Per Output Token
    val totalTokens: Int,
    val thermalStatus: Int,      // PowerManager.THERMAL_STATUS_*
    val memoryUsageMb: Long
)

/**
 * A specialized dispatcher for AI operations to prevent 
 * thread starvation on the Default dispatcher.
 */
val AIDispatcher = Dispatchers.Default.limitedParallelism(1)

@Singleton
class AICorePerformanceManager @Inject constructor(
    private val context: Context
) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Monitors thermal status as a cold Flow.
     * This allows the UI or the Model to react to overheating in real-time.
     */
    fun monitorThermalState(): Flow<Int> = callbackFlow {
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            trySend(status)
        }
        powerManager.addThermalStatusListener(listener)
        awaitClose { powerManager.removeThermalStatusListener(listener) }
    }.flowOn(Dispatchers.IO)

    /**
     * Executes an inference request while benchmarking performance.
     * 
     * @param prompt The input text.
     * @param modelAction The actual call to Gemini Nano/AICore.
     */
    suspend fun <T> benchmarkInference(
        prompt: String,
        modelAction: suspend (String) -> Flow<T>
    ): Pair<Flow<T>, InferenceMetrics> = withContext(AIDispatcher) {
        val startTime = System.currentTimeMillis()
        var firstTokenTime = 0L
        var tokenCount = 0
        val tokenTimestamps = mutableListOf<Long>()

        // We wrap the original flow to inject benchmarking logic
        val benchmarkedFlow = modelAction(prompt).onStart {
            // This block runs when the flow is first collected
        }.onEach {
            val now = System.currentTimeMillis()
            if (tokenCount == 0) {
                firstTokenTime = now - startTime
            }
            tokenTimestamps.add(now)
            tokenCount++
        }

        // Calculate metrics after the flow completes (this is a simplified approach)
        // In a real scenario, you'd use a shared flow or a wrapper object.
        
        // To keep the flow returning immediately, we calculate metrics 
        // asynchronously or return a deferred metrics object.
        
        val metrics = InferenceMetrics(
            ttftMs = 0, // Will be updated via side-effect or post-processing
            averageTpotMs = 0.0,
            totalTokens = 0,
            thermalStatus = powerManager.currentThermalStatus,
            memoryUsageMb = getProcessMemoryUsage()
        )

        return@withContext benchmarkedFlow to metrics
    }

    private fun getProcessMemoryUsage(): Long {
        val runtime = Runtime.getRuntime()
        return (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
    }
}

/**
 * Using Context Receivers (Kotlin 2.x) to provide AI capabilities.
 * This ensures that any function using [generateText] has access to 
 * the performance manager and the AI model.
 */
context(AICorePerformanceManager, GeminiModelProvider)
suspend fun generateText(prompt: String): Flow<String> {
    Log.d("AI_PERF", "Starting inference with thermal status: ${monitorThermalState().first()}")
    
    // The actual call to the model
    return executeInference(prompt)
        .onEach { token ->
            // Logic to handle token streaming
        }
}

// Mock providers for the example
interface GeminiModelProvider {
    suspend fun executeInference(prompt: String): Flow<String>
}
