
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. AI Repository: Handles the raw interaction with the On-Device LLM.
 * This layer ensures that AI inference happens off the Main Thread.
 */
@Singleton
class AiRepository @Inject constructor() {
    // In a real scenario, this would be your GeminiNano or MediaPipe LLM instance
    // For this example, we simulate a token-by-token stream
    fun generateTextStream(prompt: String): Flow<String> = flow {
        val simulatedResponse = "On-device GenAI allows for privacy, offline capability, and reduced latency by running models directly on the NPU/GPU."
        val tokens = simulatedResponse.split(" ")

        for (token in tokens) {
            // Simulate the time it takes for the LLM to generate a token
            kotlinx.coroutines.delay(100) 
            // Emit the token followed by a space to the collector
            emit("$token ") 
        }
    }.flowOn(Dispatchers.Default) // CRITICAL: Ensure inference runs on background threads
}

/**
 * 2. ViewModel: Orchestrates the Flow and maintains UI state.
 * It converts the cold Flow from the repository into a hot StateFlow for the UI.
 */
@HiltViewModel
class AiViewModel @Inject constructor(
    private val repository: AiRepository
) : ViewModel() {

    // Holds the accumulated text to be displayed in the UI
    private val _uiState = MutableStateFlow("")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    // Tracks whether the AI is currently generating text
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _isGenerating.value = true
            _uiState.value = "" // Reset state for new prompt

            repository.generateTextStream(prompt)
                .catch { e -> 
                    _uiState.value = "Error: ${e.localizedMessage}" 
                }
                .collect { token ->
                    // Append each new token to the existing state
                    _uiState.value += token
                }

            _isGenerating.value = false
        }
    }
}

/**
 * 3. UI Layer: A Jetpack Compose screen that observes the StateFlow.
 */
@Composable
fun StreamingAiScreen(viewModel: AiViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var inputPrompt by remember { mutableStateOf("") }
    
    // collectAsStateWithLifecycle is the modern way to collect flows in Compose
    // It automatically pauses collection when the app is in the background
    val streamedText by viewModel.uiState.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TextField(
            value = inputPrompt,
            onValueChange = { inputPrompt = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask Gemini Nano something...") },
            enabled = !isGenerating
        )

        Button(
            onClick = { viewModel.sendPrompt(inputPrompt) },
            modifier = Modifier.padding(vertical = 8.dp),
            enabled = !isGenerating && inputPrompt.isNotBlank()
        ) {
            Text(if (isGenerating) "Generating..." else "Send")
        }

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        // Scrollable area to display the streaming output
        Text(
            text = streamedText,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        )
    }
}
