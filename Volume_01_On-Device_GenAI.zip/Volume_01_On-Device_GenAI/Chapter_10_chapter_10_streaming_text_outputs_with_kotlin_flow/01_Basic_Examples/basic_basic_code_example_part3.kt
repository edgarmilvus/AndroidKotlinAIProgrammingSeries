
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.genai.data.GenAiRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State representing the current status of the AI interaction.
 */
data class AiUiState(
    val fullText: String = "",
    val isGenerating: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class GenAiViewModel @Inject constructor(
    private val repository: GenAiRepository
) : ViewModel() {

    // Private mutable state to prevent external modification
    private val _uiState = MutableStateFlow(AiUiState())
    // Public immutable state for the Compose UI to observe
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    /**
     * Triggers the AI generation process.
     */
    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            // Reset state for new prompt
            _uiState.update { it.copy(fullText = "", isGenerating = true, errorMessage = null) }

            try {
                repository.generateResponseStream(prompt)
                    .catch { e -> 
                        _uiState.update { it.copy(errorMessage = e.localizedMessage, isGenerating = false) }
                    }
                    .collect { chunk ->
                        // Append the new chunk to the existing text
                        _uiState.update { currentState ->
                            currentState.copy(
                                fullText = currentState.fullText + chunk
                            )
                        }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Inference failed: ${e.message}", isGenerating = false) }
            } finally {
                _uiState.update { it.copy(isGenerating = false) }
            }
        }
    }
}
