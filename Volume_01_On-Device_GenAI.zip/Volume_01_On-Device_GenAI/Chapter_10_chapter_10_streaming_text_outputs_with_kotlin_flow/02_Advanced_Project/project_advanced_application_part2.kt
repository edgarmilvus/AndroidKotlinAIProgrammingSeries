
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.assistant.core

import android.content.Context
import android.util.Log
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.qualifiers.ApplicationContext
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.Inject
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DATA STATE: Represents the UI state of the AI Assistant.
 */
data class AssistantUiState(
    val inputPrompt: String = "",
    val generatedText: String = "",
    val isGenerating: Boolean = false,
    val error: String? = null
)

/**
 * REPOSITORY: Handles the low-level interaction with the LLM.
 * This is a Singleton because loading the model into memory is expensive.
 */
@Singleton
class GenAiRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with hardware-aware options
    suspend fun initializeModel() = withContext(Dispatchers.Default) {
        if (llmInference != null) return@withContext

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to on-device model
            .setMaxTokens(1024)
            .setTopK(40)
            .setTemperature(0.7f)
            // Hardware Orchestration: MediaPipe internally handles the 
            // GPU/NPU delegate based on the device's TFLite capabilities.
            .build()

        llmInference = LlmInference.createFromOptions(context, options)
        Log.d("GenAiRepo", "LLM Model loaded successfully on hardware delegate.")
    }

    /**
     * THE STREAMING ENGINE: Converts the callback-based MediaPipe API 
     * into a cold Kotlin Flow.
     */
    fun streamCompletion(prompt: String): Flow<String> = callbackFlow {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")

        // generateResponseAsync is the non-blocking streaming call
        inference.generateResponseAsync(prompt) { partialResult, done ->
            // Emit each token as it arrives from the NPU
            trySend(partialResult) 
            
            if (done) {
                close() // Close the flow channel when the LLM finishes
            }
        }

        // Ensure the LLM resources are cleaned up if the flow is cancelled
        awaitClose {
            Log.d("GenAiRepo", "Streaming cancelled by consumer.")
        }
    }.flowOn(Dispatchers.Default) // Ensure inference runs on background threads
}

/**
 * VIEWMODEL: Manages the UI state and handles structured concurrency.
 */
@HiltViewModel
class WritingAssistantViewModel @Inject constructor(
    private val repository: GenAiRepository
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    // Job reference to manage the current streaming session
    private var streamingJob: Job? = null

    init {
        viewModelScope.launch {
            try {
                repository.initializeModel()
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Model Load Failed: ${e.localizedMessage}") }
            }
        }
    }

    fun onPromptChanged(newPrompt: String) {
        _uiState.update { it.copy(inputPrompt = newPrompt) }
    }

    fun generateSmartCompletion() {
        val currentPrompt = _uiState.value.inputPrompt
        if (currentPrompt.isBlank()) return

        // Cancel any existing generation to prevent overlapping streams
        streamingJob?.cancel()

        streamingJob = viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, generatedText = "", error = null) }

            try {
                // Collect the stream from the repository
                repository.streamCompletion(currentPrompt)
                    .onStart { Log.d("VM", "Starting AI Stream...") }
                    .catch { e -> 
                        _uiState.update { it.copy(error = e.localizedMessage, isGenerating = false) } 
                    }
                    .collect { token ->
                        // Append the new token to the existing state
                        _uiState.update { it.copy(generatedText = it.generatedText + token) }
                    }
            } catch (e: CancellationException) {
                Log.d("VM", "Generation was cancelled.")
            } finally {
                _uiState.update { it.copy(isGenerating = false) }
            }
        }
    }

    fun cancelGeneration() {
        streamingJob?.cancel()
        _uiState.update { it.copy(isGenerating = false) }
    }
}
