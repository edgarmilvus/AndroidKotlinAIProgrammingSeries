
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.genai.assistant

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.Inject
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the UI state for the AI Assistant.
 * Using a sealed interface ensures exhaustive state handling in Compose.
 */
sealed interface AiAssistantUiState {
    object Idle : AiAssistantUiState
    object Thinking : AiAssistantUiState
    data class Streaming(val partialText: String) : AiAssistantUiState
    data class Success(val fullText: String) : AiAssistantUiState
    data class Error(val message: String) : AiAssistantUiState
}

/**
 * Repository responsible for managing the LLM lifecycle and inference.
 */
@Singleton
class GenAiRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the LLM engine. In a real app, this should be called 
    // during a splash screen or background worker to avoid UI lag.
    fun initializeModel() {
        if (llmInference != null) return
        
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to local .bin model
            .setMaxTokens(1024)
            .setTemperature(0.7f)
            .setTopK(40)
            .build()
            
        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Streams the response from the LLM using a Flow.
     * We use flow { ... } to emit tokens as they are generated.
     */
    fun streamRefinedText(prompt: String): Flow<String> = flow {
        val engine = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // We wrap the callback-based MediaPipe API into a Flow.
        // The engine.generateResponse() method can be used for non-streaming,
        // but for streaming, we use the callback variant.
        
        val fullResponse = StringBuilder()
        
        // Note: MediaPipe LLM Inference provides a streaming callback.
        // We use a callbackFlow or a custom flow wrapper to bridge it.
        callbackFlow {
            engine.generateResponseAsync(prompt) { partialResult, done ->
                fullResponse.append(partialResult)
                trySend(fullResponse.toString())
                if (done) {
                    channel.close()
                }
            }
            awaitClose { /* Cleanup if necessary */ }
        }
        .flowOn(Dispatchers.Default) // Ensure AI compute doesn't block Main thread
        .collect { value ->
            emit(value)
        }
    }
}

/**
 * ViewModel implementing MVI-like state management.
 */
@AndroidEntryPoint
class AiAssistantViewModel @Inject constructor(
    private val repository: GenAiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AiAssistantUiState>(AiAssistantUiState.Idle)
    val uiState: StateFlow<AiAssistantUiState> = _uiState.asStateFlow()

    private var streamingJob: Job? = null

    fun refineDocument(userDraft: String) {
        // Cancel any existing streaming job to prevent overlapping outputs
        streamingJob?.cancel()

        streamingJob = viewModelScope.launch {
            _uiState.value = AiAssistantUiState.Thinking
            
            try {
                // Construct a system prompt to guide Gemini Nano
                val systemPrompt = "Refine the following text for professional clarity and grammar: $userDraft"
                
                repository.streamRefinedText(systemPrompt)
                    .onStart { 
                        // Transition to streaming state as soon as first token arrives
                    }
                    .catch { e -> 
                        _uiState.value = AiAssistantUiState.Error(e.localizedMessage ?: "Unknown Error") 
                    }
                    .collect { partialText ->
                        _uiState.value = AiAssistantUiState.Streaming(partialText)
                    }
                
                // Once the flow completes, move to Success state
                val finalState = _uiState.value
                if (finalState is AiAssistantUiState.Streaming) {
                    _uiState.value = AiAssistantUiState.Success(finalState.partialText)
                }
                
            } catch (e: Exception) {
                _uiState.value = AiAssistantUiState.Error("Inference failed: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        streamingJob?.cancel()
    }
}
