
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.lifecycle.*
import androidx.lifecycle.compose.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// 1. Data Layer: Simulating Gemini Nano token generation
class AiRepository {
    fun streamSummary(prompt: String): Flow<String> = flow {
        val simulatedResponse = "This is a simulated AI summary for: '$prompt'. It generates tokens one by one to mimic a real LLM streaming experience."
        val tokens = simulatedResponse.split(" ")
        
        for (token in tokens) {
            delay(100) // Simulate network/inference latency
            emit("$token ") 
        }
    }
}

// 2. ViewModel: Bridging the Flow to StateFlow
class SummaryViewModel(private val repository: AiRepository = AiRepository()) : ViewModel() {
    private val _uiState = MutableStateFlow("")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    fun generateSummary(prompt: String) {
        viewModelScope.launch {
            _uiState.value = "" // Reset state for new prompt
            repository.streamSummary(prompt)
                .collect { token ->
                    _uiState.value += token // Append incrementally
                }
        }
    }
}

// 3. UI: Observing the stream with lifecycle awareness
@Composable
fun QuickNoteScreen(viewModel: SummaryViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var prompt by remember { mutableStateOf("") }
    // collectAsStateWithLifecycle ensures collection stops when app is in background
    val summary by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Enter prompt") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.generateSummary(prompt) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Summarize")
        }
        Text(text = summary, style = MaterialTheme.typography.bodyLarge)
    }
}
