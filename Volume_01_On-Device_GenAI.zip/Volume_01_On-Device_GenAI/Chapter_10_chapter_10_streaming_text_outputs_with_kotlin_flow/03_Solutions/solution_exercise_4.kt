
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel

fun Flow<String>.smoothTokens(intervalMs: Long = 30L): Flow<String> = channelFlow {
    val tokenChannel = Channel<String>(capacity = Channel.UNLIMITED)

    // Producer: Collect raw tokens from AI and put them in the channel
    launch {
        collect { token -> tokenChannel.send(token) }
    }

    // Consumer: Release tokens from the channel at a fixed interval
    launch {
        while (isActive) {
            val token = tokenChannel.tryReceive().getOrNull()
            if (token != null) {
                send(token)
                delay(intervalMs)
            } else {
                // If channel is empty, wait a bit before checking again 
                // to avoid tight loop when AI is thinking
                delay(intervalMs) 
            }
        }
    }
}.flowOn(Dispatchers.Default)

// ViewModel Implementation
class SmoothViewModel(private val repository: AiRepository = AiRepository()) : ViewModel() {
    private val _uiState = MutableStateFlow("")
    val uiState = _uiState.asStateFlow()

    fun startStreaming(prompt: String) {
        viewModelScope.launch {
            repository.streamSummary(prompt)
                .smoothTokens() // Apply custom smoothing operator
                .collect { token ->
                    _uiState.value += token
                }
        }
    }
}
