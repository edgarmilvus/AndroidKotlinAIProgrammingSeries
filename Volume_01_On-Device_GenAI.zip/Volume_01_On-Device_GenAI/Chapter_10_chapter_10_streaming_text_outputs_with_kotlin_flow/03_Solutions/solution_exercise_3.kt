
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

class ChatViewModel(private val repository: AiRepository = AiRepository()) : ViewModel() {
    private val _messages = MutableStateFlow<String>("")
    val messages: StateFlow<String> = _messages.asStateFlow()

    private var streamingJob: Job? = null

    fun generateResponse(prompt: String) {
        // Requirement 2 & 3: Cancel previous job before starting new one
        streamingJob?.cancel() 
        
        streamingJob = viewModelScope.launch {
            _messages.value = ""
            repository.streamSummary(prompt).collect { token ->
                _messages.value += token
            }
        }
    }

    fun stopGeneration() {
        streamingJob?.cancel() // Requirement 2: Halt LLM stream
    }
}

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val text by viewModel.messages.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    
    // Requirement 1: Intelligent Scrolling
    val isAtBottom by remember {
        derivedStateOf {
            val lastVisibleItem = listState.layoutInfo.visibleItemsInfo.lastOrNull()
            lastVisibleItem?.index == listState.layoutInfo.totalItemsCount - 1
        }
    }

    LaunchedEffect(text) {
        if (isAtBottom) {
            listState.animateScrollToItem(listState.layoutInfo.totalItemsCount)
        }
    }

    Column {
        LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
            item { Text(text) }
        }
        Row {
            Button(onClick = { viewModel.generateResponse("Hello") }) { Text("Send") }
            Button(onClick = { viewModel.stopGeneration() }) { Text("Stop") }
        }
    }
}
