
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class StreamManager @Inject constructor() {
    private val activeJobs = mutableMapOf<String, Job>()
    private val mutex = Mutex()
    
    private val _systemEvents = MutableSharedFlow<String>(replay = 0)
    val systemEvents = _systemEvents.asSharedFlow()

    suspend fun <T> runStream(
        streamId: String, 
        scope: CoroutineScope, 
        block: suspend () -> T
    ) {
        mutex.withLock {
            if (activeJobs.size >= 2) {
                // Concurrency Guard: Cancel oldest stream
                val oldestId = activeJobs.keys.first()
                activeJobs[oldestId]?.cancel()
                activeJobs.remove(oldestId)
                _systemEvents.emit("Stream $oldestId paused due to resource limits")
            }

            val job = scope.launch {
                try {
                    block()
                } finally {
                    mutex.withLock { activeJobs.remove(streamId) }
                }
            }
            activeJobs[streamId] = job
        }
    }
}

class MultiAgentViewModel(private val streamManager: StreamManager) : ViewModel() {
    private val _agentStates = MutableStateFlow<Map<String, String>>(emptyMap())
    val agentStates = _agentStates.asStateFlow()

    fun requestAgent(agentId: String, prompt: String) {
        viewModelScope.launch {
            streamManager.runStream(agentId, this) {
                // Use flatMapLatest if we were switching models here
                repository.streamSummary(prompt).collect { token ->
                    _agentStates.update { current -> 
                        val existingText = current[agentId] ?: ""
                        current + (agentId to (existingText + token))
                    }
                }
            }
        }
    }
}
