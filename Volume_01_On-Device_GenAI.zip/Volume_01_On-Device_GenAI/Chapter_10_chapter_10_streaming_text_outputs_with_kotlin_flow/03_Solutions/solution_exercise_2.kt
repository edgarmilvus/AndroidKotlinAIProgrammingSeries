
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

sealed class AICoreState {
    object Checking : AICoreState()
    data class Downloading(val progress: Float) : AICoreState()
    object Ready : AICoreState()
    data class Error(val message: String) : AICoreState()
}

class AICoreRepository @Inject constructor(
    private val aiCoreService: AICoreService // Hypothetical SDK service
) {
    fun getServiceState(): Flow<AICoreState> = callbackFlow {
        val listener = object : AICoreListener {
            override fun onProgress(p: Float) { trySend(AICoreState.Downloading(p)) }
            override fun onReady() { trySend(AICoreState.Ready) }
            override fun onError(err: String) { 
                if (err == "SERVICE_BUSY") {
                    close(ServiceBusyException())
                } else {
                    trySend(AICoreState.Error(err))
                }
            }
        }

        aiCoreService.registerListener(listener)
        trySend(AICoreState.Checking)

        awaitClose { aiCoreService.unregisterListener(listener) }
    }.retryWhen { cause, attempt ->
        if (cause is ServiceBusyException && attempt < 3) {
            delay(1000L * (attempt + 1)) // Exponential backoff
            true
        } else {
            false
        }
    }.shareIn(
        scope = ProcessLifecycleOwner.get().lifecycleScope,
        started = SharingStarted.WhileSubscribed(5000),
        replay = 1
    )
}

class ServiceBusyException : Exception()
