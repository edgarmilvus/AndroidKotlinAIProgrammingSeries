
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

sealed class AiResponseState {
    object Idle : AiResponseState()
    object Thinking : AiResponseState()
    data class Streaming(val text: String) : AiResponseState()
    data class Completed(val text: String) : AiResponseState()
    data class Error(val message: String) : AiResponseState()
}

class AiStateViewModel(private val repository: AiRepository = AiRepository()) : ViewModel() {
    private val _prompt = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<AiResponseState> = _prompt
        .flatMapLatest { prompt ->
            if (prompt.isEmpty()) flowOf(AiResponseState.Idle)
            else {
                repository.streamSummary(prompt)
                    .map { token -> 
                        // This is a simplification; we need to accumulate text
                        // In a real app, we'd use scan() to accumulate tokens
                        AiResponseState.Streaming(token) 
                    }
                    .onStart { emit(AiResponseState.Thinking) }
                    .catch { e -> emit(AiResponseState.Error(e.message ?: "Unknown Error")) }
                    .onCompletion { emit(AiResponseState.Completed("Done!")) }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AiResponseState.Idle
        )

    // Improved version using scan to accumulate text
    fun generateResponse(prompt: String) {
        viewModelScope.launch {
            repository.streamSummary(prompt)
                .onStart { _uiState.value = AiResponseState.Thinking }
                .scan(AiResponseState.Streaming("")) { accumulator, token ->
                    val currentText = (accumulator as? AiResponseState.Streaming)?.text ?: ""
                    AiResponseState.Streaming(currentText + token)
                }
                .catch { _uiState.value = AiResponseState.Error(it.message ?: "Error") }
                .onCompletion { if (_uiState.value is AiResponseState.Streaming) {
                    val finalText = (_uiState.value as AiResponseState.Streaming).text
                    _uiState.value = AiResponseState.Completed(finalText)
                }}
                .collect { _uiState.value = it }
        }
    }
    
    private val _uiState = MutableStateFlow<AiResponseState>(AiResponseState.Idle)
    val state: StateFlow<AiResponseState> = _uiState.asStateFlow()
}

@Composable
fun AiStateScreen(viewModel: AiStateViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column {
            when (val s = state) {
                is AiResponseState.Idle -> Text("Ask me something!")
                is AiResponseState.Thinking -> CircularProgressIndicator()
                is AiResponseState.Streaming -> Text(s.text)
                is AiResponseState.Completed -> Text(s.text)
                is AiResponseState.Error -> {
                    LaunchedEffect(s.message) { snackbarHostState.showSnackbar(s.message) }
                    Text("Error occurred")
                }
            }
            
            if (state is AiResponseState.Completed || state is AiResponseState.Error) {
                Button(onClick = { /* trigger regenerate */ }) { Text("Regenerate") }
            }
        }
        SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter))
    }
}
