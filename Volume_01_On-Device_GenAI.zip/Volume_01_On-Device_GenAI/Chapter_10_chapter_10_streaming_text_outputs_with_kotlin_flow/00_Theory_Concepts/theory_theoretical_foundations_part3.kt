
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import javax.inject.Inject
import javax.inject.Singleton

// Domain model for the AI response
data class AiResponseState(
    val text: String = "",
    val isGenerating: Boolean = false,
    val error: String? = null
)

@Singleton
class GeminiNanoRepository @Inject constructor(
    private val aiCoreClient: AICoreClient // Hypothesized system client
) {
    /**
     * Streams the response from Gemini Nano.
     * We use a Flow to emit partial strings as they arrive from the NPU.
     */
    fun streamChatResponse(prompt: String): Flow<String> = flow {
        // The 'collect' call here happens inside the native AICore runtime
        aiCoreClient.generateContentStream(prompt).collect { chunk ->
            emit(chunk) 
        }
    }.flowOn(Dispatchers.Default) // Ensure NPU-to-JVM bridging doesn't block Main
}

@Inject
class ChatViewModel @Inject constructor(
    private val repository: GeminiNanoRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(AiResponseState())
    val uiState: StateFlow<AiResponseState> = _uiState.asStateFlow()

    fun sendPrompt(prompt: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, text = "") }
            
            repository.streamChatResponse(prompt)
                .catch { e -> 
                    _uiState.update { it.copy(error = e.message, isGenerating = false) } 
                }
                .collect { token ->
                    // Append each token to the existing state for a "typing" effect
                    _uiState.update { it.copy(text = it.text + token) }
                }
            
            _uiState.update { it.copy(isGenerating = false) }
        }
    }
}
