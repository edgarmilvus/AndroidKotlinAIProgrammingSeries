
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

// 1. Prompt Builder with Sliding Window
class PromptBuilder(private val maxMessages: Int = 10) {
    fun buildPrompt(history: List<ChatMessage>, systemPrompt: String): String {
        // Always keep the system prompt, then take the last N messages
        val windowedHistory = if (history.size > maxMessages) {
            history.takeLast(maxMessages)
        } else {
            history
        }

        return buildString {
            appendLine("System: $systemPrompt")
            windowedHistory.forEach { msg ->
                appendLine("${msg.role}: ${msg.content}")
            }
        }
    }
}

// 2. Session Manager (Singleton)
@Singleton
class SessionManager @Inject constructor() {
    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId = _currentConversationId.asStateFlow()

    fun setSession(id: String) { _currentConversationId.value = id }
}

// 3. Session-Aware ViewModel
@HiltViewModel
class ThreadedChatViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val repository: ChatRepository,
    private val promptBuilder: PromptBuilder
) : ViewModel() {

    // Automatically switch history when session ID changes
    @OptIn(ExperimentalCoroutinesApi::class)
    val messages = sessionManager.currentConversationId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) 
        else repository.getChatStream(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun preparePromptForAI(systemPrompt: String): String {
        return promptBuilder.buildPrompt(messages.value, systemPrompt)
    }
}

// 4. Navigation and Drawer UI
@Composable
fun MainChatScreen(navController: NavController) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("Your Conversations", modifier = Modifier.padding(16.dp))
                // List of conversations from DB
                ConversationList(onConversationClick = { id ->
                    // Update session and close drawer
                    // sessionManager.setSession(id)
                    scope.launch { drawerState.close() }
                })
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI Chat") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    }
                )
            }
        ) { padding ->
            ChatContent(modifier = Modifier.padding(padding))
        }
    }
}
