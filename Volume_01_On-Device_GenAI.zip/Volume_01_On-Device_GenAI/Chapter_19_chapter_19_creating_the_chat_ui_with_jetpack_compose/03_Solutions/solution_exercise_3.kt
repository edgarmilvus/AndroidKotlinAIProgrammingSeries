
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.room.*
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

// Room Persistence
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val text: String,
    val sender: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAllMessages(): kotlinx.coroutines.flow.Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(message: MessageEntity)
}

// Markdown Parser
object MarkdownParser {
    fun parse(text: String): AnnotatedString {
        return buildAnnotatedString {
            var currentText = text
            // Simple regex for Bold (**text**) and Italic (*text*)
            val boldRegex = "\\*\\*(.*?)\\*\\*".toRegex()
            val italicRegex = "\\*(.*?)\\*".toRegex()

            // This is a simplified parser for demonstration
            // In production, use a state-machine or a library like Markwon
            val parts = text.split(Regex("(?<=\\*\\*)|(?=\\*\\*)")) 
            // Note: Real parsing requires a more complex loop to handle nested styles
            
            append(text) // Fallback: for the exercise, we'll use a basic style map
            // Example of manual styling for a specific pattern
            if (text.contains("**")) {
                // Logic to find indices and apply SpanStyle(fontWeight = FontWeight.Bold)
            }
        }
    }
    
    // Improved simple implementation for the exercise
    fun renderSimpleMarkdown(text: String): AnnotatedString {
        return buildAnnotatedString {
            val tokens = text.split(Regex("(?<=\\*\\*)|(?=\\*\\*)"))
            var isBold = false
            tokens.forEach { token ->
                if (token == "**") {
                    isBold = !isBold
                } else {
                    withStyle(style = if (isBold) SpanStyle(fontWeight = FontWeight.Bold) else SpanStyle()) {
                        append(token)
                    }
                }
            }
        }
    }
}
