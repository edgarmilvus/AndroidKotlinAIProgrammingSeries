
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. ViewModel with Token Accumulation
class StreamingChatViewModel : ViewModel() {
    private val _streamingText = MutableStateFlow("")
    val streamingText = _streamingText.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking = _isThinking.asStateFlow()

    fun startStreaming() {
        viewModelScope.launch {
            _isThinking.value = true
            val tokens = listOf("Hello", "!", " I", " am", " Gemini", " Nano", "...", " **Bold**", " text")
            
            tokens.forEach { token ->
                delay(50) // Simulate network/NPU latency
                _streamingText.value += token 
            }
            _isThinking.value = false
        }
    }
}

// 2. Optimized Markdown Rendering
@Composable
fun StreamingMarkdownText(text: String) {
    // Cache the parsing logic to avoid re-parsing the whole string on every token
    val annotatedString = remember(text) {
        buildAnnotatedString {
            // Basic custom parser for **bold**
            var isBold = false
            var currentText = StringBuilder()
            
            text.forEach { char ->
                if (char == '*') {
                    if (isBold) {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(currentText.toString())
                        }
                        currentText.clear()
                        isBold = false
                    } else {
                        isBold = true
                    }
                } else {
                    currentText.append(char)
                }
            }
            append(currentText.toString())
        }
    }
    Text(text = annotatedString)
}

// 3. Smooth Scroll Logic
@Composable
fun ChatList(viewModel: StreamingChatViewModel) {
    val listState = rememberLazyListState()
    val streamingText by viewModel.streamingText.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    // Monitor scroll position to determine if we should auto-scroll
    LaunchedEffect(streamingText) {
        val isAtBottom = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index == 
                         listState.layoutInfo.totalItemsCount - 1
        
        if (isAtBottom) {
            listState.animateScrollToItem(listState.layoutInfo.totalItemsCount)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            item { StreamingMarkdownText(streamingText) }
        }

        if (isThinking) {
            TypingIndicator(modifier = Modifier.align(Alignment.BottomStart))
        }
    }
}

@Composable
fun TypingIndicator(modifier: Modifier) {
    Row(modifier = modifier.padding(16.dp)) {
        repeat(3) { index ->
            Box(
                Modifier.size(8.dp).clip(CircleShape).background(Color.Gray)
                    .animateFloatAsState(targetValue = 1f) // Simplified animation
            )
            Spacer(Modifier.width(4.dp))
        }
    }
}
