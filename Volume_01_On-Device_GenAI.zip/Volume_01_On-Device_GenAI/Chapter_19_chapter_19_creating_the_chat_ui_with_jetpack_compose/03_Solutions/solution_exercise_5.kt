
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable

@Composable
fun AdaptiveChatLayout(
    widthSizeClass: WindowWidthSizeClass,
    viewModel: ChatViewModel
) {
    var selectedChatId by remember { mutableStateOf("default") }

    when (widthSizeClass) {
        Compact -> {
            // Standard single-pane view
            ChatDetailPane(viewModel, selectedChatId)
        }
        Medium, Expanded -> {
            // Dual-pane view
            Row(modifier = Modifier.fillMaxSize()) {
                // Left Pane: History (30%)
                Box(modifier = Modifier.weight(0.3f).fillMaxHeight().background(MaterialTheme.colorScheme.surface)) {
                    ConversationList(
                        onConversationSelected = { id -> selectedChatId = id },
                        selectedId = selectedChatId
                    )
                }
                
                // Right Pane: Active Chat (70%)
                Box(modifier = Modifier.weight(0.7f).fillMaxHeight()) {
                    ChatDetailPane(viewModel, selectedChatId)
                }
            }
        }
    }
}

@Composable
fun ConversationList(onConversationSelected: (String) -> Unit, selectedId: String) {
    val conversations = listOf("Chat 1", "Chat 2", "Chat 3") // Mock data
    LazyColumn {
        items(conversations) { chat ->
            ListItem(
                headlineContent = { Text(chat) },
                modifier = Modifier.clickable { onConversationSelected(chat) },
                colors = ListItemDefaults.colors(
                    containerColor = if (chat == selectedId) MaterialTheme.colorScheme.primaryContainer 
                                     else MaterialTheme.colorScheme.surface
                )
            )
        }
    }
}

@Composable
fun ChatDetailPane(viewModel: ChatViewModel, chatId: String) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Chat messages area
        Box(modifier = Modifier.weight(1f)) {
            OptimizedChatScreen(viewModel)
        }
        // Adaptive Input: Fixed bottom bar
        MessageInputBar(onSend = { text -> viewModel.sendMessage(text) })
    }
}
