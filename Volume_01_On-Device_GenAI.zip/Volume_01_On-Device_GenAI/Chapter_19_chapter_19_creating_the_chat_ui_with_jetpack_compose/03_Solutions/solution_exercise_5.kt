
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// 1. Stability Optimization
@Immutable
data class ChatMessageUiModel(
    val id: Long,
    val role: MessageRole,
    val content: String
)

// Use kotlinx.collections.immutable.ImmutableList
data class ChatUiState(
    val messages: ImmutableList<ChatMessageUiModel> = persistentListOf()
)

// 2. Advanced LazyColumn Tuning
@Composable
fun OptimizedChatList(state: ChatUiState) {
    LazyColumn {
        items(
            items = state.messages,
            key = { it.id }, // Stable key
            contentType = { it.role } // Optimize recycling based on role
        ) { msg ->
            ChatBubbleItem(msg)
        }
    }
}

@Composable
fun ChatBubbleItem(msg: ChatMessageUiModel) {
    // Move expensive formatting to remember or ViewModel
    val formattedTimestamp = remember(msg.id) { 
        formatTimestamp(msg.id) // Hypothetical expensive function
    }

    ChatBubble(role = msg.role) {
        Column {
            Text(text = msg.content)
            Text(text = formattedTimestamp, style = MaterialTheme.typography.labelSmall)
        }
    }
}

// 3. Paging 3 Integration (Conceptual)
class ChatPagingSource(val dao: ChatDao, val convId: String) : PagingSource<Int, ChatMessage>() {
    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ChatMessage> {
        val position = params.key ?: 0
        val data = dao.getPagedMessages(convId, params.loadSize, position)
        return LoadResult.Page(
            data = data,
            prevKey = if (position == 0) null else position - params.loadSize,
            nextKey = if (data.isEmpty()) null else position + params.loadSize
        )
    }
    override fun getRefreshKey(state: PagingState<Int, ChatMessage>): Int? = state.anchorPosition
}

// 4. Layout Phase Optimization
@Composable
fun PerformanceBubble(content: String) {
    Box(
        modifier = Modifier
            .graphicsLayer { 
                // Use graphicsLayer to handle animations/transforms 
                // without triggering recomposition
                alpha = 0.9f 
            }
            .drawWithCache {
                // Cache drawing commands for complex backgrounds
                onDrawBehind {
                    drawCircle(Color.LightGray)
                }
            }
    ) {
        Text(text = content)
    }
}
