
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Data Layer: Entity and DAO
@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: MessageRole, // Enum: USER, AI
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val conversationId: String
)

enum class MessageRole { USER, AI }

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE conversationId = :convId ORDER BY timestamp ASC")
    fun getMessagesForConversation(convId: String): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Query("UPDATE chat_messages SET content = :newContent WHERE id = :messageId")
    suspend fun updateMessageContent(messageId: Long, newContent: String)

    @Query("DELETE FROM chat_messages WHERE conversationId = :convId")
    suspend fun clearConversation(convId: String)
}

// 2. Repository Pattern
class ChatRepository @Inject constructor(private val chatDao: ChatDao) {
    fun getChatStream(conversationId: String): Flow<List<ChatMessage>> = 
        chatDao.getMessagesForConversation(conversationId)

    suspend fun appendMessage(message: ChatMessage) = chatDao.insertMessage(message)
    
    suspend fun updateLastMessage(messageId: Long, content: String) = 
        chatDao.updateMessageContent(messageId, content)

    suspend fun clearChat(conversationId: String) = chatDao.clearConversation(conversationId)
}

// 3. ViewModel Orchestration
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository,
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val conversationId: String = savedStateHandle["convId"] ?: "default_session"

    // Convert Room Flow to StateFlow for Compose
    val messages: StateFlow<List<ChatMessage>> = repository.getChatStream(conversationId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun sendMessage(text: String) {
        viewModelScope.launch {
            // Save user message
            repository.appendMessage(ChatMessage(role = MessageRole.USER, content = text, conversationId = conversationId))
            
            // Simulate AI streaming response
            val aiMsg = ChatMessage(role = MessageRole.AI, content = "", conversationId = conversationId)
            repository.appendMessage(aiMsg) // Get ID
            
            // In a real scenario, the AI service would provide a flow of tokens
            // repository.updateLastMessage(aiMsg.id, "Updated content...")
        }
    }

    fun clearHistory() {
        viewModelScope.launch { repository.clearChat(conversationId) }
    }
}

// 4. UI Layer
@Composable
fun ChatScreen(viewModel: ChatViewModel = hiltViewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Button(onClick = { viewModel.clearHistory() }) { Text("Clear Conversation") }
        
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages, key = { it.id }) { msg ->
                Text(text = "${msg.role}: ${msg.content}")
            }
        }
    }
}
