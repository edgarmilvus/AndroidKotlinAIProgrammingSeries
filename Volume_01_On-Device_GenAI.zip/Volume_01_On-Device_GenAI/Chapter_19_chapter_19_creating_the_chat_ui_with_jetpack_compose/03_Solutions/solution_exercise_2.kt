
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// 1. Diverse Message Types
sealed class MessageContent {
    data class TextContent(val text: String) : MessageContent()
    data class ErrorContent(val errorMessage: String) : MessageContent()
    data class SystemContent(val info: String) : MessageContent()
}

// 2. Slot-Based Bubble Component
@Composable
fun ChatBubble(
    role: MessageRole,
    content: @Composable () -> Unit
) {
    val alignment = if (role == MessageRole.USER) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleColor = if (role == MessageRole.USER) 
        MaterialTheme.colorScheme.primaryContainer 
    else 
        MaterialTheme.colorScheme.secondaryContainer
    
    val shape = if (role == MessageRole.USER) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 2.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 2.dp, bottomStart = 16.dp)
    }

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = shape,
            modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp)
        ) {
            content() // The "Slot"
        }
    }
}

// 3. Message Content Renderer
@Composable
fun MessageContentRenderer(content: MessageContent) {
    when (content) {
        is MessageContent.TextContent -> {
            var showCopy by remember { mutableStateOf(false) }
            val clipboardManager = LocalClipboardManager.current

            Box(modifier = Modifier.combinedClickable(
                onClick = {},
                onLongClick = { showCopy = true }
            ).padding(12.dp)) {
                Text(text = content.text, style = MaterialTheme.typography.bodyLarge)
                
                AnimatedVisibility(visible = showCopy) {
                    IconButton(onClick = {
                        clipboardManager.setText(AnnotatedString(content.text))
                        showCopy = false
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                    }
                }
            }
        }
        is MessageContent.ErrorContent -> {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text(text = content.errorMessage, color = MaterialTheme.colorScheme.error)
            }
        }
        is MessageContent.SystemContent -> {
            Text(
                text = content.info,
                modifier = Modifier.padding(8.dp),
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

// 4. Integration in Theme.kt (Conceptual)
@Composable
fun AIAppTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(LocalContext.current) 
            else dynamicLightColorScheme(LocalContext.current)
        }
        darkTheme -> DarkColorScheme else LightColorScheme
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}
