
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private var generationJob: Job? = null

    fun sendMessage(text: String) {
        // Add user message
        val userMsg = ChatMessage(java.util.UUID.randomUUID().toString(), text, MessageSender.USER)
        _messages.value += userMsg

        // Start AI Generation
        _isGenerating.value = true
        generationJob = viewModelScope.launch {
            try {
                val aiMsgId = java.util.UUID.randomUUID().toString()
                // Placeholder for AI streaming flow
                simulateAiStream().collect { token ->
                    updateLastMessage(aiMsgId, token)
                }
            } catch (e: CancellationException) {
                // Job was cancelled via stopGeneration(), keep partial text
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        // Requirement 2 & 3: Job Cancellation
        generationJob?.cancel()
    }

    private fun updateLastMessage(id: String, token: String) {
        val currentList = _messages.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index == -1) {
            currentList.add(ChatMessage(id, token, MessageSender.AI))
        } else {
            val oldMsg = currentList[index]
            currentList[index] = oldMsg.copy(text = oldMsg.text + token)
        }
        _messages.value = currentList
    }

    private fun simulateAiStream() = flow {
        val response = "This is a simulated streaming response from Gemini Nano..."
        response.forEach { 
            delay(50) // Simulate network/NPU latency
            emit(it.toString()) 
        }
    }
}
