
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.genai.chat

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.lifecycle.HiltViewModel
import com.google.dagger.hilt.android.AndroidEntryPoint
import com.google.dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions

/**
 * DATA MODELS
 * Representing the state of a chat message and the overall UI state.
 */
data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isTyping: Boolean = false,
    val inputText: String = "",
    val error: String? = null
)

sealed class ChatIntent {
    data class UpdateInput(val text: String) : ChatIntent()
    object SendMessage : ChatIntent()
    object ClearChat : ChatIntent()
}

/**
 * REPOSITORY LAYER
 * Handles the interaction with AICore/MediaPipe.
 * Implements hardware-aware orchestration and context windowing.
 */
@Singleton
class ChatRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with hardware-aware options
    init {
        initializeModel()
    }

    private fun initializeModel() {
        try {
            val options = LlmInferenceOptions.builder()
                .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to local .bin model
                .setMaxTokens(1024)
                .setTopK(40)
                .setTemperature(0.7f)
                // In a real scenario, the SDK handles the NPU/GPU delegation 
                // based on the device's capability and the model's compatibility.
                .build()
            
            llmInference = LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e("ChatRepo", "Failed to initialize LLM: ${e.message}")
        }
    }

    /**
     * Generates a response using a cold Flow to stream tokens.
     * Implements Structured Concurrency by using the provided scope.
     */
    fun generateResponse(prompt: String, history: List<ChatMessage>): Flow<String> = flow {
        // 1. Context Window Management:
        // LLMs have a finite token limit. We prune the history to only include 
        // the last 10 messages to avoid "Out of Memory" or "Context Overflow" errors.
        val prunedHistory = history.takeLast(10).joinToString("\n") { 
            "${if (it.isUser) "User" else "AI"}: ${it.text}" 
        }
        
        val fullPrompt = "Context:\n$prunedHistory\nUser: $prompt\nAI:"

        // 2. Hardware-aware execution:
        // We move the inference to Dispatchers.Default because LLM execution 
        // is CPU/NPU intensive and would block the Main thread.
        withContext(Dispatchers.Default) {
            try {
                // MediaPipe's generateResponse allows for a callback or a streaming result.
                // We simulate the streaming behavior using the SDK's streaming API.
                llmInference?.generateResponseAsync(fullPrompt) { partialResult, done ->
                    // Emit the partial token to the flow
                    runBlocking { emit(partialResult) }
                }
            } catch (e: Exception) {
                emit("Error: ${e.localizedMessage}")
            }
        }
    }.flowOn(Dispatchers.Default)
}

/**
 * VIEWMODEL LAYER
 * Implements MVI pattern to manage the complex state of streaming AI responses.
 */
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    /**
     * Process user intents. This is the single entry point for all UI actions.
     */
    fun handleIntent(intent: ChatIntent) {
        when (intent) {
            is ChatIntent.UpdateInput -> {
                _uiState.update { it.copy(inputText = intent.text) }
            }
            is ChatIntent.SendMessage -> sendMessage()
            is ChatIntent.ClearChat -> {
                _uiState.update { it.copy(messages = emptyList()) }
            }
        }
    }

    private fun sendMessage() {
        val currentText = _uiState.value.inputText
        if (currentText.isBlank()) return

        // Create the user message
        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            text = currentText,
            isUser = true
        )

        // Update state: Add user message and clear input
        _uiState.update { 
            it.copy(
                messages = it.messages + userMsg,
                inputText = "",
                isTyping = true 
            ) 
        }

        // Launch a coroutine in the viewModelScope to handle the AI response
        viewModelScope.launch {
            var fullAiResponse = ""
            val aiMsgId = java.util.UUID.randomUUID().toString()

            // Start the repository flow
            repository.generateResponse(currentText, _uiState.value.messages)
                .catch { e -> 
                    _uiState.update { it.copy(error = e.message, isTyping = false) }
                }
                .collect { token ->
                    fullAiResponse += token
                    
                    // Update the state by finding the last message 
                    // and appending the token if it's the AI's response.
                    _uiState.update { state ->
                        val updatedMessages = state.messages.toMutableList()
                        
                        // If the last message isn't the AI response we're building, add it.
                        if (updatedMessages.isEmpty() || updatedMessages.last().id != aiMsgId) {
                            updatedMessages.add(ChatMessage(aiMsgId, fullAiResponse, false))
                        } else {
                            // Update the existing AI message with the new token
                            val lastIdx = updatedMessages.size - 1
                            updatedMessages[lastIdx] = updatedMessages[lastIdx].copy(text = fullAiResponse)
                        }
                        
                        state.copy(messages = updatedMessages)
                    }
                }
            
            // Mark as finished typing
            _uiState.update { it.copy(isTyping = false) }
        }
    }
}
