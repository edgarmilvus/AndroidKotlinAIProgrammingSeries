
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.ondeviceai.chat

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// --- Domain Models ---
data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = System.currentTimeMillis())
data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isTyping: Boolean = false,
    val isModelLoading: Boolean = true,
    val errorMessage: String? = null
)

// --- Repository Layer: Hardware Orchestration ---
@Singleton
class OnDeviceChatRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with hardware-aware options
    suspend fun initializeModel(modelPath: String) = withContext(Dispatchers.Default) {
        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                // In a real scenario, we would check device capabilities here
                // to decide between GPU or CPU. MediaPipe handles the NPU 
                // delegation internally via the TFLite GPU delegate.
                .setMaxTokens(1024)
                .setTopK(40)
                .setTemperature(0.7f)
                .build()
            
            llmInference = LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e("ChatRepo", "Failed to init LLM: ${e.message}")
            throw e
        }
    }

    /**
     * Streams the response from the local LLM.
     * Uses a callback-to-flow wrapper to bridge MediaPipe's listener to Coroutines.
     */
    fun generateResponseStream(prompt: String): Flow<String> = callbackFlow {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // MediaPipe's generateResponse provides a streaming callback
        inference.generateResponseAsync(prompt) { partialResult, done ->
            trySend(partialResult)
            if (done) {
                channel.close()
            }
        }
        
        awaitClose { /* Cleanup if necessary */ }
    }.flowOn(Dispatchers.Default) // Ensure inference runs off the Main thread
}

// --- ViewModel Layer: State Management ---
@HiltViewModel
@AndroidEntryPoint
class ChatViewModel @Inject constructor(
    private val repository: OnDeviceChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        loadModel()
    }

    private fun loadModel() {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                // Path to the .bin model file in the assets or internal storage
                repository.initializeModel("/data/local/tmp/gemini_nano.bin")
                _uiState.update { it.copy(isModelLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isModelLoading = false, errorMessage = "Model Load Failed") }
            }
        }
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        // 1. Update UI immediately with user message
        val userMsg = ChatMessage(userText, isUser = true)
        _uiState.update { it.copy(
            messages = it.messages + userMsg,
            isTyping = true,
            errorMessage = null
        )}

        viewModelScope.launch {
            try {
                // 2. Start the AI response stream
                var fullAiResponse = ""
                
                repository.generateResponseStream(userText)
                    .collect { token ->
                        fullAiResponse += token
                        
                        // 3. Update the last message in the list as the AI "types"
                        _uiState.update { state ->
                            val updatedMessages = state.messages.toMutableList()
                            if (updatedMessages.isNotEmpty() && updatedMessages.last().isUser) {
                                updatedMessages.add(ChatMessage(fullAiResponse, isUser = false))
                            } else {
                                updatedMessages[updatedMessages.size - 1] = 
                                    ChatMessage(fullAiResponse, isUser = false)
                            }
                            state.copy(messages = updatedMessages)
                        }
                    }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Inference Error: ${e.localizedMessage}") }
            } finally {
                _uiState.update { it.copy(isTyping = false) }
            }
        }
    }
}

// --- Hilt Module for Dependency Injection ---
@Module
@InstallIn(SingletonComponent::class)
object ChatModule {
    @Provides
    @Singleton
    fun provideChatRepository(@ApplicationContext context: Context): OnDeviceChatRepository {
        return OnDeviceChatRepository(context)
    }
}
