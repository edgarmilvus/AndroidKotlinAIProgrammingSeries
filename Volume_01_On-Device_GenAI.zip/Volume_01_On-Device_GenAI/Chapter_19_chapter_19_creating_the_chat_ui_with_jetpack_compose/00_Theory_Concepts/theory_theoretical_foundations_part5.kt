
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val aiRepository: AiRepository 
) : ViewModel() {

    // The source of truth for the UI
    private val _uiState = MutableStateFlow(ChatState())
    val uiState: StateFlow<ChatState> = _uiState.asStateFlow()

    fun sendMessage(text: String) {
        viewModelScope.launch {
            // 1. Append user message to state
            appendMessage(UserMessage(text))
            
            // 2. Set state to 'Thinking'
            _uiState.update { it.copy(isAiThinking = true) }

            try {
                // 3. Collect stream from AICore
                aiRepository.generateResponse(text)
                    .collect { token ->
                        // 4. Incrementally update the last message in the list
                        updateLastAiMessage(token)
                    }
            } catch (e: Exception) {
                handleError(e)
            } finally {
                _uiState.update { it.copy(isAiThinking = false) }
            }
        }
    }

    private fun updateLastAiMessage(token: String) {
        _uiState.update { currentState ->
            val updatedMessages = currentState.messages.toMutableList()
            if (updatedMessages.isNotEmpty() && updatedMessages.last() is AiMessage) {
                val lastMsg = updatedMessages.last() as AiMessage
                updatedMessages[updatedMessages.lastIndex] = lastMsg.copy(
                    text = lastMsg.text + token
                )
            } else {
                updatedMessages.add(AiMessage(text = token))
            }
            currentState.copy(messages = updatedMessages)
        }
    }
}
