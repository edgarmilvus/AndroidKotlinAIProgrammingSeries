
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. Data Model representing the structured output we want from the document.
 */
data class ParsedDocument(
    val vendorName: String = "",
    val totalAmount: String = "",
    val date: String = "",
    val confidenceScore: Float = 0f
)

/**
 * 2. The Repository: Handles the interaction with the On-Device AI Model.
 * This is where the MediaPipe / Gemini Nano logic resides.
 */
@Singleton
class DocumentParserRepository @Inject constructor() {
    
    // In a real scenario, you would initialize the LlmInference engine here
    // private val llmInference = LlmInference.createFromOptions(options)

    suspend fun parseTextToStructuredData(rawOcrText: String): Result<ParsedDocument> = withContext(Dispatchers.Default) {
        try {
            Log.d("AI_ENGINE", "Starting inference on background thread...")
            
            // SYSTEM PROMPT: This is the "secret sauce" for document parsing.
            // We instruct the model to return ONLY valid JSON.
            val prompt = """
                Extract the following fields from the text: Vendor, Total Amount, and Date.
                Return the result strictly as JSON.
                Text: $rawOcrText
                JSON:
            """.trimIndent()

            // Simulate AI Inference latency
            kotlinx.coroutines.delay(1500) 
            
            // Simulated model output string
            val simulatedAiResponse = """{"vendor": "Coffee House", "amount": "$12.50", "date": "2023-10-27"}"""
            
            // In production, use kotlinx.serialization to parse the AI's JSON string
            val parsed = mapJsonResponseToModel(simulatedAiResponse)
            
            Result.success(parsed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun mapJsonResponseToModel(json: String): ParsedDocument {
        // Simplified manual parsing for the example; use Json.decodeFromString in production
        return ParsedDocument(
            vendorName = "Coffee House", 
            totalAmount = "$12.50", 
            date = "2023-10-27", 
            confidenceScore = 0.98f
        )
    }
}

/**
 * 3. The ViewModel: Manages UI state and ensures AI calls don't block the Main Thread.
 */
@HiltViewModel
class DocumentViewModel @Inject constructor(
    private val repository: DocumentParserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ParsingUiState>(ParsingUiState.Idle)
    val uiState: StateFlow<ParsingUiState> = _uiState.asStateFlow()

    fun processDocument(text: String) {
        viewModelScope.launch {
            _uiState.value = ParsingUiState.Loading
            
            // The repository handles the Dispatcher.Default switch internally
            val result = repository.parseTextToStructuredData(text)
            
            _uiState.value = result.fold(
                onSuccess = { ParsingUiState.Success(it) },
                onFailure = { ParsingUiState.Error(it.message ?: "Unknown Error") }
            )
        }
    }
}

sealed class ParsingUiState {
    object Idle : ParsingUiState()
    object Loading : ParsingUiState()
    data class Success(val data: ParsedDocument) : ParsingUiState()
    data class Error(val message: String) : ParsingUiState()
}

/**
 * 4. The UI: Modern Jetpack Compose screen.
 */
@AndroidEntryPoint
@Composable
fun DocumentParsingScreen(viewModel: DocumentViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var inputText by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "On-Device Doc Parser", style = MaterialTheme.typography.headlineMedium)
        
        TextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Paste OCR Text Here") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.processDocument(inputText) },
            modifier = Modifier.fillMaxWidth(),
            enabled = state !is ParsingUiState.Loading
        ) {
            Text(if (state is ParsingUiState.Loading) "Parsing..." else "Extract Data")
        }

        Divider()

        when (state) {
            is ParsingUiState.Idle -> Text("Enter text to begin extraction.")
            is ParsingUiState.Loading -> CircularProgressIndicator()
            is ParsingUiState.Error -> Text("Error: ${(state as ParsingUiState.Error).message}", color = MaterialTheme.colorScheme.error)
            is ParsingUiState.Success -> {
                val data = (state as ParsingUiState.Success).data
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Vendor: ${data.vendorName}", style = MaterialTheme.typography.bodyLarge)
                        Text("Amount: ${data.totalAmount}", style = MaterialTheme.typography.bodyLarge)
                        Text("Date: ${data.date}", style = MaterialTheme.typography.bodyLarge)
                        Text("Confidence: ${(data.confidenceScore * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
