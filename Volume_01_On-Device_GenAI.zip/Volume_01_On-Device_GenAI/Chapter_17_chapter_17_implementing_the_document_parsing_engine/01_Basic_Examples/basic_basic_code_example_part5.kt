
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.graphics.Bitmap

@Composable
fun DocumentParsingScreen(viewModel: DocumentParsingViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "AI Document Parser", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(24.dp))

        when (state) {
            is ParsingState.Idle -> {
                Button(onClick = { 
                    // Simulate image selection and processing
                    val dummyBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
                    viewModel.processDocument(dummyBitmap) 
                }) {
                    Text("Upload Receipt")
                }
            }
            is ParsingState.Processing -> {
                CircularProgressIndicator()
                Text(text = "Gemini Nano is analyzing...", modifier = Modifier.padding(top = 8.dp))
            }
            is ParsingState.Success -> {
                val data = (state as ParsingState.Success).data
                ResultCard(data)
                Button(onClick = { viewModel.resetState() }, modifier = Modifier.padding(top = 16.dp)) {
                    Text("Parse Another")
                }
            }
            is ParsingState.Error -> {
                Text(text = "Error: ${(state as ParsingState.Error).message}", color = MaterialTheme.colorScheme.error)
                Button(onClick = { viewModel.resetState() }) {
                    Text("Retry")
                }
            }
        }
    }
}

@Composable
fun ResultCard(data: ParsedDocument) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Vendor: ${data.vendorName}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Amount: ${data.totalAmount} ${data.currency}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Date: ${data.date}", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
