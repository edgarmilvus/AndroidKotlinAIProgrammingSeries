
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.tasks.vision.ocr.OcrLandmarker
import com.google.mediapipe.tasks.vision.ocr.OcrLandmarker.OcrLandmarkerOptions
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DocumentParserRepository @Inject constructor(
    private val context: Context
) {
    // Initialize Gemini Nano via the GenerativeAI SDK (AICore)
    private val generativeModel = GenerativeModel(
        modelName = "gemini-nano", 
        apiKey = "LOCAL_AICORE_KEY" // AICore handles authentication internally on supported devices
    )

    /**
     * The primary orchestration method for parsing a document.
     */
    suspend fun parseReceipt(bitmap: Bitmap): Result<ParsedDocument> = withContext(Dispatchers.Default) {
        try {
            // Step 1: Perform OCR using MediaPipe
            val rawText = performOcr(bitmap)
            
            if (rawText.isBlank()) {
                return@withContext Result.failure(Exception("No text detected in image"))
            }

            // Step 2: Use Gemini Nano to structure the raw text
            val structuredJson = promptGeminiNano(rawText)
            
            // Step 3: Map the LLM output to our Kotlin Data Class
            val parsedData = mapJsonToDocument(structuredJson)
            
            Result.success(parsedData)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun performOcr(bitmap: Bitmap): String {
        // In a production app, the OcrLandmarker should be a singleton to avoid 
        // the overhead of reloading the TFLite model for every image.
        val options = OcrLandmarkerOptions.builder()
            .setBaseOptions(com.google.mediapipe.tasks.core.BaseOptions.builder()
                .setModelAssetPath("ocr_model.tflite")
                .build())
            .build()

        val ocrLandmarker = OcrLandmarker.createFromOptions(context, options)
        
        // Convert Bitmap to MediaPipe Image
        val mpImage = com.google.mediapipe.framework.image.BitmapImageBuilder(bitmap).build()
        val result = ocrLandmarker.detect(mpImage)
        
        // Extract and concatenate all detected text blocks
        return result.textBlocks().joinToString("\n") { it.text() }
    }

    private suspend fun promptGeminiNano(rawText: String): String {
        // System Prompting: This is critical for guiding the LLM to output structured data.
        val prompt = """
            You are a professional document parsing engine. 
            Extract the following information from the text provided below:
            - Vendor Name
            - Total Amount (numeric only)
            - Currency
            - Date
            
            Return the output strictly as a JSON object with keys: 
            "vendor", "amount", "currency", "date".
            
            Text to parse:
            ---
            $rawText
            ---
        """.trimIndent()

        val response = generativeModel.generateContent(prompt)
        return response.text ?: ""
    }

    private fun mapJsonToDocument(jsonString: String): ParsedDocument {
        // In a real-world scenario, use kotlinx.serialization or Gson.
        // For this basic example, we simulate the parsing logic.
        return try {
            // Simplified simulation of JSON parsing
            ParsedDocument(
                vendorName = extractValue(jsonString, "vendor"),
                totalAmount = extractValue(jsonString, "amount").toDoubleOrNull() ?: 0.0,
                currency = extractValue(jsonString, "currency"),
                date = extractValue(jsonString, "date")
            )
        } catch (e: Exception) {
            ParsedDocument()
        }
    }

    private fun extractValue(json: String, key: String): String {
        // Regex to extract value from a simple JSON string
        val regex = "\"$key\"\\s*:\\s*\"?([^\",}]*)\"?".toRegex()
        return regex.find(json)?.groupValues?.get(1) ?: "Unknown"
    }
}
