
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import android.graphics.Bitmap
import javax.inject.Inject

@HiltViewModel
class DocumentParsingViewModel @Inject constructor(
    private val repository: DocumentParserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ParsingState>(ParsingState.Idle)
    val uiState: StateFlow<ParsingState> = _uiState.asStateFlow()

    /**
     * Triggers the parsing pipeline.
     */
    fun processDocument(bitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.value = ParsingState.Processing
            
            val result = repository.parseReceipt(bitmap)
            
            result.fold(
                onSuccess = { parsedData ->
                    _uiState.value = ParsingState.Success(parsedData)
                },
                onFailure = { exception ->
                    _uiState.value = ParsingState.Error(exception.localizedMessage ?: "Unknown Error")
                }
            )
        }
    }

    fun resetState() {
        _uiState.value = ParsingState.Idle
    }
}
