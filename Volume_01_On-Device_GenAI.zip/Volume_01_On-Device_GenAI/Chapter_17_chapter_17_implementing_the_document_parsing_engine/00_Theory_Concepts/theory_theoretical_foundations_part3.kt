
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*

// 1. Define the structured output we want
@Serializable
data class DocumentSchema(
    val documentType: String,
    val entities: List<Entity>,
    val confidenceScore: Float
)

@Serializable
data class Entity(
    val key: String,
    val value: String,
    val confidence: Float
)

// 2. The AI Context for dependency injection and scoping
interface ParsingContext {
    val aicoreClient: AICoreClient
    val visionProcessor: VisionProcessor
    val scope: CoroutineScope
}

// 3. The Engine Implementation
class DocumentParsingEngine : ParsingContext {
    override val aicoreClient: AICoreClient = AICoreClient.getInstance()
    override val visionProcessor: VisionProcessor = VisionProcessor()
    override override val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    /**
     * The core parsing pipeline.
     * Just like with CameraX, we abstract the hardware complexity 
     * and provide a high-level stream of results.
     */
    fun parseDocument(imageUri: String): Flow<ParsingState> = flow {
        emit(ParsingState.Loading("Analyzing visual layout..."))

        // Step 1: Visual Processing (OCR + Layout)
        // This happens on the NPU/GPU via MediaPipe
        val rawLayoutText = visionProcessor.extractStructuredText(imageUri)
        
        emit(ParsingState.Loading("Extracting semantic data..."))

        // Step 2: Cognitive Processing (Gemini Nano)
        // We use a streaming approach to handle the LLM's token generation
        val resultJson = aicoreClient.generateTextStream(
            prompt = buildParsingPrompt(rawLayoutText),
            config = GenerationConfig(temperature = 0.1f) // Low temp for high precision
        ).foldToString() // Helper to accumulate tokens

        emit(ParsingState.Loading("Validating structure..."))

        // Step 3: Serialization & Validation
        try {
            val structuredData = Json.decodeFromString<DocumentSchema>(resultJson)
            emit(ParsingState.Success(structuredData))
        } catch (e: SerializationException) {
            emit(ParsingState.Error("Model output was not valid JSON: ${e.message}"))
        }
    }.catch { e -> 
        emit(ParsingState.Error("Pipeline failure: ${e.localizedMessage}")) 
    }.flowOn(Dispatchers.Default)

    private fun buildParsingPrompt(layoutText: String): String {
        return """
            You are a professional document parser. 
            Convert the following OCR text into a strict JSON format.
            
            SCHEMA:
            {
              "documentType": "string",
              "entities": [{"key": "string", "value": "string", "confidence": float}],
              "confidenceScore": float
            }
            
            TEXT:
            $layoutText
            
            JSON:
        """.trimIndent()
    }
}

// Sealed class for UI state management
sealed class ParsingState {
    data class Loading(val message: String) : ParsingState()
    data class Success(val data: DocumentSchema) : ParsingState()
    data class Error(val message: String) : ParsingState()
}

// Mock classes for the sake of theoretical completeness
class AICoreClient {
    companion object { fun getInstance() = AICoreClient() }
    fun generateTextStream(prompt: String, config: GenerationConfig): Flow<String> = flow {
        // Simulate token streaming from Gemini Nano
        emit("{ \"documentType\": \"Invoice\", ")
        delay(100)
        emit("\"entities\": [{\"key\": \"Total\", \"value\": \"$120.00\", \"confidence\": 0.98}], ")
        delay(100)
        emit("\"confidenceScore\": 0.95 }")
    }
}

class VisionProcessor {
    suspend fun extractStructuredText(uri: String): String {
        delay(500) // Simulate MediaPipe OCR
        return "INV-2023-001\nDate: 2023-10-01\nTotal: $120.00"
    }
}

data class GenerationConfig(val temperature: Float)

// Extension to accumulate Flow tokens into a single string
suspend fun Flow<String>.foldToString(): String {
    var accumulator = ""
    this.collect { accumulator += it }
    return accumulator
}
