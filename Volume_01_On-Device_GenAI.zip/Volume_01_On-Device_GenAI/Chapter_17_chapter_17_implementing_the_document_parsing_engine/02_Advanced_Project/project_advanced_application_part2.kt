
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.docparser.engine

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.vision.ocr.Ocr
import com.google.mediapipe.tasks.vision.ocr.OcrResult

// --- Domain Models ---
data class ParsedDocument(
    val rawText: String,
    val structuredJson: String,
    val confidenceScore: Float,
    val processingTimeMs: Long
)

sealed class ParsingState {
    object Idle : ParsingState()
    object AnalyzingLayout : ParsingState() // GPU/NPU Stage
    object ExtractingSemantics : ParsingState() // AICore/LLM Stage
    data class Success(val data: ParsedDocument) : ParsingState()
    data class Error(val message: String) : ParsingState()
}

// --- Repository: The Orchestrator ---
@Singleton
class DocumentParsingRepository @Inject constructor(
    private val context: Context
) {
    // Hardware-aware OCR configuration (Targeting GPU/NPU)
    private val ocrHelper = Ocr.createFromOptions(context, Ocr.OcrOptions.builder()
        .setResultPriority(Ocr.ResultPriority.HIGH)
        .build())

    // Gemini Nano / AICore Interface (Abstracted)
    private val aiCoreClient = AICoreClient() 

    suspend fun parseDocument(uri: Uri): ParsedDocument = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // Stage 1: Visual Layout Analysis & OCR (GPU Accelerated)
        // We use Dispatchers.Default to avoid blocking the main thread during native calls
        val rawText = performOcr(uri)

        // Stage 2: Semantic Structuring via Gemini Nano (AICore)
        // We prompt the LLM to transform raw OCR text into a structured JSON format
        val structuredJson = extractStructuredData(rawText)

        ParsedDocument(
            rawText = rawText,
            structuredJson = structuredJson,
            confidenceScore = 0.92f, // Simplified for example
            processingTimeMs = System.currentTimeMillis() - startTime
        )
    }

    private suspend fun performOcr(uri: Uri): String = withContext(Dispatchers.Default) {
        // In a real scenario, convert Uri to MediaPipe Image
        val result: OcrResult = ocrHelper.process(uri.toMediaPipeImage()) 
        result.text // Return combined text from all detected blocks
    }

    private suspend fun extractStructuredData(text: String): String = withContext(Dispatchers.Default) {
        val prompt = """
            Extract the following entities from the text: InvoiceNumber, Date, TotalAmount, VendorName.
            Format the output as a strict JSON object. 
            Text: $text
        """.trimIndent()
        
        // Calling AICore for local GenAI inference
        aiCoreClient.generateResponse(prompt)
    }
}

// --- ViewModel: State Management ---
@HiltViewModel
class DocumentParsingViewModel @Inject constructor(
    private val repository: DocumentParsingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ParsingState>(ParsingState.Idle)
    val uiState: StateFlow<ParsingState> = _uiState.asStateFlow()

    fun processDocument(uri: Uri) {
        viewModelScope.launch {
            try {
                // Transition to Layout Analysis (NPU/GPU)
                _uiState.value = ParsingState.AnalyzingLayout
                
                // Transition to Semantic Extraction (AICore)
                _uiState.value = ParsingState.ExtractingSemantics
                
                val result = repository.parseDocument(uri)
                _uiState.value = ParsingState.Success(result)
            } catch (e: Exception) {
                _uiState.value = ParsingState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }
}

// Mock for AICore Client
class AICoreClient {
    suspend fun generateResponse(prompt: String): String {
        delay(800) // Simulate LLM latency
        return "{\"InvoiceNumber\": \"INV-123\", \"TotalAmount\": \"$450.00\"}"
    }
}

// Extension helper for URI conversion
fun Uri.toMediaPipeImage() = this // Implementation detail for MediaPipe Image conversion
