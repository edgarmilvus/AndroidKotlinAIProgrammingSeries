
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.documentengine.parsing

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as HiltInject
import javax.inject.Singleton
import com.google.mediapipe.tasks.vision.layout.LayoutDetector // Hypothetical MediaPipe API
import com.google.ai.client.generativeai.GenerativeModel

/**
 * MVI State representing the Document Parsing Pipeline
 */
data class DocumentParsingState(
    val isProcessing: Boolean = false,
    val extractedText: String = "",
    val structuredJson: String = "",
    val error: String? = null,
    val hardwareAccelerator: String = "Detecting..."
)

/**
 * User Intents for the Parsing Engine
 */
sealed class DocumentIntent {
    data class ParseDocument(val bitmap: Bitmap) : DocumentIntent()
    object ResetState : DocumentIntent()
}

/**
 * Hardware Orchestrator: Decides the best delegate for TFLite models
 * based on device capabilities.
 */
@Singleton
class HardwareOrchestrator @HiltInject constructor(
    @ApplicationContext private val context: Context
) {
    enum class Accelerator { NPU, GPU, CPU }

    fun getOptimalAccelerator(): Accelerator {
        // In a real scenario, check for NNAPI availability or specific SoC
        // e.g., checking for Snapdragon 8 Gen 2+ for NPU optimization
        return try {
            // Pseudo-logic for hardware detection
            if (isNpuSupported()) Accelerator.NPU else Accelerator.GPU
        } catch (e: Exception) {
            Accelerator.CPU
        }
    }

    private fun isNpuSupported(): Boolean {
        // Check system properties or use NNAPI check
        return true // Simplified for example
    }
}

/**
 * Repository handling the heavy lifting of AI orchestration.
 * Uses Structured Concurrency to ensure no leaks during long-running AI tasks.
 */
@Singleton
class DocumentParsingRepository @HiltInject constructor(
    private val hardwareOrchestrator: HardwareOrchestrator,
    @ApplicationContext private val context: Context
) {
    // Initialize Gemini Nano via AICore
    private val geminiNano = GenerativeModel(
        modelName = "gemini-nano",
        apiKey = "LOCAL_AICORE_KEY" // AICore manages keys internally on Android
    )

    suspend fun processDocument(bitmap: Bitmap): Result<String> = withContext(Dispatchers.Default) {
        try {
            val accelerator = hardwareOrchestrator.getOptimalAccelerator()
            Log.d("DocEngine", "Using Accelerator: $accelerator")

            // Step 1: Layout Analysis using MediaPipe (TFLite)
            // We target the GPU/NPU for the visual model to keep the CPU free for the LLM
            val layoutRegions = performLayoutAnalysis(bitmap, accelerator)

            // Step 2: Targeted Text Extraction (OCR)
            // Only extract text from the regions identified as 'content' or 'table'
            val rawText = performTargetedOCR(bitmap, layoutRegions)

            // Step 3: Semantic Parsing via Gemini Nano
            // We pass the raw text and the layout context to the LLM
            val structuredData = performSemanticParsing(rawText)

            Result.success(structuredData)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun performLayoutAnalysis(bitmap: Bitmap, acc: HardwareOrchestrator.Accelerator): List<Region> {
        return withContext(Dispatchers.Default) {
            // Simulate MediaPipe Layout Detection
            delay(500) // Simulate GPU latency
            listOf(Region("Header"), Region("Table_1"), Region("Footer"))
        }
    }

    private suspend fun performTargetedOCR(bitmap: Bitmap, regions: List<Region>): String {
        return withContext(Dispatchers.Default) {
            // Simulate OCR extraction
            delay(300)
            "Invoice #1234\nDate: 2023-10-01\nTotal: $150.00\nItems: Cloud Compute, Storage"
        }
    }

    private suspend fun performSemanticParsing(text: String): String {
        return withContext(Dispatchers.Default) {
            val prompt = "Convert the following raw OCR text into a structured JSON object. " +
                         "Extract 'invoice_number', 'date', 'total_amount', and 'items'.\n\nText: $text"
            
            // Gemini Nano call via AICore
            val response = geminiNano.generateContent(prompt)
            response.text ?: "Parsing failed"
        }
    }

    data class Region(val type: String)
}

/**
 * ViewModel implementing MVI pattern.
 * Manages the state flow and handles hardware-aware execution.
 */
@HiltViewModel
@AndroidEntryPoint
class DocumentParsingViewModel @HiltInject constructor(
    private val repository: DocumentParsingRepository,
    private val hardwareOrchestrator: HardwareOrchestrator
) : androidx.lifecycle.ViewModel() {

    private val _state = MutableStateFlow(DocumentParsingState())
    val state: StateFlow<DocumentParsingState> = _state.asStateFlow()

    init {
        _state.update { it.copy(hardwareAccelerator = hardwareOrchestrator.getOptimalAccelerator().name) }
    }

    fun handleIntent(intent: DocumentIntent) {
        when (intent) {
            is DocumentIntent.ParseDocument -> parseDocument(intent.bitmap)
            is DocumentIntent.ResetState -> _state.update { DocumentParsingState() }
        }
    }

    private fun parseDocument(bitmap: Bitmap) {
        // Use viewModelScope for structured concurrency
        viewModelScope.launch {
            _state.update { it.copy(isProcessing = true, error = null) }

            val result = repository.processDocument(bitmap)

            result.fold(
                onSuccess = { json ->
                    _state.update { it.copy(
                        isProcessing = false, 
                        structuredJson = json, 
                        extractedText = "Successfully parsed document."
                    )}
                },
                onFailure = { error ->
                    _state.update { it.copy(
                        isProcessing = false, 
                        error = error.localizedMessage ?: "Unknown AI Error"
                    )}
                }
            )
        }
    }
}
