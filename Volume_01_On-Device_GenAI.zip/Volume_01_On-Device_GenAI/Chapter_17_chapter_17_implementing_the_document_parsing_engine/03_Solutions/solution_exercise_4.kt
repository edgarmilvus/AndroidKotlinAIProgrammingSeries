
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapRegionDecoder
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.FileInputStream

class MemoryAwareParser(
    private val context: Context,
    private var llmInference: LlmInference? // Nullable to allow release
) : ComponentCallbacks2 {

    override fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            // Release the heavy LLM model weights from memory
            llmInference = null 
            System.gc() // Suggest GC to reclaim memory immediately
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}
    override fun onLowMemory() { onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) }

    fun processImageInTiles(uri: Uri) {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return
        
        // Use BitmapRegionDecoder to avoid loading a 20MP image into RAM
        BitmapRegionDecoder.newInstance(inputStream, false).use { decoder ->
            val width = decoder.width
            val height = decoder.height
            val tileSize = 1024 // Process in 1k x 1k tiles

            for (y in 0 until height step tileSize) {
                for (x in 0 until width step tileSize) {
                    val rect = android.graphics.Rect(
                        x, y, 
                        (x + tileSize).coerceAtMost(width), 
                        (y + tileSize).coerceAtMost(height)
                    )
                    val tileBitmap = decoder.decodeRegion(rect)
                    // Pass tileBitmap to OCR...
                    tileBitmap.recycle() // Immediately free native memory
                }
            }
        }
    }
}
