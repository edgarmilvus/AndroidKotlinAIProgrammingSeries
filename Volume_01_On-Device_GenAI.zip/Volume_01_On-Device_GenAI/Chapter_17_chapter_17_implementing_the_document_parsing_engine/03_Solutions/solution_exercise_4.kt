
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

class LegalContractParser(private val model: GenerativeModel) {

    suspend fun extractLiabilityClauses(fullText: String): String {
        val chunkSize = 1000 // Approximate tokens/words
        val overlap = 200
        val chunks = mutableListOf<String>()
        
        // 1. Sliding Window Chunking
        var start = 0
        while (start < fullText.length) {
            val end = (start + chunkSize).coerceAtMost(fullText.length)
            chunks.add(fullText.substring(start, end))
            if (end == fullText.length) break
            start += (chunkSize - overlap)
        }

        // 2. Map Phase: Extract from each chunk
        val extractedClauses = chunks.map { chunk ->
            val response = model.generateContent(
                "Extract any liability clauses from this text. If none, return 'NONE'.\nText: $chunk"
            )
            response.text ?: "NONE"
        }.filter { it != "NONE" }

        // 3. Reduce Phase: Synthesis
        val synthesisPrompt = """
            The following are potential liability clauses extracted from different parts of a contract.
            Remove duplicates and merge fragmented clauses into a cohesive summary.
            Clauses: ${extractedClauses.joinToString("\n---\n")}
        """.trimIndent()

        return model.generateContent(synthesisPrompt).text ?: "No liability clauses found."
    }
}
