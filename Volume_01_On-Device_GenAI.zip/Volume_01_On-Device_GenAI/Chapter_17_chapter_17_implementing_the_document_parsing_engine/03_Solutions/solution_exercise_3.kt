
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

data class TextChunk(val index: Int, val content: String, val isLast: Boolean)

class DocumentChunker {
    fun chunkText(text: String, chunkSize: Int = 2000, overlap: Int = 200): List<TextChunk> {
        val chunks = mutableListOf<TextChunk>()
        var start = 0
        var index = 0
        
        while (start < text.length) {
            val end = (start + chunkSize).coerceAtMost(text.length)
            val content = text.substring(start, end)
            chunks.add(TextChunk(index++, content, end == text.length))
            
            if (end == text.length) break
            start += (chunkSize - overlap) // Slide the window
        }
        return chunks
    }
}

class LargeDocumentAnalyzer @Inject constructor(
    private val llmInference: LlmInference
) {
    private val chunker = DocumentChunker()

    fun analyzeDocument(text: String): Flow<String> = flow {
        val chunks = chunker.chunkText(text)
        val partialSummaries = mutableListOf<String>()

        // Map Phase: Process chunks individually
        chunks.forEachIndexed { index, chunk ->
            emit("Processing chunk ${index + 1} of ${chunks.size}...")
            val summary = llmInference.generateResponse(
                "Extract the key arguments from this section of a legal document: ${chunk.content}"
            )
            partialSummaries.add(summary)
        }

        // Reduce Phase: Synthesize all partial summaries
        emit("Synthesizing final analysis...")
        val finalPrompt = "Combine these partial summaries into one cohesive legal analysis: ${partialSummaries.joinToString("\n")}"
        val finalAnalysis = llmInference.generateResponse(finalPrompt)
        
        emit(finalAnalysis)
    }
}
