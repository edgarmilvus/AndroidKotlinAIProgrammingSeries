
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

data class ParsingSession(
    var accumulatedText: String = "",
    var currentTotal: Double = 0.0,
    var subtotal: Double = 0.0,
    var tax: Double = 0.0,
    var vendorName: String? = null
)

class InvoiceAggregator(private val model: GenerativeModel) {
    
    suspend fun processInvoice(pages: List<Bitmap>): ParsingSession {
        val session = ParsingSession()
        
        pages.forEachIndexed { index, bitmap ->
            val rawText = performOcr(bitmap)
            
            // Cross-Page Context: Feed a summary of previous findings
            val prompt = """
                You are processing page ${index + 1} of an invoice.
                Previous pages found: Vendor=${session.vendorName}, Current Subtotal=${session.subtotal}.
                Extract data from this page: $rawText.
                Return JSON with: {vendor, subtotal, tax, grandTotal}.
            """.trimIndent()
            
            val pageData = parseJson(model.generateContent(prompt).text)
            
            // State Management: Aggregate values
            session.vendorName = pageData.vendor ?: session.vendorName
            session.subtotal = pageData.subtotal ?: session.subtotal
            session.tax = pageData.tax ?: session.tax
            session.currentTotal = pageData.grandTotal ?: session.currentTotal
        }
        return session
    }

    fun validateInvoice(session: ParsingSession): Boolean {
        return (session.subtotal + session.tax) == session.currentTotal
    }
    
    private fun performOcr(bitmap: Bitmap): String = "..." // MediaPipe impl
    private fun parseJson(json: String?): InvoicePageData = ... // Serialization impl
}

data class InvoicePageData(val vendor: String?, val subtotal: Double?, val tax: Double?, val grandTotal: Double?)
