
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

// 1. Dependency Injection for the heavy LLM engine
@Module
@InstallIn(SingletonComponent::class)
object AIModule {
    @Provides
    @Singleton
    fun provideLlmInference(@ApplicationContext context: Context): LlmInference {
        return LlmInference.createFromOptions(context, LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to the model on device
            .setMaxTokens(512)
            .build())
    }
}

// 2. Logic for cleaning and extracting text
class DocumentParser {
    fun parseFile(uri: Uri, context: Context): String {
        return context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BufferedReader(InputStreamReader(inputStream)).use { reader ->
                reader.readText()
                    .replace(Regex("\\s+"), " ") // Remove excessive whitespace
                    .trim()
                    .take(10000) // Guard against massive files crashing the model
            }
        } ?: throw Exception("Could not open file")
    }
}

// 3. Summarizer Implementation
interface DocumentSummarizer {
    suspend fun summarize(text: String): Result<String>
}

class GeminiSummarizer @Inject constructor(
    private val llmInference: LlmInference
) : DocumentSummarizer {
    override suspend fun summarize(text: String): Result<String> = withContext(Dispatchers.Default) {
        try {
            // Prompt Anchoring: Forcing the model into a specific format
            val prompt = "You are a reading assistant. Summarize the following text into exactly three concise bullet points. " +
                         "Format: SUMMARY: \n- [Point 1]\n- [Point 2]\n- [Point 3]\n\nText: $text"
            
            val response = llmInference.generateResponse(prompt)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// 4. ViewModel to manage UI state
sealed class SummaryState {
    object Idle : SummaryState()
    object Loading : SummaryState()
    data class Success(val summary: String) : SummaryState()
    data class Error(val message: String) : SummaryState()
}

@HiltViewModel
class SummaryViewModel @Inject constructor(
    private val summarizer: GeminiSummarizer,
    private val parser: DocumentParser = DocumentParser() 
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummaryState>(SummaryState.Idle)
    val uiState: StateFlow<SummaryState> = _uiState

    fun processDocument(uri: Uri, context: Context) {
        viewModelScope.launch {
            _uiState.value = SummaryState.Loading
            try {
                val text = withContext(Dispatchers.IO) { parser.parseFile(uri, context) }
                val result = summarizer.summarize(text)
                
                result.fold(
                    onSuccess = { _uiState.value = SummaryState.Success(it) },
                    onFailure = { _uiState.value = SummaryState.Error(it.message ?: "Unknown Error") }
                )
            } catch (e: Exception) {
                _uiState.value = SummaryState.Error(e.message ?: "Parsing failed")
            }
        }
    }
}
