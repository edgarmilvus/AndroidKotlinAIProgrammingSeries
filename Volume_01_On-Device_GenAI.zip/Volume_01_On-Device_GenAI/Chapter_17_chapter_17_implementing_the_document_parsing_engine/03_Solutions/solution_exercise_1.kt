
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.graphics.Bitmap
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.mediapipe.tasks.vision.text.TextRecognizer
import com.google.mediapipe.tasks.vision.text.textrecognizer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString

@Serializable
data class Contact(
    val fullName: String,
    val jobTitle: String,
    val company: String,
    val email: String,
    val phoneNumber: String
)

class BusinessCardParser(private val generativeModel: GenerativeModel) {
    private val jsonParser = Json { ignoreUnknownKeys = true }

    // Initialize MediaPipe Text Recognizer
    private val textRecognizer = TextRecognizer.createFromFile(
        // Assume the model file is in assets
        "text_recognizer.tflite" 
    )

    suspend fun parseBusinessCard(bitmap: Bitmap): Contact {
        // 1. Preprocessing: Extract raw text from image
        val visionText = textRecognizer.recognize(bitmap)
        val rawText = visionText.text // Aggregated text from all blocks

        // 2. Prompting: Strict JSON instruction to avoid "conversational filler"
        val prompt = """
            Act as a Structured Data Extractor. Extract contact information from the following OCR text.
            Return ONLY a valid JSON object. Do not include any markdown formatting, 
            preamble, or explanations.
            
            Fields: fullName, jobTitle, company, email, phoneNumber.
            If a field is not found, use "Unknown".
            
            OCR Text:
            $rawText
        """.trimIndent()

        // 3. LLM Execution
        val response = generativeModel.generateContent(prompt)
        val jsonString = response.text ?: "{}"

        // 4. Safe Parsing: Cleaning potential LLM markdown backticks
        val cleanedJson = jsonString.trim().removeSurrounding("