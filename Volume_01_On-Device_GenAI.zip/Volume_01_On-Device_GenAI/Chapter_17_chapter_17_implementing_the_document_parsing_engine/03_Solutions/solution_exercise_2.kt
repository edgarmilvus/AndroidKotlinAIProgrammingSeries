
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import javax.inject.Inject
import javax.inject.Singleton

sealed class ParseResult {
    data class Receipt(val merchant: String, val total: Double, val date: String) : ParseResult()
    data class Identity(val name: String, val idNumber: String, val expiry: String) : ParseResult()
    data class Prescription(val medication: String, val dosage: String, val doctor: String) : ParseResult()
    data class Error(val message: String) : ParseResult()
}

interface DocumentParserStrategy {
    suspend fun parse(rawText: String, model: GenerativeModel): ParseResult
}

class ReceiptParserStrategy : DocumentParserStrategy {
    override suspend fun parse(rawText: String, model: GenerativeModel): ParseResult {
        val prompt = "Extract receipt data (merchant, total, date) as JSON from: $rawText"
        // Implementation similar to Ex 1...
        return ParseResult.Receipt("Store X", 12.50, "2023-10-01") 
    }
}

class IdCardParserStrategy : DocumentParserStrategy {
    override suspend fun parse(rawText: String, model: GenerativeModel): ParseResult {
        val prompt = "Extract ID card data (name, idNumber, expiry) as JSON from: $rawText"
        return ParseResult.Identity("John Doe", "12345", "2030-01-01")
    }
}

@Singleton
class ParserFactory @Inject constructor(
    private val receiptStrategy: ReceiptParserStrategy,
    private val idStrategy: IdCardParserStrategy
) {
    fun getStrategy(type: DocumentType): DocumentParserStrategy {
        return when (type) {
            DocumentType.RECEIPT -> receiptStrategy
            DocumentType.ID_CARD -> idStrategy
            DocumentType.PRESCRIPTION -> throw NotImplementedError()
        }
    }
}

enum class DocumentType { RECEIPT, ID_CARD, PRESCRIPTION }
