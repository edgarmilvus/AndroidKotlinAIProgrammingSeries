
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognitionOptions
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject

@Serializable
data class Receipt(
    val merchant: String,
    val total: Double,
    val date: String
)

class ReceiptExtractor @Inject constructor(
    private val llmInference: LlmInference
) {
    private val jsonParser = Json { ignoreUnknownKeys = true }
    private val ocrClient = TextRecognition.getClient(TextRecognitionOptions.DEFAULT_OPTIONS)

    suspend fun extractReceiptData(bitmap: Bitmap): Result<Receipt> {
        return try {
            // Step 1: OCR Extraction
            val image = InputImage.fromBitmap(bitmap, 0)
            val visionText = ocrClient.process(image).await()
            val rawText = visionText.text

            if (rawText.isBlank()) return Result.failure(Exception("No text found in image"))

            // Step 2: LLM Denoiser and Structurer
            val prompt = """
                Extract receipt details from this messy OCR text. 
                Ignore typos (e.g., 'T0TAL' means 'Total').
                Return ONLY a valid JSON object with keys: "merchant", "total" (number), and "date".
                
                OCR Text: $rawText
                JSON:
            """.trimIndent()

            val response = llmInference.generateResponse(prompt)
            
            // Step 3: JSON Parsing with safety
            val cleanJson = sanitizeJsonResponse(response)
            val receipt = jsonParser.decodeFromString<Receipt>(cleanJson)
            
            Result.success(receipt)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun sanitizeJsonResponse(response: String): String {
        // LLMs sometimes wrap JSON in markdown code blocks (