
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*
import java.time.LocalDate
import java.time.format.DateTimeParseException

sealed class ParsingStrategy {
    object Regex : ParsingStrategy()
    object Generative : ParsingStrategy()
}

data class ExtractionField(
    val name: String,
    val strategy: ParsingStrategy,
    val pattern: Regex? = null
)

class HybridParsingEngine(
    private val llmInference: LlmInference,
    private val fields: List<ExtractionField>
) {
    suspend fun parse(text: String): Map<String, Any> = coroutineScope {
        fields.map { field ->
            async(Dispatchers.Default) {
                val value = when (field.strategy) {
                    ParsingStrategy.Regex -> extractViaRegex(text, field)
                    ParsingStrategy.Generative -> extractViaLLM(text, field)
                }
                field.name to (value ?: "Not Found")
            }
        }.awaitAll().toMap()
    }

    private fun extractViaRegex(text: String, field: ExtractionField): String? {
        return field.pattern?.find(text)?.value
    }

    private suspend fun extractViaLLM(text: String, field: ExtractionField): String {
        var attempts = 0
        var result: String
        
        do {
            val prompt = "Extract the ${field.name} from this text. Return only the value: $text"
            result = llmInference.generateResponse(prompt)
            
            // Validation Loop: Cross-check dates
            if (field.name == "date") {
                if (isValidDate(result)) break
                attempts++
            } else {
                break
            }
        } while (attempts < 2)
        
        return result
    }

    private fun isValidDate(dateStr: String): Boolean {
        return try {
            LocalDate.parse(dateStr.trim())
            true
        } catch (e: DateTimeParseException) {
            false
        }
    }
}
