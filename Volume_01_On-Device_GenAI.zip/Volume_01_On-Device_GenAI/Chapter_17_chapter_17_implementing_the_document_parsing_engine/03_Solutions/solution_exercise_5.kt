
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

class HybridParsingEngine(
    private val objectDetector: ObjectDetector, 
    private val model: GenerativeModel
) {
    suspend fun parseComplexForm(originalBitmap: Bitmap): Map<String, String> {
        val results = mutableMapOf<String, String>()
        
        // 1. Layout Detection
        val detections = objectDetector.detect(originalBitmap)
        
        detections.forEach { detection ->
            val category = detection.categories.first().categoryName // e.g., "Table"
            val boundingBox = detection.boundingBox
            
            // 2. Cropping & Targeted OCR
            val croppedBitmap = cropBitmap(originalBitmap, boundingBox)
            val regionText = performOcr(croppedBitmap)
            
            // 3. Spatial Prompting
            val prompt = "The following text was found in the [$category] region of a form: $regionText. Extract the key values."
            val semanticData = model.generateContent(prompt).text ?: ""
            
            results[category] = semanticData
        }
        
        return results
    }

    private fun cropBitmap(src: Bitmap, rect: Rect): Bitmap {
        // Handle scaling: TFLite coordinates are often normalized (0-1) or relative to model input
        // This example assumes Rect is already scaled to src dimensions
        return Bitmap.createBitmap(src, rect.left, rect.top, rect.width(), rect.height())
    }
    
    private fun performOcr(bitmap: Bitmap): String = "..." // MediaPipe impl
}
