
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.util.LruCache

interface OOVStrategy {
    fun handle(word: String, vocab: Map<String, Int>): List<Int>?
}

// Strategy A: Longest Prefix Subword Search (Recursive)
class SubwordFallback : OOVStrategy {
    override fun handle(word: String, vocab: Map<String, Int>): List<Int>? {
        if (word.isEmpty()) return emptyList()
        
        for (i in word.length downTo 1) {
            val prefix = word.substring(0, i)
            if (vocab.containsKey(prefix)) {
                val remainder = word.substring(i)
                return listOf(vocab[prefix]!!) + (handle(remainder, vocab) ?: emptyList())
            }
        }
        return null // Fail to Character fallback
    }
}

// Strategy B: Character-level Fallback
class CharacterFallback : OOVStrategy {
    override fun handle(word: String, vocab: Map<String, Int>): List<Int>? {
        return word.map { char -> vocab[char.toString()] ?: vocab["<UNK>"] ?: 0 }
    }
}

class DynamicVocabularyManager(
    private var vocab: MutableMap<String, Int>,
    private val strategies: List<OOVStrategy>
) {
    // Cache OOV decompositions to avoid expensive recursion
    private val oovCache = LruCache<String, List<Int>>(100)

    fun tokenizeWithFallback(word: String): Pair<List<Int>, Double> {
        if (vocab.containsKey(word)) {
            return listOf(vocab[word]!!) to 1.0
        }

        oovCache.get(word)?.let { return it to 0.5 }

        for (strategy in strategies) {
            val result = strategy.handle(word, vocab)
            if (result != null) {
                oovCache.put(word, result)
                // Confidence is lower for decomposed words
                return result to 0.5 
            }
        }

        return listOf(vocab["<UNK>"] ?: 0) to 0.0
    }

    fun updateVocab(newMappings: Map<String, Int>) {
        vocab.putAll(newMappings)
        oovCache.evictAll() // Clear cache as mappings changed
    }
}
