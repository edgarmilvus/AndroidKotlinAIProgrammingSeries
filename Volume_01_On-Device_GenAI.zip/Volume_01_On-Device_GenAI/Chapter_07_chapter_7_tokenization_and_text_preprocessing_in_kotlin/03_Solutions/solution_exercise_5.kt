
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

class PromptTemplateEngine(
    private val tokenizer: Tokenizer,
    private val maxTokens: Int
) {
    private val contextStartToken = "[CONTEXT_START]"
    private val contextEndToken = "[CONTEXT_END]"
    private val forbiddenTokens = listOf("[ADMIN]", "[ROOT]", "DROP TABLE")

    fun constructPrompt(template: String, context: String, query: String): String {
        // 1. Validation: Check for forbidden tokens
        if (forbiddenTokens.any { context.contains(it, ignoreCase = true) }) {
            throw SecurityException("Forbidden tokens detected in retrieved context.")
        }

        // 2. Special Token Injection
        val wrappedContext = "$contextStartToken $context $contextEndToken"
        
        // 3. Smart Truncation
        val templateWithoutPlaceholders = template
            .replace("{{context}}", "")
            .replace("{{query}}", "")
        
        val templateTokens = tokenizer.encode(templateWithoutPlaceholders).size
        val queryTokens = tokenizer.encode(query).size
        val specialTokenOverhead = tokenizer.encode("$contextStartToken $contextEndToken").size
        
        val availableForContext = maxTokens - templateTokens - queryTokens - specialTokenOverhead

        val finalContext = if (tokenizer.encode(context).size > availableForContext) {
            truncateToTokenLimit(context, availableForContext)
        } else {
            context
        }

        // 4. Final Injection
        return template
            .replace("{{context}}", "$contextStartToken $finalContext $contextEndToken")
            .replace("{{query}}", query)
    }

    private fun truncateToTokenLimit(text: String, limit: Int): String {
        val tokens = tokenizer.encode(text)
        val truncatedTokens = tokens.take(limit)
        return tokenizer.decode(truncatedTokens)
    }
}

// Usage in ViewModel via Hilt
@HiltViewModel
class RagViewModel @Inject constructor(
    private val templateEngine: PromptTemplateEngine
) : ViewModel() {
    fun generatePrompt(userQuery: String, retrievedDoc: String): String {
        val template = "Answer the question based on the context. Context: {{context}} Question: {{query}}"
        return templateEngine.constructPrompt(template, retrievedDoc, userQuery)
    }
}
