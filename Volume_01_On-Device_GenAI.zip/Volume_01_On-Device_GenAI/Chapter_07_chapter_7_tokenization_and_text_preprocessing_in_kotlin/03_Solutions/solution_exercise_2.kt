
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*

// 1. Domain Modeling
sealed class ChatMessage {
    abstract val content: String
    data class UserMessage(override val content: String) : ChatMessage()
    data class ModelMessage(override val content: String) : ChatMessage()
    data class SystemInstruction(override val content: String) : ChatMessage()
}

// 2. Template Engine
class PromptComposer {
    fun compose(messages: List<ChatMessage>): String = buildString {
        messages.forEach { msg ->
            when (msg) {
                is ChatMessage.SystemInstruction -> {
                    append("<start_of_turn>system\n${msg.content}<end_of_turn>\n")
                }
                is ChatMessage.UserMessage -> {
                    append("<start_of_turn>user\n${msg.content}<end_of_turn>\n")
                }
                is ChatMessage.ModelMessage -> {
                    append("<start_of_turn>model\n${msg.content}<end_of_turn>\n")
                }
            }
        }
        // 3. Token Injection: Prime the model for the next response
        append("<start_of_turn>model\n")
    }
}

// 4. State Management in ViewModel
class ChatViewModel(private val composer: PromptComposer) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Derived state: The final prompt is automatically updated when messages change
    val composedPrompt: StateFlow<String> = _messages
        .map { composer.compose(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    fun addMessage(message: ChatMessage) {
        _messages.update { it + message }
    }
}
