
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Interface Definition
interface Tokenizer {
    fun encode(text: String): List<Int>
    fun decode(tokens: List<Int>): String
}

// 2. Concrete Implementations
class GeminiNanoTokenizer @Inject constructor() : Tokenizer {
    override fun encode(text: String): List<Int> = text.map { it.code }.toList() // Mock: ASCII
    override fun decode(tokens: List<Int>): String = tokens.map { it.toChar() }.joinToString("")
}

class CustomTFLiteTokenizer @Inject constructor() : Tokenizer {
    override fun encode(text: String): List<Int> = text.split(" ").mapIndexed { i, _ -> i + 100 }.toList() // Mock: Word-based
    override fun decode(tokens: List<Int>): String = "Decoded TFLite Tokens"
}

// 3. Hilt Integration
@Singleton
class UserPreferences @Inject constructor() {
    var useCustomModel: Boolean = false // Toggle for simulation
}

@Module
@InstallIn(SingletonComponent::class)
object TokenizerModule {
    @Provides
    @Singleton
    fun provideTokenizer(prefs: UserPreferences, 
                         gemini: GeminiNanoTokenizer, 
                         tflite: CustomTFLiteTokenizer): Tokenizer {
        return if (prefs.useCustomModel) tflite else gemini
    }
}

// ViewModel for Compose
@HiltViewModel
class TokenizerViewModel @Inject constructor(
    private val tokenizer: Tokenizer
) : ViewModel() {
    private val _inputText = MutableStateFlow("")
    val inputText = _inputText.asStateFlow()

    val tokens = _inputText.map { text ->
        tokenizer.encode(text)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onTextChange(newText: String) {
        _inputText.value = newText
    }
}

// 4. Compose Integration
@AndroidEntryPoint
@Composable
fun TokenizerScreen(viewModel: TokenizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val text by viewModel.inputText.collectAsState()
    val tokens by viewModel.tokens.collectAsState()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = text,
            onValueChange = { viewModel.onTextChange(it) },
            label = { Text("Enter text to tokenize") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Token IDs: ${tokens.joinToString(", ")}")
    }
}
