
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

data class TokenBatch(val batchId: Int, val tokens: IntArray)

class BatchTokenizationEngine(
    private val tokenizer: BpeTokenizer,
    private val windowSize: Int = 512,
    private val overlapSize: Int = 50
) {
    // Channel to decouple tokenization from DB insertion (Backpressure)
    private val resultChannel = Channel<TokenBatch>(capacity = 10)

    fun processDocument(text: String): Flow<TokenBatch> = flow {
        // 1. Initial tokenization of the whole text (on Default dispatcher)
        val allTokens = withContext(Dispatchers.Default) {
            tokenizer.encode(text).toIntArray()
        }

        // 2. Sliding Window Logic
        val batches = mutableListOf<IntArray>()
        var start = 0
        var batchCount = 0

        while (start < allTokens.size) {
            val end = (start + windowSize).coerceAtMost(allTokens.size)
            val window = allTokens.sliceArray(start until end)
            
            batches.add(window)
            
            // Move start pointer by (windowSize - overlapSize)
            start += (windowSize - overlapSize)
            if (start >= allTokens.size || end == allTokens.size) break
            batchCount++
        }

        // 3. Concurrent Processing of batches
        // flatMapMerge allows parallel execution of the inner flow
        batches.asFlow()
            .flatMapMerge(concurrency = Runtime.getRuntime().availableProcessors()) { window ->
                flow {
                    // Simulate heavy processing/embedding generation
                    emit(TokenBatch(batchCount++, window))
                }.flowOn(Dispatchers.Default)
            }
            .collect { emit(it) }
    }
}

// Usage in ViewModel/Repository
/*
viewModelScope.launch {
    engine.processDocument(largeText)
        .onEach { batch -> 
            vectorDb.insert(batch) 
        }
        .catch { e -> Log.e("AI", "Error: ${e.message}") }
        .collect()
}
*/
