
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

sealed class BenchmarkResult {
    data class Success(val results: Map<String, Long>, val memoryUsed: Long) : BenchmarkResult()
    object Loading : BenchmarkResult()
}

class PerformanceProfiler(private val tokenizer: Tokenizer) {

    // Approach A: Chained methods
    private fun cleanChained(text: String) = text.replace("\n", " ").trim().lowercase()

    // Approach B: Single Complex Regex
    private val complexRegex = Regex("[\\s]+")
    private fun cleanRegex(text: String) = text.replace(complexRegex, " ").trim().lowercase()

    // Approach C: Manual StringBuilder
    private fun cleanManual(text: String): String {
        val sb = StringBuilder()
        var lastWasSpace = false
        for (char in text) {
            if (char.isWhitespace()) {
                if (!lastWasSpace) sb.append(' ')
                lastWasSpace = true
            } else {
                sb.append(char.lowercaseChar())
                lastWasSpace = false
            }
        }
        return sb.toString().trim()
    }

    suspend fun runBenchmark(largeText: String): BenchmarkResult = withContext(Dispatchers.Default) {
        val iterations = 100
        val results = mutableMapOf<String, Long>()

        // Memory baseline
        System.gc()
        val startMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()

        // Benchmark A
        results["Chained"] = measureTime { repeat(iterations) { cleanChained(largeText) } }
        // Benchmark B
        results["Regex"] = measureTime { repeat(iterations) { cleanRegex(largeText) } }
        // Benchmark C
        results["Manual"] = measureTime { repeat(iterations) { cleanManual(largeText) } }

        val endMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        
        BenchmarkResult.Success(results, endMem - startMem)
    }

    private inline fun measureTime(block: () -> Unit): Long {
        val start = System.nanoTime()
        block()
        return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start)
    }
}

// ViewModel integration
class ProfilerViewModel(private val profiler: PerformanceProfiler) : ViewModel() {
    private val _uiState = MutableStateFlow<BenchmarkResult>(BenchmarkResult.Loading)
    val uiState = _uiState.asStateFlow()

    fun startProfiling(text: String) {
        viewModelScope.launch {
            _uiState.value = BenchmarkResult.Loading
            _uiState.value = profiler.runBenchmark(text)
        }
    }
}
