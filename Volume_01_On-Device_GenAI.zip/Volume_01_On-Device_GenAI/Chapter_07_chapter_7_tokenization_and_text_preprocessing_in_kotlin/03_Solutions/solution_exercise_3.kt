
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

data class ChatMessage(val role: String, val content: String)

class ConversationBufferManager(
    private val tokenizer: Tokenizer, 
    private val maxTokens: Int,
    private val systemPrompt: String
) {
    private val history = mutableListOf<ChatMessage>()
    private val bosToken = 1 // Beginning of Sequence
    private val eosToken = 2 // End of Sequence

    fun addMessage(role: String, content: String) {
        history.add(ChatMessage(role, content))
    }

    /**
     * Manages the sliding window and prepares the final token sequence.
     */
    fun prepareInputForInference(currentQuery: String): List<Int> {
        val systemTokens = tokenizer.encode(systemPrompt)
        val queryTokens = tokenizer.encode(currentQuery)
        
        // Special tokens overhead
        val overhead = 2 // <bos> and <eos>
        var availableTokens = maxTokens - systemTokens.size - queryTokens.size - overhead

        // 3. Message-Level Eviction
        // Calculate tokens for each message in history
        val messageTokenCounts = history.map { tokenizer.encode(it.content).size }
        var totalHistoryTokens = messageTokenCounts.sum()

        // Remove oldest messages until they fit in the available window
        var oldestIndexToRemove = 0
        while (totalHistoryTokens > availableTokens && oldestIndexToRemove < history.size) {
            totalHistoryTokens -= messageTokenCounts[oldestIndexToRemove]
            oldestIndexToRemove++
        }

        // Construct final sequence
        val finalTokens = mutableListOf<Int>()
        finalTokens.add(bosToken)
        finalTokens.addAll(systemTokens)
        
        // Add remaining history
        for (i in oldestIndexToRemove until history.size) {
            finalTokens.addAll(tokenizer.encode(history[i].content))
        }
        
        finalTokens.addAll(queryTokens)
        finalTokens.add(eosToken)

        return finalTokens
    }
}
