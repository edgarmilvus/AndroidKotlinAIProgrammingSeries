
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.serialization.json.Json
import java.io.InputStream

class BpeTokenizer(
    private val vocab: Map<String, Int>,
    private val mergeTable: List<Pair<Pair<String, String>, String>>
) {
    fun encode(text: String): List<Int> {
        // Start by splitting into individual characters
        var tokens = text.map { it.toString() }.toMutableList()

        while (true) {
            // Find the merge pair that appears earliest in the mergeTable
            val bestMerge = mergeTable.firstOrNull { (pair, _) ->
                tokens.windowed(2).contains(pair)
            } ?: break // No more possible merges

            val (pair, replacement) = bestMerge
            
            // Replace all occurrences of the pair with the merged token
            val nextTokens = mutableListOf<String>()
            var i = 0
            while (i < tokens.size) {
                if (i < tokens.size - 1 && tokens[i] == pair.first && tokens[i+1] == pair.second) {
                    nextTokens.add(replacement)
                    i += 2
                } else {
                    nextTokens.add(tokens[i])
                    i++
                }
            }
            tokens = nextTokens
        }

        // Map tokens to IDs, fallback to <UNK> (ID 0) if not found
        return tokens.map { vocab[it] ?: vocab["<UNK>"] ?: 0 }
    }

    fun decode(ids: List<Int>): String {
        val idToToken = vocab.entries.associate { it.value to it.key }
        return ids.map { idToToken[it] ?: "" }
            .joinToString("")
            .replace("Ġ", " ") // Restore spaces from BPE marker
    }
}

// Vocab Loader implementation
class VocabLoader(private val assets: android.content.res.AssetManager) {
    fun loadVocab(fileName: String): Map<String, Int> {
        val jsonString = assets.open(fileName).bufferedReader().use { it.readText() }
        return Json.decodeFromString<Map<String, Int>>(jsonString)
    }
}
