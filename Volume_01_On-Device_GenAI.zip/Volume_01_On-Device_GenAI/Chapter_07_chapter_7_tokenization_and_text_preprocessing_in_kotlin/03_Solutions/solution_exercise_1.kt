
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import java.text.Normalizer
import javax.inject.Inject
import javax.inject.Singleton

// 1. Interface-Driven Design
interface TextTransformer {
    fun transform(input: String): String
}

// 2. Specific Transformer Implementations
class UnicodeNormalizer : TextTransformer {
    override fun transform(input: String): String = 
        Normalizer.normalize(input, Normalizer.Form.NFC)
}

class WhitespaceCollapser : TextTransformer {
    private val whitespaceRegex = Regex("\\s+")
    override fun transform(input: String): String = 
        input.replace(whitespaceRegex, " ").trim()
}

class ControlCharacterStripper : TextTransformer {
    // Removes non-printable ASCII control characters (0-31 and 127)
    private val controlCharRegex = Regex("[\\x00-\\x1F\\x7F]")
    override fun transform(input: String): String = 
        input.replace(controlCharRegex, "")
}

class CaseFolder(private val lowercase: Boolean = true) : TextTransformer {
    override fun transform(input: String): String = 
        if (lowercase) input.lowercase() else input
}

// 3. Pipeline Orchestration
class NormalizationPipeline @Inject constructor(
    private val transformers: List<TextTransformer>
) {
    fun normalize(text: String): String {
        // Use fold to apply each transformer sequentially to the result of the previous one
        return transformers.fold(text) { currentText, transformer ->
            transformer.transform(currentText)
        }
    }
}

// 4. Hilt Integration
// Note: In a real app, this would be in a @Module class
/*
@Module
@InstallIn(SingletonComponent::class)
object NormalizationModule {
    @Provides
    @Singleton
    fun provideNormalizationPipeline(): NormalizationPipeline {
        return NormalizationPipeline(
            listOf(
                UnicodeNormalizer(),
                ControlCharacterStripper(),
                WhitespaceCollapser(),
                CaseFolder(lowercase = false) // Preserve case for legal documents
            )
        )
    }
}
*/
