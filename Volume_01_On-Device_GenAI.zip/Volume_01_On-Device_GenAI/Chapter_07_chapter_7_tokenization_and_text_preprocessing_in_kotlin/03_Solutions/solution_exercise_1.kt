
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import java.text.Normalizer
import java.util.regex.Pattern

class TextNormalizationPipeline(private val lowercaseMode: Boolean = false) {

    // Matches non-printable ASCII characters (control characters)
    private val nonPrintableRegex = Regex("[\\x00-\\x1F\\x7F]")
    // Matches one or more whitespace characters (including tabs/newlines)
    private val redundantWhitespaceRegex = Regex("\\s+")

    /**
     * Cleans raw input string to a canonical form.
     * Returns an empty string if input is null or blank.
     */
    fun normalize(input: String?): String {
        if (input.isNullOrBlank()) return ""

        // 1. Unicode Normalization (NFC: Canonical Decomposition, followed by Canonical Composition)
        // This ensures characters like 'é' are represented as a single code point rather than 'e' + accent.
        val normalizedUnicode = Normalizer.normalize(input, Normalizer.Form.NFC)

        // 2. Noise Reduction
        var cleanedText = normalizedUnicode
            .replace(nonPrintableRegex, "")
            .replace(redundantWhitespaceRegex, " ")

        // 3. Case Strategy
        if (lowercaseMode) {
            cleanedText = cleanedText.lowercase()
        }

        // 4. Trim and Final Sanitize
        return cleanedText.trim()
    }
}

// Usage Example
fun main() {
    val pipeline = TextNormalizationPipeline(lowercaseMode = true)
    val noisyInput = "  Hello   World! \u0007 This is a test with e\u0301 (decomposed)  \n\n  "
    val result = pipeline.normalize(noisyInput)
    println("Result: '$result'") // Expected: "hello world! this is a test with é"
}
