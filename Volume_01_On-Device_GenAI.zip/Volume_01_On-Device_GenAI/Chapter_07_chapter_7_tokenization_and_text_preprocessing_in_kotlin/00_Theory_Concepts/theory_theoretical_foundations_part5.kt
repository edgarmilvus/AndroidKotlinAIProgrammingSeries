
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.kt
// Description: Theoretical Foundations
// ==========================================

// Gradle Dependencies
// implementation("com.google.dagger:hilt-android:2.x")
// implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.x")
// implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.x")

@Singleton
class GeminiTokenizer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var vocabulary: Map<String, TokenId> = emptyMap()
    private var isInitialized = false

    // Use a Mutex to ensure thread-safe initialization of the vocab
    private val initMutex = Mutex()

    suspend fun initialize() {
        initMutex.withLock {
            if (isInitialized) return
            
            // Simulate loading from assets/AICore provider
            val vocabJson = context.assets.open("gemini_nano_vocab.json").bufferedReader().use { it.readText() }
            val config = Json.decodeFromString<TokenizerConfig>(vocabJson)
            
            vocabulary = config.entries.associate { it.token to TokenId(it.id) }
            isInitialized = true
        }
    }

    fun tokenize(text: String): TokenizedResult {
        if (!isInitialized) throw IllegalStateException("Tokenizer must be initialized before use")

        // 1. Normalization
        val normalized = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKC)
            .lowercase()
            .trim()

        // 2. Subword splitting (Simplified BPE logic)
        val tokens = mutableListOf<TokenId>()
        
        // Add BOS token
        tokens.add(TokenId(1)) 

        // Logic for subword matching
        var remainingText = normalized
        while (remainingText.isNotEmpty()) {
            // Find the longest matching token in the vocabulary (Greedy Match)
            val match = vocabulary.keys
                .filter { remainingText.startsWith(it) }
                .maxByOrNull { it.length }
            
            if (match != null) {
                tokens.add(vocabulary[match]!!)
                remainingText = remainingText.substring(match.length)
            } else {
                // Handle OOV (Out of Vocabulary) by using an <UNK> token
                tokens.add(TokenId(0)) 
                remainingText = remainingText.substring(1)
            }
        }

        // Add EOS token
        tokens.add(TokenId(2))

        return TokenizedResult(
            tokens = tokens,
            attentionMask = List(tokens.size) { 1 } // All tokens are attended to
        )
    }
}
