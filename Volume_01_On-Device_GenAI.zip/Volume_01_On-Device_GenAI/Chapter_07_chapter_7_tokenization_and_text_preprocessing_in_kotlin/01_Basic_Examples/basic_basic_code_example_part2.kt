
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data model representing a single tokenized unit.
 */
data class TokenDetail(
    val text: String,
    val tokenId: Int
)

/**
 * Tokenizer Interface to allow switching between different 
 * tokenization strategies (e.g., WordPiece, BPE, or SentencePiece).
 */
interface Tokenizer {
    fun tokenize(text: String): List<TokenDetail>
}

/**
 * A simulated Local LLM Tokenizer. 
 * In production, this would load a vocabulary file from assets 
 * and use a TFLite support library or MediaPipe's internal tokenizer.
 */
@Singleton
class LocalLLMTokenizer @Inject constructor() : Tokenizer {
    // Simulated vocabulary map: Word/Sub-word -> ID
    private val vocabMap = mapOf(
        "<bos>" to 1,
        "hello" to 101,
        "world" to 102,
        "on" to 103,
        "device" to 104,
        "ai" to 105,
        "is" to 106,
        "powerful" to 107,
        " " to 0, // Space token
        "!" to 108
    )

    override fun tokenize(text: String): List<TokenDetail> {
        // 1. Normalization: Lowercase and trim
        val normalized = text.lowercase().trim()
        
        // 2. Pre-tokenization: Split by whitespace and punctuation
        // This is a simplified regex for demonstration
        val words = normalized.split(Regex("(?<=\\s)|(?=\\s)|(?<=[!.,])|(?=[!.,])"))
        
        // 3. Mapping: Convert strings to IDs
        return words.map { word ->
            val id = vocabMap[word] ?: 0 // 0 is typically the [UNK] (Unknown) token
            TokenDetail(text = word, tokenId = id)
        }
    }
}

/**
 * ViewModel handling the business logic.
 * Ensures that tokenization (CPU intensive) happens off the Main Thread.
 */
@HiltViewModel
class TokenizationViewModel @Inject constructor(
    private val tokenizer: Tokenizer
) : ViewModel() {

    private val _inputText = MutableStateFlow("")
    val inputText = _inputText.asStateFlow()

    private val _tokens = MutableStateFlow<List<TokenDetail>>(emptyList())
    val tokens = _tokens.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    fun onTextChanged(newText: String) {
        _inputText.value = newText
        processText(newText)
    }

    private fun processText(text: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            
            // Switch to Dispatchers.Default for CPU-bound tokenization
            val result = withContext(Dispatchers.Default) {
                tokenizer.tokenize(text)
            }
            
            _tokens.value = result
            _isProcessing.value = false
        }
    }
}

/**
 * Jetpack Compose UI for visualizing the tokenization process.
 */
@Composable
fun TokenizationScreen(viewModel: TokenizationViewModel) {
    val text by viewModel.inputText.collectAsState()
    val tokens by viewModel.tokens.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "On-Device Tokenizer Preview", style = MaterialTheme.typography.headlineMedium)
        
        OutlinedTextField(
            value = text,
            onValueChange = { viewModel.onTextChanged(it) },
            label = { Text("Enter text to tokenize...") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                if (isProcessing) CircularProgressIndicator(modifier = Modifier.size(24.dp))
            }
        )

        Text(text = "Tokens:", style = MaterialTheme.typography.titleMedium)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(tokens) { token ->
                TokenRow(token)
            }
        }
    }
}

@Composable
fun TokenRow(token: TokenDetail) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (token.tokenId == 0) MaterialTheme.colorScheme.errorContainer 
                             else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Text: '${token.text}'", style = MaterialTheme.typography.bodyMedium)
            Text(text = "ID: ${token.tokenId}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
