
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.genai.preprocessing

import java.io.BufferedReader
import java.io.InputStreamReader
import android.content.Context

/**
 * TextPreprocessor handles the transformation of raw strings into integer arrays
 * compatible with TFLite models.
 */
class TextPreprocessor(context: Context) {

    // The vocabulary map: Token String -> Integer ID
    private val vocabulary: Map<String, Int> = loadVocabulary(context)
    
    // Special tokens common in LLMs
    private val UNK_TOKEN = "[UNK]" // Unknown
    private val PAD_TOKEN = "[PAD]" // Padding
    private val CLS_TOKEN = "[CLS]" // Classification start
    private val SEP_TOKEN = "[SEP]" // Sequence separator

    private fun loadVocabulary(context: Context): Map<String, Int> {
        val vocabMap = mutableMapOf<String, Int>()
        try {
            // In production, load from assets/vocab.txt
            context.assets.open("vocab.txt").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).useLines { lines ->
                    lines.forEachIndexed { index, token ->
                        vocabMap[token] = index
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback for the example: manually populate a tiny vocab
            listOf(PAD_TOKEN, UNK_TOKEN, CLS_TOKEN, SEP_TOKEN, "hello", "world", "ai", "kotlin").forEachIndexed { i, s ->
                vocabMap[s] = i
            }
        }
        return vocabMap
    }

    /**
     * The core tokenization function.
     * @param text The raw input string.
     * @param maxSeqLength The fixed size required by the model tensor.
     * @return A List of integers representing the token IDs.
     */
    fun tokenize(text: String, maxSeqLength: Int = 128): List<Int> {
        // 1. Normalization: Lowercase and trim
        val normalizedText = text.lowercase().trim()

        // 2. Pre-tokenization: Split by whitespace and punctuation
        val words = normalizedText.split(Regex("\\s+"))

        // 3. Numericalization
        val tokenIds = mutableListOf<Int>()
        
        // Add start token [CLS]
        tokenIds.add(vocabulary[CLS_TOKEN] ?: 0)

        for (word in words) {
            // Simple Word-level tokenization (Subword would be more complex)
            val id = vocabulary[word] ?: vocabulary[UNK_TOKEN] ?: 1
            tokenIds.add(id)
        }

        // Add separator token [SEP]
        tokenIds.add(vocabulary[SEP_TOKEN] ?: 2)

        // 4. Post-processing: Padding and Truncation
        return if (tokenIds.size > maxSeqLength) {
            // Truncate to max length
            tokenIds.take(maxSeqLength)
        } else {
            // Pad with [PAD] token until maxSeqLength is reached
            val paddingSize = maxSeqLength - tokenIds.size
            val padId = vocabulary[PAD_TOKEN] ?: 0
            tokenIds + List(paddingSize) { padId }
        }
    }
}
