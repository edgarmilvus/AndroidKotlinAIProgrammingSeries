
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.preprocessing

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import javax.inject.Named

/**
 * Represents the state of the tokenization process.
 * Using a sealed class to handle UI states in a MVI-like pattern.
 */
sealed class TokenizationState {
    object Idle : TokenizationState()
    object Processing : TokenizationState()
    data class Success(val tokenCount: Int, val processedText: String) : TokenizationState()
    data class Error(val message: String) : TokenizationState()
}

/**
 * Repository handling the heavy lifting of tokenization.
 * Encapsulates the MediaPipe GenAI Tokenizer.
 */
@Singleton
class TokenizationRepository @Inject constructor() {
    private val TAG = "TokenRepo"
    
    // Mocking the MediaPipe Tokenizer for demonstration. 
    // In production, this would be: com.google.mediapipe.tasks.genai.llm.inference.LlmInference
    private var isInitialized = false

    suspend fun initialize() = withContext(Dispatchers.IO) {
        Log.d(TAG, "Loading vocabulary and initializing NPU delegates...")
        delay(500) // Simulate loading heavy vocab file
        isInitialized = true
    }

    /**
     * Converts text to tokens and manages the window size.
     * @param text The raw input string.
     * @param maxTokens The hard limit of the model's context window.
     */
    suspend fun tokenizeAndPrune(text: String, maxTokens: Int): Pair<Int, String> = withContext(Dispatchers.Default) {
        if (!isInitialized) throw IllegalStateException("Tokenizer not initialized")

        // 1. Pre-processing: Noise reduction
        val cleanedText = preprocessText(text)

        // 2. Tokenization (Simulated MediaPipe call)
        // In reality: val tokens = llmInference.tokenize(cleanedText)
        val tokens = simulateTokenization(cleanedText)
        
        Log.d(TAG, "Initial token count: ${tokens.size}")

        // 3. Sliding Window Logic
        if (tokens.size > maxTokens) {
            Log.w(TAG, "Context overflow detected. Pruning tokens...")
            val prunedTokens = tokens.takeLast(maxTokens)
            // Convert tokens back to string for UI visibility
            val prunedText = simulateDetokenization(prunedTokens)
            return@withContext Pair(prunedTokens.size, prunedText)
        }

        return@withContext Pair(tokens.size, cleanedText)
    }

    private fun preprocessText(text: String): String {
        // Remove excessive whitespace and normalize unicode characters
        return text.replace(Regex("\\s+"), " ").trim()
    }

    private fun simulateTokenization(text: String): List<Int> {
        // Simulating BPE (Byte Pair Encoding) behavior: 
        // Roughly 1 token per 4 characters for English
        return text.chunked(4).map { it.hashCode() }
    }

    private fun simulateDetokenization(tokens: List<Int>): String {
        return "...[Pruned]... " + "Sample recovered text"
    }
}

/**
 * ViewModel orchestrating the hardware-aware preprocessing.
 */
@HiltViewModel
@AndroidEntryPoint
class TokenBufferViewModel @Inject constructor(
    private val repository: TokenizationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<TokenizationState>(TokenizationState.Idle)
    val uiState: StateFlow<TokenizationState> = _uiState.asStateFlow()

    private val MAX_CONTEXT_WINDOW = 2048

    fun processUserInput(input: String) {
        viewModelScope.launch {
            _uiState.value = TokenizationState.Processing
            
            try {
                // Ensure repository is ready
                repository.initialize()

                // Execute tokenization on Dispatchers.Default (CPU-bound)
                // The repository internally handles the switch to NPU/GPU via MediaPipe
                val result = repository.tokenizeAndPrune(input, MAX_CONTEXT_WINDOW)
                
                _uiState.value = TokenizationState.Success(
                    tokenCount = result.first,
                    processedText = result.second
                )
            } catch (e: Exception) {
                _uiState.value = TokenizationState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }
}
