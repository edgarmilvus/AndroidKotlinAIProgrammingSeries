
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.preprocessing

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data class representing the state of the preprocessing pipeline.
 */
data class PreprocessingState(
    val originalText: String = "",
    val cleanedText: String = "",
    val tokenCount: Int = 0,
    val isProcessing: Boolean = false,
    val error: String? = null
)

/**
 * The PreprocessingPipeline handles the deterministic transformation of raw text.
 * This is kept separate from the Repository to allow for unit testing without Android dependencies.
 */
class PreprocessingPipeline {
    fun sanitize(text: String): String {
        return text
            .replace(Regex("\\s+"), " ") // Collapse multiple whitespaces/newlines
            .replace(Regex("<[^>]*>"), "") // Remove HTML tags if present
            .trim()
    }

    fun normalize(text: String): String {
        // Ensure consistent unicode normalization (NFC) to prevent token duplication
        return java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFC)
    }
}

/**
 * Repository managing the interaction between the pipeline and the hardware-accelerated LLM.
 */
@Singleton
class TextPreprocessingRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val pipeline = PreprocessingPipeline()
    
    // Configure MediaPipe for NPU/GPU acceleration
    private val llmInference = LlmInference.createFromOptions(context, 
        LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") 
            .setMaxTokens(2048)
            .setTemperature(0.7f)
            .build()
    )

    suspend fun processTextForInference(rawInput: String): Pair<String, Int> = withContext(Dispatchers.Default) {
        // 1. Sanitize and Normalize
        val cleaned = pipeline.sanitize(rawInput)
        val normalized = pipeline.normalize(cleaned)

        // 2. Tokenization Estimation
        // Note: In a real MediaPipe implementation, we use the internal tokenizer 
        // to get the exact count. Here we simulate the tokenization call.
        val tokens = estimateTokenCount(normalized)
        
        if (tokens > 2048) {
            throw IllegalArgumentException("Input exceeds maximum token limit of 2048")
        }

        return@withContext normalized to tokens
    }

    private fun estimateTokenCount(text: String): Int {
        // Approximation: On-device BPE (Byte Pair Encoding) typically 
        // results in ~0.75 words per token.
        return (text.split(" ").size * 1.3).toInt()
    }
}

/**
 * ViewModel orchestrating the flow and managing UI state using StateFlow.
 */
@HiltViewModel
@AndroidEntryPoint
class PreprocessingViewModel @Inject constructor(
    private val repository: TextPreprocessingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PreprocessingState())
    val uiState: StateFlow<PreprocessingState> = _uiState.asStateFlow()

    fun onInputChanged(newText: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(originalText = newText, isProcessing = true) }
            
            try {
                // Offload heavy preprocessing to Dispatchers.Default (CPU)
                val (processedText, count) = repository.processTextForInference(newText)
                
                _uiState.update { 
                    it.copy(
                        cleanedText = processedText, 
                        tokenCount = count, 
                        isProcessing = false, 
                        error = null 
                    ) 
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(isProcessing = false, error = e.localizedMessage) 
                }
            }
        }
    }
}
