
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Gradle Dependencies
// implementation("com.google.mediapipe:tasks-genai:0.10.14")
// implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
// implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*

/**
 * Represents a structured prompt template.
 * Using serialization allows these to be fetched from a remote server
 * to tune the model without an app update.
 */
@Serializable
data class PromptTemplate(
    val systemInstruction: String,
    val userPlaceholder: String,
    val fewShotExamples: List<Example>
)

@Serializable
data class Example(val input: String, val output: String)

/**
 * Context Receiver approach (Conceptual Kotlin 2.x)
 * This allows any function within this context to access the AI engine
 * without explicitly passing it as a parameter.
 */
interface AIProvider {
    fun generateResponse(prompt: String): Flow<String>
}

// Using a context receiver to provide AI capabilities to a UseCase
context(AIProvider)
class SummarizationUseCase {
    suspend fun execute(text: String): String {
        // The 'generateResponse' method is available here because of the context receiver
        return generateResponse("Summarize this: $text").toList().joinToString("")
    }
}

// Implementation of the AI Provider using AICore/MediaPipe
class GeminiNanoProvider(private val genAiModel: LlmInference) : AIProvider {
    override fun generateResponse(prompt: String): Flow<String> = flow {
        // Streaming tokens from the local model
        genAiModel.generateResponseAsync(prompt).collect { token ->
            emit(token)
        }
    }.flowOn(Dispatchers.Default) 
}
