
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents a versioned prompt template. 
 * Using Serialization allows us to fetch these templates from a remote 
 * config (like Firebase) to tune prompts without an app update.
 */
@Serializable
data class PromptTemplate(
    val version: String,
    val systemInstruction: String,
    val userPromptTemplate: String
)

/**
 * The AIProvider abstracts the AICore interaction.
 * It handles the "Warm-up" phase similar to how a Database 
 * initialization occurs.
 */
@Singleton
class OnDeviceAIProvider @Inject constructor() {
    private var isModelLoaded = false

    // Simulating the AICore model loading process
    suspend fun ensureModelLoaded() {
        if (!isModelLoaded) {
            withContext(Dispatchers.Default) {
                // Analogy: Like a Room migration, this is a heavy, 
                // one-time setup cost.
                delay(1000) // Simulate NPU initialization
                isModelLoaded = true
            }
        }
    }

    /**
     * Generates a response as a Flow of tokens.
     * Using Flow is critical for the "streaming" feel of GenAI.
     */
    fun generateResponse(fullPrompt: String): Flow<String> = flow {
        ensureModelLoaded()
        
        // In a real scenario, this would call the AICore SDK
        // GeminiNano.generateContentStream(fullPrompt)
        val simulatedResponse = "This is a simulated streaming response from Gemini Nano..."
        simulatedResponse.split(" ").forEach { token ->
            delay(100) // Simulate inference latency
            emit("$token ")
        }
    }.flowOn(Dispatchers.Default)
}

/**
 * The PromptEngine handles the logic of combining templates with user data.
 * It uses Kotlin 2.x features to ensure efficiency.
 */
class PromptEngine @Inject constructor(
    private val aiProvider: OnDeviceAIProvider
) {
    // Example template for a summarization task
    private val summaryTemplate = PromptTemplate(
        version = "1.0.2",
        systemInstruction = "You are a concise Android assistant. Summarize text in 3 bullet points.",
        userPromptTemplate = "Please summarize the following text: %s"
    )

    fun summarizeText(input: String): Flow<String> {
        // Constructing the final prompt: System Instruction + User Input
        // On-device models require very explicit boundaries.
        val finalPrompt = "${summaryTemplate.systemInstruction}\n\n${summaryTemplate.userPromptTemplate.format(input)}"
        
        return aiProvider.generateResponse(finalPrompt)
    }
}

/**
 * ViewModel integrating the AI logic into the Jetpack Compose lifecycle.
 */
class AIViewModel @Inject constructor(
    private val promptEngine: PromptEngine
) : androidx.lifecycle.ViewModel() {

    private val _uiState = MutableStateFlow<String>("")
    val uiState: StateFlow<String> = _uiState.asStateFlow()

    fun onSummarizeClicked(text: String) {
        viewModelScope.launch {
            promptEngine.summarizeText(text)
                .catch { e -> _uiState.value = "Error: ${e.message}" }
                .collect { token ->
                    _uiState.value += token
                }
        }
    }
}
