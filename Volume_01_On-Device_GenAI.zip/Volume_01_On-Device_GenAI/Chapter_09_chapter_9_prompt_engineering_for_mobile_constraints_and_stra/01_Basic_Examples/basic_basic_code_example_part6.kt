
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.kt
// Description: Basic Code Example
// ==========================================

object PromptTemplate {
    fun createFewShotSummarizationPrompt(userInput: String): String {
        return """
            You are a professional editor. Summarize text into 3 bullet points.
            
            Example 1:
            Input: The Great Wall of China is one of the most impressive architectural feats in history. It was built over several centuries to protect the Chinese states and empire from raids. It stretches thousands of miles across northern China.
            Summary: 
            - Impressive historical architectural feat.
            - Built over centuries for defense against raids.
            - Spans thousands of miles across northern China.
            
            Example 2:
            Input: Quantum computing uses qubits to perform calculations much faster than classical computers. While classical bits are 0 or 1, qubits can exist in multiple states. This allows for solving complex problems in cryptography.
            Summary:
            - Uses qubits for superior speed over classical computers.
            - Qubits exist in multiple states unlike binary bits.
            - Highly effective for complex cryptography problems.
            
            Now do the same for this text:
            Input: $userInput
            Summary:
        """.trimIndent()
    }
}
