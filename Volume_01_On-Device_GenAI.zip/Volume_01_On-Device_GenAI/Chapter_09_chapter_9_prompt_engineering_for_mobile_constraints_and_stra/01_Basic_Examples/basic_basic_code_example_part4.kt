
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class SummarizerViewModel @Inject constructor(
    private val repository: SummarizationRepository
) : ViewModel() {

    // UI State management using StateFlow
    private val _uiState = MutableStateFlow<SummarizerUiState>(SummarizerUiState.Idle)
    val uiState: StateFlow<SummarizerUiState> = _uiState.asStateFlow()

    fun summarizeText(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SummarizerUiState.Loading
            
            // Move execution to Dispatchers.Default for CPU-intensive AI work
            val result = withContext(Dispatchers.Default) {
                val engineeredPrompt = PromptTemplate.createSummarizationPrompt(text)
                repository.generateSummary(engineeredPrompt)
            }
            
            _uiState.value = SummarizerUiState.Success(result)
        }
    }

    override fun onCleared() {
        super.onCleared()
        // In a real app, you might not close the model here if it's a Singleton,
        // but for specific lifecycle-bound models, call repository.close().
    }
}

sealed class SummarizerUiState {
    object Idle : SummarizerUiState()
    object Loading : SummarizerUiState()
    data class Success(val summary: String) : SummarizerUiState()
    data class Error(val message: String) : SummarizerUiState()
}
