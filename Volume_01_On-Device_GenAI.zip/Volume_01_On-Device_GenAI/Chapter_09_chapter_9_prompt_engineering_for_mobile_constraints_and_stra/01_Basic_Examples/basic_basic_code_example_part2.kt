
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.ondeviceai.summarizer

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject as javaxInject
import javax.inject.Singleton

/**
 * 1. Prompt Template Strategy
 * On-device models require explicit constraints. We use a template to
 * ensure the model doesn't ramble and stays focused on the task.
 */
object PromptTemplates {
    fun createSummarizationPrompt(userInput: String): String {
        // We use a "few-shot" or "instruction-based" structure.
        // Constraints are placed at the beginning to prime the model.
        return """
            Task: Summarize the text below.
            Constraints: 
            - Use exactly 3 bullet points.
            - Keep each point under 15 words.
            - Focus on actionable items.
            
            Text: $userInput
            
            Summary:
        """.trimIndent()
    }
}

/**
 * 2. Repository Layer
 * Handles the heavy lifting of the LLM inference.
 */
@Singleton
class GenAiRepository @javaxInject constructor(
    private val context: Context
) {
    // Initialize LlmInference with the model path (e.g., gemini_nano.bin)
    private var llmInference: LlmInference? = null

    init {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to your downloaded model
            .setMaxTokens(512)
            .setTemperature(0.7f) // Balance between creativity and determinism
            .setTopK(40)
            .build()
        
        llmInference = LlmInference.createFromOptions(context, options)
    }

    suspend fun generateSummary(text: String): String = withContext(Dispatchers.Default) {
        val prompt = PromptTemplates.createSummarizationPrompt(text)
        try {
            // generateResponse is a blocking call; Dispatchers.Default is mandatory
            llmInference?.generateResponse(prompt) ?: "Model not initialized"
        } catch (e: Exception) {
            "Error generating summary: ${e.localizedMessage}"
        }
    }
}

/**
 * 3. ViewModel Layer
 * Manages UI state and triggers the AI pipeline.
 */
@AndroidEntryPoint
class SummarizerViewModel @javaxInject constructor(
    private val repository: GenAiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SummarizerUiState())
    val uiState: StateFlow<SummarizerUiState> = _uiState.asStateFlow()

    fun summarizeText(input: String) {
        if (input.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, result = "")
            
            // Execute AI inference on a background thread via the repository
            val summary = repository.generateSummary(input)
            
            _uiState.value = _uiState.value.copy(
                isLoading = false, 
                result = summary
            )
        }
    }
}

data class SummarizerUiState(
    val isLoading: Boolean = false,
    val result: String = "",
)

/**
 * 4. UI Layer (Jetpack Compose)
 */
@Composable
fun SummarizerScreen(viewModel: SummarizerViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Enter long note...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 5
        )

        Button(
            onClick = { viewModel.summarizeText(inputText) },
            enabled = !state.isLoading,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (state.isLoading) "Processing..." else "Summarize Note")
        }

        if (state.result.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = state.result,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
