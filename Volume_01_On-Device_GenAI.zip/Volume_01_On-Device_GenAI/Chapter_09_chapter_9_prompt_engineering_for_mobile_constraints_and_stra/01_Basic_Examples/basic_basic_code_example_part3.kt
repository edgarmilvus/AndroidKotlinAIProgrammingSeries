
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SummarizationRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // The LlmInference object is the heavy lifter. 
    // It must be managed carefully to avoid memory leaks.
    private var llmInference: LlmInference? = null

    init {
        setupModel()
    }

    private fun setupModel() {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to the .bin model file
            .setMaxTokens(512) // Limit output to save memory/battery
            .setTopK(40)
            .setTemperature(0.7f) // Balance between creativity and determinism
            .build()
        
        llmInference = LlmInference.createFromOptions(context, options)
    }

    /**
     * Generates a summary using the provided prompt.
     * This is a blocking call, so it must be called from a background thread.
     */
    fun generateSummary(prompt: String): String {
        return try {
            llmInference?.generateResponse(prompt) ?: "Model not initialized"
        } catch (e: Exception) {
            "Error generating summary: ${e.localizedMessage}"
        }
    }

    fun close() {
        llmInference?.close()
    }
}
