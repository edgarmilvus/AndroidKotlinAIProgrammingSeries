
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.smartreply

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import dagger.BindsInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidAppModule
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.lifecycle.ViewModelInject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import com.google.mediapipe.tasks.genai.llminference.LlmInference

// --- Domain Models ---
sealed class AiState {
    object Idle : AiState()
    object Processing : AiState()
    data class Success(val response: String, val strategyUsed: PromptStrategyType) : AiState()
    data class Error(val message: String) : AiState()
}

enum class PromptStrategyType { DETAILED, CONCISE }

// --- Prompt Strategies ---
interface PromptStrategy {
    val type: PromptStrategyType
    fun format(input: String): String
}

class DetailedStrategy : PromptStrategy {
    override val type = PromptStrategyType.DETAILED
    override fun format(input: String) = 
        "You are a professional assistant. Analyze the following conversation deeply, " +
        "consider the emotional tone, and provide a comprehensive, empathetic response: $input"
}

class ConciseStrategy : PromptStrategy {
    override val type = PromptStrategyType.CONCISE
    override fun format(input: String) = 
        "Reply briefly and concisely to: $input"
}

// --- Hardware Monitor ---
@Singleton
class HardwareMonitor @Inject constructor(
    private val powerManager: PowerManager,
    private val context: Context
) {
    fun isResourceConstrained(): Boolean {
        val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 100
        // Constraint if battery < 15% or device is in power save mode
        return level < 15 || powerManager.isPowerSaveMode
    }
}

// --- Repository ---
@Singleton
class OnDeviceAiRepository @Inject constructor(
    private val hardwareMonitor: HardwareMonitor
) {
    private var llmInference: LlmInference? = null

    // Initialize LLM with hardware-aware options (NPU/GPU)
    fun initializeLlm(modelPath: String) {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(512)
            .setTemperature(0.7f)
            .build()
        llmInference = LlmInference.createFromOptions(context, options)
    }

    suspend fun generateResponse(userInput: String): Pair<String, PromptStrategyType> = withContext(Dispatchers.Default) {
        // 1. Orchestration Logic: Determine strategy based on hardware and input length
        val strategy = if (hardwareMonitor.isResourceConstrained() || userInput.length > 1000) {
            ConciseStrategy()
        } else {
            DetailedStrategy()
        }

        val finalPrompt = strategy.format(userInput)
        
        // 2. Execution on NPU/GPU via MediaPipe
        val response = llmInference?.generateResponse(finalPrompt) 
            ?: throw IllegalStateException("LLM not initialized")
            
        return@withContext Pair(response, strategy.type)
    }
}

// --- ViewModel (MVI Pattern) ---
@HiltViewModel
class SmartReplyViewModel @Inject constructor(
    private val repository: OnDeviceAiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AiState>(AiState.Idle)
    val uiState: StateFlow<AiState> = _uiState.asStateFlow()

    fun onGenerateReply(text: String) {
        viewModelScope.launch {
            _uiState.value = AiState.Processing
            try {
                // Using structured concurrency to ensure the AI task is cancelled if ViewModel is cleared
                val (result, strategy) = repository.generateResponse(text)
                _uiState.value = AiState.Success(result, strategy)
            } catch (e: Exception) {
                _uiState.value = AiState.Error(e.localizedMessage ?: "Unknown AI Error")
            }
        }
    }
}

// --- Hilt Module ---
@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides
    @Singleton
    fun providePowerManager(@BindsInstance context: Context): PowerManager = 
        context.getSystemService(Context.POWER_SERVICE) as PowerManager
}
