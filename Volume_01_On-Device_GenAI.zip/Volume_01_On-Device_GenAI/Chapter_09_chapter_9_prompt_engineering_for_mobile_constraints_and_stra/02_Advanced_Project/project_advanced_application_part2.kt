
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.ondevice.orchestrator

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import javax.inject.Singletons

/**
 * Represents the state of the AI Generation process.
 * Using a Sealed Interface for MVI-style state management.
 */
sealed interface AiDraftState {
    object Idle : AiDraftState
    object Processing : AiDraftState
    data class Success(val text: String) : AiDraftState
    data class Error(val message: String) : AiDraftState
}

/**
 * Hardware-aware Repository that manages the LLM lifecycle.
 * It ensures the model is loaded into the NPU/GPU memory only when needed.
 */
@Singleton
class AiCoreRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var llmInference: LlmInference? = null

    // Initialize the model with hardware-specific options
    suspend fun initializeModel() = withContext(Dispatchers.Default) {
        if (llmInference == null) {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath("/data/local/tmp/gemini_nano.bin") // Path to on-device model
                .setMaxTokens(512)
                .setTopK(40)
                .setTemperature(0.7f)
                .setRandomSeed(42)
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    fun generateResponse(prompt: String): Flow<String> = flow {
        val inference = llmInference ?: throw IllegalStateException("Model not initialized")
        
        // MediaPipe LLM Inference supports streaming for better perceived latency
        inference.generateResponseAsync(prompt) { partialResult, done ->
            // Note: This is a callback-based API from MediaPipe; 
            // we bridge it to Flow for idiomatic Kotlin usage.
        }
        
        // For simplicity in this example, we use the synchronous call 
        // but wrap it in a flow to maintain the architecture.
        val result = inference.generateResponse(prompt)
        emit(result)
    }.flowOn(Dispatchers.Default)

    fun close() {
        llmInference?.close()
        llmInference = null
    }
}

/**
 * The PromptOrchestrator is the "Brain" of prompt engineering.
 * It handles context pruning, few-shot injection, and template management.
 */
@Singleton
class PromptOrchestrator @Inject constructor() {
    
    // System instruction defines the "Persona" of the AI
    private val systemInstruction = """
        You are a professional Android assistant. 
        Your goal is to draft concise, polite, and contextually accurate replies.
        Constraint: Keep responses under 3 sentences. 
        Constraint: Do not use emojis unless the user has used them.
    """.trimIndent()

    // Few-shot examples to guide the model on the expected output format
    private val fewShotExamples = """
        User: "Can we meet at 5 PM?" -> Draft: "Yes, 5 PM works for me. See you then!"
        User: "I'm running 10 mins late." -> Draft: "No problem, thanks for letting me know. Drive safe!"
    """.trimIndent()

    /**
     * Assembles the final prompt based on the "Complexity Level".
     * If complexity is LOW, we skip few-shot examples to save tokens and latency.
     */
    fun buildPrompt(
        userInput: String, 
        conversationHistory: List<String>, 
        isComplexTask: Boolean
    ): String {
        val historyContext = conversationHistory.takeLast(3).joinToString("\n")
        
        return buildString {
            appendLine(systemInstruction)
            if (isComplexTask) {
                appendLine("Examples of desired style:\n$fewShotExamples")
            }
            appendLine("\nRecent Conversation:\n$historyContext")
            appendLine("\nUser Input: $userInput")
            appendLine("\nSuggested Draft:")
        }
    }
}

/**
 * ViewModel implementing the orchestration flow.
 * Uses Structured Concurrency to ensure AI tasks are cancelled on ViewModel clear.
 */
@HiltViewModel
@AndroidEntryPoint
class DraftingViewModel @Inject constructor(
    private val repository: AiCoreRepository,
    private val orchestrator: PromptOrchestrator
) : ViewModel() {

    private val _uiState = MutableStateFlow<AiDraftState>(AiDraftState.Idle)
    val uiState: StateFlow<AiDraftState> = _uiState.asStateFlow()

    fun onGenerateDraftClicked(userInput: String, history: List<String>) {
        viewModelScope.launch {
            _uiState.value = AiDraftState.Processing
            
            try {
                // 1. Ensure hardware is ready
                repository.initializeModel()

                // 2. Determine if the task is complex (e.g., based on input length or keywords)
                val isComplex = userInput.length > 50 || userInput.contains("urgent", ignoreCase = true)

                // 3. Orchestrate the prompt
                val finalPrompt = orchestrator.buildPrompt(userInput, history, isComplex)

                // 4. Execute inference on Dispatchers.Default (NPU offloading)
                repository.generateResponse(finalPrompt)
                    .catch { e -> _uiState.value = AiDraftState.Error(e.localizedMessage ?: "AI Error") }
                    .collect { result ->
                        _uiState.value = AiDraftState.Success(result)
                    }
            } catch (e: Exception) {
                _uiState.value = AiDraftState.Error("Initialization failed: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.close() // Critical: Release NPU memory
    }
}
