
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class Email(val id: String, val sender: String, val body: String, val timestamp: Long)

class SummarizationUseCase @Inject constructor(
    private val aiCoreClient: GeminiNanoClient 
) {
    suspend fun summarizeThread(emails: List<Email>): String = withContext(Dispatchers.Default) {
        val curatedContext = curateContext(emails)
        val prompt = """
            You are summarizing a truncated email thread. 
            The markers [...truncated...] indicate missing parts of the conversation.
            Provide a concise summary of the current state of the discussion.
            
            Thread:
            $curatedContext
        """.trimIndent()
        
        return@withContext aiCoreClient.generate(prompt)
    }

    private fun curateContext(emails: List<Email>): String {
        if (emails.size <= 12) return emails.joinToString("\n") { it.body }

        val firstTwo = emails.take(2)
        val lastTen = emails.takeLast(10)
        
        // Sample 3 emails from the middle based on length (heuristic for importance)
        val middle = emails.subList(2, emails.size - 10)
            .sortedByDescending { it.body.length }
            .take(3)

        return buildString {
            appendLine("--- Start of Thread ---")
            appendLine(firstTwo.joinToString("\n") { it.body })
            appendLine("\n[...truncated...]")
            appendLine(middle.joinToString("\n") { it.body })
            appendLine("\n[...truncated...]")
            appendLine(lastTen.joinToString("\n") { it.body })
            appendLine("--- End of Thread ---")
        }
    }
}
