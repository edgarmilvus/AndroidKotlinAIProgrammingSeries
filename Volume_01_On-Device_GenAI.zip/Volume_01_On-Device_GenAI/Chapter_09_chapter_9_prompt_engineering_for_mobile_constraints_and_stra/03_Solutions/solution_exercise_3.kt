
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.flow.*
import java.util.*

data class ChatMessage(val role: String, val content: String)

class ConversationBuffer(
    private val maxTokens: Int = 2048,
    private val systemPrompt: String
) {
    private val history = ArrayDeque<ChatMessage>()
    
    // Heuristic: 1 token approx 4 characters for English
    private fun estimateTokens(text: String): Int = text.length / 4

    fun addMessage(role: String, content: String) {
        history.addLast(ChatMessage(role, content))
        pruneHistory()
    }

    private fun pruneHistory() {
        var currentTokens = history.sumOf { estimateTokens(it.content) } + estimateTokens(systemPrompt)

        if (currentTokens <= maxTokens) return

        // Pruning Strategy:
        // 1. Keep System Prompt (handled externally)
        // 2. Keep First Message (The Goal)
        // 3. Keep most recent N messages
        // 4. Remove intermediate messages
        
        if (history.size > 2) {
            val firstMessage = history.removeFirst()
            
            // Remove from the front (oldest) until we are under budget, 
            // but leave room for the first message.
            while (history.size > 1 && calculateTotalTokens() > maxTokens) {
                history.removeFirst()
            }
            
            // Put the first message back at the start
            history.addFirst(firstMessage)
        }
    }

    fun calculateTotalTokens(): Int {
        return history.sumOf { estimateTokens(it.content) } + estimateTokens(systemPrompt)
    }

    fun getFullPrompt(): String {
        val conversation = history.joinToString("\n") { "${it.role}: ${it.content}" }
        return "$systemPrompt\n\n$conversation\nAssistant:"
    }
    
    fun getHistoryForUi(): List<ChatMessage> = history.toList()
}

// ViewModel Integration
class ChatViewModel @Inject constructor(private val aiService: LocalAiService) : ViewModel() {
    private val buffer = ConversationBuffer(systemPrompt = "You are a helpful local assistant.")
    
    private val _uiState = MutableStateFlow<Pair<List<ChatMessage>, Int>>(emptyList<ChatMessage>() to 0)
    val uiState = _uiState.asStateFlow()

    fun sendMessage(text: String) {
        viewModelScope.launch {
            buffer.addMessage("User", text)
            val response = aiService.generateResponse("", buffer.getFullPrompt()).getOrNull()?.text ?: "Error"
            buffer.addMessage("Assistant", response)
            
            _uiState.value = buffer.getHistoryForUi() to buffer.calculateTotalTokens()
        }
    }
}
