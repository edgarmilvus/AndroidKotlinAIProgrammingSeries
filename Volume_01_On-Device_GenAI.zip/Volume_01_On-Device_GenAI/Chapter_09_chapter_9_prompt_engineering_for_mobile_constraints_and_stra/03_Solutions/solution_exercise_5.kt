
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlin.system.measureNanoTime
import kotlinx.serialization.*
import kotlinx.serialization.json.*

@Serializable
data class GoldExample(val input: String, val idealOutput: String)

data class BenchmarkMetric(
    val ttftMs: Long,
    val tps: Double,
    val totalLatencyMs: Long,
    val similarityScore: Double
)

class PromptBenchmarker(private val aiService: LocalAiService) {

    suspend fun benchmark(
        promptA: String, 
        promptB: String, 
        dataset: List<GoldExample>
    ): Map<String, List<BenchmarkMetric>> {
        val resultsA = mutableListOf<BenchmarkMetric>()
        val resultsB = mutableListOf<BenchmarkMetric>()

        dataset.forEach { example ->
            resultsA.add(runSingleTest(promptA, example))
            resultsB.add(runSingleTest(promptB, example))
        }

        return mapOf("PromptA" to resultsA, "PromptB" to resultsB)
    }

    private suspend fun runSingleTest(promptTemplate: String, example: GoldExample): BenchmarkMetric {
        var firstTokenTime = 0L
        var totalTime = 0L
        var generatedText = ""

        val startTime = System.nanoTime()
        
        // Note: This assumes aiService.generateResponseStream exists for TTFT
        aiService.generateResponseStream(promptTemplate, example.input).collectIndexed { index, token ->
            if (index == 0) firstTokenTime = (System.nanoTime() - startTime) / 1_000_000
            generatedText += token
        }
        
        totalTime = (System.nanoTime() - startTime) / 1_000_000
        val tokensCount = generatedText.length / 4 // Heuristic
        val tps = tokensCount.toDouble() / (totalTime / 1000.0)
        
        return BenchmarkMetric(
            ttftMs = firstTokenTime,
            tps = tps,
            totalLatencyMs = totalTime,
            similarityScore = calculateSimilarity(generatedText, example.idealOutput)
        )
    }

    private fun calculateSimilarity(s1: String, s2: String): Double {
        val distance = levenshtein(s1, s2)
        return 1.0 - (distance.toDouble() / maxOf(s1.length, s2.length))
    }

    private fun levenshtein(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            }
        }
        return dp[s1.length][s2.length]
    }
}
