
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*

@Serializable
data class Expense(
    val amount: Double,
    val currency: String,
    val category: String,
    val vendor: String
)

class ExpenseExtractionPipeline(private val model: GenerativeModel) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun extractExpense(userInput: String): Expense? {
        val prompt = "Extract expense to JSON. Fields: amount, currency, category, vendor. " +
                     "Input: $userInput. Output JSON only: {" // Output Priming
        
        var response = model.generateContent(prompt).text ?: ""
        
        // 1. Clean "dirty" JSON (remove markdown blocks)
        val cleanedJson = cleanJson(response)
        
        return try {
            json.decodeFromString<Expense>(cleanedJson)
        } catch (e: Exception) {
            // 2. Self-Correction Retry Loop (Limit 1)
            Log.w("AI_PIPELINE", "Parsing failed, retrying... ${e.message}")
            val retryPrompt = "The JSON you provided was invalid: $cleanedJson. Please correct it and return ONLY the JSON starting with {."
            val retryResponse = model.generateContent(retryPrompt).text ?: ""
            
            try {
                json.decodeFromString<Expense>(cleanJson(retryResponse))
            } catch (e2: Exception) {
                null // Final failure
            }
        }
    }

    private fun cleanJson(input: String): String {
        // Remove 