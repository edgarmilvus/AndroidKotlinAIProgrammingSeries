
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*

@Serializable
data class ApartmentCriteria(
    val rooms: Int? = null,
    val location: String? = null,
    val max_price: Int? = null
)

class EntityExtractor(private val aiService: LocalAiService) {

    // 1. Example Registry for Few-Shot Prompting
    private val examples = listOf(
        "Input: I want a 3-bed place in Manhattan for 5000\nOutput: {\"rooms\": 3, \"location\": \"Manhattan\", \"max_price\": 5000}",
        "Input: Looking for a studio in Brooklyn under 2000\nOutput: {\"rooms\": 1, \"location\": \"Brooklyn\", \"max_price\": 2000}",
        "Input: 2 bedroom apartment in Queens, budget is 3000\nOutput: {\"rooms\": 2, \"location\": \"Queens\", \"max_price\": 3000}"
    )

    suspend fun extractCriteria(userInput: String): Result<ApartmentCriteria> {
        // 2. Dynamic Prompt Assembler
        val prompt = StringBuilder().apply {
            append("Extract apartment details into JSON. Use the following examples:\n\n")
            examples.forEach { append("$it\n") }
            append("\nInput: $userInput\nOutput:")
        }.toString()

        return runCatching {
            val response = aiService.generateResponse(
                systemInstruction = "You are a data extraction tool. Output ONLY valid JSON.",
                userInput = prompt
            ).getOrThrow().text

            // 3. JSON Cleaning Logic
            val cleanedJson = cleanJsonResponse(response)
            Json.decodeFromString<ApartmentCriteria>(cleanedJson)
        }
    }

    private fun cleanJsonResponse(response: String): String {
        // Remove markdown code blocks (e.g., 