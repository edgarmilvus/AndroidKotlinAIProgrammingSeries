
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*

object DeviceSupportConfig {
    const val SYSTEM_INSTRUCTION = """
        Identity: You are the Android Settings Assistant.
        Knowledge Boundary: ONLY answer questions about Android OS settings, hardware, and device troubleshooting.
        Tone: Professional and concise.
        Negative Constraints: 
        - DO NOT answer questions about general knowledge, politics, or other apps.
        - DO NOT apologize or explain why you cannot answer.
        - If the query is outside your boundary, respond ONLY with the token: [OUT_OF_SCOPE]
    """.trimIndent()
}

@Composable
fun DeviceSupportScreen(viewModel: SupportViewModel) {
    var query by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("") }
    var isOutOfScope by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(value = query, onValueChange = { query = it })
        Button(onClick = {
            // In a real app, this calls the ViewModel
            val result = viewModel.askAssistant(query) 
            if (result == "[OUT_OF_SCOPE]") {
                isOutOfScope = true
                response = ""
            } else {
                isOutOfScope = false
                response = result
            }
        }) { Text("Ask") }

        if (isOutOfScope) {
            Text("I can only help with device settings. Please ask about your phone's configuration.", 
                 color = MaterialTheme.colorScheme.error)
        } else {
            Text(text = response)
        }
    }
}
