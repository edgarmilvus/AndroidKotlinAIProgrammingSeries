
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// 1. UI State Management
sealed class SummaryUiState {
    object Idle : SummaryUiState()
    object Loading : SummaryUiState()
    data class Success(val summary: String) : SummaryUiState()
    data class Error(val message: String) : SummaryUiState()
}

// 2. Prompt Template Engine
object PromptTemplates {
    const val SYSTEM_INSTRUCTION = """
        You are a professional CRM assistant. 
        Your task is to transform unstructured call notes into a professional summary.
        
        CONSTRAINTS:
        - Use a clean bulleted list.
        - ONLY include information explicitly provided in the notes.
        - If a piece of information is not provided, do not invent it; simply omit it.
        - Maintain a professional, neutral tone.
    """

    fun buildUserPrompt(notes: String): String {
        return "### Notes: \n$notes\n### End of Notes"
    }
}

// 3. ViewModel with Hilt Integration
@HiltViewModel
class SummaryViewModel @Inject constructor(
    private val aiService: LocalAiService // Wrapper for GenerativeModel
) : ViewModel() {

    private val _uiState = MutableStateFlow<SummaryUiState>(SummaryUiState.Idle)
    val uiState: StateFlow<SummaryUiState> = _uiState.asStateFlow()

    fun summarizeNotes(rawNotes: String) {
        if (rawNotes.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SummaryUiState.Loading
            val result = aiService.generateResponse(
                systemInstruction = PromptTemplates.SYSTEM_INSTRUCTION,
                userInput = PromptTemplates.buildUserPrompt(rawNotes)
            )
            
            _uiState.value = result.fold(
                onSuccess = { SummaryUiState.Success(it.text) },
                onFailure = { SummaryUiState.Error(it.message ?: "Inference failed") }
            )
        }
    }
}

// 4. Jetpack Compose UI
@Composable
fun ContactNoteScreen(viewModel: SummaryViewModel) {
    var noteText by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        TextField(
            value = noteText,
            onValueChange = { noteText = it },
            label = { Text("Enter messy notes...") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.summarizeNotes(noteText) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Generate Professional Summary")
        }
        
        when (val s = state) {
            is SummaryUiState.Loading -> CircularProgressIndicator()
            is SummaryUiState.Success -> Text("Summary:\n${s.summary}", style = MaterialTheme.typography.bodyLarge)
            is SummaryUiState.Error -> Text("Error: ${s.message}", color = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }
}
