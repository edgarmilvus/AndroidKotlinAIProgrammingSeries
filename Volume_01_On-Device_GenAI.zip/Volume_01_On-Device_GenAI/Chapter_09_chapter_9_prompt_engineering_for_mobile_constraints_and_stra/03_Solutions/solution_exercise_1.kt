
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import com.google.ai.client.generativeai.GenerativeModel

data class PromptTemplate(
    val systemInstruction: String,
    val examples: List<Pair<String, String>>
)

class SmartReplyPromptBuilder {
    private val template = PromptTemplate(
        systemInstruction = "You are a messaging assistant. Provide 3 short, natural replies separated by '|'. Keep each reply under 4 words.",
        examples = listOf(
            "User: Hey, are you coming to the party?\nAssistant: Yes, see you! | I can't make it | Maybe later" to "Few-shot 1",
            "User: Did you finish the report?\nAssistant: Almost done! | Yes, sent it | Still working on it" to "Few-shot 2",
            "User: Want to grab lunch?\nAssistant: I'm down! | Too busy now | What time?" to "Few-shot 3"
        )
    )

    fun buildPrompt(messages: List<String>): String {
        val conversationContext = messages.takeLast(5).joinToString("\n") { it }
        
        return buildString {
            appendLine(template.systemInstruction)
            appendLine("\nExamples:")
            template.examples.forEach { (example, _) ->
                appendLine(example)
            }
            appendLine("\nActual Conversation:")
            appendLine(conversationContext)
            append("Assistant: ")
        }
    }
}

// Usage in ViewModel/Repository
suspend fun getSmartReplies(messages: List<String>, model: GenerativeModel): List<String> {
    val builder = SmartReplyPromptBuilder()
    val prompt = builder.buildPrompt(messages)
    
    val response = model.generateContent(prompt)
    val text = response.text ?: ""
    
    // Parse the delimited format: "Reply 1 | Reply 2 | Reply 3"
    return text.split("|").map { it.trim() }.filter { it.isNotEmpty() }.take(3)
}
