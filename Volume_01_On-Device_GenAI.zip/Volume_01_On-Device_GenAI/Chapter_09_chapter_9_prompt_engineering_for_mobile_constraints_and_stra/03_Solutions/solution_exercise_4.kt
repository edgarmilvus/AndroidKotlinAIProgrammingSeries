
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.util.Log
import kotlin.system.measureTimeMillis

class WritingAssistant(private val model: GenerativeModel) {
    
    // Strategy A: Naive
    private suspend fun generateNaive(fullNote: String): String {
        val prompt = "System: Rewrite professional. Note: $fullNote. Improve this."
        return model.generateContent(prompt).text ?: ""
    }

    // Strategy B: Compressed (Differential)
    private suspend fun generateCompressed(fullNote: String, changedParagraph: String, contextWindow: String): String {
        // Token-efficient system prompt: "Rewrite professional:" instead of "Please rewrite..."
        val prompt = "Rewrite professional: Context: $contextWindow. Target: [$changedParagraph]"
        return model.generateContent(prompt).text ?: ""
    }

    suspend fun benchmark(fullNote: String, changedParagraph: String, contextWindow: String) {
        val timeA = measureTimeMillis { generateNaive(fullNote) }
        val timeB = measureTimeMillis { generateCompressed(fullNote, changedParagraph, contextWindow) }
        
        Log.d("AI_BENCHMARK", "Naive Latency: ${timeA}ms | Compressed Latency: ${timeB}ms")
        Log.d("AI_BENCHMARK", "Improvement: ${((timeA - timeB).toDouble() / timeA * 100).toInt()}%")
    }
}
