
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*

sealed interface PipelineStage {
    data class Extraction(val input: String) : PipelineStage
    data class Brainstorming(val constraints: String) : PipelineStage
    data class Scheduling(val ideas: String) : PipelineStage
    data class Refinement(val itinerary: String) : PipelineStage
}

class TravelPlanner(private val aiService: LocalAiService) {

    suspend fun planTrip(userRequest: String): Result<String> = runCatching {
        // Stage 1: Extraction
        val constraints = executeStage(PipelineStage.Extraction(userRequest))
        
        // Stage 2: Brainstorming
        val ideas = executeStage(PipelineStage.Brainstorming(constraints))
        
        // Stage 3: Scheduling
        val itinerary = executeStage(PipelineStage.Scheduling(ideas))
        
        // Stage 4: Refinement
        val finalPlan = executeStage(PipelineStage.Refinement(itinerary))
        
        finalPlan
    }

    private suspend fun executeStage(stage: PipelineStage): String {
        val (systemPrompt, userPrompt) = when (stage) {
            is PipelineStage.Extraction -> 
                "Extract destination, budget, and theme." to stage.input
            is PipelineStage.Brainstorming -> 
                "Generate 10 specific activities based on these constraints." to stage.constraints
            is PipelineStage.Scheduling -> 
                "Organize these activities into a 3-day calendar." to stage.ideas
            is PipelineStage.Refinement -> 
                "Review this itinerary for logical errors or distance conflicts." to stage.itinerary
        }
        
        return aiService.generateResponse(systemPrompt, userPrompt).getOrThrow().text
    }
}

@HiltViewModel
class PlannerViewModel @Inject constructor(private val planner: TravelPlanner) : ViewModel() {
    private var planningJob: Job? = null

    fun startPlanning(request: String) {
        planningJob?.cancel() // Cancellation Logic
        planningJob = viewModelScope.launch {
            try {
                val result = planner.planTrip(request)
                // Update UI with result...
            } catch (e: CancellationException) {
                // Handle cancellation
            }
        }
    }
}
