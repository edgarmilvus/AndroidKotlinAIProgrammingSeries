
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.ai.agent.context

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 1. DATA LAYER: SensorRepository
 * Responsible for the raw acquisition of sensor data.
 * It converts the callback-based SensorEventListener into a modern Kotlin Flow.
 */
@Singleton
class SensorRepository @Inject constructor(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    
    // StateFlows to emit raw sensor values to the ViewModel
    private val _accelerometerData = MutableStateFlow(floatArrayOf(0f, 0f, 0f))
    val accelerometerData: StateFlow<FloatArray> = _accelerometerData.asStateFlow()

    private val _lightData = MutableStateFlow(0f)
    val lightData: StateFlow<Float> = _lightData.asStateFlow()

    init {
        // Register sensors
        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val light = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> _accelerometerData.value = event.values.copyOf()
            Sensor.TYPE_LIGHT -> _lightData.value = event.values[0]
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not needed for this basic example
    }

    fun stopListening() {
        sensorManager.unregisterListener(this)
    }
}

/**
 * 2. LOGIC LAYER: ContextViewModel
 * This is where the "Fusion" happens. It takes raw streams and 
 * runs them through an AI inference logic to determine semantic state.
 */
class ContextViewModel @Inject constructor(
    private val repository: SensorRepository
) : ViewModel() {

    // The final semantic state that the AI Agent will use
    private val _aiContext = MutableStateFlow("Analyzing...")
    val aiContext: StateFlow<String> = _aiContext.asStateFlow()

    // A buffer to store the last 10 accelerometer readings (Sliding Window)
    private val accelWindow = mutableListOf<FloatArray>()
    private val WINDOW_SIZE = 10

    init {
        observeSensorsAndInfer()
    }

    private fun observeSensorsAndInfer() {
        viewModelScope.launch {
            // Combine both sensor streams into one fusion pipeline
            combine(
                repository.accelerometerData,
                repository.lightData
            ) { accel, light ->
                // Update the sliding window
                accelWindow.add(accel)
                if (accelWindow.size > WINDOW_SIZE) accelWindow.removeAt(0)
                
                // Perform inference on a background thread
                withContext(Dispatchers.Default) {
                    performAiInference(accelWindow, light)
                }
            }.collect { inferredState ->
                _aiContext.value = inferredState
            }
        }
    }

    /**
     * MOCK AI INFERENCE ENGINE
     * In a production app, this would call a TFLite model or a local SLM.
     * Here, we implement the "Heuristic Fusion" logic to demonstrate the concept.
     */
    private fun performAiInference(window: List<FloatArray>, light: Float): String {
        if (window.size < WINDOW_SIZE) return "Calibrating..."

        // 1. Calculate Magnitude of acceleration (Vector Sum)
        // Formula: sqrt(x^2 + y^2 + z^2)
        val lastReading = window.last()
        val magnitude = Math.sqrt(
            (lastReading[0] * lastReading[0] + 
             lastReading[1] * lastReading[1] + 
             lastReading[2] * lastReading[2]).toDouble()
        ).toFloat()

        // 2. Calculate Variance (Is the device shaking or still?)
        val avgMagnitude = window.map { 
            Math.sqrt((it[0]*it[0] + it[1]*it[1] + it[2]*it[2]).toDouble()).toFloat() 
        }.average().toFloat()
        
        val variance = Math.abs(magnitude - avgMagnitude)

        // 3. Fusion Logic (The "AI" Decision Tree)
        return when {
            variance > 1.5f -> "User is Moving (High Activity)"
            variance < 0.2f && light < 10f -> "User is Resting in Dark (Sleep/Cinema)"
            variance < 0.2f && light >= 10f -> "User is Stationary (Reading/Working)"
            else -> "User is Calmly Moving"
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.stopListening()
    }
}

/**
 * 3. UI LAYER: ContextScreen
 * Visualizes the AI's current understanding of the physical world.
 */
@Composable
fun ContextScreen(viewModel: ContextViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val currentContext by viewModel.aiContext.collectAsState()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "AI Agent Perception",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Text(
                    text = currentContext,
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "This state is injected into the LLM prompt\nto modify agent behavior.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 32.dp)
            )
        }
    }
}
