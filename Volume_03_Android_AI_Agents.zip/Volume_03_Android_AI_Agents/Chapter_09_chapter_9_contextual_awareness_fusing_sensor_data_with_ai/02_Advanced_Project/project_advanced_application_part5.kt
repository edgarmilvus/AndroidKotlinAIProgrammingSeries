
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ai.agent.domain.engine.FusionEngine
import com.ai.agent.domain.model.FusedContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MVI State representing the UI's view of the world.
 */
data class ContextViewState(
    val context: FusedContext = FusedContext(),
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * MVI Intents (User or System actions).
 */
sealed class ContextIntent {
    object StartObserving : ContextIntent()
    object StopObserving : ContextIntent()
}

@HiltViewModel
class ContextViewModel @Inject constructor(
    private val fusionEngine: FusionEngine
) : ViewModel() {

    private val _state = MutableStateFlow(ContextViewState())
    val state: StateFlow<ContextViewState> = _state.asStateFlow()

    private var observationJob: kotlinx.coroutines.Job? = null

    fun handleIntent(intent: ContextIntent) {
        when (intent) {
            is ContextIntent.StartObserving -> startObservation()
            is ContextIntent.StopObserving -> stopObservation()
        }
    }

    private fun startObservation() {
        if (observationJob?.isActive == true) return

        _state.update { it.copy(isLoading = true) }

        observationJob = viewModelScope.launch {
            fusionEngine.observeFusedContext()
                .catch { e ->
                    _state.update { it.copy(error = e.message, isLoading = false) }
                }
                .collect { fusedContext ->
                    _state.update { 
                        it.copy(
                            context = fusedContext, 
                            isLoading = false, 
                            error = null 
                        ) 
                    }
                }
        }
    }

    private fun stopObservation() {
        observationJob?.cancel()
        _state.update { it.copy(isLoading = false) }
    }
}
