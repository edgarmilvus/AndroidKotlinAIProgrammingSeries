
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.domain.engine

import com.ai.agent.data.repository.ContextRepository
import com.ai.agent.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

class FusionEngine @Inject constructor(
    private val repository: ContextRepository
) {
    /**
     * Fuses motion and vision data into a single FusedContext stream.
     * Uses Dispatchers.Default for heavy mathematical computations.
     */
    fun observeFusedContext(): Flow<FusedContext> = combine(
        repository.getMotionStream(),
        repository.getVisionStream()
    ) { motion, vision ->
        // This block runs on the dispatcher provided by the collector, 
        // but we ensure it's handled efficiently.
        performFusion(motion, vision)
    }
    .flowOn(Dispatchers.Default) // Ensure math doesn't block the Main thread
    .conflate() // If fusion is slower than sensor frequency, drop old samples

    private fun performFusion(motion: MotionData, vision: VisionData): FusedContext {
        // 1. Calculate Magnitude of Acceleration (Intensity)
        val accelerationMagnitude = Math.sqrt(
            (motion.x * motion.x + motion.y * motion.y + motion.z * motion.z).toDouble()
        ).toFloat()

        // 2. Determine Motion-based Environment
        // Heuristic: High magnitude fluctuation indicates walking/running
        val motionBasedEnv = when {
            accelerationMagnitude < 9.8f && accelerationMagnitude > 8.5f -> EnvironmentType.STATIONARY
            accelerationMagnitude in 10.0f..15.0f -> EnvironmentType.WALKING
            accelerationMagnitude > 15.0f -> EnvironmentType.CYCLING
            else -> EnvironmentType.UNKNOWN
        }

        // 3. Semantic Fusion (Weighted Average Logic)
        // We trust Vision for the "Type" but use IMU to validate "Intensity"
        val finalEnv = if (vision.detectionConfidence > 0.8f) {
            vision.detectedEnvironment
        } else {
            motionBasedEnv
        }

        // 4. Confidence Scoring
        // Confidence decreases if Vision and IMU disagree significantly
        val disagreementPenalty = if (finalEnv != vision.detectedEnvironment) 0.2f else 0f
        val finalConfidence = (vision.detectionConfidence - disagreementPenalty).coerceIn(0f, 1f)

        return FusedContext(
            environment = finalEnv,
            activityIntensity = accelerationMagnitude / 20f, // Normalized
            confidence = finalConfidence
        )
    }
}
