
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.data.repository

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.ai.agent.domain.model.MotionData
import com.ai.agent.domain.model.VisionData
import com.ai.agent.domain.model.EnvironmentType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContextRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    /**
     * Provides a high-frequency stream of Accelerometer data.
     */
    fun getMotionStream(): Flow<MotionData> = callbackFlow {
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    trySend(
                        MotionData(
                            x = it.values[0],
                            y = it.values[1],
                            z = it.values[2],
                            timestamp = it.timestamp
                        )
                    )
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_GAME)

        // Crucial: Unregister listener when the Flow is closed to prevent battery drain
        awaitClose {
            sensorManager.unregisterListener(listener)
        }
    }

    /**
     * In a real implementation, this would interface with CameraX and a TFLite model.
     * Here, we simulate the NPU-driven vision stream.
     */
    fun getVisionStream(): Flow<VisionData> = callbackFlow {
        // Simulate NPU inference latency and frequency
        val timer = java.util.Timer()
        timer.scheduleAtFixedRate(object : java.util.TimerTask() {
            override fun run() {
                // In reality, this comes from an ImageAnalysis.Analyzer
                trySend(
                    VisionData(
                        detectedEnvironment = EnvironmentType.values().random(),
                        detectionConfidence = (0.7f..0.99f).random()
                    )
                )
            }
        }, 0, 500) // 2Hz frequency

        awaitClose { timer.cancel() }
    }
}

// Helper extension for simulation
private fun ClosedRange<Float>.random() = 
    (Math.random().toFloat() * (endInclusive - start)) + start
