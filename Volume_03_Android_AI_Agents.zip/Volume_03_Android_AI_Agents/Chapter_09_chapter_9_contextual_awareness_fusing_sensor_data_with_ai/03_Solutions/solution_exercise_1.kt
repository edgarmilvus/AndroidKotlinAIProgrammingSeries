
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.Priority
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Sensor Integration: Light Sensor Repository
@Singleton
class SensorRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

    fun getLightLevelFlow(): Flow<Float> = callbackFlow {
        if (lightSensor == null) {
            // Fallback: Emit -1 to indicate absence
            trySend(-1f)
            close()
            return@callbackFlow
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.values?.get(0)?.let { trySend(it) }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(listener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL)
        awaitClose { sensorManager.unregisterListener(listener) }
    }.conflate() // Only care about the latest reading
}

// 2. Location Awareness Repository
@Singleton
class LocationRepository @Inject constructor(
    private val fusedLocationClient: FusedLocationProviderClient
) {
    // Simplified home check for exercise purposes
    private val homeLat = 40.7128
    private val homeLon = -74.0060

    suspend fun isAtHome(): Boolean {
        return try {
            val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
            location != null && 
                Math.abs(location.latitude - homeLat) < 0.001 && 
                Math.abs(location.longitude - homeLon) < 0.001
        } catch (e: SecurityException) {
            false // Permission denied
        }
    }
}

// 3. The Context Bridge
@Singleton
class ContextManager @Inject constructor(
    private val sensorRepo: SensorRepository,
    private val locationRepo: LocationRepository
) {
    val currentContext: Flow<String> = sensorRepo.getLightLevelFlow().map { lux ->
        val isHome = locationRepo.isAtHome()
        val lightDesc = when {
            lux < 0 -> "Light sensor unavailable (estimating by time)"
            lux < 10 -> "Dimly lit"
            lux < 50 -> "Moderately lit"
            else -> "Brightly lit"
        }
        val locationDesc = if (isHome) "User is at home" else "User is away from home"
        "Current Environment: $locationDesc. Ambient light is ${if(lux >= 0) lux.toInt() else "N/A"} lux ($lightDesc)."
    }
}

// 4. AI Prompt Fusion in ViewModel
class HomeAgentViewModel @Inject constructor(
    private val contextManager: ContextManager,
    private val generativeModel: GenerativeModel // Hypothetical Gemini SDK
) : ViewModel() {
    
    private val _uiState = MutableStateFlow("")
    val uiState = _uiState.asStateFlow()

    fun sendRequest(userPrompt: String) {
        viewModelScope.launch {
            // Fuse current snapshot with user prompt
            val contextSnapshot = contextManager.currentContext.first()
            val fusedPrompt = "SYSTEM: $contextSnapshot\nUSER: $userPrompt"
            
            val response = generativeModel.generateContent(fusedPrompt)
            _uiState.value = response.text ?: "I'm sorry, I couldn't process that."
        }
    }
}
