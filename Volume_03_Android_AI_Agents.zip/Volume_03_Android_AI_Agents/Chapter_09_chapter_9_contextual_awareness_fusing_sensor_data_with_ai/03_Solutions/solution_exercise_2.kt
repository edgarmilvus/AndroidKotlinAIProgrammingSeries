
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.work.*
import kotlinx.coroutines.flow.*
import java.time.Instant
import java.time.temporal.ChronoUnit

enum class CoachingPersona(val systemPrompt: String) {
    ENCOURAGING("You are a supportive coach. The user is pushing hard! Be brief and high-energy."),
    CHALLENGING("You are a tough drill sergeant. The user is coasting. Demand more effort!"),
    REST_MODE("You are a recovery specialist. Focus on breathing and cooling down.")
}

@Singleton
class HealthRepository @Inject constructor(
    private val healthConnectClient: HealthConnectClient
) {
    suspend fun getRecentHeartRate(): Double? {
        val end = Instant.now()
        val start = end.minus(5, ChronoUnit.MINUTES)
        
        val response = healthConnectClient.readRecords(
            ReadRecordsRequest(
                recordType = HeartRateRecord::class,
                timeRangeFilter = TimeRangeFilter.between(start, end)
            )
        )
        return response.records.lastOrNull()?.samples?.lastOrNull()?.beatsPerMinute?.toDouble()
    }
}

@Singleton
class PersonaManager @Inject constructor(private val healthRepo: HealthRepository) {
    private val _currentPersona = MutableStateFlow(CoachingPersona.REST_MODE)
    val currentPersona = _currentPersona.asStateFlow()

    suspend fun updatePersona() {
        val hr = healthRepo.getRecentHeartRate() ?: return
        val persona = when {
            hr > 150 -> CoachingPersona.ENCOURAGING
            hr < 100 -> CoachingPersona.CHALLENGING
            else -> CoachingPersona.REST_MODE
        }
        _currentPersona.value = persona
    }
}

// 3. Proactive Trigger via WorkManager
class MotivationWorker(
    context: Context, 
    params: WorkerParameters,
    private val personaManager: PersonaManager,
    private val aiService: AIService
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val oldPersona = personaManager.currentPersona.value
        personaManager.updatePersona()
        val newPersona = personaManager.currentPersona.value

        if (oldPersona != newPersona) {
            val message = aiService.generateProactiveMessage(newPersona)
            NotificationHelper.showNotification(applicationContext, message)
        }
        return Result.success()
    }
}
