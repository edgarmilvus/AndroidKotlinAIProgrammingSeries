
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

sealed class TransportMode {
    object Walking : TransportMode()
    object Cycling : TransportMode()
    object Driving : TransportMode()
    object Stationary : TransportMode()
    object Uncertain : TransportMode()
}

@Singleton
class MobilityManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val activityClient: ActivityRecognitionClient
) {
    private val _mode = MutableStateFlow<TransportMode>(TransportMode.Stationary)
    val mode = _mode.asStateFlow()

    // Hysteresis buffer to prevent jitter
    private var stabilityCounter = 0
    private var pendingMode: TransportMode? = null

    fun processActivityUpdate(detectedActivity: DetectedActivity) {
        val newMode = when (detectedActivity.type) {
            DetectedActivity.WALKING -> TransportMode.Walking
            DetectedActivity.CYCLING -> TransportMode.Cycling
            DetectedActivity.IN_VEHICLE -> TransportMode.Driving
            else -> TransportMode.Stationary
        }

        if (newMode == pendingMode) {
            stabilityCounter++
            if (stabilityCounter >= 3) { // Must be stable for 3 updates
                _mode.value = newMode
                stabilityCounter = 0
            }
        } else {
            pendingMode = newMode
            stabilityCounter = 1
        }
    }
}

class PersonaProvider {
    fun getSystemInstruction(mode: TransportMode): String = when (mode) {
        is TransportMode.Walking -> "You are a local tour guide. Be descriptive, suggest landmarks, and be leisurely."
        is TransportMode.Driving -> "You are a professional navigator. Be concise, prioritize safety, and use short sentences."
        is TransportMode.Cycling -> "You are a cycling assistant. Focus on bike lanes and high-impact safety cues."
        else -> "You are a helpful assistant. Wait for user input."
    }
}

// ViewModel implementing Dynamic Prompting
class NavigationViewModel @Inject constructor(
    private val mobilityManager: MobilityManager,
    private val personaProvider: PersonaProvider,
    private val generativeModel: GenerativeModel
) : ViewModel() {

    fun getNavigationResponse(userQuery: String) {
        viewModelScope.launch {
            val currentMode = mobilityManager.mode.value
            val systemPrompt = personaProvider.getSystemInstruction(currentMode)
            
            // Dynamic Prompt Engineering: The system prompt is swapped entirely
            val finalPrompt = "SYSTEM: $systemPrompt\nUSER: $userQuery"
            val response = generativeModel.generateContent(finalPrompt)
            // Update UI...
        }
    }
}
