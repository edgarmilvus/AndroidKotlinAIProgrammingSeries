
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.ArrayDeque

data class SensorSample(val x: Float, val y: Float, val z: Float, val timestamp: Long)

class WindowedBuffer(val capacity: Int = 200) {
    private val buffer = ArrayDeque<SensorSample>(capacity)

    fun add(sample: SensorSample) {
        if (buffer.size >= capacity) buffer.removeFirst()
        buffer.addLast(sample)
    }

    fun getSamples(): List<SensorSample> = buffer.toList()
}

class MotionAnalyzer {
    // Simple Low-Pass Filter to remove noise
    private var filteredZ = 0f
    private val alpha = 0.1f 

    fun analyze(samples: List<SensorSample>): String {
        if (samples.isEmpty()) return "No movement detected."
        
        var dips = 0
        var pivots = 0
        
        // Heuristic: Detect "Vertical Dip" (Z-axis peak and reversal)
        samples.windowed(3).forEach { window ->
            val z1 = window[0].z
            val z2 = window[1].z
            val z3 = window[2].z
            if (z2 > z1 && z2 > z3 && z2 > 12.0f) { // Threshold for "dip"
                dips++
            }
        }

        // Heuristic: Detect "Pivot" (X or Y axis rotation)
        if (samples.any { Math.abs(it.x) > 5.0f }) pivots++

        return "Last 2 seconds: $dips Vertical Dips, $pivots Pivots detected."
    }
}

class SensorStreamer @Inject constructor(
    private val sensorManager: SensorManager
) {
    private val buffer = WindowedBuffer()
    private val analyzer = MotionAnalyzer()
    
    private val _semanticStream = MutableSharedFlow<String>()
    val semanticStream = _semanticStream.asSharedFlow()

    fun startStreaming() {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    val sample = SensorSample(it.values[0], it.values[1], it.values[2], it.timestamp)
                    buffer.add(sample)
                }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sensorManager.registerListener(listener, 
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), 
            SensorManager.SENSOR_DELAY_FASTEST)

        // Processing loop on Default dispatcher to avoid blocking Main Thread
        CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                delay(2000) // Analyze every 2 seconds
                val summary = analyzer.analyze(buffer.getSamples())
                _semanticStream.emit(summary)
            }
        }
    }
}
