
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

@Singleton
class PrivacyGateway @Inject constructor(
    private val localModel: GeminiNanoClient, // AICore
    private val cloudModel: CloudLLMClient
) {
    private val piiRegex = Regex("""\d{3}-\d{3}-\d{4}|\d{1,5}\s\w+.*St|Apartment\s\d+""")

    suspend fun processRequest(rawSensorData: String, userQuery: String): String {
        // 1. Hard-coded PII Scrubbing (Regex)
        val scrubbedData = rawSensorData.replace(piiRegex, "[REDACTED]")

        // 2. Local Semantic Anonymization (Gemini Nano)
        val anonymizedContext = localModel.generateContent(
            "Summarize this environmental data for a cloud AI. " +
            "Remove specific addresses and names, but keep the intent and urgency. " +
            "Data: $scrubbedData"
        ).text ?: "Context unavailable"

        // 3. Hybrid Chain: Send anonymized context to Cloud
        val finalPrompt = "SYSTEM: $anonymizedContext\nUSER: $userQuery"
        return cloudModel.generateContent(finalPrompt).text ?: "Error"
    }
}

// Compose UI for Transparency
@Composable
fun PrivacyDashboard(original: String, anonymized: String) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Privacy Audit", style = MaterialTheme.typography.h6)
        
        Row {
            Box(modifier = Modifier.weight(1f).background(Color.Red.copy(alpha = 0.1f))) {
                Text("Local (Raw):\n$original", color = Color.Red)
            }
            Spacer(Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f).background(Color.Green.copy(alpha = 0.1f))) {
                Text("Cloud (Anonymized):\n$anonymized", color = Color.DarkGray)
            }
        }
    }
}
