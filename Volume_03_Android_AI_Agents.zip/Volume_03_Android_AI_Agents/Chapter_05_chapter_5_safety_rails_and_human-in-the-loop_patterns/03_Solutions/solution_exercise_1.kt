
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// 1. State Definitions
data class TransactionDetails(val amount: Double, val recipientId: String, val currency: String)

sealed class AgentState {
    object Idle : AgentState()
    data class AwaitingApproval(val details: TransactionDetails, val deferred: CompletableDeferred<Boolean>) : AgentState()
    object Executing : AgentState()
    data class Success(val message: String) : AgentState()
    data class Failed(val error: String) : AgentState()
}

// 2. The Tool Implementation
class TransferFundsTool {
    // This function simulates the tool call that the LLM triggers
    suspend fun execute(amount: Double, recipientId: String, currency: String, 
                       approvalProvider: suspend (TransactionDetails) -> Boolean): String {
        
        // Trigger the "Human-in-the-Loop" gate
        val isApproved = approvalProvider(TransactionDetails(amount, recipientId, currency))
        
        return if (isApproved) {
            "SUCCESS: Transferred $amount $currency to $recipientId"
        } else {
            "CANCELLED: User rejected the transaction."
        }
    }
}

// 3. ViewModel handling the "Handshake"
class FinanceViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState: StateFlow<AgentState> = _uiState.asStateFlow()

    private val tool = TransferFundsTool()

    fun processAgentRequest(amount: Double, recipientId: String, currency: String) {
        viewModelScope.launch {
            // Create a deferred value that will be completed by the UI
            val approvalDeferred = CompletableDeferred<Boolean>()
            
            // Update state to trigger the Compose Dialog
            _uiState.value = AgentState.AwaitingApproval(
                TransactionDetails(amount, recipientId, currency), 
                approvalDeferred
            )

            // The agent "suspends" here until approvalDeferred.complete() is called
            _uiState.value = AgentState.Executing
            val result = tool.execute(amount, recipientId, currency) { details ->
                approvalDeferred.await() 
            }
            
            _uiState.value = AgentState.Success(result)
        }
    }

    fun onUserDecision(approved: Boolean) {
        val currentState = _uiState.value
        if (currentState is AgentState.AwaitingApproval) {
            // Resolve the suspension point
            currentState.deferred.complete(approved)
        }
    }
}
