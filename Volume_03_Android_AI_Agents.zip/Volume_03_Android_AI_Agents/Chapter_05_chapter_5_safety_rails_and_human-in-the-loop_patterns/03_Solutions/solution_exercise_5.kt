
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import java.io.File

// 1. The Command Pattern
interface FileCommand {
    val description: String
    suspend fun execute(): Boolean
    suspend fun undo(): Boolean
}

class MoveFileCommand(
    private val source: File, 
    private val dest: File
) : FileCommand {
    override val description = "Moved ${source.name} to ${dest.parent}"

    override suspend fun execute(): Boolean = source.renameTo(dest)
    override suspend fun undo(): Boolean = dest.renameTo(source)
}

class DeleteFileCommand(
    private val target: File, 
    private val trashFolder: File
) : FileCommand {
    private var backupFile: File? = null
    override val description = "Deleted ${target.name}"

    override suspend fun execute(): Boolean {
        // Snapshot Mechanism: Move to trash instead of permanent delete
        backupFile = File(trashFolder, "${target.name}_${System.currentTimeMillis()}")
        return target.renameTo(backupFile!!)
    }

    override suspend fun undo(): Boolean {
        return backupFile?.renameTo(target) ?: false
    }
}

// 2. The Undo Stack Manager
class FileOperationManager(private val trashFolder: File) {
    private val undoStack = java.util.ArrayDeque<FileCommand>()

    suspend fun performAction(command: FileCommand) {
        if (command.execute()) {
            undoStack.push(command)
        }
    }

    suspend fun undoLastAction(): String {
        if (undoStack.isEmpty()) return "Nothing to undo"
        
        val command = undoStack.pop()
        return if (command.undo()) {
            "Successfully undid: ${command.description}"
        } else {
            "Failed to undo: ${command.description}"
        }
    }

    suspend fun undoBatch(count: Int) {
        repeat(count) { undoLastAction() }
    }
    
    fun getHistory(): List<String> = undoStack.map { it.description }
}

// 3. Integration with ViewModel
class FileOrganizerViewModel(private val opManager: FileOperationManager) : ViewModel() {
    private val _history = MutableStateFlow<List<String>>(emptyList())
    val history = _history.asStateFlow()

    fun onAgentMoveFile(src: String, dst: String) {
        viewModelScope.launch {
            opManager.performAction(MoveFileCommand(File(src), File(dst)))
            _history.value = opManager.getHistory()
        }
    }

    fun undo() {
        viewModelScope.launch {
            opManager.undoLastAction()
            _history.value = opManager.getHistory()
        }
    }
}
