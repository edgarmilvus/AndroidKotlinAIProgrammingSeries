
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import java.util.UUID

class PIISanitizer {
    // Registry to map Token -> Original Value
    private val tokenRegistry = mutableMapOf<String, String>()

    // Simple Regex patterns for PII
    private val piiPatterns = mapOf(
        "PHONE_NUMBER" to Regex("""\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"""),
        "SSN" to Regex("""\b\d{3}-\d{2}-\d{4}\b"""),
        "EMAIL" to Regex("""\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b""")
    )

    /**
     * Masks PII in the input string and stores mappings.
     */
    fun sanitize(input: String): String {
        var sanitizedText = input
        
        piiPatterns.forEach { (label, regex) ->
            regex.findAll(sanitizedText).forEach { match ->
                val originalValue = match.value
                val token = "[${label}_${UUID.randomUUID().toString().take(4)}]"
                
                tokenRegistry[token] = originalValue
                sanitizedText = sanitizedText.replace(originalValue, token)
            }
        }
        return sanitizedText
    }

    /**
     * Replaces tokens back with original values.
     */
    fun desanitize(input: String): String {
        var restoredText = input
        tokenRegistry.forEach { (token, originalValue) ->
            restoredText = restoredText.replace(token, originalValue)
        }
        return restoredText
    }
    
    fun clearRegistry() = tokenRegistry.clear()
}

// Usage in a Repository/Service
class HealthcareAgentRepository(private val sanitizer: PIISanitizer, private val llmClient: LlmClient) {
    suspend fun summarizePatientNotes(rawNotes: String): String {
        // 1. Masking (Client-Side)
        val safePrompt = sanitizer.sanitize(rawNotes)
        
        // 2. Transmission to untrusted cloud
        val aiResponse = llmClient.generateResponse(safePrompt)
        
        // 3. Unmasking (Local-Side)
        return sanitizer.desanitize(aiResponse)
    }
}

interface LlmClient { suspend fun generateResponse(prompt: String): String }
