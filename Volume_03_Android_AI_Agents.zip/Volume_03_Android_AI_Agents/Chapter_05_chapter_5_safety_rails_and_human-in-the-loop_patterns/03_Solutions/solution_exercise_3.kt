
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.*

// 1. Data Models
data class ProposedChange(
    val id: String,
    val parameter: String,
    val oldValue: String,
    var newValue: String,
    val reasoning: String,
    var isValid: Boolean = true,
    var errorMessage: String? = null
)

sealed class PipelineState {
    object Proposing : PipelineState()
    data class Reviewing(val changes: List<ProposedChange>) : PipelineState()
    object Validating : PipelineState()
    object Applying : PipelineState()
    data class Completed(val log: String) : PipelineState()
}

// 2. Validation Rail
class ConfigValidator {
    fun validate(change: ProposedChange): Pair<Boolean, String?> {
        return when (change.parameter) {
            "network_timeout" -> {
                val value = change.newValue.toIntOrNull()
                if (value == null || value < 0 || value > 300) 
                    false to "Timeout must be between 0 and 300s" else true to null
            }
            "camera_enabled" -> {
                if (change.newValue !in listOf("true", "false")) 
                    false to "Must be true or false" else true to null
            }
            else -> true to null
        }
    }
}

// 3. ViewModel with State Machine
class DeviceManagerViewModel(
    private val validator: ConfigValidator,
    private val auditLogger: AuditLogger // Assume Room implementation
) : ViewModel() {

    private val _state = MutableStateFlow<PipelineState>(PipelineState.Proposing)
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    fun onAgentProposedChanges(changes: List<ProposedChange>) {
        _state.value = PipelineState.Reviewing(changes)
    }

    fun updateChangeValue(id: String, newValue: String) {
        val currentState = _state.value
        if (currentState is PipelineState.Reviewing) {
            val updatedList = currentState.changes.map {
                if (it.id == id) it.copy(newValue = newValue) else it
            }
            _state.value = PipelineState.Reviewing(updatedList)
        }
    }

    fun executeChanges() {
        val currentState = _state.value
        if (currentState !is PipelineState.Reviewing) return

        viewModelScope.launch {
            _state.value = PipelineState.Validating
            
            // Validation Rail
            val allValid = currentState.changes.map { change ->
                val (isValid, error) = validator.validate(change)
                change.isValid = isValid
                change.errorMessage = error
                isValid
            }.all { it }

            if (!allValid) {
                _state.value = PipelineState.Reviewing(currentState.changes)
                return@launch
            }

            _state.value = PipelineState.Applying
            try {
                // Atomic Execution Simulation
                applySettingsAtomics(currentState.changes)
                auditLogger.log("Executed ${currentState.changes.size} changes")
                _state.value = PipelineState.Completed("Settings updated successfully")
            } catch (e: Exception) {
                _state.value = PipelineState.Reviewing(currentState.changes)
                // Handle rollback logic here
            }
        }
    }
    
    private suspend fun applySettingsAtomics(changes: List<ProposedChange>) { /* Android API calls */ }
}

interface AuditLogger { suspend fun log(message: String) }
