
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*

// 1. Strict Schema Definition
@Serializable
data class DeviceState(
    val power: String,
    val brightness: Int,
    val color: String
)

class RecoveryAgentExecutor(private val llmClient: LlmClient) {
    private val MAX_RETRIES = 3

    suspend fun executeDeviceTool(deviceId: String, userPrompt: String): DeviceState? {
        var attempts = 0
        var currentPrompt = "Set state for $deviceId based on: $userPrompt. Return ONLY JSON."
        var lastError: String? = null

        while (attempts < MAX_RETRIES) {
            val rawResponse = llmClient.generateResponse(currentPrompt)
            
            try {
                // Hard Constraint: Attempt to parse the JSON
                return Json.decodeFromString<DeviceState>(cleanJson(rawResponse))
            } catch (e: SerializationException) {
                attempts++
                lastError = e.message
                
                // Feedback Loop: Construct a System Correction Prompt
                currentPrompt = """
                    Your previous response was invalid JSON.
                    Error: $lastError
                    Malformed String: $rawResponse
                    Please correct the JSON and return ONLY the valid object.
                """.trimIndent()
                
                println("Recovery Attempt $attempts: Fixing JSON drift...")
            }
        }

        // Circuit Breaker: Max retries reached
        throw RecoveryFailedException("LLM failed to produce valid JSON after $MAX_RETRIES attempts. Last error: $lastError")
    }

    private fun cleanJson(input: String): String {
        // Remove markdown code blocks if present
        return input.replace("