
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*

// 1. Define the Tool Schema
@Serializable
sealed class AgentAction {
    @Serializable @SerialName("send_message")
    data class SendMessage(val recipient: String, val content: String) : AgentAction()
    
    @Serializable @SerialName("delete_file")
    data class DeleteFile(val path: String) : AgentAction()
    
    @Serializable @SerialName("final_answer")
    data class FinalAnswer(val text: String) : AgentAction()
}

// 2. The Safety Rail Interface
interface SafetyRail {
    suspend fun validate(action: AgentAction): RailResult
}

sealed class RailResult {
    object Allowed : RailResult()
    data class Blocked(val reason: String) : RailResult()
    data class RequiresApproval(val message: String) : RailResult()
}

// 3. Concrete Rail Implementations
class PiiSafetyRail : SafetyRail {
    override suspend fun validate(action: AgentAction): RailResult {
        return if (action is AgentAction.SendMessage && action.content.contains(Regex("\\d{4}-\\d{4}-\\d{4}-\\d{4}"))) {
            RailResult.Blocked("Credit card numbers cannot be sent via AI agent.")
        } else {
            RailResult.Allowed
        }
    }
}

class SystemPermissionRail : SafetyRail {
    override suspend fun validate(action: AgentAction): RailResult {
        return if (action is AgentAction.DeleteFile && action.path.contains("/system/")) {
            RailResult.Blocked("Agent cannot modify system files.")
        } else {
            RailResult.Allowed
        }
    }
}

// 4. The Agent Orchestrator
class SafeAgentOrchestrator(
    private val rails: List<SafetyRail>,
    private val scope: CoroutineScope
) {
    private val _agentState = MutableStateFlow<AgentState>(AgentState.Idle)
    val agentState: StateFlow<AgentState> = _agentState

    suspend fun processAction(action: AgentAction) {
        // Execute all safety rails in parallel for efficiency
        val results = rails.map { rail -> 
            scope.async { rail.validate(action) } 
        }.awaitAll()

        val failure = results.find { it is RailResult.Blocked } as? RailResult.Blocked
        if (failure != null) {
            _agentState.value = AgentState.Error(failure.reason)
            return
        }

        val approvalNeeded = results.find { it is RailResult.RequiresApproval } as? RailResult.RequiresApproval
        if (approvalNeeded != null) {
            _agentState.value = AgentState.AwaitingApproval(action, approvalNeeded.message)
            return
        }

        // If all rails pass, execute the action
        executeAction(action)
    }

    private suspend fun executeAction(action: AgentAction) {
        _agentState.value = AgentState.Executing
        // Actual tool execution logic here
        delay(1000) // Simulate work
        _agentState.value = AgentState.Idle
    }
}

sealed class AgentState {
    object Idle : AgentState()
    object Executing : AgentState()
    data class AwaitingApproval(val action: AgentAction, val message: String) : AgentState()
    data class Error(val message: String) : AgentState()
}
