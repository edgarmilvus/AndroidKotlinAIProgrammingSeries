
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.safety

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the state of the AI Agent's action lifecycle.
 * MVI Pattern: State is immutable and driven by the ViewModel.
 */
sealed class AgentState {
    object Idle : AgentState()
    data class Thinking(val prompt: String) : AgentState()
    data class AwaitingApproval(val proposal: ToolProposal) : AgentState()
    data class Executing(val proposal: ToolProposal) : AgentState()
    data class Success(val result: String) : AgentState()
    data class Error(val message: String) : AgentState()
}

/**
 * Data model for a Tool Call proposal.
 * This is what the LLM generates via Function Injection.
 */
data class ToolProposal(
    val toolName: String,
    val arguments: Map<String, Any>,
    val riskScore: Float = 0.0f, // Populated by NPU Safety Rail
    val requiresHITL: Boolean = false
)

/**
 * The Safety Rail Repository: Orchestrates NPU validation and deterministic rules.
 */
@Singleton
class SafetyRailRepository @Inject constructor(
    private val npuValidator: NpuIntentValidator, 
    private val accountService: AccountService
) {
    // Deterministic threshold for HITL
    private val HIGH_RISK_THRESHOLD = 500.0

    suspend fun evaluateProposal(proposal: ToolProposal): ToolProposal = withContext(Dispatchers.Default) {
        Log.d("SafetyRail", "Evaluating tool: ${proposal.toolName}")

        // 1. Probabilistic Guard: Use NPU to check for "Malicious Intent" or "Prompt Injection"
        // This runs on the NPU via TFLite for low latency and privacy.
        val aiRiskScore = npuValidator.analyzeIntent(proposal.toolName, proposal.arguments)
        
        // 2. Deterministic Guard: Check business logic rules
        var needsHITL = aiRiskScore > 0.7f // High AI risk triggers HITL
        
        if (proposal.toolName == "transferFunds") {
            val amount = proposal.arguments["amount"] as? Double ?: 0.0
            val recipient = proposal.arguments["recipient"] as? String ?: ""
            
            // Rule: Any transfer over $500 or to an unknown recipient requires human approval
            if (amount > HIGH_RISK_THRESHOLD || !accountService.isTrustedContact(recipient)) {
                needsHITL = true
                Log.w("SafetyRail", "Deterministic Guard triggered: High value or unknown recipient")
            }
        }

        proposal.copy(riskScore = aiRiskScore, requiresHITL = needsHITL)
    }

    suspend fun executeTool(proposal: ToolProposal): String = withContext(Dispatchers.IO) {
        // Final execution of the tool call
        when (proposal.toolName) {
            "transferFunds" -> accountService.performTransfer(
                proposal.arguments["recipient"] as String, 
                proposal.arguments["amount"] as Double
            )
            "checkBalance" -> accountService.getBalance()
            else -> throw IllegalArgumentException("Unknown tool")
        }
    }
}

/**
 * NPU-Accelerated Validator.
 * In a real app, this would wrap a TFLite model or Gemini Nano.
 */
class NpuIntentValidator @Inject constructor() {
    suspend fun analyzeIntent(tool: String, args: Map<String, Any>): Float = withContext(Dispatchers.Default) {
        // Simulate NPU inference latency
        delay(150) 
        // In production: tfliteInterpreter.run(inputTensor, outputTensor)
        // Returns a score between 0.0 (Safe) and 1.0 (Dangerous)
        return@withContext (0..100).random() / 100f 
    }
}

/**
 * ViewModel implementing the HITL State Machine.
 */
@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: SafetyRailRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState: StateFlow<AgentState> = _uiState.asStateFlow()

    /**
     * Entry point: The AI Agent proposes an action.
     */
    fun onAgentProposeAction(proposal: ToolProposal) {
        viewModelScope.launch {
            _uiState.value = AgentState.Thinking("Evaluating safety rails...")
            
            // Process proposal through the safety rail
            val validatedProposal = repository.evaluateProposal(proposal)
            
            if (validatedProposal.requiresHITL) {
                // Transition to HITL state: The UI will now show a confirmation dialog
                _uiState.value = AgentState.AwaitingApproval(validatedProposal)
            } else {
                // Low risk: Execute immediately
                executeAction(validatedProposal)
            }
        }
    }

    /**
     * Called by the UI when the user clicks "Confirm" in the HITL dialog.
     */
    fun onUserApproval(proposal: ToolProposal) {
        viewModelScope.launch {
            executeAction(proposal)
        }
    }

    /**
     * Called by the UI when the user clicks "Cancel" or "Modify".
     */
    fun onUserRejection() {
        _uiState.value = AgentState.Error("Action cancelled by user.")
    }

    private suspend fun executeAction(proposal: ToolProposal) {
        _uiState.value = AgentState.Executing(proposal)
        try {
            val result = repository.executeTool(proposal)
            _uiState.value = AgentState.Success(result)
        } catch (e: Exception) {
            _uiState.value = AgentState.Error(e.localizedMessage ?: "Execution failed")
        }
    }
}

// Mock Service for demonstration
@Singleton
class AccountService @Inject constructor() {
    fun isTrustedContact(name: String): Boolean = name == "Mom" || name == "Partner"
    suspend fun getBalance(): String = "$1,250.00"
    suspend fun performTransfer(to: String, amount: Double): String {
        delay(1000) // Simulate network
        return "Successfully transferred $$amount to $to"
    }
}
