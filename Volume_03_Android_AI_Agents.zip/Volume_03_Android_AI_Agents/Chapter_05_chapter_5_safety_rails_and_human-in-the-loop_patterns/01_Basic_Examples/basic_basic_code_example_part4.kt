
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.ai.agent.safety

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState: StateFlow<AgentState> = _uiState.asStateFlow()

    /**
     * Step 1: User sends a prompt.
     * The AI processes it and either returns a response or proposes a tool.
     */
    fun handleUserPrompt(prompt: String) {
        viewModelScope.launch {
            _uiState.update { AgentState.Thinking }
            
            val result = repository.processPrompt(prompt)
            
            result.fold(
                onSuccess = { response ->
                    when (response) {
                        is ToolCall -> {
                            // SAFETY RAIL: Instead of executing, we move to AwaitingApproval
                            _uiState.update { AgentState.AwaitingApproval(response) }
                        }
                        is String -> {
                            _uiState.update { AgentState.Success(response) }
                        }
                    }
                },
                onFailure = { error ->
                    _uiState.update { AgentState.Error(error.message ?: "Unknown Error") }
                }
            )
        }
    }

    /**
     * Step 2: Human-in-the-Loop Approval.
     * This is only called when the user clicks "Confirm" in the UI.
     */
    fun approveAction() {
        val currentState = _uiState.value
        if (currentState is AgentState.AwaitingApproval) {
            val toolToExecute = currentState.toolCall
            
            viewModelScope.launch {
                _uiState.update { AgentState.Executing(toolToExecute) }
                
                val result = repository.executeTool(toolToExecute)
                
                result.fold(
                    onSuccess = { msg -> _uiState.update { AgentState.Success(msg) } },
                    onFailure = { err -> _uiState.update { AgentState.Error(err.message ?: "Execution failed") } }
                )
            }
        }
    }

    /**
     * Step 3: Human-in-the-Loop Rejection.
     */
    fun rejectAction() {
        _uiState.update { AgentState.Success("Action cancelled by user.") }
    }

    fun reset() {
        _uiState.update { AgentState.Idle }
    }
}
