
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

package com.ai.agent.safety

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun AgentSafetyScreen(viewModel: AgentViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var inputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "AI Agent with Safety Rails", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(20.dp))

        // Input Area
        TextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Ask the agent to send money...") },
            modifier = Modifier.fillMaxWidth(),
            enabled = state !is AgentState.Thinking && state !is AgentState.Executing
        )

        Button(
            onClick = { 
                viewModel.handleUserPrompt(inputText) 
                inputText = ""
            },
            modifier = Modifier.padding(top = 10.dp),
            enabled = state !is AgentState.Thinking && state !is AgentState.Executing
        ) {
            Text("Send Request")
        }

        Spacer(modifier = Modifier.height(30.dp))

        // State-based UI Feedback
        when (state) {
            is AgentState.Thinking -> CircularProgressIndicator()
            is AgentState.Executing -> Text("Executing secure transaction...", color = MaterialTheme.colorScheme.primary)
            is AgentState.Success -> Text("Result: ${(state as AgentState.Success).message}")
            is AgentState.Error -> Text("Error: ${(state as AgentState.Error).message}", color = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }

    // HUMAN-IN-THE-LOOP DIALOG
    if (state is AgentState.AwaitingApproval) {
        val toolCall = (state as AgentState.AwaitingApproval).toolCall
        ApprovalDialog(
            toolName = toolCall.toolName,
            args = toolCall.arguments,
            onConfirm = { viewModel.approveAction() },
            onDismiss = { viewModel.rejectAction() }
        )
    }
}

@Composable
fun ApprovalDialog(
    toolName: String,
    args: Map<String, Any>,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Safety Rail: Approval Required") },
        text = {
            Column {
                Text("The AI agent wants to perform the following action:")
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tool: $toolName", style = MaterialTheme.typography.labelLarge)
                args.forEach { (key, value) ->
                    Text("$key: $value")
                }
            }
        },
        confirmButton = {
            Button(onClick = onConfirm) { Text("Approve") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
