
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class HomeAutomationViewModel(
    private val agentRepository: AiAgentRepository 
) : ViewModel() {

    private val _status = MutableStateFlow("Monitoring...")
    val status = _status.asStateFlow()

    private var lastTriggerTime = 0L
    private val COOLDOWN_MS = 10_000L // 10 seconds

    // 1. The Sampling Loop using Flow
    fun startMonitoring(imageFlow: Flow<android.graphics.Bitmap>) {
        viewModelScope.launch {
            imageFlow
                .sample(2000) // Only process one frame every 2 seconds
                .collect { bitmap ->
                    processFrame(bitmap)
                }
        }
    }

    private suspend fun processFrame(bitmap: android.graphics.Bitmap) {
        val currentTime = System.currentTimeMillis()
        
        // 2. Cooldown Logic
        if (currentTime - lastTriggerTime < COOLDOWN_MS) return

        _status.value = "Analyzing..."
        
        // 3. Function Calling via Repository
        val result = agentRepository.detectAndAct(bitmap)
        
        result.onSuccess { action ->
            if (action is AutomationAction.Triggered) {
                lastTriggerTime = currentTime
                _status.value = "Detected: ${action.objectName} -> Executing!"
            } else {
                _status.value = "Monitoring..."
            }
        }.onFailure {
            _status.value = "Error detecting trigger"
        }
    }
}

sealed class AutomationAction {
    data class Triggered(val objectName: String) : AutomationAction()
    object NoAction : AutomationAction()
}
