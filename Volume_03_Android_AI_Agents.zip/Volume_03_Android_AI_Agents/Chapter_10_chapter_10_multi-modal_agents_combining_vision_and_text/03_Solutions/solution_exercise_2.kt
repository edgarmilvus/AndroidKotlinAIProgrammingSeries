
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Serializable
data class ReceiptData(
    val vendor: String?,
    val date: String?,
    val total: Double?,
    val category: String?,
    val confidenceScore: Double? // Requested in challenge
)

class ReceiptAuditor(private val generativeModel: GenerativeModel) {

    private val jsonParser = Json { 
        ignoreUnknownKeys = true 
        coerceInputValues = true 
    }

    suspend fun extractReceiptData(bitmap: android.graphics.Bitmap): Result<ReceiptData> = 
        withContext(Dispatchers.IO) {
            try {
                val prompt = """
                    Extract receipt details into JSON format. 
                    Schema: {"vendor": string, "date": string, "total": double, "category": string, "confidenceScore": double}
                    Categories: [Travel, Meals, Office Supplies, Entertainment, Other].
                    If a field is missing, use null.
                """.trimIndent()

                val response = generativeModel.generateContent(
                    com.google.ai.client.generativeai.type.content {
                        image(bitmap)
                        text(prompt)
                    },
                    // Enforce JSON mode via configuration if supported, 
                    // or via strict prompting as shown.
                    generationConfig = generationConfig {
                        responseMimeType = "application/json"
                    }
                )

                val jsonString = response.text ?: throw Exception("Empty response")
                val data = jsonParser.decodeFromString<ReceiptData>(jsonString)
                
                Result.success(data)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
