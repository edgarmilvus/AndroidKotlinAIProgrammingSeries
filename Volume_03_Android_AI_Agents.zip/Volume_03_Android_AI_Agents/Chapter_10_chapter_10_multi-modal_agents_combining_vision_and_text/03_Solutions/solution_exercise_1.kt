
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageProxy
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

// Data class to represent the chat state
data class ChatMessage(val text: String, val isUser: Boolean)

class AccessibilityViewModel(
    private val generativeModel: GenerativeModel,
    private val tts: TextToSpeech
) : ViewModel() {

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory = _chatHistory.asStateFlow()

    private var chatSession = generativeModel.startChat()

    // 1. Capture and Analyze: The initial visual context
    fun analyzeScene(bitmap: android.graphics.Bitmap) {
        viewModelScope.launch {
            val prompt = "You are an accessibility assistant. Describe the scene focusing on obstacles and text. " +
                         "Use clock-face directions (e.g., 'at 2 o'clock') to describe object locations."
            
            val response = chatSession.sendMessage(
                content {
                    image(bitmap)
                    text(prompt)
                }
            )
            
            val responseText = response.text ?: "I couldn't see anything clearly."
            updateChat(responseText, false)
            speak(responseText)
        }
    }

    // 2. Follow-up: Text-only interaction leveraging session memory
    fun askQuestion(question: String) {
        viewModelScope.launch {
            updateChat(question, true)
            val response = chatSession.sendMessage(question)
            val responseText = response.text ?: "I'm not sure about that."
            updateChat(responseText, false)
            speak(responseText)
        }
    }

    private fun updateChat(text: String, isUser: Boolean) {
        _chatHistory.value += ChatMessage(text, isUser)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TTS_ID")
    }
}

/**
 * Utility to resize Bitmap for VLM efficiency
 */
fun android.graphics.Bitmap.resizeForVLM(maxWidth: Int = 1024): android.graphics.Bitmap {
    val aspectRatio = height.toFloat() / width.toFloat()
    val targetHeight = (maxWidth * aspectRatio).toInt()
    return android.graphics.Bitmap.createScaledBitmap(this, maxWidth, targetHeight, true)
}
