
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.vision

import android.content.Context
import android.graphics.Bitmap
import androidx.camera.core.ImageProxy
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the immutable state of our Multi-Modal Agent.
 */
sealed interface AgentViewState {
    object Idle : AgentViewState
    object Processing : AgentViewState
    data class Success(val response: String, val detectedObjects: List<String>) : AgentViewState
    data class Error(val message: String) : AgentViewState
}

/**
 * Data class representing the semantic distilled version of a visual frame.
 */
data class VisualContext(
    val bitmap: Bitmap,
    val detectedLabels: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * The Repository acts as the "Orchestrator". It manages the fusion of 
 * high-frequency vision data and low-frequency user text prompts.
 */
@Singleton
class AgentRepository @Inject constructor(
    private val context: Context,
    private val generativeModel: GenerativeModel // Injected Gemini Model
) {
    // A StateFlow that holds the "Latest Perceived Reality"
    private val _currentVisualContext = MutableStateFlow<VisualContext?>(null)
    val currentVisualContext: StateFlow<VisualContext?> = _currentVisualContext.asStateFlow()

    // A dedicated dispatcher for heavy AI computations to avoid blocking the UI or IO
    private val aiDispatcher = Dispatchers.Default.limitedParallelism(2)

    /**
     * Updates the internal perception of the world. 
     * This is called by the Camera Analyzer.
     */
    suspend fun updatePerception(context: VisualContext) {
        withContext(aiDispatcher) {
            _currentVisualContext.emit(context)
        }
    }

    /**
     * The core Multi-Modal reasoning function.
     * It takes a text prompt and fuses it with the latest visual context.
     */
    suspend fun performReasoning(userPrompt: String): Result<Pair<String, List<String>>> = 
        withContext(aiDispatcher) {
            try {
                val visualContext = _currentVisualContext.value 
                    ?: return@withContext Result.failure(Exception("No visual context available"))

                // Constructing the Multi-Modal Prompt (Late Fusion)
                val multimodalContent = content {
                    image(visualContext.bitmap)
                    text("Contextual Labels: ${visualContext.detectedLabels.joinToString()}. " +
                         "User Question: $userPrompt")
                }

                // Execute the LLM reasoning
                val response = generativeModel.generateContent(multimodalContent)
                val textResponse = response.text ?: "I saw something, but I couldn't describe it."

                Result.success(Pair(textResponse, visualContext.detectedLabels))
            } catch (e: Exception {
                Timber.e(e, "Multi-modal reasoning failed")
                Result.failure(e)
            }
        }
}

/**
 * The ViewModel manages the MVI state machine.
 */
@HiltViewModel
class MultiModalViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentViewState>(AgentViewState.Idle)
    val uiState: StateFlow<AgentViewState> = _uiState.asStateFlow()

    // Expose the visual context for the UI (e.g., to draw bounding boxes)
    val visualContext = repository.currentVisualContext

    fun askAgent(query: String) {
        viewModelScope.launch {
            _uiState.value = AgentViewState.Processing
            
            repository.performReasoning(query)
                .onSuccess { (response, labels) ->
                    _uiState.value = AgentViewState.Success(response, labels)
                }
                .onFailure { error ->
                    _uiState.value = AgentViewState.Error(error.message ?: "Unknown Error")
                }
        }
    }
}

/**
 * The Hardware-Aware Analyzer.
 * This component bridges the CameraX hardware stream to the AI Repository.
 */
class VisionAnalyzer @Inject constructor(
    private val repository: AgentRepository,
    private val scope: CoroutineScope
) : androidx.camera.core.ImageAnalysis.Analyzer {

    // In a real production app, this would be a MediaPipe Object Detector
    // initialized with a GPU/NPU delegate.
    private var isProcessing = false

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        // Prevent frame buildup (Structured Concurrency / Backpressure)
        if (isProcessing) {
            imageProxy.close()
            return
        }

        isProcessing = true

        scope.launch(Dispatchers.Default) {
            try {
                val bitmap = imageProxy.toBitmap() // Extension function to convert ImageProxy to Bitmap
                
                // 1. Perform On-Device Vision Task (e.g., Object Detection via NPU)
                // This simulates the heavy lifting of a local TFLite model.
                val detectedLabels = simulateLocalObjectDetection(bitmap)

                // 2. Update the Repository with the new "Perception"
                repository.updatePerception(
                    VisualContext(
                        bitmap = bitmap,
                        detectedLabels = detectedLabels
                    )
                )
            } catch (e: Exception) {
                Timber.e(e, "Vision analysis failed")
            } finally {
                isProcessing = false
                imageProxy.close()
            }
        }
    }

    private suspend fun simulateLocalObjectDetection(bitmap: Bitmap): List<String> {
        // Simulate NPU latency
        delay(50) 
        return listOf("Apple", "Table", "Knife") // Mocked labels
    }
}

/**
 * Extension to convert ImageProxy to Bitmap efficiently.
 */
fun ImageProxy.toBitmap(): Bitmap {
    val buffer = planes[0].buffer
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    // Note: In production, use YUV_420_888 to RGB conversion logic 
    // or use the ImageProxy.toBitmap() available in newer CameraX versions.
    return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
}
