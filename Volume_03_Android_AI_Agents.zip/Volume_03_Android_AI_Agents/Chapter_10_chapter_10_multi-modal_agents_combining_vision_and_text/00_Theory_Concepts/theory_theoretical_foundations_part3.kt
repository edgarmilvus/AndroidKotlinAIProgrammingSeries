
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

// Note: Context Receivers is a progressive feature in Kotlin 2.x
// It allows us to define functions that require a specific context to be present.

interface AICoreProvider {
    suspend fun runInference(input: MultimodalInput): AgentResponse
}

class MultimodalAgentProcessor(
    private val aicore: AICoreProvider
) {
    /**
     * Processes a stream of visual frames and text prompts.
     * Uses Flow to handle the asynchronous nature of video/image streams.
     */
    @OptIn(ExperimentalStdlibApi::class)
    fun observeAndReact(
        visualStream: Flow<String>, // Stream of Image URIs
        textPrompt: String
    ): Flow<AgentResponse> = flow {
        visualStream.collect { imageUri ->
            // We combine the latest visual data with the text prompt
            val input = MultimodalInput.VisionText(
                prompt = textPrompt,
                imageUri = imageUri
            )
            
            // Perform inference in a background dispatcher to avoid blocking
            val response = withContext(Dispatchers.Default) {
                aicore.runInference(input)
            }
            
            emit(response)
        }
    }.flowOn(Dispatchers.Default) 
}
