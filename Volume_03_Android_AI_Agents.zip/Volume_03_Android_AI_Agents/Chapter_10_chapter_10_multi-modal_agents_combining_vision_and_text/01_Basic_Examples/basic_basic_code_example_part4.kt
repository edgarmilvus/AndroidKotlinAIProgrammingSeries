
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

package com.example.multimodalagent.ui

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.multimodalagent.data.VisionAiRepository
import com.example.multimodalagent.ui.state.VisionAiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VisionAiViewModel @Inject constructor(
    private val repository: VisionAiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VisionAiState())
    val uiState: StateFlow<VisionAiState> = _uiState.asStateFlow()

    fun onPromptChanged(newPrompt: String) {
        _uiState.update { it.copy(userPrompt = newPrompt) }
    }

    fun onImageCaptured(bitmap: Bitmap) {
        _uiState.update { it.copy(capturedImage = bitmap) }
    }

    /**
     * Triggers the multi-modal reasoning process.
     */
    fun runInference() {
        val currentState = _uiState.value
        val image = currentState.capturedImage
        val prompt = currentState.userPrompt

        if (image == null || prompt.isBlank()) {
            _uiState.update { it.copy(error = "Please provide both an image and a prompt.") }
            return
        }

        viewModelScope.launch {
            // 1. Set loading state to update UI (show progress bar)
            _uiState.update { it.copy(isLoading = true, error = null, agentResponse = null) }

            try {
                // 2. Execute the repository call (runs on Dispatchers.IO)
                val result = repository.analyzeImageAndText(image, prompt)

                // 3. Update state with the successful response
                _uiState.update { it.copy(agentResponse = result, isLoading = false) }
            } catch (e: Exception) {
                // 4. Handle errors (Network issues, API limits, etc.)
                _uiState.update { 
                    it.copy(isLoading = false, error = e.localizedMessage ?: "Unknown Error") 
                }
            }
        }
    }
}
