
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

package com.example.multimodalagent.data

import android.graphics.Bitmap
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository responsible for interacting with the Multi-Modal LLM.
 */
@Singleton
class VisionAiRepository @Inject constructor(
    private val generativeModel: GenerativeModel
) {
    /**
     * Performs multi-modal inference.
     * 
     * @param image The bitmap captured from the camera.
     * @param prompt The user's natural language question.
     * @return The text response from the model.
     * @throws Exception if the network or model fails.
     */
    suspend fun analyzeImageAndText(image: Bitmap, prompt: String): String = withContext(Dispatchers.IO) {
        // The 'content' block is the key to multi-modality. 
        // It allows us to interleave text tokens and visual data.
        val inputContent = content {
            image(image)
            text(prompt)
        }

        // generateContent is a suspend function that performs the network request
        val response = generativeModel.generateContent(inputContent)
        
        // Return the text part of the response, or a fallback error message
        response.text ?: "The model returned an empty response."
    }
}
