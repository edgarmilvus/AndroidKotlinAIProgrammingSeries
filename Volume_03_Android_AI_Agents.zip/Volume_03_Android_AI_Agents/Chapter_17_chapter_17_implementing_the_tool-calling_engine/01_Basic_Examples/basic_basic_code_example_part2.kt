
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DOMAIN MODELS ---

/**
 * Represents the structured request emitted by an LLM.
 * In a real scenario, this JSON is parsed from the LLM's text stream.
 */
@Serializable
data class ToolCallRequest(
    val functionName: String,
    val arguments: Map<String, String>
)

/**
 * The state of our Agent UI.
 */
data class AgentUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isProcessing: Boolean = false
)

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val isToolResult: Boolean = false
)

// --- 2. TOOL DEFINITIONS & REGISTRY ---

/**
 * A functional interface for any tool the agent can use.
 */
interface Tool {
    val name: String
    suspend fun execute(args: Map<String, String>): String
}

/**
 * Concrete implementation of a Smart Home Tool.
 */
class LightControlTool @Inject constructor() : Tool {
    override val name: String = "toggle_light"

    override suspend fun execute(args: Map<String, String>): String {
        // Simulate a hardware delay (e.g., communicating with a Zigbee/Matter device)
        kotlinx.coroutines.delay(1000)
        val deviceId = args["deviceId"] ?: "unknown"
        val status = args["status"] ?: "off"
        
        // In a real app, this would call a Repository or a Bluetooth/Matter service
        return "SUCCESS: Light $deviceId is now $status."
    }
}

/**
 * The Registry holds all available tools and manages their lookup.
 */
@Singleton
class ToolRegistry @Inject constructor(
    private val lightControlTool: LightControlTool
) {
    private val tools = mapOf(
        lightControlTool.name to lightControlTool
    )

    fun getTool(name: String): Tool? = tools[name]
}

// --- 3. THE TOOL-CALLING ENGINE ---

/**
 * The Engine orchestrates the logic between the LLM's request and the ToolRegistry.
 */
class ToolCallingEngine @Inject constructor(
    private val registry: ToolRegistry
) {
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Processes a raw string (simulating LLM output) and executes the tool if needed.
     * We use Dispatchers.Default because parsing and registry lookup are CPU-bound.
     */
    suspend fun processToolCall(rawJson: String): String = withContext(Dispatchers.Default) {
        try {
            val request = json.decodeFromString<ToolCallRequest>(rawJson)
            val tool = registry.getTool(request.functionName) 
                ?: return@withContext "Error: Tool '${request.functionName}' not found."

            // Execute the tool. Note: The tool itself is responsible for its own 
            // internal threading/delay, but we run it here on Dispatchers.Default.
            tool.execute(request.arguments)
        } catch (e: Exception) {
            "Error processing tool call: ${e.localizedMessage}"
        }
    }
}

// --- 4. VIEWMODEL (THE ORCHESTRATOR) ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val engine: ToolCallingEngine
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgentUiState())
    val uiState = _uiState.asStateFlow()

    fun sendMessage(userInput: String) {
        viewModelScope.launch {
            // 1. Add User Message
            updateMessages(ChatMessage(userInput, isUser = true))
            _uiState.value = _uiState.value.copy(isProcessing = true)

            // 2. Simulate LLM Inference
            // In a real app, you'd call your Gemini/OpenAI/Local Llama API here.
            val llmResponse = simulateLlmInference(userInput)

            // 3. Check if the LLM wants to call a tool
            if (llmResponse.contains("TOOL_CALL:")) {
                val jsonPayload = llmResponse.substringAfter("TOOL_CALL:").trim()
                
                // Add the "thought" to the UI
                updateMessages(ChatMessage("Thinking: I need to use a tool...", isUser = false))

                // 4. Execute Tool via Engine
                val toolResult = engine.processToolCall(jsonPayload)
                
                // 5. Show Tool Result in UI
                updateMessages(ChatMessage(toolResult, isUser = false, isToolResult = true))

                // 6. Final LLM Pass (Simulated)
                // In real life, you send the toolResult back to the LLM to get a natural response.
                val finalResponse = "I've completed that for you. $toolResult"
                updateMessages(ChatMessage(finalResponse, isUser = false))
            } else {
                updateMessages(ChatMessage(llmResponse, isUser = false))
            }

            _uiState.value = _uiState.value.copy(isProcessing = false)
        }
    }

    private fun updateMessages(message: ChatMessage) {
        val currentList = _uiState.value.messages.toMutableList()
        currentList.add(message)
        _uiState.value = _uiState.value.copy(messages = currentList)
    }

    /**
     * Mocking the LLM behavior.
     * If user says "turn on the light", LLM returns a JSON string.
     */
    private suspend fun simulateLlmInference(input: String): String {
        kotlinx.coroutines.delay(1500) // Simulate network latency
        return when {
            input.contains("light", ignoreCase = true) -> {
                // This is the "Magic" string the LLM would produce
                """TOOL_CALL: {"functionName": "toggle_light", "arguments": {"deviceId": "living_room_01", "status": "on"}}"""
            }
            else -> "I am your AI assistant. How can I help you today?"
        }
    }
}

// --- 5. UI LAYER (JETPACK COMPOSE) ---

@Composable
fun AgentScreen(viewModel: AgentViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Chat History
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(uiState.messages) { message ->
                ChatBubble(message)
            }
        }

        if (uiState.isProcessing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }

        // Input Area
        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask the agent...") }
            )
            Button(
                onClick = {
                    viewModel.sendMessage(inputText)
                    inputText = ""
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Send")
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val alignment = if (message.isUser) androidx.compose.ui.Alignment.End else androidx.compose.ui.Alignment.Start
    val color = when {
        message.isToolResult -> MaterialTheme.colorScheme.tertiary
        message.isUser -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = alignment) {
        Surface(
            color = color,
            shape = MaterialTheme.shapes.medium
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(12.dp),
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}

// --- 6. APP ENTRY POINT & HILT SETUP ---

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    // Hilt handles the injection of LightControlTool and ToolRegistry automatically
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    // In a real app, use hiltViewModel()
                    val viewModel: AgentViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
                    AgentScreen(viewModel)
                }
            }
        }
    }
}
