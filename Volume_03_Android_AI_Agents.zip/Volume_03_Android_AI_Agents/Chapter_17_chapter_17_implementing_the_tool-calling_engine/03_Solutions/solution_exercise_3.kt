
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

sealed class AgentState {
    object Idle : AgentState()
    data class Thinking(val thought: String) : AgentState()
    data class Executing(val toolName: String) : AgentState()
    data class Error(val message: String) : AgentState()
    data class Success(val finalAnswer: String) : AgentState()
}

// Mock LLM Client for demonstration
interface LLMClient {
    suspend fun chat(history: List<String>): LLMResponse
}

sealed class LLMResponse {
    data class ToolCall(val toolName: String, val args: Map<String, Any?>) : LLMResponse()
    data class FinalAnswer(val answer: String) : LLMResponse()
}

class AgentOrchestrator(
    private val llmClient: LLMClient,
    private val registry: ToolRegistry,
    private val maxIterations: Int = 5
) {
    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    val state: StateFlow<AgentState> = _state.asStateFlow()

    private val conversationHistory = mutableListOf<String>()

    suspend fun runAgent(userPrompt: String) {
        conversationHistory.clear()
        conversationHistory.add("User: $userPrompt")
        _state.value = AgentState.Thinking("Starting task...")

        var iterations = 0
        var loopActive = true

        while (loopActive && iterations < maxIterations) {
            iterations++
            
            // 1. Get response from LLM
            val response = llmClient.chat(conversationHistory)

            when (response) {
                is LLMResponse.FinalAnswer -> {
                    conversationHistory.add("AI: ${response.answer}")
                    _state.value = AgentState.Success(response.answer)
                    loopActive = false
                }
                is LLMResponse.ToolCall -> {
                    // 2. Update state to Executing
                    _state.value = AgentState.Executing(response.toolName)
                    
                    // 3. Execute the tool
                    val result = registry.dispatch(response.toolName, response.args)
                    
                    // 4. Convert result to observation string
                    val observation = when (result) {
                        is ToolResult.Success -> "Observation: ${result.output}"
                        is ToolResult.Failure -> "Observation: Error - ${result.errorMessage}"
                    }
                    
                    // 5. Feed observation back into history
                    conversationHistory.add("Action: ${response.toolName}(${response.args})")
                    conversationHistory.add(observation)
                    
                    _state.value = AgentState.Thinking("Processing observation...")
                }
            }
        }

        if (iterations >= maxIterations && loopActive) {
            _state.value = AgentState.Error("Agent exceeded maximum iterations ($maxIterations). Potential infinite loop detected.")
        }
    }
}
