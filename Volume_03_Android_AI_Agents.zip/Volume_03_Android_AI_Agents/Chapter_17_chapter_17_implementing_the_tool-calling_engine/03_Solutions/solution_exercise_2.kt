
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import kotlinx.serialization.json.*
import kotlinx.serialization.SerializationException
import kotlin.reflect.KClass

sealed class ParseResult<out T> {
    data class Success<T>(val value: T) : ParseResult<T>()
    data class Error(val message: String) : ParseResult<Nothing>()
}

class ArgumentParser(private val json: Json) {

    /**
     * Converts a Map to a JsonObject, then attempts to decode it into the target class.
     */
    fun <T : Any> parse(rawArgs: Map<String, Any?>, targetClass: KClass<T>): ParseResult<T> {
        return try {
            // 1. Convert Map<String, Any?> to JsonObject
            val jsonObject = MapToJsonObject(rawArgs)
            
            // 2. Use kotlinx.serialization to decode the JsonElement into the target class
            val decoded = json.decodeFromJsonElement(
                serializer(targetClass), 
                jsonObject
            )
            ParseResult.Success(decoded)
        } catch (e: SerializationException) {
            // 3. Catch and transform serialization errors into user-friendly messages
            ParseResult.Error("Argument Validation Error: ${e.message}")
        } catch (e: Exception) {
            ParseResult.Error("Unexpected parsing error: ${e.localizedMessage}")
        }
    }

    /**
     * Helper to convert a dynamic Map into a kotlinx.serialization JsonObject.
     * This handles the "Type Coercion" requirement by wrapping values into JsonPrimitives.
     */
    private fun MapToJsonObject(map: Map<String, Any?>): JsonObject {
        val content = map.mapValues { (_, value) ->
            when (value) {
                null -> JsonNull
                is Number -> JsonPrimitive(value)
                is Boolean -> JsonPrimitive(value)
                is String -> JsonPrimitive(value)
                else -> JsonPrimitive(value.toString()) // Fallback coercion
            }
        }
        return JsonObject(content)
    }

    // Note: In a real implementation, we would use a more robust way to get 
    // the KSerializer for a KClass, typically via a registry or reflection.
    @Suppress("UNCHECKED_CAST")
    private fun <T : Any> serializer(clazz: KClass<T>): kotlinx.serialization.KSerializer<T> {
        // This is a simplification for the exercise context
        return kotlinx.serialization.serializer(clazz.java) as kotlinx.serialization.KSerializer<T>
    }
}

@kotlinx.serialization.Serializable
data class WeatherArgs(
    val location: String,
    val unit: String = "celsius"
)
