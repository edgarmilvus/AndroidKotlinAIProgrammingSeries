
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The contract for any tool that can be invoked by the AI Agent.
 */
interface Tool {
    val name: String
    val description: String
    val isSensitive: Boolean get() = false
    suspend fun execute(args: Map<String, Any?>): ToolResult
}

sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Failure(val errorMessage: String) : ToolResult()
}

/**
 * Implementation of the ToolRegistry using Hilt Multibindings.
 */
@Singleton
class ToolRegistry @Inject constructor(
    // @JvmSuppressWildcards is required for Hilt multibindings with generic interfaces
    private val availableTools: Set<@JvmSuppressWildcards Tool>
) {
    // Pre-compute the map for O(1) lookup performance
    private val toolMap: Map<String, Tool> = availableTools.associateBy { it.name }

    suspend fun dispatch(toolName: String, args: Map<String, Any?>): ToolResult {
        val tool = toolMap[toolName] 
            ?: return ToolResult.Failure(
                "Error: Tool [$toolName] not found. Available tools are: ${toolMap.keys.joinToString()}"
            )
        
        return try {
            tool.execute(args)
        } catch (e: Exception) {
            ToolResult.Failure("Execution error in [$toolName]: ${e.localizedMessage}")
        }
    }

    fun getToolDescriptions(): String {
        return availableTools.joinToString("\n") { "- ${it.name}: ${it.description}" }
    }
}

/**
 * Hilt Module to provide tool implementations via @IntoSet.
 */
@Module
@InstallIn(SingletonComponent::class)
object ToolModule {

    @Provides
    @IntoSet
    fun provideThermostatTool(service: ThermostatService): Tool {
        return ThermostatTool(service)
    }

    // Additional tools would be added here via other @Provides @IntoSet methods
}

/**
 * Concrete implementation.
 */
class ThermostatTool(
    private val thermostatService: ThermostatService
) : Tool {
    override val name = "set_temperature"
    override val description = "Sets the smart thermostat to a specific temperature in Celsius."

    override suspend fun execute(args: Map<String, Any?>): ToolResult {
        val value = args["value"]?.toString()?.toDoubleOrNull()
            ?: return ToolResult.Failure("Missing or invalid argument: 'value' must be a number.")
        
        return try {
            thermostatService.setTemp(value)
            ToolResult.Success("Temperature set to $value°C")
        } catch (e: Exception) {
            ToolResult.Failure("Hardware error: ${e.message}")
        }
    }
}

// Mock service for compilation purposes
class ThermostatService { suspend fun setTemp(temp: Double) {} }
