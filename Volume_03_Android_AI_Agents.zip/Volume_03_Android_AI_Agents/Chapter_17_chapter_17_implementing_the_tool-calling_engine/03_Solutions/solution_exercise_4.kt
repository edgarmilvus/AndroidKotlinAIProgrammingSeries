
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Button
import android.view.accessibility.AccessibilityNodeInfo

class ScreenContextProvider {

    /**
     * Traverses the view hierarchy and builds a semantic description.
     * In a real app, this would use AccessibilityNodeInfo for cross-app awareness,
     * but for an internal app, we traverse the View tree.
     */
    fun getSemanticSnapshot(rootView: View): String {
        val elements = mutableListOf<String>()
        traverseView(rootView, elements)
        
        return if (elements.isEmpty()) {
            "No interactive elements found on screen."
        } else {
            "Elements on screen:\n" + elements.joinToString("\n")
        }
    }

    private fun traverseView(view: View, elements: MutableList<String>) {
        // 1. Filter for "Meaningful" nodes to save Token Budget
        // We only care about things that are clickable, focusable, or have text.
        val isInteractive = view.isClickable || view.isFocusable || view.isImportantForAccessibility
        val hasText = (view as? TextView)?.text?.isNotEmpty() == true

        if (isInteractive || hasText) {
            val description = buildDescription(view)
            if (description.isNotEmpty()) {
                elements.add("- $description")
            }
        }

        // 2. Recursive traversal
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                traverseView(view.getChildAt(i), elements)
            }
        }
    }

    private fun buildDescription(view: View): String {
        val sb = StringBuilder()
        
        // Identify the type of element
        val type = when (view) {
            is Button -> "Button"
            is TextView -> "TextView"
            else -> "View"
        }
        
        sb.append("[$type]")

        // Capture the semantic label (text or content description)
        val label = (view as? TextView)?.text?.toString() 
            ?: view.contentDescription?.toString()
            ?: ""

        if (label.isNotEmpty()) {
            sb.append(": '$label'")
        }

        // Add state information
        if (view.isClickable) sb.append(" (Clickable)")
        if (view.isFocusable) sb.append(" (Focusable)")
        
        return sb.toString()
    }
}
