
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.CompletableDeferred

data class ToolConfirmationRequest(
    val toolName: String,
    val args: Map<String, Any?>,
    val confirmationDeferred: CompletableDeferred<Boolean>
)

class SafetyInterceptor(
    private val confirmationChannel: Channel<ToolConfirmationRequest>
) {
    suspend fun intercept(tool: Tool, args: Map<String, Any?>): Boolean {
        return if (tool.isSensitive) {
            val deferred = CompletableDeferred<Boolean>()
            
            // Send request to the UI layer
            confirmationChannel.send(
                ToolConfirmationRequest(tool.name, args, deferred)
            )
            
            // SUSPEND the coroutine here until the UI completes the deferred
            deferred.await()
        } else {
            true
        }
    }
}

@Composable
fun SafetyGuardDialog(
    channel: ReceiveChannel<ToolConfirmationRequest>
) {
    // Local state to hold the current request being displayed
    var currentRequest by remember { mutableStateOf<ToolConfirmationRequest?>(null) }

    // Effect to listen to the channel for new requests
    LaunchedEffect(channel) {
        for (request in channel) {
            currentRequest = request
        }
    }

    // The actual Dialog UI
    currentRequest?.let { request ->
        AlertDialog(
            onDismissRequest = { 
                request.confirmationDeferred.complete(false)
                currentRequest = null 
            },
            title = { Text("Confirm Sensitive Action") },
            text = { 
                Text("The agent wants to call '${request.toolName}' with arguments: ${request.args}. Allow this?") 
            },
            confirmButton = {
                TextButton(onClick = {
                    request.confirmationDeferred.complete(true)
                    currentRequest = null
                }) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    request.confirmationDeferred.complete(false)
                    currentRequest = null
                }) {
                    Text("Deny")
                }
            }
        )
    }
}
