
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.engine

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import javax.inject.Inject
import javax.inject.Qualifier
import javax.inject.Singleton

// --- 1. Core Domain Models ---

@Serializable
data class ToolCall(
    val toolName: String,
    val arguments: Map<String, String>,
    val priority: Int = 0
)

sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Failure(val error: String) : ToolResult()
    object SafetyViolation : ToolResult()
}

data class AgentViewState(
    val isProcessing: Boolean = false,
    val lastAction: String = "",
    val logs: List<String> = emptyList(),
    val error: String? = null
)

// --- 2. Hardware-Aware Dispatchers ---

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class NPUDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class GPUDispatcher

// --- 3. The Tool Registry & Definitions ---

interface Tool {
    val name: String
    val description: String
    suspend fun execute(args: Map<String, String>): ToolResult
}

class LightControlTool @Inject constructor() : Tool {
    override val name = "control_lights"
    override val description = "Turns lights on or off in a specific room."
    
    override suspend fun execute(args: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val room = args["room"] ?: "living room"
        val state = args["state"] ?: "off"
        // Simulate hardware latency
        delay(500) 
        ToolResult.Success("Lights in $room are now $state")
    }
}

@Singleton
class ToolRegistry @Inject constructor(
    private val lightTool: LightControlTool
) {
    private val tools = mutableMapOf<String, Tool>()

    init {
        register(lightTool)
    }

    fun register(tool: Tool) {
        tools[tool.name] = tool
    }

    fun getTool(name: String): Tool? = tools[name]
}

// --- 4. The Safety Guard (NPU-Accelerated) ---

/**
 * The SafetyGuard simulates an on-device NPU-based model that performs 
 * semantic analysis to ensure the LLM's tool calls are not malicious 
 * or physically dangerous (e.g., "set oven to 1000 degrees").
 */
class SafetyGuard @Inject constructor(
    @NPUDispatcher private val npuDispatcher: CoroutineDispatcher
) {
    suspend fun validateIntent(call: ToolCall): Boolean = withContext(npuDispatcher) {
        // Simulate NPU processing time for semantic validation
        delay(300)
        
        // Logic: Prevent "destructive" arguments
        if (call.toolName == "control_lights" && call.arguments["state"] == "explode") {
            return@withContext false
        }
        true
    }
}

// --- 5. The Tool-Calling Engine (The Orchestrator) ---

class ToolCallingEngine @Inject constructor(
    private val registry: ToolRegistry,
    private val safetyGuard: SafetyGuard,
    @NPUDispatcher private val npuDispatcher: CoroutineDispatcher
) {
    /**
     * Executes a batch of tool calls using Structured Concurrency.
     * If one tool fails critically, the engine can decide whether to continue.
     */
    suspend fun executeBatch(calls: List<ToolCall>): List<ToolResult> = coroutineScope {
        calls.map { call ->
            async {
                processSingleCall(call)
            }
        }.awaitAll()
    }

    private suspend fun processSingleCall(call: ToolCall): ToolResult {
        // 1. Semantic Safety Check (NPU Offload)
        val isSafe = safetyGuard.validateIntent(call)
        if (!isSafe) return ToolResult.SafetyViolation

        // 2. Tool Discovery
        val tool = registry.getTool(call.toolName) 
            ?: return ToolResult.Failure("Tool ${call.toolName} not found")

        // 3. Execution (Bounded by the calling scope)
        return try {
            tool.execute(call.arguments)
        } catch (e: CancellationException) {
            // Ensure we handle cancellation properly in an agentic loop
            throw e 
        } catch (e: Exception) {
            ToolResult.Failure(e.message ?: "Unknown error")
        }
    }
}

// --- 6. The ViewModel (MVI Implementation) ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val engine: ToolCallingEngine
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgentViewState())
    val uiState: StateFlow<AgentViewState> = _uiState.asStateFlow()

    /**
     * Represents a user intent parsed by the LLM.
     * In a real app, this comes from the LLM's JSON output.
     */
    fun onIntentReceived(toolCalls: List<ToolCall>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, logs = it.logs + "Processing intent...") }

            val results = engine.executeBatch(toolCalls)

            _uiState.update { state ->
                val newLogs = state.logs.toMutableList().apply {
                    results.forEach { res ->
                        add(when(res) {
                            is ToolResult.Success -> "✅ Success: ${res.output}"
                            is ToolResult.Failure -> "❌ Error: ${res.error}"
                            is ToolResult.SafetyViolation -> "⚠️ Safety Violation Blocked!"
                        })
                    }
                }
                state.copy(
                    isProcessing = false,
                    logs = newLogs,
                    lastAction = "Batch completed"
                )
            }
        }
    }
}

// --- 7. Dependency Injection Module ---

@Module
@InstallIn(SingletonComponent::class)
object AgentModule {

    @Provides
    @NPUDispatcher
    fun provideNPUDispatcher(): CoroutineDispatcher = 
        Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    @Provides
    @GPUDispatcher
    fun provideGPUDispatcher(): CoroutineDispatcher = 
        Dispatchers.Default // In real Android, this might be a custom dispatcher for Vulkan/OpenCL
}
