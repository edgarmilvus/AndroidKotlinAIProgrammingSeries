
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.functionCalling
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class HomeAgentViewModel @Inject constructor(
    private val repository: HomeDeviceRepository
) : ViewModel() {

    // UI State: A list of messages (User or AI)
    private val _messages = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val messages: StateFlow<List<Pair<String, String>>> = _messages.asStateFlow()

    // Initialize the Gemini Model with Function Calling capabilities
    private val generativeModel = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = "YOUR_API_KEY_HERE",
        // Here we define the 'Tools' the model can use
        toolConfig = functionCalling {
            // We describe the functions so the LLM knows when to use them
            // Note: In a real SDK implementation, you map these to actual function references
        }
    )

    // Create a chat session to maintain history
    private val chat = generativeModel.startChat()

    fun sendMessage(userPrompt: String) {
        viewModelScope.launch {
            // 1. Update UI with User message
            appendMessage("User", userPrompt)

            try {
                // 2. Switch to Default dispatcher for AI inference to avoid blocking Main thread
                withContext(Dispatchers.Default) {
                    // Send the prompt to Gemini
                    var response = chat.sendMessage(userPrompt)
                    var candidate = response.candidate

                    // 3. The "Reasoning Loop": Check if the model wants to call a function
                    // The model might call multiple functions in a row (Parallel Function Calling)
                    while (candidate?.content?.parts?.filterIsInstance<com.google.ai.client.generativeai.type.FunctionCall>()?.isNotEmpty() == true) {
                        
                        val functionCalls = candidate.content.parts.filterIsInstance<com.google.ai.client.generativeai.type.FunctionCall>()
                        val functionResponses = mutableListOf<com.google.ai.client.generativeai.type.FunctionResponse>()

                        for (call in functionCalls) {
                            // Execute the local Kotlin logic based on the function name requested by Gemini
                            val result = when (call.name) {
                                "getTemperature" -> {
                                    val room = call.args["room"] as? String ?: "unknown"
                                    repository.getTemperature(room)
                                }
                                "setLightStatus" -> {
                                    val room = call.args["room"] as? String ?: "unknown"
                                    val isOn = call.args["isOn"] as? Boolean ?: false
                                    repository.setLightStatus(room, isOn)
                                }
                                else -> "Error: Function not found"
                            }

                            // Wrap the result in a FunctionResponse object
                            functionResponses.add(
                                com.google.ai.client.generativeai.type.FunctionResponse(
                                    functionName = call.name,
                                    response = mapOf("result" to result)
                                )
                            )
                        }

                        // 4. Feed the results back to the model to get the final natural language response
                        val responseWithToolData = chat.sendMessage(
                            content {
                                functionResponses.forEach { part(it) }
                            }
                        )
                        candidate = responseWithToolData.candidate
                    }

                    // 5. Final answer synthesis
                    val finalText = candidate?.content?.text ?: "I'm sorry, I couldn't process that."
                    
                    withContext(Dispatchers.Main) {
                        appendMessage("AI", finalText)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    appendMessage("System", "Error: ${e.localizedMessage}")
                }
            }
        }
    }

    private fun appendMessage(sender: String, text: String) {
        _messages.value = _messages.value + (sender to text)
    }
}
