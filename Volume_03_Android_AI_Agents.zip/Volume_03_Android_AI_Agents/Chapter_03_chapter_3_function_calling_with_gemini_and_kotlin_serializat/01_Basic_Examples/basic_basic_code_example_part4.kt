
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HomeDeviceRepository @Inject constructor() {
    // Mock data representing the state of the house
    private val temperatures = mapOf("living room" to "72°F", "bedroom" to "68°F", "kitchen" to "75°F")
    private val lights = mutableMapOf("living room" to false, "bedroom" to false, "kitchen" to false)

    fun getTemperature(room: String): String {
        val temp = temperatures[room.lowercase()] ?: "unknown"
        return "The temperature in the $room is $temp."
    }

    fun setLightStatus(room: String, isOn: Boolean): String {
        lights[room.lowercase()] = isOn
        val status = if (isOn) "ON" else "OFF"
        return "Successfully turned the $room light $status."
    }
}
