
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.travel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.*
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. Domain Models & Tool Definitions ---

@Serializable
data class FlightRequest(val destination: String, val date: String)

@Serializable
data class HotelRequest(val city: String, val checkIn: String, val budget: Double)

@Serializable
data class CalendarEvent(val title: String, val date: String)

/**
 * ToolRegistry acts as the bridge between Gemini's string-based function calls
 * and actual Kotlin type-safe implementations.
 */
@Singleton
class ToolRegistry @Inject constructor() {
    private val json = Json { ignoreUnknownKeys = true }

    // Actual business logic for tools
    suspend fun checkCalendar(): List<CalendarEvent> {
        delay(500) // Simulate network
        return listOf(CalendarEvent("Conference in Tokyo", "2024-11-12"))
    }

    suspend fun searchFlights(req: FlightRequest): String {
        delay(800)
        return "Flight JL123 to ${req.destination} on ${req.date} costs \$1,200."
    }

    suspend fun bookHotel(req: HotelRequest): String {
        delay(1000)
        return "Hotel Ritz in ${req.city} booked for ${req.checkIn} within budget \$${req.budget}."
    }

    /**
     * Dynamically dispatches the function call based on the name provided by Gemini.
     * Uses Kotlin Serialization to convert the Map of arguments into a typed Data Class.
     */
    suspend fun executeTool(functionName: String, args: Map<String, Any?>): String {
        return when (functionName) {
            "check_calendar" -> {
                val events = checkCalendar()
                "User has the following events: ${events.joinToString { it.title + " on " + it.date }}"
            }
            "search_flights" -> {
                // Convert Map to JsonElement then to FlightRequest
                val jsonArgs = json.encodeToJsonElement(args)
                val request = json.decodeFromJsonElement<FlightRequest>(jsonArgs)
                searchFlights(request)
            }
            "book_hotel" -> {
                val jsonArgs = json.encodeToJsonElement(args)
                val request = json.decodeFromJsonElement<HotelRequest>(jsonArgs)
                bookHotel(request)
            }
            else -> "Error: Tool $functionName not found."
        }
    }
}

// --- 2. Repository: The Agentic Orchestrator ---

class TravelAgentRepository @Inject constructor(
    private val toolRegistry: ToolRegistry
) {
    // Define the tools for Gemini using FunctionDeclarations
    private val tools = listOf(
        Tool(functionDeclarations = listOf(
            FunctionDeclaration("check_calendar", "Checks the user's calendar for existing commitments"),
            FunctionDeclaration(
                "search_flights", 
                "Searches for flights to a destination",
                FunctionSchema(
                    parameters = Schema.objectSchema(
                        properties = mapOf(
                            "destination" to Schema.stringSchema("The city to fly to"),
                            "date" to Schema.stringSchema("The date of travel in YYYY-MM-DD")
                        ),
                        required = listOf("destination", "date")
                    )
                )
            ),
            FunctionDeclaration(
                "book_hotel",
                "Books a hotel in a specific city",
                FunctionSchema(
                    parameters = Schema.objectSchema(
                        properties = mapOf(
                            "city" to Schema.stringSchema("The city where the hotel is located"),
                            "checkIn" to Schema.stringSchema("Check-in date"),
                            "budget" to Schema.doubleSchema("Maximum budget per night")
                        ),
                        required = listOf("city", "checkIn", "budget")
                    )
                )
            )
        ))
    )

    private val model = GenerativeModel(
        modelName = "gemini-1.5-pro",
        apiKey = "YOUR_API_KEY",
        tools = tools
    )

    /**
     * The Core Agent Loop:
     * This function manages the "Think -> Act -> Observe" cycle.
     */
    suspend fun runAgenticTask(userPrompt: String, onUpdate: (String) -> Unit): String = withContext(Dispatchers.Default) {
        var currentChat = model.startChat()
        var response = currentChat.sendMessage(userPrompt)
        var iterations = 0
        val maxIterations = 5 // Prevent infinite loops

        while (iterations < maxIterations) {
            val candidate = response.candidate ?: break
            val functionCalls = candidate.content.parts.filterIsInstance<FunctionCall>()

            if (functionCalls.isEmpty()) {
                // No more tools needed, return the final text response
                return@withContext candidate.content.text ?: "Task completed."
            }

            // Process each function call requested by the AI
            val toolResponses = functionCalls.map { call ->
                onUpdate("Executing tool: ${call.name}...")
                Log.d("Agent", "Calling tool ${call.name} with args ${call.args}")
                
                val result = toolRegistry.executeTool(call.name, call.args)
                
                FunctionResponse(call.name, result)
            }

            // Feed the tool results back to the model to continue the reasoning chain
            response = currentChat.sendMessage(
                content(parts = toolResponses.map { FunctionResponsePart(it) })
            )
            iterations++
        }
        
        "Agent reached maximum iterations without a final answer."
    }
}

// --- 3. ViewModel: State Management ---

sealed class AgentUiState {
    object Idle : AgentUiState()
    data class Thinking(val message: String) : AgentUiState()
    data class Success(val result: String) : AgentUiState()
    data class Error(val error: String) : AgentUiState()
}

@HiltViewModel
@AndroidEntryPoint
class TravelAgentViewModel @Inject constructor(
    private val repository: TravelAgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentUiState>(AgentUiState.Idle)
    val uiState: StateFlow<AgentUiState> = _uiState.asStateFlow()

    fun handleUserRequest(prompt: String) {
        viewModelScope.launch {
            _uiState.value = AgentUiState.Thinking("Analyzing your request...")
            try {
                // Structured Concurrency: The repository handles the heavy lifting on Dispatchers.Default
                val finalResult = repository.runAgenticTask(prompt) { status ->
                    _uiState.value = AgentUiState.Thinking(status)
                }
                _uiState.value = AgentUiState.Success(finalResult)
            } catch (e: Exception) {
                Log.e("ViewModel", "Agent Error", e)
                _uiState.value = AgentUiState.Error(e.localizedMessage ?: "An unknown error occurred")
            }
        }
    }
}
