
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

sealed class AgentState {
    object Idle : AgentState()
    object Thinking : AgentState()
    data class AwaitingConfirmation(val actionName: String, val details: String) : AgentState()
    data class Executing(val step: String) : AgentState()
    data class Error(val message: String) : AgentState()
    object Completed : AgentState()
}

class TravelOrchestratorViewModel(
    private val generativeModel: GenerativeModel
) : ViewModel() {

    private val _agentState = MutableStateFlow<AgentState>(AgentState.Idle)
    val agentState = _agentState.asStateFlow()

    private val chat = generativeModel.startChat()

    fun startTripPlanning(userRequest: String) {
        viewModelScope.launch {
            _agentState.value = AgentState.Thinking
            var response = chat.sendMessage(userRequest)

            while (response.functionCalls.isNotEmpty()) {
                val calls = response.functionCalls
                val results = mutableListOf<FunctionResponse>()

                for (call in calls) {
                    // Handle Human-in-the-loop
                    if (call.name == "confirm_payment") {
                        _agentState.value = AgentState.AwaitingConfirmation(
                            "Payment", "Confirm booking for $500?"
                        )
                        // We break the loop and wait for user interaction
                        return@launch 
                    }

                    _agentState.value = AgentState.Executing(call.name)
                    
                    val result = when (call.name) {
                        "book_flight" -> "Flight booked successfully"
                        "book_hotel" -> "Error: No rooms available in Paris" // Simulated failure
                        "search_hotels" -> "Found Hotel: Ritz Paris"
                        else -> "Unknown"
                    }
                    results.add(FunctionResponse(call.name, mapOf("result" to result)))
                }
                response = chat.sendMessage(results)
            }
            _agentState.value = AgentState.Completed
        }
    }

    fun onUserConfirmed(details: String) {
        viewModelScope.launch {
            // Resume the loop by feeding the confirmation back to the model
            val response = chat.sendMessage("User confirmed: $details")
            // ... continue loop logic ...
            _agentState.value = AgentState.Completed
        }
    }
}
