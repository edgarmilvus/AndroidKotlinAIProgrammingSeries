
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*

// 1. Polymorphic Data Structure
@Serializable
sealed class DeviceParams {
    @Serializable @SerialName("light")
    data class LightParams(val brightness: Int) : DeviceParams()

    @Serializable @SerialName("thermostat")
    data class ThermostatParams(val temperature: Double) : DeviceParams()
}

@Serializable
data class DeviceCommand(
    val device_id: String,
    val device_type: String, // "light" or "thermostat"
    val params: DeviceParams
)

// 2. Smart Home State
data class HomeState(
    val securityDisarmed: Boolean = true,
    val lightsOn: Boolean = false,
    val temperature: Double = 20.0
)

class SmartHomeRepository {
    private val _state = MutableStateFlow(HomeState())
    val state = _state.asStateFlow()

    fun executeCommand(command: DeviceCommand) {
        _state.update { current ->
            when (command.params) {
                is DeviceParams.LightParams -> 
                    current.copy(lightsOn = command.params.brightness > 0)
                is DeviceParams.ThermostatParams -> 
                    current.copy(temperature = command.params.temperature)
            }
        }
    }
    
    fun getSecurityStatus(): Boolean = _state.value.securityDisarmed
}

// 3. ViewModel Logic
class SmartHomeViewModel(
    private val repository: SmartHomeRepository,
    private val generativeModel: GenerativeModel
) : ViewModel() {

    private val json = Json { 
        ignoreUnknownKeys = true
        classDiscriminator = "type" // Tells Kotlin how to find the @SerialName
    }

    fun processCommand(query: String) {
        viewModelScope.launch {
            val chat = generativeModel.startChat()
            var response = chat.sendMessage(query)

            while (response.functionCalls.isNotEmpty()) {
                val toolResults = response.functionCalls.map { call ->
                    val result = when (call.name) {
                        "get_security_status" -> repository.getSecurityStatus().toString()
                        "set_device_state" -> {
                            // Polymorphic Decoding
                            val cmd = json.decodeFromJsonElement<DeviceCommand>(
                                json.encodeToJsonElement(call.args)
                            )
                            repository.executeCommand(cmd)
                            "Command executed successfully"
                        }
                        else -> "Unknown tool"
                    }
                    FunctionResponse(call.name, mapOf("result" to result))
                }
                response = chat.sendMessage(toolResults)
            }
        }
    }
}
