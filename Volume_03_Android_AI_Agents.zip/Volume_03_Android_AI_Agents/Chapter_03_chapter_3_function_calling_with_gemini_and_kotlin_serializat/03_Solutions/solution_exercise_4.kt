
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

@Serializable
data class NoteSnippet(
    val id: String,
    val excerpt: String,
    val date: String
)

class NoteRepository {
    // Simulated large dataset
    private val allNotes = List(1000) { i -> 
        "Note $i: This is a long piece of text about Project X on 2023-10-01..." 
    }

    // Efficient Search Tool
    fun searchNotes(query: String): List<NoteSnippet> {
        return allNotes.asSequence()
            .filter { it.contains(query, ignoreCase = true) }
            .take(5) // Limit results to prevent token overflow
            .mapIndexed { index, text ->
                NoteSnippet(
                    id = index.toString(),
                    excerpt = text.take(100), // Return only a snippet!
                    date = "2023-10-01"
                )
            }
            .toList()
    }
}

class DataAnalystViewModel(
    private val repository: NoteRepository,
    private val generativeModel: GenerativeModel
) : ViewModel() {

    private val _isThinking = MutableStateFlow(false)
    val isThinking = _isThinking.asStateFlow()

    fun analyzeNotes(query: String) {
        viewModelScope.launch(Dispatchers.Default) { // Use Default for heavy search
            _isThinking.value = true
            try {
                val chat = generativeModel.startChat()
                var response = chat.sendMessage(query)

                while (response.functionCalls.isNotEmpty()) {
                    val toolResults = response.functionCalls.map { call ->
                        if (call.name == "search_notes") {
                            val queryParam = call.args["query"] as String
                            val snippets = repository.searchNotes(queryParam)
                            
                            if (snippets.isEmpty()) {
                                FunctionResponse(call.name, mapOf("result" to "No notes found."))
                            } else {
                                // Return snippets as a JSON string to the model
                                val jsonString = Json.encodeToString(snippets)
                                FunctionResponse(call.name, mapOf("result" to jsonString))
                            }
                        } else {
                            FunctionResponse(call.name, mapOf("result" to "Unknown"))
                        }
                    }
                    response = chat.sendMessage(toolResults)
                }
                // Handle final response...
            } finally {
                _isThinking.value = false
            }
        }
    }
}
