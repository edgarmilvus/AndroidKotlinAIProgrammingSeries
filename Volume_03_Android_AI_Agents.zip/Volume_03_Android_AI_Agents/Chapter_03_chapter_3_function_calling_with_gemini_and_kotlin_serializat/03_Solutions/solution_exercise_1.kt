
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.*
import com.google.ai.client.generativeai.type.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// 1. Data Modeling with Serialization
@Serializable
data class WeatherRequest(val location: String, val unit: String = "Celsius")

@Serializable
data class TimeRequest(val timezone: String)

// 2. Mock Repository
class WeatherRepository {
    fun getWeather(request: WeatherRequest): String {
        return if (request.location.contains("London", ignoreCase = true)) {
            "Rainy, 15°C"
        } else {
            "Sunny, 25°C"
        }
    }
    
    fun getTime(request: TimeRequest): String {
        return "14:00 PM" // Mocked time
    }
}

// 3. ViewModel managing the Agentic Loop
class EnvironmentalViewModel(
    private val generativeModel: GenerativeModel,
    private val repository: WeatherRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<String>("Ask me about the weather!")
    val uiState = _uiState.asStateFlow()

    private val chat = generativeModel.startChat()
    private val json = Json { ignoreUnknownKeys = true }

    fun sendMessage(userPrompt: String) {
        viewModelScope.launch {
            _uiState.value = "Thinking..."
            var response = chat.sendMessage(userPrompt)
            
            // The Agentic Loop: Handle function calls until no more are requested
            while (response.functionCalls.isNotEmpty()) {
                val functionResponses = mutableListOf<FunctionResponse>()

                for (call in response.functionCalls) {
                    val resultText = when (call.name) {
                        "get_weather" -> handleWeatherCall(call.args)
                        "get_time" -> handleTimeCall(call.args)
                        else -> "Error: Unknown function"
                    }
                    functionResponses.add(FunctionResponse(call.name, mapOf("result" to resultText)))
                }

                // Feed the tool results back to the model
                response = chat.sendMessage(functionResponses)
            }

            _uiState.value = response.text ?: "No response"
        }
    }

    private fun handleWeatherCall(args: Map<String, Any?>): String {
        // The Serialization Bridge: Map -> JsonElement -> Data Class
        val jsonElement = json.encodeToJsonElement(args.toMutableMap().filterValues { it != null })
        val request = json.decodeFromJsonElement<WeatherRequest>(jsonElement)
        return repository.getWeather(request)
    }

    private fun handleTimeCall(args: Map<String, Any?>): String {
        val jsonElement = json.encodeToJsonElement(args.toMutableMap().filterValues { it != null })
        val request = json.decodeFromJsonElement<TimeRequest>(jsonElement)
        return repository.getTime(request)
    }
}

// Helper extension to convert Map to JsonElement for the bridge
private fun Map<String, Any?>.toMutableMap() = this.toMutableMap()
