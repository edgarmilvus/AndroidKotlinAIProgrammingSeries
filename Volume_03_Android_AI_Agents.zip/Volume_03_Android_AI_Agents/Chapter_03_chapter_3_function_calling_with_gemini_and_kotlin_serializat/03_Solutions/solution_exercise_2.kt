
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@Serializable
data class Contact(val name: String, val phone: String)

// 1. Repository with State Management
class ContactRepository @Inject constructor() {
    private val _contacts = MutableStateFlow<List<Contact>>(emptyList())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    fun addContact(name: String, phone: String) {
        _contacts.value += Contact(name, phone)
    }

    fun searchContact(name: String): List<Contact> {
        return _contacts.value.filter { it.name.contains(name, ignoreCase = true) }
    }

    fun deleteContact(name: String): Boolean {
        val initialSize = _contacts.value.size
        _contacts.value = _contacts.value.filterNot { it.name.equals(name, ignoreCase = true) }
        return _contacts.value.size < initialSize
    }
}

// 2. Hilt-injected ViewModel
@HiltViewModel
class ContactViewModel @Inject constructor(
    private val repository: ContactRepository,
    private val generativeModel: GenerativeModel // Assume provided by Hilt module
) : ViewModel() {

    val contacts = repository.contacts
    private val chat = generativeModel.startChat()
    private val json = Json { ignoreUnknownKeys = true }

    fun handleUserQuery(query: String) {
        viewModelScope.launch {
            var response = chat.sendMessage(query)

            while (response.functionCalls.isNotEmpty()) {
                val calls = response.functionCalls
                val results = calls.map { call ->
                    val resultMsg = when (call.name) {
                        "add_contact" -> {
                            val args = json.decodeFromJsonElement<Contact>(json.encodeToJsonElement(call.args))
                            repository.addContact(args.name, args.phone)
                            "Success: Added ${args.name}"
                        }
                        "search_contact" -> {
                            val name = call.args["name"] as? String ?: ""
                            val found = repository.searchContact(name)
                            if (found.isEmpty()) "Error: Contact '$name' not found" 
                            else "Found: ${found.joinToString { "${it.name}: ${it.phone}" }}"
                        }
                        "delete_contact" -> {
                            val name = call.args["name"] as? String ?: ""
                            if (repository.deleteContact(name)) "Deleted $name" 
                            else "Error: Contact '$name' not found"
                        }
                        else -> "Error: Unknown tool"
                    }
                    FunctionResponse(call.name, mapOf("output" to resultMsg))
                }
                response = chat.sendMessage(results)
            }
            // Update UI with final response...
        }
    }
}
