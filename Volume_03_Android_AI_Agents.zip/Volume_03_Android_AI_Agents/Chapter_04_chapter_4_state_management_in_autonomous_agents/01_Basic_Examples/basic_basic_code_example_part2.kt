
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

// --- 1. DOMAIN MODELS: The "Atomic" parts of the Agent's State ---

/**
 * Represents a single step in the agent's reasoning process.
 * Using a sealed class allows us to represent different types of cognitive events.
 */
sealed class AgentEvent {
    data class Thought(val reasoning: String) : AgentEvent()
    data class Action(val toolName: String, val input: String) : AgentEvent()
    data class Observation(val content: String) : AgentEvent()
    data class Error(val message: String) : AgentEvent()
    object GoalReached : AgentEvent()
}

/**
 * The Immutable State Object.
 * In autonomous agents, immutability is critical to prevent race conditions 
 * between the reasoning engine (Background Thread) and the UI (Main Thread).
 */
data class AgentState(
    val currentGoal: String = "",
    val isRunning: Boolean = false,
    val eventHistory: List<AgentEvent> = emptyList(),
    val lastError: String? = null,
    val progress: Float = 0f // 0.0 to 1.0
)

// --- 2. THE ENGINE: The "Brain" (Simulating the Reasoning Loop) ---

/**
 * The AgentEngine simulates the heavy lifting: LLM calls, tool execution, and reasoning.
 * In a real app, this would interface with Gemini Nano or a remote LLM.
 */
class AgentEngine @Inject constructor() {

    /**
     * The core reasoning loop. 
     * This is a suspending function that performs the ReAct (Reasoning + Acting) pattern.
     */
    suspend fun runAutonomousLoop(
        goal: String,
        onEvent: (AgentEvent) -> Unit
    ) = withContext(Dispatchers.Default) {
        try {
            onEvent(AgentEvent.Thought("Analyzing goal: $goal"))
            delay(1500) // Simulate LLM latency

            // Step 1: Observe
            onEvent(AgentEvent.Observation("Scanning screen for 'Submit' button..."))
            delay(1000)

            // Step 2: Reason & Act
            onEvent(AgentEvent.Thought("Found button. I need to click it to complete the task."))
            onEvent(AgentEvent.Action(toolName = "CLICK_ELEMENT", input = "id:submit_btn"))
            delay(1500)

            // Step 3: Observe Result
            onEvent(AgentEvent.Observation("Button clicked. Confirmation dialog appeared."))
            delay(1000)

            // Step 4: Final Reasoning
            onEvent(AgentEvent.Thought("Task completed successfully."))
            onEvent(AgentEvent.GoalReached)
            
        } catch (e: Exception) {
            onEvent(AgentEvent.Error(e.localizedMessage ?: "Unknown error occurred"))
        }
    }
}

// --- 3. THE REPOSITORY: The State Manager ---

/**
 * The Repository acts as the single source of truth for the Agent's state.
 * It manages the transition from one state to the next.
 */
class AgentRepository @Inject constructor(
    private val engine: AgentEngine
) {
    private val _state = MutableStateFlow(AgentState())
    val state: StateFlow<AgentState> = _state.asStateFlow()

    suspend fun startAgent(goal: String) {
        // Reset state for a new task
        _state.update { 
            AgentState(currentGoal = goal, isRunning = true, eventHistory = emptyList()) 
        }

        engine.runAutonomousLoop(goal) { event ->
            // Update the state reactively based on the event received from the engine
            updateStateWithEvent(event)
        }
    }

    private fun updateStateWithEvent(event: AgentEvent) {
        _state.update { currentState ->
            val newHistory = currentState.eventHistory + event
            
            when (event) {
                is AgentEvent.GoalReached -> currentState.copy(
                    isRunning = false,
                    eventHistory = newHistory,
                    progress = 1f
                )
                is AgentEvent.Error -> currentState.copy(
                    isRunning = false,
                    eventHistory = newHistory,
                    lastError = event.message
                )
                else -> currentState.copy(
                    eventHistory = newHistory
                )
            }
        }
    }
}

// --- 4. THE VIEWMODEL: The Orchestrator ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    // Expose the state to the UI
    val uiState: StateFlow<AgentState> = repository.state

    fun executeGoal(goal: String) {
        viewModelScope.launch {
            repository.startAgent(goal)
        }
    }
}

// --- 5. THE UI: Jetpack Compose Representation ---

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AgentControlScreen(viewModel: AgentViewModel) {
    // Collect state using the lifecycle-aware collector
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var goalInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Autonomous Agent Controller",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Input Area
        OutlinedTextField(
            value = goalInput,
            onValueChange = { goalInput = it },
            label = { Text("Enter Task Goal") },
            modifier = Modifier.fillMaxWidth(),
            enabled = !state.isRunning
        )

        Button(
            onClick = { viewModel.executeGoal(goalInput) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            enabled = !state.isRunning && goalInput.isNotBlank()
        ) {
            Text(if (state.isRunning) "Agent Thinking..." else "Launch Agent")
        }

        // Progress Indicator
        LinearProgressIndicator(
            progress = { state.progress },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        )

        Divider(modifier = Modifier.padding(vertical = 8.dp))

        // Cognitive Trace (The "Thought Process" Log)
        Text(text = "Cognitive Trace:", style = MaterialTheme.typography.titleMedium)
        
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.eventHistory) { event ->
                EventLogItem(event)
            }
        }
    }
}

@Composable
fun EventLogItem(event: AgentEvent) {
    val (text, color) = when (event) {
        is AgentEvent.Thought -> "🧠 Thought: ${event.reasoning}" to MaterialTheme.colorScheme.primary
        is AgentEvent.Action -> "🛠️ Action: ${event.toolName}(${event.input})" to MaterialTheme.colorScheme.secondary
        is AgentEvent.Observation -> "👁️ Observed: ${event.content}" to MaterialTheme.colorScheme.tertiary
        is AgentEvent.Error -> "❌ Error: ${event.message}" to MaterialTheme.colorScheme.error
        is AgentEvent.GoalReached -> "✅ Goal Reached!" to MaterialTheme.colorScheme.primary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(8.dp),
            style = MaterialTheme.typography.bodySmall
        )
    }
}
