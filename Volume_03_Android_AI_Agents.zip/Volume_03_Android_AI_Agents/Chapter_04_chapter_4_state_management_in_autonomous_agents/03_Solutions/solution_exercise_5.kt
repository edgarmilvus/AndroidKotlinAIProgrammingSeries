
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class Modifier { USER, AGENT }

data class DraftState(
    val content: String,
    val version: Int,
    val lastModifiedBy: Modifier
)

sealed class StateEvent {
    data class ConflictDetected(val currentVersion: Int) : StateEvent()
    object SyncRequested : StateEvent()
}

class DraftManager {
    private val _state = MutableStateFlow(DraftState("", 0, Modifier.USER))
    val state: StateFlow<DraftState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<StateEvent>()
    val events: SharedFlow<StateEvent> = _events.asSharedFlow()

    private val mutex = Mutex()

    suspend fun applyChange(newContent: String, baseVersion: Int, modifier: Modifier) {
        mutex.withLock {
            val current = _state.value
            
            if (baseVersion == current.version) {
                // Happy path: No conflict
                _state.value = DraftState(newContent, current.version + 1, modifier)
            } else {
                // Conflict Logic
                handleConflict(newContent, baseVersion, modifier, current)
            }
        }
    }

    private suspend fun handleConflict(
        newContent: String, 
        baseVersion: Int, 
        modifier: Modifier, 
        current: DraftState
    ) {
        if (modifier == Modifier.AGENT && current.lastModifiedBy == Modifier.USER) {
            // Reject Agent: User has modified the state since the agent last read it
            _events.emit(StateEvent.ConflictDetected(current.version))
            println("Agent proposal rejected: User modified draft.")
        } else if (modifier == Modifier.USER) {
            // Force User: User always wins, increment version
            _state.value = DraftState(newContent, current.version + 1, Modifier.USER)
            _events.emit(StateEvent.SyncRequested) // Notify agent to re-sync
            println("User forced update: Agent must re-sync.")
        }
    }
}

// Simulated Agent Loop
class EmailAgent(private val manager: DraftManager) {
    private val scope = CoroutineScope(Dispatchers.Default)

    fun startAgent() {
        scope.launch {
            manager.events.collect { event ->
                if (event is StateEvent.ConflictDetected) {
                    println("Agent: My edit was rejected. Re-reading draft...")
                    syncState()
                }
                if (event is StateEvent.SyncRequested) {
                    println("Agent: User changed the draft. Updating my internal state...")
                    syncState()
                }
            }
        }
    }

    private fun syncState() {
        val latest = manager.state.value
        println("Agent synced to version ${latest.version}")
    }
}
