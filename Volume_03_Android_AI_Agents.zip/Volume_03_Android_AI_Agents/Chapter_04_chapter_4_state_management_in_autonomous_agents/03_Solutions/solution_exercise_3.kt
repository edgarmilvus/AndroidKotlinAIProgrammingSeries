
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

// 1. Screen Snapshot Model
data class ScreenState(
    val epoch: Long,
    val flattenedHierarchy: String,
    val focusedElementId: String?
)

// 3. Action Model
enum class ActionType { CLICK, TYPE, SCROLL }
data class AgentAction(
    val targetElementId: String,
    val actionType: ActionType,
    val observedEpoch: Long
)

// 2. The Scanner (Mock Accessibility Service)
class ScreenScanner {
    private val _screenFlow = MutableStateFlow(ScreenState(0, "Initial Screen", null))
    val screenFlow: StateFlow<ScreenState> = _screenFlow.asStateFlow()

    suspend fun simulateUiChange(newHierarchy: String, newFocus: String?) {
        delay(500)
        _screenFlow.update { it.copy(
            epoch = it.epoch + 1, 
            flattenedHierarchy = newHierarchy, 
            focusedElementId = newFocus
        ) }
    }
}

// 3. The Action Validator
class StateValidator {
    fun validateAction(action: AgentAction, currentState: ScreenState): Boolean {
        // CRITICAL: The epoch must match exactly
        return action.observedEpoch == currentState.epoch
    }
}

// 4. The Recovery Loop
class AccessibilityAgent(
    private val scanner: ScreenScanner,
    private val validator: StateValidator
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    fun executeAgentLoop(targetId: String) {
        scope.launch {
            var success = false
            while (!success) {
                // 1. Scan the screen
                val currentState = scanner.screenFlow.value
                println("Agent scanning screen Epoch: ${currentState.epoch}")

                // 2. Simulate LLM generating an action based on that epoch
                val action = AgentAction(targetId, ActionType.CLICK, currentState.epoch)
                
                // Simulate a delay where the UI might change (the "Gap")
                delay(100) 

                // 3. Validate before acting
                val latestState = scanner.screenFlow.value
                if (validator.validateAction(action, latestState)) {
                    println("Action Validated! Clicking $targetId")
                    success = true
                } else {
                    println("State Divergence Detected! Epoch ${action.observedEpoch} != ${latestState.epoch}. Refreshing...")
                    // The loop continues, triggering a re-scan (Recovery Loop)
                }
            }
        }
    }
}
