
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

// 1. State Definition: The Finite State Machine
sealed interface ToolExecutionState {
    object Idle : ToolExecutionState
    object Thinking : ToolExecutionState
    data class Calling(val toolName: String, val job: Job) : ToolExecutionState
    object Integrating : ToolExecutionState
    data class Failed(val error: String) : ToolExecutionState
}

@HiltViewModel
class TravelAgentViewModel @Inject constructor() : ViewModel() {
    private val _uiState = MutableStateFlow<ToolExecutionState>(ToolExecutionState.Idle)
    val uiState: StateFlow<ToolExecutionState> = _uiState.asStateFlow()

    fun performAgentAction(prompt: String) {
        viewModelScope.launch {
            try {
                // Transition: Idle -> Thinking
                _uiState.value = ToolExecutionState.Thinking
                delay(1000) // Simulate LLM deciding tool

                // Transition: Thinking -> Calling
                val toolName = "fetchFlightStatus"
                val toolJob = Job() // Create a job specifically for the API call
                _uiState.value = ToolExecutionState.Calling(toolName, toolJob)

                // Simulate the legacy SOAP API call (3-7 seconds)
                withContext(Dispatchers.IO + toolJob) {
                    delay((3000..7000).random().toLong())
                }

                // Transition: Calling -> Integrating
                _uiState.value = ToolExecutionState.Integrating
                delay(1000) // Simulate LLM interpreting result

                // Transition: Integrating -> Idle
                _uiState.value = ToolExecutionState.Idle
            } catch (e: CancellationException) {
                _uiState.value = ToolExecutionState.Failed("Tool execution cancelled by user.")
                delay(2000)
                _uiState.value = ToolExecutionState.Idle
            } catch (e: Exception) {
                _uiState.value = ToolExecutionState.Failed(e.message ?: "Unknown Error")
            }
        }
    }

    fun cancelToolExecution() {
        val currentState = _uiState.value
        if (currentState is ToolExecutionState.Calling) {
            currentState.job.cancel()
        }
    }
}

@Composable
fun TravelAssistantScreen(viewModel: TravelAgentViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // UI Feedback based on FSM state
        Text(
            text = when (state) {
                is ToolExecutionState.Idle -> "Ready to help!"
                is ToolExecutionState.Thinking -> "Agent is thinking..."
                is ToolExecutionState.Calling -> "Calling ${(state as ToolExecutionState.Calling).toolName}..."
                is ToolExecutionState.Integrating -> "Processing flight data..."
                is ToolExecutionState.Failed -> "Error: ${(state as ToolExecutionState.Failed).error}"
            },
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = text,
            onValueChange = { text = it },
            enabled = state is ToolExecutionState.Idle,
            label = { Text("Enter flight number") }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { viewModel.performAgentAction(text) },
                enabled = state is ToolExecutionState.Idle
            ) {
                Text("Send")
            }

            if (state is ToolExecutionState.Calling) {
                Button(
                    onClick = { viewModel.cancelToolExecution() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}
