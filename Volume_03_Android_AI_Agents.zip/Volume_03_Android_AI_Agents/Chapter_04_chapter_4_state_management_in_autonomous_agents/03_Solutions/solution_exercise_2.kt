
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.room.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

// 1. Message Model
data class ChatMessage(
    val id: Long = 0,
    val role: Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Role { USER, ASSISTANT, SYSTEM }

// Room Persistence
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val timestamp: Long
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Insert
    suspend fun insert(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id IN (:ids)")
    suspend fun deleteMessages(ids: List<Long>)
}

// 3. Pruning Logic
class ConversationManager(private val dao: MessageDao) {
    private val TOKEN_LIMIT = 3000
    private val CHARS_PER_TOKEN = 4

    // Token Estimation helper
    fun estimateTokens(text: String): Int = text.length / CHARS_PER_TOKEN

    suspend fun addMessage(role: Role, content: String) {
        dao.insert(MessageEntity(role = role.name, content = content, timestamp = System.currentTimeMillis()))
        
        // Check if pruning is needed
        val currentMessages = dao.getAllMessages().first()
        val totalTokens = currentMessages.sumOf { estimateTokens(it.content) }

        if (totalTokens > TOKEN_LIMIT) {
            summarizeOldMessages(currentMessages)
        }
    }

    private suspend fun summarizeOldMessages(messages: List<MessageEntity>) {
        // Take the first 50% of the conversation
        val splitIndex = messages.size / 2
        val toSummarize = messages.take(splitIndex)
        val idsToRemove = toSummarize.map { it.id }

        // Simulate LLM call to summarize
        val summaryText = simulateLLMSummary(toSummarize)

        // Replace with a single System message
        dao.insert(MessageEntity(
            role = Role.SYSTEM.name,
            content = "Summary of previous conversation: $summaryText",
            timestamp = System.currentTimeMillis()
        ))

        // Remove the original fragmented messages
        dao.deleteMessages(idsToRemove)
    }

    private suspend fun simulateLLMSummary(messages: List<MessageEntity>): String {
        delay(1000) // Simulate network latency
        return "The user discussed their diet and morning workouts."
    }
}
