
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.room.*
import kotlinx.coroutines.flow.*

// 1. Memory Stores
@Entity(tableName = "semantic_memory")
data class SemanticMemory(@PrimaryKey val key: String, val value: String)

@Entity(tableName = "episodic_memory")
data class EpisodicMemory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val task: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM semantic_memory WHERE key LIKE '%' || :query || '%'")
    suspend fun searchSemantic(query: String): List<SemanticMemory>

    @Query("SELECT * FROM episodic_memory WHERE task LIKE '%' || :query || '%'")
    suspend fun searchEpisodic(query: String): List<EpisodicMemory>

    @Insert
    suspend fun saveEpisodic(memory: EpisodicMemory)
}

// 2. The Retrieval Engine
class MemoryRetriever(private val dao: MemoryDao) {
    suspend fun retrieveRelevantContext(currentQuery: String): String {
        val semantic = dao.searchSemantic(currentQuery)
        val episodic = dao.searchEpisodic(currentQuery)

        val semanticBlock = semantic.joinToString("\n") { "${it.key}: ${it.value}" }
        val episodicBlock = episodic.joinToString("\n") { "Past Task [${it.task}] Result: ${it.result}" }

        return "--- LONG TERM MEMORY ---\nUser Prefs:\n$semanticBlock\nPast Experiences:\n$episodicBlock\n------------------------"
    }
}

// 3. Augmented State Loop
class FinanceAgent(
    private val retriever: MemoryRetriever,
    private val dao: MemoryDao
) {
    suspend fun generatePrompt(userQuery: String, history: List<String>): String {
        val context = retriever.retrieveRelevantContext(userQuery)
        
        return """
            System: You are a Finance Agent.
            $context
            Conversation History: ${history.joinToString("\n")}
            User: $userQuery
        """.trimIndent()
    }

    // 4. Reflection Step
    suspend fun reflectOnTask(task: String, result: String, isImportant: Boolean) {
        if (isImportant) {
            dao.saveEpisodic(EpisodicMemory(task = task, result = result))
        }
    }
}
