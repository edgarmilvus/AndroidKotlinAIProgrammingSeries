
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.kt
// Description: Advanced Application
// ==========================================

package com.agent.search.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agent.search.domain.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MVI Intent representing user actions.
 */
sealed interface SearchIntent {
    data class PerformSearch(val query: String) : SearchIntent
    object Reset : SearchIntent
}

/**
 * MVI State representing the UI at any given time.
 */
data class SearchUiState(
    val status: SearchPipelineStatus = SearchPipelineStatus.Idle,
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class SearchToolViewModel @Inject constructor(
    private val repository: WebSearchRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    /**
     * Processes user intents. This is the entry point for the UI.
     */
    fun handleIntent(intent: SearchIntent) {
        when (intent) {
            is SearchIntent.PerformSearch -> executeSearch(intent.query)
            is SearchIntent.Reset -> _uiState.value = SearchUiState()
        }
    }

    private fun executeSearch(query: String) {
        viewModelScope.launch {
            repository.executeAdvancedSearch(query)
                .collect { status ->
                    _uiState.update { currentState ->
                        currentState.copy(
                            status = status,
                            isLoading = status is SearchPipelineStatus.Searching || 
                                        status is SearchPipelineStatus.Filtering,
                            error = if (status is SearchPipelineStatus.Error) status.message else null
                        )
                    }
                }
        }
    }
}
