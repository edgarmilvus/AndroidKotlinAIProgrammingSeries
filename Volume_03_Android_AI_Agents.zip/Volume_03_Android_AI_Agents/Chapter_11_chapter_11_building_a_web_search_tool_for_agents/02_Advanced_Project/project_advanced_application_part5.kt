
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.kt
// Description: Advanced Application
// ==========================================

package com.agent.search.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agent.search.domain.SearchPipelineStatus
import com.agent.search.domain.SearchResult

@Composable
fun SearchToolScreen(viewModel: SearchToolViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var queryInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Search Input Area
        Row(modifier = Modifier.fillMaxWidth()) {
            TextField(
                value = queryInput,
                onValueChange = { queryInput = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask the Agent to search...") }
            )
            Button(
                onClick = { 
                    viewModel.handleIntent(SearchIntent.PerformSearch(queryInput)) 
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Search")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Pipeline Status Indicator
        StatusIndicator(state.status)

        // Results Area
        Box(modifier = Modifier.weight(1f)) {
            if (state.status is SearchPipelineStatus.Success) {
                ResultsList(state.status.refinedResults)
            } else if (state.error != null) {
                Text("Error: ${state.error}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun StatusIndicator(status: SearchPipelineStatus) {
    when (status) {
        is SearchPipelineStatus.Searching -> Text("🌐 Querying Web Engines...", style = MaterialTheme.typography.bodySmall)
        is SearchPipelineStatus.Filtering -> Text("🧠 NPU: Reranking & Filtering Results...", style = MaterialTheme.typography.bodySmall)
        else -> {}
    }
}

@Composable
fun ResultsList(results: List<SearchResult>) {
    LazyColumn {
        items(results) { result ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = result.title, style = MaterialTheme.typography.titleMedium)
                    Text(text = result.snippet, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "Relevance: ${(result.relevanceScore * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
