
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.agent.search.domain

import kotlinx.coroutines.flow.Flow

/**
 * Represents a single piece of information retrieved from the web.
 */
data class SearchResult(
    val title: String,
    val snippet: String,
    val url: String,
    val relevanceScore: Float = 0.0f // Calculated by the local NPU scorer
)

/**
 * Represents the different states of the search pipeline.
 */
sealed interface SearchPipelineStatus {
    object Idle : SearchPipelineStatus
    data class Searching(val query: String) : SearchPipelineStatus
    data class Filtering(val resultsCount: Int) : SearchPipelineStatus
    data class Success(val refinedResults: List<SearchResult>) : SearchPipelineStatus
    data class Error(val message: String) : SearchPipelineStatus
}

/**
 * The core interface for the Web Search Tool.
 * This is what the AI Agent's Tool-Calling mechanism will interact with.
 */
interface WebSearchRepository {
    /**
     * Executes a multi-stage search: 
     * 1. Remote Query -> 2. Local Semantic Scoring -> 3. Context Optimization
     */
    fun executeAdvancedSearch(query: String): Flow<SearchPipelineStatus>
}
