
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Theoretical orchestration loop
suspend fun agentLoop(userQuery: String) = withContext(Dispatchers.Default) {
    var currentContext = userQuery
    
    while (agentNeedsMoreInfo()) {
        // Inference happens on a specialized AI dispatcher or via AICore's async API
        val response = aiCoreClient.generateResponse(currentContext) 
        
        if (response.hasToolCall) {
            val toolCall = response.toolCall ?: throw IllegalStateException()
            
            // Switch to IO for the web search
            val observation = withContext(Dispatchers.IO) {
                webSearchTool.execute(toolCall.arguments["query"])
            }
            
            // Append the observation to the context for the next iteration
            currentContext += "\nObservation: $observation"
        } else {
            return@withContext response.text
        }
    }
}
