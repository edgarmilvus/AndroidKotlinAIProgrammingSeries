
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

// 1. State Modeling
sealed interface AgentState {
    object Idle : AgentState
    object Thinking : AgentState
    data class Searching(val query: String) : AgentState
    object Synthesizing : AgentState
}

class AgentViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState: StateFlow<AgentState> = _uiState.asStateFlow()

    fun performSearchTask(prompt: String) {
        viewModelScope.launch {
            _uiState.value = AgentState.Thinking
            delay(1000) // Simulate LLM processing

            val query = "Tokyo festivals 2024" // Mock extracted query
            _uiState.value = AgentState.Searching(query)
            delay(2000) // Simulate Network Latency

            _uiState.value = AgentState.Synthesizing
            delay(1000) // Simulate Synthesis

            _uiState.value = AgentState.Idle
        }
    }
}

@Composable
fun AgentStatusScreen(viewModel: AgentViewModel) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 3. Compose UI Components with AnimatedContent
        AnimatedContent(
            targetState = state,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "AgentStateAnimation"
        ) { targetState ->
            when (targetState) {
                is AgentState.Idle -> Text("Ready to help!")
                is AgentState.Thinking -> CircularProgressIndicator()
                is AgentState.Searching -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        // Search Chip
                        SuggestionChip(
                            onClick = {}, 
                            label = { Text("Searching: ${targetState.query}") }
                        )
                    }
                }
                is AgentState.Synthesizing -> Text("Synthesizing answer... ✨")
            }
        }

        Spacer(Modifier.height(20.dp))
        Button(onClick = { viewModel.performSearchTask("Hello") }) {
            Text("Ask Agent")
        }
    }
}
