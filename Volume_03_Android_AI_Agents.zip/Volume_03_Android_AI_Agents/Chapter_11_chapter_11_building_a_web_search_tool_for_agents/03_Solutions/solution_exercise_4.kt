
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import com.google.ai.client.generativeai.type.*

class RecursiveAgent(private val model: GenerativeModel) {
    private val chat = model.startChat()
    private val maxIterations = 3

    suspend fun research(userPrompt: String): String {
        // Update system prompt for ReAct pattern
        val reactPrompt = "User Question: $userPrompt\n" +
            "Format your response as: Thought: <reasoning> | Action: <tool_call>"

        var currentPrompt = reactPrompt
        var iteration = 0

        while (iteration < maxIterations) {
            val response = chat.sendMessage(currentPrompt).first()
            val content = response.text ?: ""
            
            // Check for tool call in the response
            val functionCall = response.candidates.first().content.parts
                .filterIsInstance<FunctionCall>().firstOrNull()

            if (functionCall == null) {
                return content // No more tools needed, return final answer
            }

            // Execute tool (Mocked)
            val query = functionCall.args["query"] as? String ?: ""
            val searchResult = executeMockSearch(query)

            // Memory Persistence: Feed result back to chat
            chat.sendMessage(
                Content(
                    role = "function",
                    parts = listOf(FunctionResponse(functionCall.name, mapOf("result" to searchResult)))
                )
            )

            // Update loop state
            currentPrompt = "Continue reasoning based on the search result."
            iteration++
        }

        return "I reached the maximum search limit but here is what I found: ${chat.sendMessage("Summarize").first().text}"
    }

    private fun executeMockSearch(query: String): String {
        return when {
            query.contains("acquired Figma") -> "Adobe attempted to acquire Figma, but the deal was terminated in Dec 2023."
            query.contains("CEO of Adobe") -> "The current CEO of Adobe is Shantanu Narayen."
            else -> "No results."
        }
    }
}
