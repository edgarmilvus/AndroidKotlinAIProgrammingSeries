
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

data class SearchResult(val url: String, val content: String)

class TokenOptimizer {
    // 2. Relevance Scoring: Keyword Density + Position Bias
    private fun calculateScore(query: String, content: String, index: Int): Double {
        val keywords = query.lowercase().split(" ")
        val wordCount = keywords.count { content.lowercase().contains(it) }
        
        // Position Bias: Top 3 results get a boost
        val positionBoost = if (index < 3) 2.0 else 1.0
        return wordCount * positionBoost
    }

    // 3. Content Truncation: Limit to X words without cutting mid-sentence
    private fun truncateContent(text: String, maxWords: Int = 100): String {
        val words = text.split(" ")
        if (words.size <= maxWords) return text
        
        val truncated = words.take(maxWords).joinToString(" ")
        // Regex to find the last sentence-ending punctuation
        val lastSentenceEnd = truncated.lastIndexOfAny(charArrayOf('.', '!', '?'))
        
        return if (lastSentenceEnd != -1) {
            truncated.substring(0, lastSentenceEnd + 1)
        } else {
            truncated + "..."
        }
    }

    // 1. The Pruning Engine
    fun pruneResults(query: String, rawResults: List<SearchResult>): String {
        return rawResults
            .mapIndexed { index, result -> 
                val score = calculateScore(query, result.content, index)
                result to score 
            }
            .sortedByDescending { it.second } // Rank by score
            .take(3) // Keep only top 3
            .joinToString("\n\n") { (result, _) ->
                // 4. Context Summary Format
                val cleanText = truncateContent(result.content)
                "Source [${rawResults.indexOf(result) + 1}]: (${result.url}) - \"$cleanText\""
            }
    }
}

// Extension for lastIndexOfAny
private fun String.lastIndexOfAny(chars: CharArray): Int {
    for (i in this.length - 1 downTo 0) {
        if (chars.contains(this[i])) return i
    }
    return -1
}
