
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Content
import com.google.ai.client.generativeai.type.FunctionDeclaration
import com.google.ai.client.generativeai.type.Tool
import com.google.ai.client.generativeai.type.FunctionCall
import com.google.ai.client.generativeai.type.FunctionResponse
import kotlinx.coroutines.flow.first

// 1. Tool Definition: Define the search function schema
val searchTool = Tool(
    functionDeclarations = listOf(
        FunctionDeclaration(
            name = "web_search",
            description = "Search the web for real-time information, current events, or specific data",
            parameters = com.google.ai.client.generativeai.type.Schema.objectSchema(
                properties = mapOf(
                    "query" to com.google.ai.client.generativeai.type.Schema.stringSchema("The search query to look up")
                ),
                required = listOf("query")
            )
        )
    )
)

class TravelConciergeViewModel {
    private val model = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = "YOUR_API_KEY",
        tools = listOf(searchTool),
        // 3. System Prompting: Instructing the agent on when to use the tool
        systemInstruction = Content.text(
            "You are a Personal Travel Concierge. Use the web_search tool whenever the user asks for " +
            "real-time information, weather, or current events you are not certain about."
        )
    )

    private val chat = model.startChat()

    // Mock Search Service
    private fun mockWebSearch(query: String): String {
        return when {
            query.contains("weather", ignoreCase = true) -> "Tokyo Weather: 15°C, Partly Cloudy."
            query.contains("festival", ignoreCase = true) -> "Tokyo Festivals: Cherry Blossom festival happening this weekend in Ueno Park."
            else -> "No specific results found for $query."
        }
    }

    suspend fun askConcierge(userPrompt: String): String {
        // Step 1: Send user prompt to LLM
        var response = chat.sendMessage(userPrompt).first()
        
        // 2. The Interceptor Logic: Check if LLM wants to call a tool
        val functionCall = response.candidates.first().content.parts.filterIsInstance<FunctionCall>().firstOrNull()

        if (functionCall != null && functionCall.name == "web_search") {
            val query = functionCall.args["query"] as? String ?: ""
            
            // Execute the tool
            val searchResult = mockWebSearch(query)
            
            // Format as Tool Response and send back to LLM
            val toolResponse = Content(
                role = "function", 
                parts = listOf(FunctionResponse(functionCall.name, mapOf("result" to searchResult)))
            )
            
            // Final call to get the natural language answer
            response = chat.sendMessage(toolResponse).first()
        }

        return response.text ?: "I'm sorry, I couldn't process that."
    }
}
