
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.room.*
import kotlinx.coroutines.delay
import java.io.IOException

// 1. Search Cache Schema
@Entity(tableName = "search_cache")
data class SearchCache(
    @PrimaryKey val query: String,
    val results: String,
    val timestamp: Long
)

@Dao
interface SearchCacheDao {
    @Query("SELECT * FROM search_cache WHERE query = :query")
    suspend fun getCache(query: String): SearchCache?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCache(cache: SearchCache)
}

class SearchRepository(private val dao: SearchCacheDao, private val api: SearchApiService) {
    
    // 2. TTL Logic (e.g., 1 hour)
    private val TTL_MILLIS = 60 * 60 * 1000L

    suspend fun search(query: String): String {
        // 3. Interceptor Pattern
        val cached = dao.getCache(query)
        if (cached != null && (System.currentTimeMillis() - cached.timestamp) < TTL_MILLIS) {
            return cached.results // Cache Hit
        }

        // 4. Exponential Backoff for Rate Limits
        return retryWithBackoff {
            val freshResults = api.fetchWebSearch(query)
            dao.insertCache(SearchCache(query, freshResults, System.currentTimeMillis()))
            freshResults
        }
    }

    private suspend fun <T> retryWithBackoff(
        times: Int = 3, 
        initialDelay: Long = 1000, 
        block: suspend () -> T
    ): T {
        var currentDelay = initialDelay
        repeat(times - 1) {
            try {
                return block()
            } catch (e: IOException) {
                // Assume 429 Too Many Requests is wrapped in IOException
                delay(currentDelay)
                currentDelay *= 2 // Exponential increase
            }
        }
        return block() // Final attempt
    }
}

interface SearchApiService {
    suspend fun fetchWebSearch(query: String): String
}
