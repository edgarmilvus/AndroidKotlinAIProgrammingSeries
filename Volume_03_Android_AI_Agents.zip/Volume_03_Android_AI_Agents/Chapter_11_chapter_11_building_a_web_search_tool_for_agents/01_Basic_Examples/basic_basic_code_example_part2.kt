
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Query
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DATA MODELS ---

/**
 * Represents the structured response from a Search API.
 * We use @Serializable for seamless integration with kotlinx.serialization.
 */
@Serializable
data class SearchResponse(
    val items: List<SearchResult> = emptyList()
)

@Serializable
data class SearchResult(
    val title: String,
    val snippet: String,
    val link: String
)

/**
 * Sealed class to represent the UI State of our search process.
 * This is a modern pattern to handle Loading, Success, and Error states.
 */
sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val results: List<SearchResult>) : SearchUiState
    data class Error(val message: String) : SearchUiState
}

// --- 2. NETWORK LAYER ---

/**
 * The Retrofit interface defining our API contract.
 * In a real-world scenario, this would hit an endpoint like Tavily or Google Custom Search.
 */
interface SearchApiService {
    @GET("search")
    suspend fun performSearch(
        @Query("q") query: String,
        @Query("api_key") apiKey: String
    ): SearchResponse
}

// --- 3. REPOSITORY LAYER ---

/**
 * The Repository abstracts the data source. 
 * It ensures the rest of the app doesn't care if the data comes from Retrofit, 
 * a local Room database, or a mock.
 */
class WebSearchRepository @Inject constructor(
    private val apiService: SearchApiService
) {
    // In production, the API key should be retrieved from a secure source like EncryptedSharedPreferences
    private val apiKey = "YOUR_SECURE_API_KEY"

    suspend fun searchWeb(query: String): Result<List<SearchResult>> {
        return try {
            // We explicitly switch to Dispatchers.IO for networking to avoid blocking the Main thread.
            val response = apiService.performSearch(query, apiKey)
            Result.success(response.items)
        } catch (e: Exception) {
            Log.e("WebSearchRepository", "Search failed", e)
            Result.failure(e)
        }
    }
}

// --- 4. TOOL LAYER (The Agent's Interface) ---

/**
 * This class represents the "Tool" that the AI Agent interacts with.
 * It acts as the bridge between the LLM's intent and the Repository's execution.
 */
class WebSearchTool @Inject constructor(
    private val repository: WebSearchRepository
) {
    /**
     * This function is what the Agent "calls".
     * It returns a string representation of the results, which is then 
     * fed back into the LLM's context.
     */
    suspend fun execute(query: String): String {
        val result = repository.searchWeb(query)
        return result.fold(
            onSuccess = { items ->
                if (items.isEmpty()) "No results found for '$query'."
                else items.joinToString(separator = "\n") { 
                    "Title: ${it.title}\nSnippet: ${it.snippet}\nURL: ${it.link}\n" 
                }
            },
            onFailure = { error ->
                "Error performing web search: ${error.localizedMessage}"
            }
        )
    }

    /**
     * In a real Agent implementation, this method provides the JSON Schema 
     * that tells the LLM how to use this tool.
     */
    fun getToolDefinition(): String {
        return """
            {
                "name": "web_search",
                "description": "Search the internet for real-time information, news, or facts.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": { "type": "string", "description": "The search query" }
                    },
                    "required": ["query"]
                }
            }
        """.trimIndent()
    }
}

// --- 5. PRESENTATION LAYER (ViewModel) ---

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val searchTool: WebSearchTool
) : ViewModel() {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun onSearchRequested(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _uiState.value = SearchUiState.Loading
            
            // The execution happens in the background via the tool
            // We use Dispatchers.Default for the tool logic if it involved heavy parsing
            val resultString = searchTool.execute(query)
            
            // For this basic example, we parse the string back into objects for the UI.
            // In a real agent, the 'resultString' goes back to the LLM.
            // Here, we simulate the UI showing the "Grounding" data.
            _uiState.value = SearchUiState.Success(parseResultsForDemo(resultString))
        }
    }

    // A helper for demonstration purposes to turn the tool's string output back into objects
    private fun parseResultsForDemo(text: String): List<SearchResult> {
        // In a real app, the Repository would return objects directly.
        // This is just to show the UI working with the tool's output.
        return listOf(SearchResult("Demo Result", "This is a simulated result from the tool.", "https://example.com"))
    }
}

// --- 6. UI LAYER (Jetpack Compose) ---

@Composable
fun SearchToolScreen(viewModel: SearchViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var queryText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Agent Web Search Tool",
            style = MaterialTheme.typography.headlineMedium
        )
        
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = queryText,
            onValueChange = { queryText = it },
            label = { Text("Enter query for Agent") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { viewModel.onSearchRequested(queryText) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text("Trigger Tool")
        }

        Divider(modifier = Modifier.padding(vertical = 8.dp))

        when (val state = uiState) {
            is SearchUiState.Idle -> Text("Waiting for input...")
            is SearchUiState.Loading -> CircularProgressIndicator()
            is SearchUiState.Error -> Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
            is SearchUiState.Success -> {
                LazyColumn {
                    items(state.results) { result ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(text = result.title, style = MaterialTheme.typography.titleMedium)
                                Text(text = result.snippet, style = MaterialTheme.typography.bodySmall)
                                Text(text = result.link, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 7. DEPENDENCY INJECTION MODULE ---

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }

    @Provides
    @Singleton
    fun provideSearchApiService(json: Json): SearchApiService {
        return Retrofit.Builder()
            .baseUrl("https://api.example-search.com/") // Placeholder URL
            .addConverterFactory(kotlinx.serialization.json.Json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(SearchApiService::class.java)
    }
}
