
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.kt
// Description: Basic Code Example
// ==========================================

package com.example.aiagent.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SandboxScreen(viewModel: SandboxViewModel) {
    // collectAsStateWithLifecycle is the production-standard for observing flows in Compose
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "AI Agent Sandbox",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = uiState.inputCode,
            onValueChange = { viewModel.onCodeChanged(it) },
            label = { Text("Generated Code Snippet") },
            modifier = Modifier.fillMaxWidth().height(200.dp),
            placeholder = { Text("e.g., function calculate(a, b) { return a + b; }") }
        )

        Button(
            onClick = { viewModel.executeCode() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !uiState.isProcessing && uiState.inputCode.isNotBlank()
        ) {
            if (uiState.isProcessing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Text("Execute in Sandbox")
            }
        }

        Divider()

        Text(text = "Execution Result:", style = MaterialTheme.typography.titleMedium)

        ResultDisplay(uiState.result)
    }
}

@Composable
fun ResultDisplay(result: SandboxResult) {
    val (text, color) = when (result) {
        is SandboxResult.Success -> result.output to Color(0xFF2E7D32) // Green
        is SandboxResult.Error -> result.message to Color.Red
        is SandboxResult.Running -> "Executing logic..." to Color.Gray
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = color.copy(alpha = 0.1f),
        shape = MaterialTheme.shapes.medium
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(16.dp),
            color = color,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
