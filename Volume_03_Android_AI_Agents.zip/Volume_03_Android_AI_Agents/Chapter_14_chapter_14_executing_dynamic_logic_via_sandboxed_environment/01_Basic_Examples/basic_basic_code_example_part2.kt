
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.aiagent.sandbox

import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the outcome of a dynamic code execution attempt.
 */
sealed interface SandboxResult {
    data class Success(val output: String) : SandboxResult
    data class Error(val message: String, val exception: Throwable? = null) : SandboxResult
    object Running : SandboxResult
}

/**
 * The contract for our sandboxed environment.
 * In a real app, this would interface with a JNI-based engine like QuickJS.
 */
interface CodeSandbox {
    suspend fun execute(code: String): SandboxResult
}

/**
 * A simulated implementation of a sandbox.
 * This demonstrates the necessary threading patterns for CPU-bound tasks.
 */
@Singleton
class SimulatedJavaScriptSandbox @Inject constructor() : CodeSandbox {

    override suspend fun execute(code: String): SandboxResult = withContext(Dispatchers.Default) {
        try {
            // Simulate the overhead of spinning up a virtual machine/interpreter
            delay(1500) 

            // SECURITY CHECK: A primitive example of "Static Analysis"
            // In a real sandbox, this happens at the engine level.
            if (code.contains("System.exit") || code.contains("java.io.File")) {
                return@withContext SandboxResult.Error("Security Violation: Unauthorized API access detected.")
            }

            // Simulate code execution
            // In reality, the engine would parse the AST and execute instructions.
            if (code.isBlank()) {
                return@withContext SandboxResult.Error("Empty code provided.")
            }

            // Mocking a successful calculation result
            val mockResult = "Execution Output: ${code.hashCode().toString(16)}"
            SandboxResult.Success(mockResult)

        } catch (e: Exception) {
            SandboxResult.Error("Runtime Exception: ${e.localizedMessage}", e)
        }
    }
}
