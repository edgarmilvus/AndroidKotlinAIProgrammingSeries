
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.compose.runtime.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

// 1. Granular Capability Definitions
sealed class Capability {
    data class AccessCalendar(val dateRange: String) : Capability()
    data class SendEmail(val recipient: String, val subject: String) : Capability()
    data class GetLocation(val precision: String) : Capability()
}

// 2. The Mediator
class CapabilityMediator {
    // A flow to communicate requests to the UI layer
    private val _requestFlow = MutableSharedFlow<CapabilityRequest>()
    val requestFlow = _requestFlow.asSharedFlow()

    data class CapabilityRequest(
        val capability: Capability,
        val onApproved: () -> Unit,
        val onDenied: () -> Unit
    )

    suspend fun request(capability: Capability): Boolean {
        val approved = kotlinx.coroutines.CompletableDeferred<Boolean>()
        
        // Wrap the request into a flow-friendly object
        _requestFlow.emit(CapabilityRequest(
            capability = capability,
            onApproved = { approved.complete(true) },
            onDenied = { approved.complete(false) }
        ))

        return approved.await()
    }
}

// 3. The UI Layer (Jetpack Compose)
@Composable
fun ConsentDialog(mediator: CapabilityMediator) {
    val request by mediator.requestFlow.collectAsState(initial = null)
    var showDialog by remember { mutableStateOf(false) }
    var currentRequest by remember { mutableStateOf<CapabilityMediator.CapabilityRequest?>(null) }

    // Listen for new requests
    LaunchedEffect(Unit) {
        mediator.requestFlow.collect { request ->
            currentRequest = request
            showDialog = true
        }
    }

    if (showDialog && currentRequest != null) {
        AlertDialog(
            onDismissRequest = { 
                currentRequest?.onDenied()
                showDialog = false 
            },
            title = { Text("AI Permission Request") },
            text = {
                val message = when (val cap = currentRequest!!.capability) {
                    is Capability.SendEmail -> "The AI wants to send an email to ${cap.recipient}."
                    is Capability.AccessCalendar -> "The AI wants to read your calendar for ${cap.dateRange}."
                    is Capability.GetLocation -> "The AI wants to access your location."
                }
                Text(message)
            },
            confirmButton = {
                Button(onClick = {
                    currentRequest!!.onApproved()
                    showDialog = false
                }) { Text("Allow") }
            },
            dismissButton = {
                TextButton(onClick = {
                    currentRequest!!.onDenied()
                    showDialog = false
                }) { Text("Deny") }
            }
        )
    }
}

// 4. Implementation in ViewModel
class PersonalAssistantViewModel(private val mediator: CapabilityMediator) : ViewModel() {
    
    fun performAgentAction(intent: String) {
        viewModelScope.launch {
            if (intent == "send_email") {
                val emailCap = Capability.SendEmail("boss@work.com", "Report")
                val isAllowed = mediator.request(emailCap)
                
                if (isAllowed) {
                    executeActualEmail(emailCap)
                } else {
                    println("Agent: User denied email permission.")
                }
            }
        }
    }

    private fun executeActualEmail(cap: Capability.SendEmail) {
        // Here you would call the actual Android Intent/SmsManager
        println("Executing: Sending email to ${cap.recipient}")
    }
}
