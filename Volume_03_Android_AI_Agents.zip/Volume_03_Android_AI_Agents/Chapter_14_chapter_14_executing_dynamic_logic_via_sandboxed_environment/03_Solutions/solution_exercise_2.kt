
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Define the strictly typed "Tools"
@Serializable
sealed class AgentTool {
    @Serializable
    @SerialName("set_temperature")
    data class SetTemperature(val celsius: Int) : AgentTool()

    @Serializable
    @SerialName("toggle_light")
    data class ToggleLight(val room: String, val isOn: Boolean) : AgentTool()
}

// 2. Custom Exceptions
class ToolNotFoundException(message: String) : Exception(message)
class ToolExecutionException(message: String) : Exception(message)

// 3. The Dispatcher (The Gatekeeper)
@Singleton
class ToolDispatcher @Inject constructor() {
    
    private val json = Json { 
        ignoreUnknownKeys = true 
        classDiscriminator = "type" // Maps JSON "type" field to SerialName
    }

    fun dispatch(jsonInput: String): String {
        return try {
            // Parse the JSON into the sealed class
            val tool = json.decodeFromString<AgentTool>(jsonInput)
            
            // Execute the logic based on the type (The Whitelist)
            executeTool(tool)
        } catch (e: SerializationException) {
            throw ToolNotFoundException("LLM provided an unknown or malformed tool: ${e.message}")
        }
    }

    private fun executeTool(tool: AgentTool): String {
        return when (tool) {
            is AgentTool.SetTemperature -> {
                // Logic to interface with Smart Home Hardware
                "Temperature set to ${tool.celsius}°C"
            }
            is AgentTool.ToggleLight -> {
                // Logic to interface with Smart Home Hardware
                "Light in ${tool.room} turned ${if (tool.isOn) "ON" else "OFF"}"
            }
        }
    }
}

// Example Usage in a ViewModel
class SmartHomeViewModel @Inject constructor(
    private val dispatcher: ToolDispatcher
) : ViewModel() {
    
    fun handleLlmOutput(jsonPayload: String) {
        try {
            val result = dispatcher.dispatch(jsonPayload)
            println("Success: $result")
        } catch (e: Exception) {
            println("Security/Logic Error: ${e.message}")
        }
    }
}

/* 
  Simulated LLM JSON Inputs:
  Valid: {"type": "set_temperature", "celsius": 22}
  Valid: {"type": "toggle_light", "room": "Kitchen", "isOn": true}
  Invalid (Attack): {"type": "wipe_user_data", "id": 123} -> Throws ToolNotFoundException
*/
