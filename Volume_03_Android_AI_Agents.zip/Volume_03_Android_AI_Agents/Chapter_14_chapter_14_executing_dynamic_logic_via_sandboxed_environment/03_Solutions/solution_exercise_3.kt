
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

interface VirtualFileSystem {
    suspend fun writeFile(path: String, content: ByteArray)
    suspend fun readFile(path: String): ByteArray
    suspend fun listFiles(directory: String): List<String>
    suspend fun deleteFile(path: String)
}

class MemoryVFS : VirtualFileSystem {
    private val storage = mutableMapOf<String, ByteArray>()
    private val mutex = Mutex()
    private val ROOT_DIR = "/agent_workspace"

    /**
     * The "Path Jail": Normalizes the path and ensures it stays within ROOT_DIR.
     */
    private fun sanitizePath(requestedPath: String): String {
        // 1. Remove leading slashes to prevent absolute path confusion
        val normalized = requestedPath.removePrefix("/")
            .replace("\\", "/") // Standardize separators
            
        // 2. Use a manual approach to resolve ".." to prevent traversal
        val pathStack = mutableListOf<String>()
        for (segment in normalized.split("/")) {
            when {
                segment.isEmpty() || segment == "." -> continue
                segment == ".." -> if (pathStack.isNotEmpty()) pathStack.removeAt(pathStack.size - 1)
                else -> pathStack.add(segment)
            }
        }
        
        val finalPath = "$ROOT_DIR/${pathStack.joinToString("/")}"
        
        // 3. Final safety check: Does the resolved path still start with our root?
        if (!finalPath.startsWith(ROOT_DIR)) {
            throw SecurityException("Directory Traversal Attempt Detected!")
        }
        return finalPath
    }

    override suspend fun writeFile(path: String, content: ByteArray) = mutex.withLock {
        val safePath = sanitizePath(path)
        storage[safePath] = content
    }

    override suspend fun readFile(path: String): ByteArray = mutex.withLock {
        val safePath = sanitizePath(path)
        return storage[safePath] ?: throw Exception("File not found: $path")
    }

    override suspend fun listFiles(directory: String): List<String> = mutex.withLock {
        val safeDir = sanitizePath(directory)
        return storage.keys
            .filter { it.startsWith(safeDir) && it != safeDir }
            .map { it.removePrefix(safeDir).removePrefix("/") }
    }

    override suspend fun deleteFile(path: String) = mutex.withLock {
        val safePath = sanitizePath(path)
        storage.remove(safePath)
    }
}
