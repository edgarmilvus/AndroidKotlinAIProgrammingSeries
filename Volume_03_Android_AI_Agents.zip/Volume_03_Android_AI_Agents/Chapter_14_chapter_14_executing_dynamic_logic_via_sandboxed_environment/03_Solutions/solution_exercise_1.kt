
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import net.objecthunter.exp4j.ExpressionBuilder // Assuming exp4j dependency

// Custom Exceptions for granular error handling
sealed class SandboxException(message: String) : Exception(message)
class SandboxSecurityException(message: String) : SandboxException(message)
class SandboxSyntaxException(message: String) : SandboxException(message)

interface ExpressionSandbox {
    fun evaluate(expression: String): Double
}

class MathExpressionSandbox : ExpressionSandbox {
    // Strict whitelist: Only digits, operators, parentheses, dots, and spaces
    private val whitelistRegex = Regex("^[0-9+\\-*/().%\\s]+$")

    override fun evaluate(expression: String): Double {
        val trimmed = expression.trim()

        // 1. Security Guard: Check for forbidden characters/commands
        if (!whitelistRegex.matches(trimmed)) {
            throw SandboxSecurityException("Security Violation: Illegal characters detected in expression.")
        }

        return try {
            // 2. Parsing: Using exp4j to build an AST and evaluate
            ExpressionBuilder(trimmed).build().evaluate()
        } catch (e: Exception) {
            // 3. Error Handling: Distinguish between bad math and system errors
            throw SandboxSyntaxException("Syntax Error: The expression is mathematically invalid.")
        }
    }
}

class FinanceViewModel : ViewModel() {
    private val sandbox: ExpressionSandbox = MathExpressionSandbox()
    
    private val _uiState = MutableStateFlow<EvalState>(EvalState.Idle)
    val uiState = _uiState.asStateFlow()

    sealed class EvalState {
        object Idle : EvalState()
        object Loading : EvalState()
        data class Success(val result: Double) : EvalState()
        data class Error(val message: String) : EvalState()
    }

    fun processExpression(input: String) {
        _uiState.value = EvalState.Loading
        try {
            val result = sandbox.evaluate(input)
            _uiState.value = EvalState.Success(result)
        } catch (e: SandboxException) {
            _uiState.value = EvalState.Error(e.message ?: "Unknown Error")
        } catch (e: Exception) {
            _uiState.value = EvalState.Error("Unexpected Error")
        }
    }
}

// --- Jetpack Compose UI ---
@Composable
fun FinanceSandboxScreen(viewModel: FinanceViewModel) {
    var inputText by remember { mutableStateOf("") }
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("LLM Generated Math") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.processExpression(inputText) },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("Evaluate Safely")
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (val s = state) {
            is FinanceViewModel.EvalState.Success -> Text("Result: ${s.result}", color = Color.Green)
            is FinanceViewModel.EvalState.Error -> Text("Error: ${s.message}", color = Color.Red)
            is FinanceViewModel.EvalState.Loading -> CircularProgressIndicator()
            else -> Text("Enter expression (e.g., 5000 * 0.8 - 400)")
        }
    }
}
