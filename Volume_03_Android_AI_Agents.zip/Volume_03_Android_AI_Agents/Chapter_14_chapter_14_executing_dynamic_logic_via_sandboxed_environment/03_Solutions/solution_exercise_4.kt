
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import android.util.Log

class SandboxExecutor(
    private val timeoutMillis: Long,
    private val memoryLimitBytes: Long
) {
    /**
     * Executes a block of code with a time-based watchdog and a 
     * simulated memory-based monitor.
     */
    suspend fun <T> executeWithWatchdog(block: suspend () -> T): Result<T> {
        return coroutineScope {
            // 1. Create a Job for the actual execution
            val executionJob = Job()
            val executionContext = coroutineContext + executionJob

            val result = try {
                // 2. The Time-Based Watchdog
                withTimeout(timeoutMillis) {
                    // Launch the actual work in a separate child job
                    val work = async(executionContext) {
                        block()
                    }

                    // 3. The Memory-Based Watchdog (Polling Monitor)
                    val monitor = launch(Dispatchers.Default) {
                        while (executionJob.isActive) {
                            val currentMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
                            if (currentMemory > memoryLimitBytes) {
                                Log.e("Sandbox", "Memory limit exceeded! Terminating...")
                                executionJob.cancel("Memory Limit Exceeded")
                                break
                            }
                            delay(100) // Poll every 100ms
                        }
                    }

                    val finalResult = work.await()
                    monitor.cancel() // Clean up monitor if work finishes
                    Result.success(finalResult)
                }
            } catch (e: TimeoutCancellationException) {
                Result.failure(Exception("Execution timed out (Infinite loop suspected)"))
            } catch (e: CancellationException) {
                Result.failure(Exception(e.message ?: "Execution terminated by watchdog"))
            } catch (e: Exception) {
                Result.failure(e)
            }

            // Ensure the job is cleaned up
            executionJob.cancel()
            result
        }
    }
}

// --- Demonstration of Cooperative Cancellation ---
suspend fun mainDemo() {
    val executor = SandboxExecutor(timeoutMillis = 2000, memoryLimitBytes = 100 * 1024 * 1024)

    // Scenario A: The Infinite Loop (Fails via Timeout)
    val resultA = executor.executeWithWatchdog {
        var i = 0
        while (true) {
            // CRITICAL: Without yield(), this loop is NOT cooperative and 
            // might block the thread, though withTimeout handles it at the coroutine level.
            yield() 
            i++
        }
    }
    println("Scenario A: ${resultA.exceptionOrNull()?.message}")

    // Scenario B: The Memory Hog (Fails via Memory Monitor)
    val resultB = executor.executeWithWatchdog {
        val list = mutableListOf<ByteArray>()
        while (true) {
            list.add(ByteArray(10 * 1024 * 1024)) // Add 10MB chunks
            yield() // Ensure we check for cancellation
        }
    }
    println("Scenario B: ${resultB.exceptionOrNull()?.message}")
}
