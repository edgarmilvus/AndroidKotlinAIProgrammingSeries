
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Implementation of a streaming reasoning state
sealed interface ReasoningStep {
    data class Thinking(val partialThought: String) : ReasoningStep
    data class CallingTool(val toolName: String, val arguments: Map<String, Any>) : ReasoningStep
    data class ToolResult(val output: String) : ReasoningStep
    data class FinalAnswer(val answer: String) : ReasoningStep
    data class Error(val message: String) : ReasoningStep
}

// The ViewModel manages the stream
class AgentViewModel @Inject constructor(
    private val agentRepository: AgentRepository
) : ViewModel() {

    // A StateFlow to hold the UI state, derived from the reasoning Flow
    private val _uiState = MutableStateFlow<AgentUiState>(AgentUiState.Idle)
    val uiState: StateFlow<AgentUiState> = _uiState.asStateFlow()

    fun processRequest(prompt: String) {
        viewModelScope.launch {
            agentRepository.executeAgentLoop(prompt)
                .catch { e -> _uiState.value = AgentUiState.Error(e.message) }
                .collect { step ->
                    // Update UI incrementally as the agent "thinks"
                    _uiState.value = AgentUiState.Reasoning(step)
                }
        }
    }
}
