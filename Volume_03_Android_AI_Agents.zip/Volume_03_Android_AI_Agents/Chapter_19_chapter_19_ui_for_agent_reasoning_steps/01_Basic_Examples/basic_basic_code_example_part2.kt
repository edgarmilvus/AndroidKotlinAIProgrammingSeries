
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DATA MODELS ---

/**
 * Represents the different types of reasoning steps an agent performs.
 */
sealed class ReasoningStep(
    val id: Long,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    class Thought(id: Long, content: String) : ReasoningStep(id, content)
    class Action(id: Long, content: String, val toolName: String) : ReasoningStep(id, content)
    class Observation(id: Long, content: String) : ReasoningStep(id, content)
    class Error(id: Long, content: String) : ReasoningStep(id, content)
}

/**
 * UI Model to map ReasoningStep to visual properties.
 */
data class StepUiModel(
    val id: Long,
    val text: String,
    val type: StepType,
    val icon: ImageVector,
    val color: Color
)

enum class StepType { THOUGHT, ACTION, OBSERVATION, ERROR }

// --- 2. DOMAIN/REPOSITORY LAYER ---

@Singleton
class AgentRepository @Inject constructor() {

    /**
     * Simulates an autonomous agent loop. 
     * In a real app, this would interface with a Gemini/OpenAI model 
     * and receive a stream of tokens or tool calls.
     */
    fun streamReasoningSteps(): Flow<ReasoningStep> = flow {
        var stepId = 0L
        
        // Step 1: The Thought
        emit(ReasoningStep.Thought(stepId++, "Analyzing user request: 'Set an alarm for 7 AM'"))
        delay(1500) // Simulate LLM latency

        // Step 2: The Action (Tool Call)
        emit(ReasoningStep.Action(stepId++, "Accessing System Clock API", "ClockManager"))
        delay(2000)

        // Step 3: The Observation
        emit(ReasoningStep.Observation(stepId++, "ClockManager successfully scheduled alarm for 07:00:00"))
        delay(1000)

        // Step 4: Final Thought
        emit(ReasoningStep.Thought(stepId++, "Task complete. Notifying user."))
    }.flowOn(Dispatchers.Default) // Ensure heavy simulation happens off the Main Thread
}

// --- 3. VIEWMODEL LAYER ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    private val _steps = MutableStateFlow<List<ReasoningStep>>(emptyList())
    val steps = _steps.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    fun startAgentTask() {
        viewModelScope.launch {
            _isProcessing.value = true
            _steps.value = emptyList() // Reset state

            repository.streamReasoningSteps().collect { step ->
                // Append the new step to the existing list
                _steps.value = _steps.value + step
            }
            
            _isProcessing.value = false
        }
    }
}

// --- 4. UI LAYER (JETPACK COMPOSE) ---

@Composable
fun AgentReasoningScreen(viewModel: AgentViewModel = hiltViewModel()) {
    // collectAsStateWithLifecycle is the production-ready way to collect flows in Compose
    val steps by viewModel.steps.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Agent Reasoning Feed",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.startAgentTask() },
            enabled = !isProcessing,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isProcessing) "Agent is working..." else "Run Agent Task")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // The Reasoning Feed
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = steps,
                key = { it.id } // CRITICAL: Use stable keys for performance
            ) { step ->
                ReasoningStepItem(step)
            }
        }
    }
}

@Composable
fun ReasoningStepItem(step: ReasoningStep) {
    // Map the domain model to UI properties
    val (text, type, icon, color) = when (step) {
        is ReasoningStep.Thought -> Triple(
            step.content, 
            StepType.THOUGHT, 
            Icons.Default.Info, 
            Color(0xFF673AB7) // Deep Purple
        )
        is ReasoningStep.Action -> Triple(
            "${step.toolName}: ${step.content}", 
            StepType.ACTION, 
            Icons.Default.Settings, 
            Color(0xFF0288D1) // Light Blue
        )
        is ReasoningStep.Observation -> Triple(
            step.content, 
            StepType.OBSERVATION, 
            Icons.Default.CheckCircle, 
            Color(0xFF388E3C) // Green
        )
        is ReasoningStep.Error -> Triple(
            step.content, 
            StepType.ERROR, 
            Icons.Default.Info, // Replace with error icon in real app
            Color.Red
        )
    }

    // Use AnimatedVisibility to make new steps "pop" in smoothly
    AnimatedVisibility(
        visible = true,
        enter = fadeIn() + expandVertically()
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = color.copy(alpha = 0.1f)
            )
        ) {
            Row(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = text,
                    color = color.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// --- 5. ENTRY POINT ---

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AgentReasoningScreen()
                }
            }
        }
    }
}
