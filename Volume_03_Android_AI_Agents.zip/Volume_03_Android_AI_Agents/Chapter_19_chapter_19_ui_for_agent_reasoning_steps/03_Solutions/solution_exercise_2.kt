
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ToolStatus {
    object Idle : ToolStatus()
    data class Executing(val toolName: String, val parameters: Map<String, Any>) : ToolStatus()
    data class Success(val result: String) : ToolStatus()
    data class Failure(val error: String) : ToolStatus()
}

class ToolViewModel : ViewModel() {
    private val _status = MutableStateFlow<ToolStatus>(ToolStatus.Idle)
    val status = _status.asStateFlow()

    fun runTool() {
        viewModelScope.launch {
            val params = mapOf("device" to "living_room_light", "action" to "on")
            _status.value = ToolStatus.Executing("SmartHomeTool", params)
            
            delay(2000) // Simulate network/hardware latency

            // Simulate 50/50 success/failure
            if (Math.random() > 0.5) {
                _status.value = ToolStatus.Success("Light turned on successfully.")
            } else {
                _status.value = ToolStatus.Failure("Device unreachable: Timeout.")
            }
        }
    }

    fun reset() {
        _status.value = ToolStatus.Idle
    }
}

@Composable
fun ToolExecutionComponent(viewModel: ToolViewModel) {
    val status by viewModel.status.collectAsState()

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedContent(
            targetState = status,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            }, 
            label = "ToolStatusTransition"
        ) { targetStatus ->
            when (targetStatus) {
                is ToolStatus.Idle -> {
                    Button(onClick = { viewModel.runTool() }) {
                        Text("Execute Smart Home Command")
                    }
                }
                is ToolStatus.Executing -> {
                    ToolExecutingCard(targetStatus.toolName, targetStatus.parameters)
                }
                is ToolStatus.Success -> {
                    ToolResultCard(
                        icon = Icons.Default.Check,
                        color = Color(0xFF4CAF50),
                        message = targetStatus.result,
                        onRetry = { viewModel.runTool() }
                    )
                }
                is ToolStatus.Failure -> {
                    ToolResultCard(
                        icon = Icons.Default.Error,
                        color = MaterialTheme.colorScheme.error,
                        message = targetStatus.error,
                        onRetry = { viewModel.runTool() }
                    )
                }
            }
        }
    }
}

@Composable
fun ToolExecutingCard(toolName: String, params: Map<String, Any>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Text(text = "Calling $toolName...", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(
                text = params.toString(),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ToolResultCard(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, message: String, onRetry: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(48.dp))
            Text(text = message, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onRetry) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Retry")
            }
        }
    }
}
