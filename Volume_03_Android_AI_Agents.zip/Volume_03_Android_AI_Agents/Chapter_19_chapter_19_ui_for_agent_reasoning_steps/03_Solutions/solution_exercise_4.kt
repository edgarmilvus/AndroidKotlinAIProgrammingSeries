
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@Immutable // Crucial for performance optimization
data class ReasoningStep(
    val id: Long,
    val message: String,
    val timestamp: Long
)

class HighFrequencyViewModel : ViewModel() {
    private val _rawSteps = MutableStateFlow<List<ReasoningStep>>(emptyList())
    
    // The Optimized Flow
    val optimizedSteps: StateFlow<List<ReasoningStep>> = _rawSteps
        .sample(150) // Only emit updates every 150ms (approx 6.6 updates/sec)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        simulateHighFrequencyStream()
    }

    private fun simulateHighFrequencyStream() {
        viewModelScope.launch {
            var count = 0L
            while (true) {
                delay(40) // 25 updates per second
                val newStep = ReasoningStep(count++, "Agent thought $count", System.currentTimeMillis())
                _rawSteps.value = _rawSteps.value + newStep
            }
        }
    }
}

@Composable
fun OptimizedReasoningLog(viewModel: HighFrequencyViewModel) {
    // Using collectAsStateWithLifecycle is preferred in production
    val steps by viewModel.optimizedSteps.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            "High-Frequency Stream (Optimized)",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )
        
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Using id as key is vital for efficient diffing
            items(steps, key = { it.id }) { step ->
                ListItem(
                    headlineContent = { Text(step.message) },
                    supportingContent = { Text("${step.timestamp}") }
                )
                HorizontalDivider(thickness = 0.5.dp)
            }
        }
    }
}
