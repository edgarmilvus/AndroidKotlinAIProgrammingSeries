
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

// 1. Data Modeling
sealed interface ReasoningStep {
    val timestamp: Long
    val message: String

    data class Thought(override val message: String, override val timestamp: Long) : ReasoningStep
    data class Action(val toolName: String, override val message: String, override val timestamp: Long) : ReasoningStep
    data class Observation(val resultSummary: String, override val timestamp: Long) : ReasoningStep {
        override val message: String get() = resultSummary
    }
}

// 2. State Management
@HiltViewModel
class ReasoningViewModel @Inject constructor() : ViewModel() {
    private val _steps = MutableStateFlow<List<ReasoningStep>>(emptyList())
    val steps: StateFlow<List<ReasoningStep>> = _steps.asStateFlow()

    init {
        simulateAgentReasoning()
    }

    private fun simulateAgentReasoning() {
        viewModelScope.launch {
            val sequence = listOf(
                ReasoningStep.Thought("I need to identify the best time to visit Tokyo.", System.currentTimeMillis()),
                ReasoningStep.Action("FlightSearchTool", "Searching for flights from NYC to NRT...", System.currentTimeMillis()),
                ReasoningStep.Observation("Found 3 options under $1200.", System.currentTimeMillis()),
                ReasoningStep.Thought("Now analyzing weather patterns.", System.currentTimeMillis()),
                ReasoningStep.Action("WeatherAPI", "Fetching Tokyo weather for April.", System.currentTimeMillis()),
                ReasoningStep.Observation("April shows mild weather, high probability of cherry blossoms.", System.currentTimeMillis()),
                ReasoningStep.Thought("Compiling the final itinerary.", System.currentTimeMillis())
            )

            for (step in sequence) {
                delay(1500) // Mimic LLM latency
                _steps.value = _steps.value + step
            }
        }
    }
}

// 3. UI Implementation
@Composable
fun ReasoningLogView(viewModel: ReasoningViewModel) {
    val steps by viewModel.steps.collectAsState()
    val listState = rememberLazyListState()

    // Auto-scroll logic
    LaunchedEffect(steps.size) {
        if (steps.isNotEmpty()) {
            listState.animateScrollToItem(steps.size - 1)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(steps, key = { it.hashCode() }) { step ->
            ReasoningStepItem(step)
        }
    }
}

@Composable
fun ReasoningStepItem(step: ReasoningStep) {
    val (color, icon, label) = when (step) {
        is ReasoningStep.Thought -> Triple(MaterialTheme.colorScheme.primaryContainer, Icons.Default.Info, "THOUGHT")
        is ReasoningStep.Action -> Triple(MaterialTheme.colorScheme.secondaryContainer, Icons.Default.Settings, "ACTION")
        is ReasoningStep.Observation -> Triple(MaterialTheme.colorScheme.tertiaryContainer, Icons.Default.CheckCircle, "OBSERVATION")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(text = label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(text = step.message, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
