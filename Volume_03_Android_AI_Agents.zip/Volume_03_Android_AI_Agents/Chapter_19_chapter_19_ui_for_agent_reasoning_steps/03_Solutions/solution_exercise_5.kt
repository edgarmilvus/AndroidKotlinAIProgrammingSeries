
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

data class VisualPerception(
    val elementId: String,
    val relativeRect: Rect, // Normalized coordinates (0.0 to 1.0)
    val confidence: Float
)

@Composable
fun PerceptionOverlay(
    perceptions: List<VisualPerception>,
    modifier: Modifier = Modifier
) {
    // Animate the scanning line
    val infiniteTransition = rememberInfiniteTransition(label = "Scanner")
    val scanLineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "ScanLine"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        // 1. Draw the Scanning Line
        val scanY = scanLineOffset * canvasHeight
        drawLine(
            color = Color.Cyan.copy(alpha = 0.5f),
            start = Offset(0f, scanY),
            end = Offset(canvasWidth, scanY),
            strokeWidth = 2.dp.toPx()
        )

        // 2. Draw Bounding Boxes
        perceptions.forEach { perception ->
            val rect = perception.relativeRect
            // Map normalized coordinates to actual pixel coordinates
            val left = rect.left * canvasWidth
            val top = rect.top * canvasHeight
            val right = rect.right * canvasWidth
            val bottom = rect.bottom * canvasHeight

            val boxRect = Rect(Offset(left, top), Offset(right, bottom))

            // Pulse effect for the box
            val pulse = (Math.sin(scanLineOffset * Math.PI * 2).toFloat() + 1f) / 2f
            
            drawRect(
                color = Color.Cyan.copy(alpha = 0.3f + (pulse * 0.4f)),
                topLeft = boxRect.topLeft,
                size = boxRect.size,
                style = Stroke(width = 2.dp.toPx())
            )
            
            // Draw corner accents for a "HUD" look
            drawRect(
                color = Color.Cyan,
                topLeft = boxRect.topLeft,
                size = androidx.compose.ui.geometry.Size(10.dp.toPx(), 2.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

@Composable
fun AgentPerceptionDemo() {
    // Mock Perceptions: Agent "sees" two buttons
    val perceptions by remember {
        mutableStateOf(
            listOf(
                VisualPerception("btn_login", Rect(0.1f, 0.2f, 0.4f, 0.3f), 0.98f),
                VisualPerception("input_user", Rect(0.1f, 0.4f, 0.9f, 0.5f), 0.92f)
            )
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // The "Real" UI
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center
        ) {
            OutlinedTextField(value = "", onValueChange = {}, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Text("Login")
            }
        }

        // The Perception Overlay (Layered on top)
        PerceptionOverlay(perceptions = perceptions)
    }
}
