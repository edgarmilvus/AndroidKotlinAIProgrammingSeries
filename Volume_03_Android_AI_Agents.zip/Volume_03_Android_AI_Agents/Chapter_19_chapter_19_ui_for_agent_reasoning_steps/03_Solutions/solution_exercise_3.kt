
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

enum class NodeType { PLAN, TASK, TOOL_CALL, OBSERVATION }

data class AgentNode(
    val id: String,
    val summary: String,
    val type: NodeType,
    val children: List<AgentNode> = emptyList(),
    val rawMetadata: String? = null
)

@Composable
fun HierarchicalReasoningInspector(rootNodes: List<AgentNode>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(rootNodes, key = { it.id }) { node ->
            AgentNodeItem(node)
        }
    }
}

@Composable
fun AgentNodeItem(node: AgentNode) {
    // Localize the expansion state to this specific node
    var isExpanded by remember { mutableStateOf(false) }
    var showRawData by remember { mutableStateOf(false) }

    Column {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isExpanded = !isExpanded },
            colors = CardDefaults.cardColors(
                containerColor = getNodeColor(node.type)
            )
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Expansion Indicator
                if (node.children.isNotEmpty()) {
                    Icon(
                        if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                        contentDescription = null
                    )
                }

                Text(
                    text = "[${node.type}] ${node.summary}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )

                if (node.type == NodeType.TOOL_CALL && node.rawMetadata != null) {
                    TextButton(onClick = { showRawData = !showRawData }) {
                        Text("JSON", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Recursive Reveal
        AnimatedVisibility(visible = isExpanded) {
            Column(
                modifier = Modifier
                    .padding(start = 24.dp, top = 4.dp, bottom = 8.dp)
                    .fillMaxWidth()
            ) {
                node.children.forEach { child ->
                    AgentNodeItem(child = child)
                }
            }
        }

        // Raw Data Inspector
        AnimatedVisibility(visible = showRawData) {
            Card(
                modifier = Modifier
                    .padding(start = 32.dp, bottom = 8.dp)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Text(
                    text = node.rawMetadata ?: "",
                    modifier = Modifier.padding(12.dp),
                    color = Color.Green,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun getNodeColor(type: NodeType): Color = when (type) {
    NodeType.PLAN -> Color(0xFFE3F2FD)
    NodeType.TASK -> Color(0xFFF1F8E9)
    NodeType.TOOL_CALL -> Color(0xFFFFF3E0)
    NodeType.OBSERVATION -> Color(0xFFF3E5F5)
}
