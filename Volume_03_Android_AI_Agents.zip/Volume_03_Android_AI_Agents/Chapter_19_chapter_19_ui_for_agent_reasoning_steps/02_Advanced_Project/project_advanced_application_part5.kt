
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.kt
// Description: Advanced Application
// ==========================================

package com.agent.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agent.app.domain.model.*

@Composable
fun AgentReasoningScreen(
    state: AgentViewState,
    onExecute: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Agentic Reasoning Stream",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        // Input Area
        var textInput by remember { mutableStateOf("") }
        Row(modifier = Modifier.fillMaxWidth()) {
            TextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Enter goal...") }
            )
            Button(
                onClick = { 
                    onExecute(textInput)
                    textInput = ""
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Run")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // The Reasoning List
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = state.steps,
                key = { it.id } // CRITICAL: Prevents full list recomposition
            ) { step ->
                ReasoningStepItem(step)
            }
        }
        
        if (state.isProcessing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
    }
}

@Composable
fun ReasoningStepItem(step: ReasoningStep) {
    val backgroundColor = when (step.type) {
        is ReasoningStepType.Thought -> Color(0xFFE3F2FD) // Light Blue
        is ReasoningStepType.ToolCall -> Color(0xFFF3E5F5) // Light Purple
        is ReasoningStepType.Observation -> Color(0xFFE8F5E9) // Light Green
        is ReasoningStepType.Error -> Color(0xFFFFEBEE) // Light Red
        is ReasoningStepType.FinalAnswer -> Color(0xFFFFF3E0) // Light Orange
    }

    val iconLabel = when (step.type) {
        is ReasoningStepType.Thought -> "THOUGHT"
        is ReasoningStepType.ToolCall -> "ACTION"
        is ReasoningStepType.Observation -> "OBSERVATION"
        is ReasoningStepType.Error -> "ERROR"
        is ReasoningStepType.FinalAnswer -> "RESULT"
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = iconLabel,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                color = Color.DarkGray
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = step.content,
                style = MaterialTheme.typography.bodyMedium
            )
            if (step.metadata.isNotEmpty()) {
                Text(
                    text = step.metadata.entries.joinToString { "${it.key}: ${it.value}" },
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
