
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.agent.app.domain.model

import java.util.UUID

/**
 * Represents the type of cognitive step the agent is performing.
 */
sealed interface ReasoningStepType {
    data object Thought : ReasoningStepType      // Internal monologue
    data object ToolCall : ReasoningStepType     // Invoking an external API/Function
    data object Observation : ReasoningStepType  // Result received from a tool
    data object Error : ReasoningStepType        // A failure in the reasoning chain
    data object FinalAnswer : ReasoningStepType  // The terminal state
}

/**
 * A structured unit of the agent's reasoning process.
 * @param id Unique identifier for UI stability during recomposition.
 * @param type The nature of this reasoning step.
 * @param content The textual or structured content of the step.
 * @param metadata Additional context (e.g., tool name, latency, confidence).
 */
data class ReasoningStep(
    val id: UUID = UUID.randomUUID(),
    val type: ReasoningStepType,
    val content: String,
    val metadata: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * The aggregate state of the Agent's UI.
 */
data class AgentViewState(
    val isProcessing: Boolean = false,
    val steps: List<ReasoningStep> = emptyList(),
    val currentGoal: String? = null,
    val error: String? = null
)
