
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.kt
// Description: Advanced Application
// ==========================================

package com.agent.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.agent.app.data.repository.AgentRepository
import com.agent.app.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgentViewState())
    val uiState: StateFlow<AgentViewState> = _uiState.asStateFlow()

    fun executeAgentGoal(goal: String) {
        viewModelScope.launch {
            // Reset state for new goal
            _uiState.update { AgentViewState(isProcessing = true, currentGoal = goal) }

            repository.observeReasoning(goal)
                .onEach { step ->
                    // Update the state by appending the new step to the existing list
                    _uiState.update { currentState ->
                        currentState.copy(
                            isProcessing = step.type is ReasoningStepType.FinalAnswer || 
                                           step.type is ReasoningStepType.Error,
                            steps = currentState.steps + step
                        )
                    }
                }
                .catch { e ->
                    _uiState.update { it.copy(error = e.message, isProcessing = false) }
                }
                .collect()
        }
    }
}
