
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class ToolDefinition(
    val name: String,
    val description: String,
    val parameters: Map<String, String> // Param Name -> Type (e.g., "date" -> "string")
)

class ToolExecutor(private val service: AccessibilityService) {

    // Maps dynamic function names to actual executable code
    private val registry = mutableMapOf<String, (Map<String, Any>) -> Unit>()

    init {
        // Register core "Primitive" tools
        registerPrimitiveTools()
    }

    private fun registerPrimitiveTools() {
        registry["click"] = { params ->
            val x = params["x"] as Float
            val y = params["y"] as Float
            // Implementation of dispatchGesture at (x,y)
        }
        registry["type"] = { params ->
            val text = params["text"] as String
            // Implementation of AccessibilityNodeInfo.ACTION_SET_TEXT
        }
    }

    fun registerDynamicTool(definition: ToolDefinition) {
        // In a real scenario, this would be populated by the LLM's discovery phase
        // For this exercise, we simulate the bridge
        println("Registering discovered tool: ${definition.name}")
    }

    fun execute(toolName: String, arguments: Map<String, Any>) {
        val action = registry[toolName]
        if (action != null) {
            action(arguments)
        } else {
            throw IllegalArgumentException("Tool $toolName not found in registry.")
        }
    }
}

// The "Architect" Prompt logic (Conceptual)
val DISCOVERY_PROMPT = """
    Analyze this UI JSON: $uiJson
    Identify the primary capabilities of this screen.
    For each capability, return a JSON list of ToolDefinitions.
    Example: {"name": "search_item", "description": "Searches for a product", "parameters": {"query": "string"}}
""".trimIndent()
