
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.graphics.Rect
import android.graphics.Point
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Build

data class TargetedElement(
    val semanticElement: SemanticElement,
    val boundingBox: Rect,
    val normalizedCenter: PointF
)

data class PointF(val x: Float, val y: Float)

class CoordinateMapper(private val service: AccessibilityService) {

    // Normalized coordinates (0.0 to 1.0) to prevent resolution mismatch
    fun mapNodeToTarget(node: AccessibilityNodeInfo, screenWidth: Int, screenHeight: Int): TargetedElement? {
        val rect = Rect()
        if (node.getBoundsInScreen(rect)) {
            val centerX = (rect.left + rect.right) / 2f
            val centerY = (rect.top + rect.bottom) / 2f
            
            val normalizedCenter = PointF(
                centerX / screenWidth,
                centerY / screenHeight
            )
            
            return TargetedElement(
                semanticElement = SemanticElement(
                    id = node.viewIdResourceName ?: "id",
                    role = "UNKNOWN", // In practice, pass from Exercise 1
                    text = node.text?.toString(),
                    description = node.contentDescription?.toString(),
                    isClickable = node.isClickable
                ),
                boundingBox = rect,
                normalizedCenter = normalizedCenter
            )
        }
        return null
    }

    fun performClickAtNormalized(target: TargetedElement, screenWidth: Int, screenHeight: Int) {
        val absoluteX = (target.normalizedCenter.x * screenWidth).toInt()
        val absoluteY = (target.normalizedCenter.y * screenHeight).toInt()

        val path = android.graphics.Path().apply {
            moveTo(absoluteX.toFloat(), absoluteY.toFloat())
        }

        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, 100))
        
        service.dispatchGesture(builder.build(), object : android.accessibilityservice.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                // Log success
            }
        }, null)
    }
}
