
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

sealed class AgentPhase {
    object ANALYZING_SOURCE : AgentPhase()
    object EXTRACTING_DATA : AgentPhase()
    object NAVIGATING_TO_TARGET : AgentPhase()
    object INPUTTING_DATA : AgentPhase()
    data class ERROR(val message: String) : AgentPhase()
}

@Singleton
class AgentMemory @Inject constructor() {
    private val memory = mutableMapOf<String, String>()
    fun store(key: String, value: String) { memory[key] = value }
    fun get(key: String): String? = memory[key]
}

@HiltViewModel
class AgentOrchestrator @Inject constructor(
    private val memory: AgentMemory
) : ViewModel() {

    private val _currentPhase = MutableStateFlow<AgentPhase>(AgentPhase.ANALYZING_SOURCE)
    val currentPhase: StateFlow<AgentPhase> = _currentPhase

    fun onWindowChanged(packageName: String) {
        viewModelScope.launch {
            when (_currentPhase.value) {
                is AgentPhase.EXTRACTING_DATA -> {
                    // We just finished extracting, now we need to move
                    _currentPhase.value = AgentPhase.NAVIGATING_TO_TARGET
                    prepareNavigation(packageName)
                }
                is AgentPhase.NAVIGATING_TO_TARGET -> {
                    // We were navigating, now that the window changed, we are in the target app
                    _currentPhase.value = AgentPhase.INPUTTING_DATA
                }
                else -> { /* Handle other transitions */ }
            }
        }
    }

    private fun prepareNavigation(targetPackage: String) {
        // Logic to trigger Intent to launch target app
    }

    fun extractAndStore(key: String, value: String) {
        memory.store(key, value)
        _currentPhase.value = AgentPhase.EXTRACTING_DATA
    }
}
