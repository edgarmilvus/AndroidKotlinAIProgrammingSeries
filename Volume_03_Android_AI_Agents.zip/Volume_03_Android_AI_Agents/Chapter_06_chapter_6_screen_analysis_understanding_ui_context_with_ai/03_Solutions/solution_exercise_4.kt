
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.accessibilityservice.AccessibilityService

class HybridAnalysisEngine(private val service: AccessibilityService) {

    // Heuristic: If interactable nodes < 3, the screen is "Accessibility-Poor"
    fun shouldTriggerVisualFallback(nodes: List<SemanticElement>): Boolean {
        val interactableCount = nodes.count { it.isClickable }
        return interactableCount < 3
    }

    fun captureRegionOfInterest(fullScreenshot: Bitmap, rect: Rect): Bitmap {
        // Perform a high-resolution crop of a specific area
        // This is the "Foveated Vision" approach
        return Bitmap.createBitmap(
            fullScreenshot,
            rect.left.coerceAtLeast(0),
            rect.top.coerceAtLeast(0),
            rect.width().coerceAtMost(fullScreenshot.width - rect.left),
            rect.height().coerceAtMost(fullScreenshot.height - rect.top)
        )
    }

    fun createGridCrops(fullScreenshot: Bitmap, rows: Int, cols: Int): List<Bitmap> {
        val crops = mutableListOf<Bitmap>()
        val cellWidth = fullScreenshot.width / cols
        val cellHeight = fullScreenshot.height / rows

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cropRect = Rect(
                    c * cellWidth,
                    r * cellHeight,
                    (c + 1) * cellWidth,
                    (r + 1) * cellHeight
                )
                crops.add(Bitmap.createBitmap(
                    fullScreenshot, 
                    cropRect.left, 
                    cropRect.top, 
                    cropRect.width(), 
                    cropRect.height()
                ))
            }
        }
        return crops
    }
}
