
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

@Serializable
data class SemanticElement(
    val id: String,
    val role: String,
    val text: String?,
    val description: String?,
    val isClickable: Boolean
)

class ScreenSemanticParser(private val service: AccessibilityService) {

    private val jsonSerializer = Json { ignoreUnknownKeys = true; prettyPrint = false }

    fun parseCurrentScreen(): String {
        val rootNode = service.rootInActiveWindow ?: return "[]"
        val elements = mutableListOf<SemanticElement>()
        
        traverseTree(rootNode, elements)
        
        rootNode.recycle() // Important to prevent memory leaks
        return jsonSerializer.encodeToString(elements)
    }

    private fun traverseTree(node: AccessibilityNodeInfo, elements: MutableList<SemanticElement>) {
        // 1. Filtering Logic: Prune branches that aren't important for accessibility
        if (!node.isImportantForAccessibility || !node.isVisibleToUser) {
            return
        }

        // 2. Semantic Mapping: Convert class names to simple roles
        val role = mapClassNameToRole(node.className?.toString() ?: "")

        // 3. Meaningful Element Check: Only add if it has text, description, or is an interactive component
        val hasText = !node.text.isNullOrBlank()
        val hasDescription = !node.contentDescription.isNullOrBlank()
        val isInteractive = node.isClickable || node.isFocusable

        if (hasText || hasDescription || isInteractive) {
            elements.add(
                SemanticElement(
                    id = node.viewIdResourceName ?: "unknown_${node.hashCode()}",
                    role = role,
                    text = node.text?.toString(),
                    description = node.contentDescription?.toString(),
                    isClickable = node.isClickable
                )
            )
        }

        // 4. Recursive Traversal
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                traverseTree(child, elements)
                child.recycle() // Clean up child nodes during recursion
            }
        }
    }

    private fun mapClassNameToRole(className: String): String {
        return when {
            className.contains("Button") -> "BUTTON"
            className.contains("EditText") -> "TEXT_FIELD"
            className.contains("TextView") -> "TEXT"
            className.contains("CheckBox") -> "CHECKBOX"
            className.contains("ImageView") -> "IMAGE"
            else -> "VIEW"
        }
    }
}
