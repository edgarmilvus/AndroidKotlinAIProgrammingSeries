
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

/**
 * Represents the distilled semantic and visual state of the screen.
 */
@Serializable
data class ScreenContext(
    val timestamp: Long,
    val semanticNodes: List<SemanticNode>,
    val screenshotUri: Uri,
    val userIntent: String? = null
)

@Serializable
data class SemanticNode(
    val id: String,
    val role: String,
    val text: String?,
    val bounds: Rect, // Spatial coordinates
    val isEnabled: Boolean
)

/**
 * A production-ready provider that streams screen updates.
 */
class ScreenPerceptionProvider(
    private val accessibilityService: MyAccessibilityService,
    private val imageCapture: ImageCaptureUseCase
) {
    // We use a StateFlow to represent the "Current Reality" of the screen
    private val _screenState = MutableStateFlow<ScreenContext?>(null)
    val screenState: StateFlow<ScreenContext?> = _screenState.asStateFlow()

    // Using Coroutines to poll or react to UI changes
    suspend fun startObserving(scope: CoroutineScope) {
        accessibilityService.uiHierarchyFlow()
            .combine(imageCapture.screenshotFlow()) { hierarchy, screenshot ->
                // Combine structural and visual data
                ScreenContext(
                    timestamp = System.currentTimeMillis(),
                    semanticNodes = hierarchy.toSemanticNodes(),
                    screenshotUri = screenshot
                )
            }
            .flowOn(Dispatchers.Default) // Perform heavy combination off the main thread
            .collect { context ->
                _screenState.value = context
            }
    }
}
