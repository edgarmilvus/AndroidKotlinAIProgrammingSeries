
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

// Using Context Receivers to enforce semantic awareness
interface ScreenContext {
    val currentContext: ScreenContextData
}

context(ScreenContext)
suspend fun Agent.identifyPrimaryAction(): Action {
    // This function can only be called within a scope that provides ScreenContext
    val nodes = currentContext.semanticNodes
    return nodes.filter { it.role == "Button" && it.isEnabled }
        .maxByOrNull { it.importanceScore }
        ?.toAction() ?: Action.None
}

// Usage in a ViewModel/Presenter
class AgentViewModel(private val agent: Agent) : ViewModel() {
    
    fun performAutoFill(context: ScreenContext) {
        viewModelScope.launch {
            // The compiler ensures 'context' is passed to satisfy the context receiver
            with(context) {
                val action = agent.identifyPrimaryAction()
                execute(action)
            }
        }
    }
}
