
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.screen.analysis

import android.graphics.Bitmap
import android.graphics.Rect
import android.media.ImageReader
import androidx.annotation.OptIn
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.nio.ByteBuffer
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents a semantically understood UI element discovered through 
 * a fusion of visual detection and accessibility metadata.
 */
data class SemanticElement(
    val id: String,
    val label: String,
    val boundingBox: Rect,
    val confidence: Float,
    val type: ElementType
)

enum class ElementType { BUTTON, TEXT_FIELD, IMAGE, ICON, CONTAINER }

/**
 * MVI State for the Screen Analysis UI.
 */
data class ScreenAnalysisState(
    val isAnalyzing: Boolean = false,
    val detectedElements: List<SemanticElement> = emptyList(),
    val error: String? = null,
    val lastInferenceTimeMs: Long = 0L
)

/**
 * Hardware-aware Inference Engine.
 * This component encapsulates the complexity of NPU/GPU orchestration.
 */
class VisionInferenceEngine @Inject constructor() {
    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null

    @OptIn(ExperimentalStdlibApi::class)
    fun initialize(modelBuffer: ByteBuffer) {
        val options = Interpreter.Options().apply {
            // Attempt to use GPU for heavy tensor operations
            gpuDelegate = GpuDelegate()
            addDelegate(gpuDelegate)
            setNumThreads(4)
        }
        interpreter = Interpreter(modelBuffer, options)
    }

    /**
     * Performs inference on a bitmap. 
     * Uses Dispatchers.Default to ensure heavy math doesn't block the UI or IO.
     */
    suspend fun detectElements(bitmap: Bitmap): List<DetectionResult> = withContext(Dispatchers.Default) {
        if (interpreter == null) return@withContext emptyList()
        
        // 1. Pre-processing: Resize and Normalize bitmap to Tensor input
        val inputBuffer = preprocess(bitmap)
        
        // 2. Inference: Execute the model on the NPU/GPU
        val outputBuffer = Array(1) { Array(10) { FloatArray(6) } } // [batch][max_detections][coords+conf+class]
        interpreter?.run(inputBuffer, outputBuffer)

        // 3. Post-processing: Convert raw tensors to meaningful DetectionResults
        postProcess(outputBuffer)
    }

    private fun preprocess(bitmap: Bitmap): ByteBuffer {
        // Implementation of image normalization (e.g., scaling to 300x300 and 0.0-1.0 range)
        val buffer = ByteBuffer.allocateDirect(1 * 300 * 300 * 3 * 4)
        // ... pixel manipulation logic ...
        return buffer
    }

    private fun postProcess(output: Array<Array<FloatArray>>): List<DetectionResult> {
        // Logic to filter low-confidence detections and scale coordinates back to screen size
        return emptyList() // Placeholder for brevity
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
    }
}

data class DetectionResult(val rect: Rect, val label: String, val score: Float)

/**
 * The Repository: The single source of truth for screen context.
 * It manages the lifecycle of the screen capture stream and the inference loop.
 */
@Singleton
class ScreenAnalysisRepository @Inject constructor(
    private val visionEngine: VisionInferenceEngine
) {
    private val _analysisFlow = MutableSharedFlow<ScreenAnalysisState>(replay = 1)
    val analysisFlow: SharedFlow<ScreenAnalysisState> = _analysisFlow.asSharedFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var analysisJob: Job? = null

    /**
     * Starts the continuous analysis loop.
     * @param imageReader The ImageReader provided by MediaProjection.
     */
    fun startAnalysis(imageReader: ImageReader) {
        analysisJob?.cancel()
        analysisJob = scope.launch {
            _analysisFlow.emit(ScreenAnalysisState(isAnalyzing = true))

            // We use a producer-consumer pattern to handle frames
            imageReader.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                
                // Launch a new coroutine for each frame to allow concurrent processing
                // but we use a Mutex or a Semaphore in production to prevent frame piling.
                scope.launch {
                    processFrame(image)
                }
            }, Handler(Looper.getMainLooper())) 
            // Note: In high-performance apps, use a dedicated HandlerThread
        }
    }

    private suspend fun processFrame(image: android.media.Image) {
        val startTime = System.currentTimeMillis()
        try {
            // 1. Convert Image to Bitmap (Heavy operation)
            val bitmap = image.toBitmap() 

            // 2. Run AI Inference (NPU/GPU)
            val detections = visionEngine.detectElements(bitmap)

            // 3. Semantic Fusion (Logic to merge detections with Accessibility nodes)
            // This is where the "Agent" understands the screen
            val elements = fuseVisualAndSemanticData(detections)

            val duration = System.currentTimeMillis() - startTime
            _analysisFlow.emit(
                ScreenAnalysisState(
                    isAnalyzing = true,
                    detectedElements = elements,
                    lastInferenceTimeMs = duration
                )
            )
        } catch (e: Exception) {
            _analysisFlow.emit(ScreenAnalysisState(error = e.localizedMessage))
        } finally {
            image.close()
        }
    }

    private fun fuseVisualAndSemanticData(detections: List<DetectionResult>): List<SemanticElement> {
        // Production Logic: 
        // For each visual detection, query the AccessibilityNodeInfo tree.
        // If a visual box overlaps an Accessibility node, merge their metadata.
        return detections.map { 
            SemanticElement(
                id = "visual_${it.label}_${it.hashCode()}",
                label = it.label,
                boundingBox = it.rect,
                confidence = it.score,
                type = ElementType.BUTTON // Simplified
            )
        }
    }

    fun stopAnalysis() {
        analysisJob?.cancel()
        _analysisFlow.tryEmit(ScreenAnalysisState(isAnalyzing = false))
    }
}

/**
 * ViewModel: Orchestrates the UI state using MVI.
 */
@HiltViewModel
class ScreenContextViewModel @Inject constructor(
    private val repository: ScreenAnalysisRepository
) : ViewModel() {

    val uiState: StateFlow<ScreenAnalysisState> = repository.analysisFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ScreenAnalysisState()
        )

    fun beginCapture(imageReader: ImageReader) {
        repository.startAnalysis(imageReader)
    }

    fun endCapture() {
        repository.stopAnalysis()
    }
}
