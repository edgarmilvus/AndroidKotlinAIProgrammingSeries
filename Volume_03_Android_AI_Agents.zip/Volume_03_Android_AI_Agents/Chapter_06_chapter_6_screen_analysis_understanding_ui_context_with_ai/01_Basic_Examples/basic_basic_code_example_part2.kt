
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.aiagent.screenanalysis

import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// --- MODELS ---

/**
 * Represents the semantic meaning extracted from the screen.
 * Instead of just "Button", we get "Actionable Element: Checkout".
 */
data class SemanticElement(
    val label: String,
    val type: String,
    val confidence: Float,
    val bounds: Rect // Simplified representation of screen coordinates
)

data class Rect(val top: Int, val left: Int, val bottom: Int, val right: Int)

sealed interface ScreenAnalysisState {
    object Idle : ScreenAnalysisState
    object Analyzing : ScreenAnalysisState
    data class Success(val elements: List<SemanticElement>) : ScreenAnalysisState
    data class Error(val message: String) : ScreenAnalysisState
}

// --- ENGINE (The AI Core) ---

/**
 * Interface for the AI Engine. In a real app, this would wrap 
 * Gemini Nano (on-device) or a TFLite model.
 */
interface ScreenAnalysisEngine {
    suspend fun analyze(bitmap: Bitmap): List<SemanticElement>
}

/**
 * A mock implementation of the AI Engine for demonstration.
 * In production, this performs heavy tensor math.
 */
class MockScreenAnalysisEngine @Inject constructor() : ScreenAnalysisEngine {
    override suspend fun analyze(bitmap: Bitmap): List<SemanticElement> {
        // SIMULATION: Heavy AI Inference
        // We use Dispatchers.Default because AI inference is CPU-bound.
        return withContext(Dispatchers.Default) {
            delay(2000) // Simulate model latency
            
            // In a real scenario, the model would return these via a tensor output
            listOf(
                SemanticElement("Add to Cart", "Button", 0.98f, Rect(100, 100, 200, 300)),
                SemanticElement("Product Image", "Image", 0.92f, Rect(100, 400, 500, 800)),
                SemanticElement("Price: $49.99", "Text", 0.99f, Rect(50, 50, 150, 100))
            )
        }
    }
}

// --- REPOSITORY ---

class ScreenAnalysisRepository @Inject constructor(
    private val engine: ScreenAnalysisEngine
) {
    suspend fun performAnalysis(bitmap: Bitmap): Result<List<SemanticElement>> {
        return try {
            // The repository acts as a mediator, potentially adding 
            // image preprocessing (resizing/grayscale) before calling the engine.
            val results = engine.analyze(bitmap)
            Result.success(results)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// --- VIEWMODEL ---

@HiltViewModel
class ScreenAnalysisViewModel @Inject constructor(
    private val repository: ScreenAnalysisRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ScreenAnalysisState>(ScreenAnalysisState.Idle)
    val uiState: StateFlow<ScreenAnalysisState> = _uiState.asStateFlow()

    /**
     * Triggered by the UI to start the analysis process.
     * @param screenshot The bitmap captured from the screen.
     */
    fun analyzeScreen(screenshot: Bitmap) {
        viewModelScope.launch {
            _uiState.value = ScreenAnalysisState.Analyzing
            
            // We perform the repository call within the viewModelScope.
            // The repository/engine handles the context switching to Dispatchers.Default.
            val result = repository.performAnalysis(screenshot)
            
            result.fold(
                onSuccess = { elements ->
                    _uiState.value = ScreenAnalysisState.Success(elements)
                },
                onFailure = { error ->
                    _uiState.value = ScreenAnalysisState.Error(error.localizedMessage ?: "Unknown Error")
                }
            )
        }
    }
}

// --- UI LAYER (Jetpack Compose) ---

@Composable
fun ScreenAnalysisScreen(viewModel: ScreenAnalysisViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    
    // For demo purposes, we create a dummy bitmap. 
    // In a real app, this comes from MediaProjection or a View capture.
    val dummyBitmap = remember { 
        Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888) 
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AI Agent: Screen Analyzer",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Results Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            when (val currentState = state) {
                is ScreenAnalysisState.Idle -> {
                    Text("Tap the button to analyze the current screen.")
                }
                is ScreenAnalysisState.Analyzing -> {
                    CircularProgressIndicator()
                }
                is ScreenAnalysisState.Success -> {
                    AnalysisResultList(currentState.elements)
                }
                is ScreenAnalysisState.Error -> {
                    Text("Error: ${currentState.message}", color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Button(
            onClick = { viewModel.analyzeScreen(dummyBitmap) },
            enabled = state !is ScreenAnalysisState.Analyzing,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (state is ScreenAnalysisState.Analyzing) "Analyzing..." else "Analyze Screen")
        }
    }
}

@Composable
fun AnalysisResultList(elements: List<SemanticElement>) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(elements.size) { index ->
            val element = elements[index]
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Label: ${element.label}", style = MaterialTheme.typography.bodyLarge)
                    Text(text = "Type: ${element.type}", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(
                        progress = { element.confidence },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Text(
                        text = "Confidence: ${(element.confidence * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}
