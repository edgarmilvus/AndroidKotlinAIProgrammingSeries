
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.room.*
import kotlinx.coroutines.*

// 1. Data Persistence
@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long
)

@Dao
interface NotificationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity)

    @Query("SELECT * FROM notifications WHERE timestamp >= :since AND (text LIKE '%' || :filter || '%' OR title LIKE '%' || :filter || '%') ORDER BY timestamp DESC LIMIT 20")
    suspend fun queryNotifications(since: Long, filter: String): List<NotificationEntity>
}

@Database(entities = [NotificationEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
}

// 2. Notification Listener
class ConciergeNotificationService : NotificationListenerService() {
    private lateinit var db: AppDatabase

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val entity = NotificationEntity(
            packageName = sbn.packageName,
            title = sbn.notification.extras.getString("android.title") ?: "",
            text = sbn.notification.extras.getString("android.text") ?: "",
            timestamp = sbn.postTime
        )
        
        CoroutineScope(Dispatchers.IO).launch {
            db.notificationDao().insert(entity)
        }
    }
}

// 3. The Query Tool
class NotificationTool @Inject constructor(private val dao: NotificationDao) {
    suspend fun getNotifications(sinceHours: Int, keyword: String?): String {
        val sinceTimestamp = System.currentTimeMillis() - (sinceHours * 3600_000L)
        val filter = keyword ?: ""
        
        val results = dao.queryNotifications(sinceTimestamp, filter)
        
        if (results.isEmpty()) return "No matching notifications found."
        
        // Semantic Compression: Format as a concise list for the LLM
        return results.joinToString("\n") { 
            "[${it.packageName}] ${it.title}: ${it.text} (${it.timestamp})" 
        }
    }
}
