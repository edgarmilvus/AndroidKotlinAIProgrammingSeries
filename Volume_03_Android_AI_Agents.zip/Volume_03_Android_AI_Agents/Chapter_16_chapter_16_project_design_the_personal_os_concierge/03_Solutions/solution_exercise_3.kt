
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlinx.coroutines.flow.*

// 1. Mock API Suite
data class ToolResult(val success: Boolean, val data: String, val error: String? = null)

class RideService {
    fun bookRide(time: Long, dest: String) = ToolResult(true, "Ride confirmed for $time to $dest. Driver: Alex.")
}
class CalendarService {
    fun addEvent(title: String, time: Long) = ToolResult(true, "Event '$title' added to calendar.")
}
class MessagingService {
    fun sendMessage(recipient: String, body: String) = ToolResult(true, "Message sent to $recipient.")
}

// 2. The Orchestration Loop
class WorkflowOrchestrator @Inject constructor(
    private val rideService: RideService,
    private val calendarService: CalendarService,
    private val messagingService: MessagingService,
    private val generativeModel: GenerativeModel
) {
    private val chatHistory = mutableListOf<Content>()

    suspend fun executeComplexWorkflow(userInput: String): Flow<String> = flow {
        emit("Planning your request...")
        var currentInput = userInput
        var turnCount = 0
        val maxTurns = 5

        while (turnCount < maxTurns) {
            val response = generativeModel.generateContent(
                contents = chatHistory + Content.Text(currentInput)
            )
            
            val toolCalls = response.functionCalls
            if (toolCalls.isEmpty()) {
                emit(response.text ?: "Task complete.")
                break
            }

            // Execute all requested tools in this turn
            val toolResponses = toolCalls.map { call ->
                val result = executeTool(call.name, call.args)
                chatHistory.add(Content.FunctionResponse(call.name, result.data))
                result
            }

            // Update input for the next turn based on tool results
            currentInput = "Tool results: ${toolResponses.joinToString { it.data }}"
            turnCount++
            emit("Step $turnCount complete. Reasoning next step...")
        }
    }

    private fun executeTool(name: String, args: Map<String, Any?>): ToolResult {
        return when (name) {
            "book_ride" -> rideService.bookRide(args["time"] as Long, args["dest"] as String)
            "add_calendar_event" -> calendarService.addEvent(args["title"] as String, args["time"] as Long)
            "send_message" -> messagingService.sendMessage(args["recipient"] as String, args["body"] as String)
            else -> ToolResult(false, "", "Unknown tool")
        }
    }
}
