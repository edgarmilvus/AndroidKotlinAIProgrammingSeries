
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*

// 1. Tool Registry & Router
enum class ToolCategory { SYSTEM, COMMUNICATION, HEALTH }

data class ToolMetadata(val name: String, val category: ToolCategory)

class ToolRouter {
    private val registry = mapOf(
        "toggle_flashlight" to ToolCategory.SYSTEM,
        "set_brightness" to ToolCategory.SYSTEM,
        "send_message" to ToolCategory.COMMUNICATION,
        "get_steps" to ToolCategory.HEALTH
    )

    fun pruneTools(userInput: String): List<String> {
        return when {
            userInput.contains("light", ignoreCase = true) -> listOf("toggle_flashlight")
            userInput.contains("text", ignoreCase = true) -> listOf("send_message")
            else -> registry.keys.toList() // Fallback to all
        }
    }
}

// 2. Speculative Execution (Fast-Path)
class FastPathMatcher {
    private val patterns = mapOf(
        Regex("(?i)what time is it") to { "The current time is ${System.currentTimeMillis()}" },
        Regex("(?i)turn on the light") to { "Executing: toggle_flashlight(true)" }
    )

    fun tryFastPath(input: String): String? {
        return patterns.entries.firstOrNull { it.key.containsMatchIn(input) }?.value?.invoke()
    }
}

// 3. History Compressor
class ConversationManager {
    private var history = mutableListOf<String>()
    private val tokenLimit = 1000

    suspend fun addAndCompress(userInput: String, response: String, model: GenerativeModel) {
        history.add("User: $userInput")
        history.add("AI: $response")

        if (history.size > 10) { // Simple turn-based limit
            val summaryRequest = "Summarize the key facts of this conversation into 3 bullet points: ${history.joinToString("\n")}"
            val summary = model.generateContent(summaryRequest).text
            history.clear()
            history.add("Conversation Summary: $summary")
        }
    }
}

// Integrated Optimized Agent
class OptimizedAgent @Inject constructor(
    private val router: ToolRouter,
    private val fastPath: FastPathMatcher,
    private val convManager: ConversationManager
) {
    suspend fun process(input: String): String {
        // Step 1: Fast Path (Local)
        fastPath.tryFastPath(input)?.let { return it }

        // Step 2: Tool Pruning (Reduce Prompt Size)
        val activeTools = router.pruneTools(input)
        
        // Step 3: LLM call with pruned tools and compressed history
        // ... (Call Gemini with activeTools only)
        return "Optimized response"
    }
}
