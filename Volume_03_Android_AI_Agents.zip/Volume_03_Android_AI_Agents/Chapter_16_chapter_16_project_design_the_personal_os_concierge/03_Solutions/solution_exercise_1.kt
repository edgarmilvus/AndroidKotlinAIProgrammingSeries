
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

// 1. Tool Definition Layer
sealed class OSConciergeTool(val name: String, val description: String) {
    data class ToggleFlashlight(val enabled: Boolean) : OSConciergeTool("toggle_flashlight", "Turns the device flashlight on or off.")
    data class SetRingerMode(val mode: String) : OSConciergeTool("set_ringer_mode", "Sets ringer to 'silent', 'vibrate', or 'normal'.")
    data class SetBrightness(val level: Int) : OSConciergeTool("set_brightness", "Sets screen brightness (0-255).")
}

// 2. The Executor
@Singleton
class ToolExecutor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun execute(toolName: String, args: Map<String, Any?>): String {
        return try {
            when (toolName) {
                "toggle_flashlight" -> {
                    val enabled = args["enabled"] as? Boolean ?: false
                    toggleFlashlight(enabled)
                    "Flashlight successfully turned ${if (enabled) "on" else "off"}."
                }
                "set_ringer_mode" -> {
                    val mode = args["mode"] as? String ?: "normal"
                    setRingerMode(mode)
                    "Ringer mode set to $mode."
                }
                "set_brightness" -> {
                    val level = (args["level"] as? Number)?.toInt() ?: 127
                    setBrightness(level)
                    "Brightness set to $level."
                }
                else -> "Tool $toolName not found."
            }
        } catch (e: SecurityException) {
            "Permission denied: I don't have the required system permissions to perform this action."
        } catch (e: Exception) {
            "Error executing $toolName: ${e.localizedMessage}"
        }
    }

    private fun toggleFlashlight(enabled: Boolean) {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = cameraManager.cameraIdList[0]
        cameraManager.setTorchMode(cameraId, enabled)
    }

    private fun setRingerMode(mode: String) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val ringerMode = when (mode.lowercase()) {
            "silent" -> AudioManager.RINGER_MODE_SILENT
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        audioManager.ringerMode = ringerMode
    }

    private fun setBrightness(level: Int) {
        // Requires android.permission.WRITE_SETTINGS
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level)
    }
}

// 3. Integration Example (Simplified Loop)
@AndroidEntryPoint
class ConciergeViewModel @Inject constructor(
    private val toolExecutor: ToolExecutor,
    private val generativeModel: GenerativeModel // Gemini SDK
) {
    suspend fun handleUserRequest(userInput: String) {
        val chat = generativeModel.startChat()
        val response = chat.sendMessage(userInput)
        
        response.functionCalls.forEach { call ->
            val result = toolExecutor.execute(call.name, call.args)
            // Send result back to LLM for final natural language confirmation
            chat.sendMessage(Content.FunctionResponse(call.name, result))
        }
    }
}
