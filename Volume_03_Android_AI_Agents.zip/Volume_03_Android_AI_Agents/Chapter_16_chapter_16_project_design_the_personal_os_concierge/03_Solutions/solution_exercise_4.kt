
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect
import android.accessibilityservice.GestureDescription

class ConciergeAccessibilityService : AccessibilityService() {
    
    // 1. The "Screen-to-Text" Parser
    fun getScreenSnapshot(): String {
        val rootNode = rootInActiveWindow ?: return "No active window found."
        val elements = mutableListOf<String>()
        traverseNode(rootNode, elements)
        return elements.joinToString("\n")
    }

    private fun traverseNode(node: AccessibilityNodeInfo, elements: MutableList<String>) {
        if (node.isVisibleToUser) {
            val index = elements.size
            val text = node.text ?: node.contentDescription ?: "No Label"
            val className = node.className ?: "Unknown"
            
            if (node.isClickable) {
                elements.add("[$index] Button/Link: $text ($className)")
            } else if (node.text != null) {
                elements.add("[$index] Text: $text")
            }
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNode(it, elements) }
        }
    }

    // 2. The Interaction Tool
    fun clickElement(index: Int): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val targetNode = findNodeByIndex(rootNode, index, 0) ?: return false
        
        val rect = Rect()
        targetNode.getBoundsInScreen(rect)
        
        val clickPoint = android.graphics.Point(rect.centerX(), rect.centerY())
        val path = android.graphics.Path().apply { moveTo(clickPoint.x.toFloat(), clickPoint.y.toFloat()) }
        
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
            
        dispatchGesture(gesture, null, null)
        return true
    }

    private fun findNodeByIndex(node: AccessibilityNodeInfo, targetIndex: Int, currentIndex: Int): AccessibilityNodeInfo? {
        // Simplified logic: in a real app, you'd maintain a cached list of nodes 
        // corresponding to the indices generated in getScreenSnapshot()
        return null // Implementation requires caching the list during traverseNode
    }
}
