
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DATA MODELS ---

/**
 * Represents a message in the Concierge chat interface.
 */
data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Represents the result of a Tool execution.
 */
sealed class ToolResult {
    data class Success(val message: String) : ToolResult()
    data class Failure(val error: String) : ToolResult()
}

// --- 2. THE TOOLING SYSTEM (Function Injection) ---

/**
 * The base interface for all "Tools" available to the AI Agent.
 * This is the core of "Function Injection".
 */
interface AgentTool {
    val name: String
    val description: String
    suspend fun execute(args: Map<String, String>): ToolResult
}

/**
 * A concrete implementation of a Tool: Setting an Alarm.
 * In a real app, this would interact with the AlarmManager API.
 */
class AlarmTool @Inject constructor(private val context: Context) : AgentTool {
    override val name = "set_alarm"
    override val description = "Sets a new alarm for a specific time. Args: time (e.g., '07:00')"

    override suspend fun execute(args: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val time = args["time"] ?: return@withContext ToolResult.Failure("Missing time argument")
        
        // Simulate system interaction
        delay(1000) 
        
        // In production: alarmManager.setExact(...)
        ToolResult.Success("Alarm successfully set for $time")
    }
}

/**
 * A Registry that holds all available tools. The Agent queries this registry.
 */
@Singleton
class ToolRegistry @Inject constructor(
    private val alarmTool: AlarmTool
) {
    private val tools = mapOf(
        alarmTool.name to alarmTool
    )

    fun getTool(name: String): AgentTool? = tools[name]
}

// --- 3. THE AGENT ENGINE (Reasoning Logic) ---

/**
 * The Agent Engine simulates the LLM reasoning loop.
 * It takes input, decides which tool to call, and executes it.
 */
class ConciergeAgent @Inject constructor(
    private val toolRegistry: ToolRegistry
) {
    /**
     * This function simulates the "Reasoning" phase of an LLM.
     * It parses the text and "calls" the appropriate tool.
     */
    suspend fun processIntent(userInput: String): String = withContext(Dispatchers.Default) {
        // Simulate LLM latency (thinking time)
        delay(1500)

        // MOCK REASONING LOGIC:
        // In a real scenario, this is where you send the prompt + tool schemas to Gemini/GPT.
        // Here, we use simple pattern matching to simulate an LLM's decision.
        return@withContext when {
            userInput.contains("alarm", ignoreCase = true) -> {
                val timeMatch = Regex("(\\d{2}:\\d{2})").find(userInput)
                val time = timeMatch?.value ?: "08:00"
                
                val tool = toolRegistry.getTool("set_alarm")
                val result = tool?.execute(mapOf("time" to time))
                
                when (result) {
                    is ToolResult.Success -> "I've set your alarm for $time."
                    is ToolResult.Failure -> "I tried to set the alarm, but failed: ${result.error}"
                    null -> "I found the tool but couldn't execute it."
                }
            }
            else -> "I'm not sure how to help with that yet. I can currently set alarms."
        }
    }
}

// --- 4. THE VIEWMODEL (Orchestrator) ---

@HiltViewModel
class ConciergeViewModel @Inject constructor(
    private val agent: ConciergeAgent
) : ViewModel() {

    private val _uiState = MutableStateFlow<List<ChatMessage>>(emptyList())
    val uiState = _uiState.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        viewModelScope.launch {
            // 1. Add user message to UI
            val userMsg = ChatMessage(text, isUser = true)
            _uiState.value += userMsg

            // 2. Start "Thinking" state
            _isProcessing.value = true

            // 3. Execute Agent Reasoning on a background thread
            val responseText = agent.processIntent(text)

            // 4. Add Agent response to UI
            val agentMsg = ChatMessage(responseText, isUser = false)
            _uiState.value += agentMsg
            
            _isProcessing.value = false
        }
    }
}

// --- 5. THE UI LAYER (Jetpack Compose) ---

@Composable
fun ConciergeScreen(viewModel: ConciergeViewModel) {
    val messages by viewModel.uiState.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Personal OS Concierge",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Chat History
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = false
        ) {
            items(messages) { msg ->
                ChatBubble(msg)
            }
        }

        if (isProcessing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }

        // Input Area
        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("e.g., Set alarm for 07:30") }
            )
            Button(
                onClick = {
                    viewModel.sendMessage(inputText)
                    inputText = ""
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Send")
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val alignment = if (message.isUser) Alignment.End else Alignment.Start
    val color = if (message.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = alignment) {
        Surface(
            color = color,
            shape = MaterialTheme.shapes.medium
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- HILT MODULES ---

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideAlarmTool(context: Context): AlarmTool = AlarmTool(context)
}
