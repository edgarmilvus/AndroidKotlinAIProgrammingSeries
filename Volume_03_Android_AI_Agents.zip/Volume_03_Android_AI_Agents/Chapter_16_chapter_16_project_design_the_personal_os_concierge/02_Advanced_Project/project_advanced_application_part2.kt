
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.concierge.agent.domain

import android.graphics.Bitmap

/**
 * Represents the exhaustive set of states the Agent can inhabit.
 * Using a sealed class allows for exhaustive 'when' expressions in the UI.
 */
sealed class AgentState {
    object Idle : AgentState()
    
    data class Thinking(val thoughtProcess: String) : AgentState()
    
    data class AnalyzingScreen(val captureTimestamp: Long) : AgentState()
    
    data class ExecutingTool(
        val toolName: String, 
        val parameters: Map<String, Any>
    ) : AgentState()
    
    data class Success(val finalResponse: String) : AgentState()
    
    data class Error(val message: String, val canRetry: Boolean) : AgentState()
}

/**
 * Represents a tool that the LLM can "inject" into the execution flow.
 */
interface AgentTool {
    val name: String
    val description: String
    suspend fun execute(params: Map<String, Any>): ToolResult
}

sealed class ToolResult {
    data class Success(val output: String) : ToolResult()
    data class Failure(val reason: String) : ToolResult()
}

/**
 * Data structure containing the synthesized context for the LLM.
 */
data class AgentContext(
    val userIntent: String,
    val screenMetadata: String, // Extracted via NPU (e.g., "Button 'Send' is at x:100, y:200")
    val lastActionResult: String? = null
)
