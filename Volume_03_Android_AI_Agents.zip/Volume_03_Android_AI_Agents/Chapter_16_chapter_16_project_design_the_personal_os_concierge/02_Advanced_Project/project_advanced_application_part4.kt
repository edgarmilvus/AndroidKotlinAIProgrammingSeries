
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.kt
// Description: Advanced Application
// ==========================================

package com.concierge.agent.engine

import com.concierge.agent.domain.*
import com.concierge.agent.hardware.NpuVisionAnalyzer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

/**
 * The brain of the Personal OS Concierge.
 * Manages the lifecycle of an agentic task using Structured Concurrency.
 */
class AgentOrchestrator @Inject constructor(
    private val visionAnalyzer: NpuVisionAnalyzer,
    private val llmRepository: LlmRepository, // Hypothetical LLM interface
    private val toolRegistry: Map<String, AgentTool>,
    private val externalScope: CoroutineScope // Injected scope for long-running tasks
) {

    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    val state: StateFlow<AgentState> = _state.asStateFlow()

    /**
     * The main entry point for a user request.
     * Implements a recursive-style loop to allow for multi-step reasoning.
     */
    suspend fun processIntent(userIntent: String, screenBitmap: android.graphics.Bitmap) {
        // Use a SupervisorJob so that a failure in one reasoning step 
        // doesn't kill the entire Orchestrator scope.
        val agentJob = externalScope.launch(Dispatchers.Default + SupervisorJob()) {
            try {
                var currentIntent = userIntent
                var lastResult: String? = null
                var iterations = 0
                val maxIterations = 5

                while (iterations < maxIterations) {
                    iterations++

                    // STEP 1: Screen Awareness (NPU)
                    _state.value = AgentState.AnalyzingScreen(System.currentTimeMillis())
                    val visualContext = visionAnalyzer.analyzeScreen(screenBitmap)

                    // STEP 2: Reasoning (LLM)
                    _state.value = AgentState.Thinking("Synthesizing visual context and intent...")
                    val context = AgentContext(currentIntent, visualContext, lastResult)
                    val reasoningResult = llmRepository.getReasoning(context)

                    // STEP 3: Decision Branching
                    when (reasoningResult) {
                        is ReasoningResult.FinalAnswer -> {
                            _state.value = AgentState.Success(reasoningResult.answer)
                            return@launch
                        }
                        is ReasoningResult.ToolCall -> {
                            // STEP 4: Tool Execution
                            _state.value = AgentState.ExecutingTool(
                                reasoningResult.toolName, 
                                reasoningResult.parameters
                            )
                            
                            val tool = toolRegistry[reasoningResult.toolName]
                            if (tool == null) {
                                _state.value = AgentState.Error("Tool not found", true)
                                return@launch
                            }

                            val result = tool.execute(reasoningResult.parameters)
                            
                            when (result) {
                                is ToolResult.Success -> {
                                    // Update intent for the next loop iteration (Observation)
                                    lastResult = result.output
                                    currentIntent = "The previous action resulted in: $lastResult. Continue the task."
                                }
                                is ToolResult.Failure -> {
                                    // Error recovery: Feed the failure back to the LLM
                                    lastResult = "Error: ${result.reason}. Please try a different approach."
                                    currentIntent = "The last attempt failed. $lastResult"
                                }
                            }
                        }
                    }
                }
                
                if (iterations >= maxIterations) {
                    _state.value = AgentState.Error("Agent exceeded maximum reasoning steps.", false)
                }

            } catch (e: Exception) {
                _state.value = AgentState.Error(e.localizedMessage ?: "Unknown Error", true)
            }
        }
        
        agentJob.join()
    }
}

// Supporting types for the LLM Repository
sealed class ReasoningResult {
    data class FinalAnswer(val answer: String) : ReasoningResult()
    data class ToolCall(val toolName: String, val parameters: Map<String, Any>) : ReasoningResult()
}

interface LlmRepository {
    suspend fun getReasoning(context: AgentContext): ReasoningResult
}
