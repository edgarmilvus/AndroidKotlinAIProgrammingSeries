
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.kt
// Description: Advanced Application
// ==========================================

import dev.langchain4j.model.openai.OpenAiChatModel
import dev.langchain4j.service.AiServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TravelRepository @Inject constructor(
    private val travelTools: TravelTools
) {
    // In a production app, the API key would come from a secure EncryptedSharedPreferences
    private val model = OpenAiChatModel.builder()
        .apiKey("YOUR_OPENAI_API_KEY")
        .build()

    // We build the AI Service by injecting our tools into the orchestration engine
    private val agent: TravelAgent = AiServices.builder(TravelAgent::class.java)
        .chatLanguageModel(model)
        .tools(travelTools)
        .build()

    /**
     * Executes the complex workflow.
     * We use withContext(Dispatchers.Default) because the LangChain4j loop
     * involves heavy JSON parsing, reflection, and multiple network round-trips.
     */
    suspend fun executeComplexWorkflow(userQuery: String): Result<String> = withContext(Dispatchers.Default) {
        try {
            // The call to planTrip is NOT a single request. 
            // It is a loop: Request -> Tool Call -> Result -> Request -> Final Answer.
            val response = agent.planTrip(userQuery)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
