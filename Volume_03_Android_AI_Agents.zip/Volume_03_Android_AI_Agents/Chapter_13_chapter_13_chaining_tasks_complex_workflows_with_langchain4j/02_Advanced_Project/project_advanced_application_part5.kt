
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.kt
// Description: Advanced Application
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

// MVI State definition
data class TravelUiState(
    val isLoading: Boolean = false,
    val result: String? = null,
    val error: String? = null,
    val currentStep: String? = null // To show "Searching flights..." etc.
)

// MVI Intent definition
sealed class TravelIntent {
    data class PlanTrip(val query: String) : TravelIntent()
    object ClearState : TravelIntent()
}

@HiltViewModel
class TravelViewModel @Inject constructor(
    private val repository: TravelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TravelUiState())
    val uiState: StateFlow<TravelUiState> = _uiState.asStateFlow()

    fun handleIntent(intent: TravelIntent) {
        when (intent) {
            is TravelIntent.PlanTrip -> performPlanTrip(intent.query)
            is TravelIntent.ClearState -> _uiState.value = TravelUiState()
        }
    }

    private fun performPlanTrip(query: String) {
        viewModelScope.launch {
            // 1. Transition to Loading State
            _uiState.value = TravelUiState(isLoading = true, currentStep = "Agent is thinking...")

            // 2. Execute the long-running workflow in the Repository
            val result = repository.executeComplexWorkflow(query)

            // 3. Handle the result and update UI
            result.fold(
                onSuccess = { response ->
                    _uiState.value = TravelUiState(
                        isLoading = false, 
                        result = response,
                        currentStep = "Plan Complete!"
                    )
                },
                onFailure = { error ->
                    _uiState.value = TravelUiState(
                        isLoading = false, 
                        error = error.localizedMessage ?: "An unknown error occurred"
                    )
                }
            )
        }
    }
}
