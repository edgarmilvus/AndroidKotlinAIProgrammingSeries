
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

import dev.langchain4j.agent.tool.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// Data models for our agent's domain
data class Flight(val airline: String, val price: Double, val time: String)
data class Hotel(val name: String, val location: String, val rating: Double)
data class CalendarEvent(val title: String, val startTime: String)

/**
 * The Tool Suite contains the actual logic that the AI can "reach out" and execute.
 * We use @Singleton because these tools are stateless and can be shared across sessions.
 */
@Singleton
class TravelTools @Inject constructor() {

    @Tool("Searches for available flights based on destination and date")
    fun searchFlights(destination: String, date: String): List<Flight> {
        // In a real app, this would call a Retrofit service.
        // We simulate a network delay.
        return listOf(
            Flight("SkyHigh Air", 450.0, "$date 10:00 AM"),
            Flight("Global Jet", 520.0, "$date 02:00 PM")
        )
    }

    @Tool("Finds hotels in a specific location")
    fun searchHotels(location: String): List<Hotel> {
        return listOf(
            Hotel("Shibuya Grand", location, 4.8),
            Hotel("Tokyo Inn", location, 4.2)
        )
    }

    @Tool("Checks the user's calendar for conflicts on a specific date")
    fun checkCalendar(date: String): List<CalendarEvent> {
        return listOf(
            CalendarEvent("Business Meeting", "$date 09:00 AM")
        )
    }
}
