
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*

// 1. Data Models & Tools
data class ToolResult(val source: String, val summary: String)

class IntelligenceTools {
    @Tool("Fetches Bitcoin price and trend.")
    suspend fun fetchCryptoData(): String = "BTC is at $65,000, trending bullish."

    @Tool("Fetches social media sentiment.")
    suspend fun fetchSentiment(): String = "Sentiment is highly positive on X/Twitter."

    @Tool("Fetches tech news headlines.")
    suspend fun fetchTechNews(): String = "AI advancements are dominating tech headlines."
}

// 2. The Aggregator Agent
interface AggregatorAgent {
    @SystemMessage("Synthesize the following data into a cohesive briefing: {{data}}")
    fun synthesize(data: String): String
}

// 3. The Orchestrator (Parallel Execution)
class IntelligenceOrchestrator(
    private val tools: IntelligenceTools,
    private val aggregator: AggregatorAgent
) {
    suspend fun getUnifiedBriefing(): String = coroutineScope {
        // Step 1: Parallel Execution using async
        val cryptoDeferred = async { tools.fetchCryptoData() }
        val sentimentDeferred = async { tools.fetchSentiment() }
        val newsDeferred = async { tools.fetchTechNews() }

        // Step 2: Await all results
        val results = listOf(
            cryptoDeferred.await(),
            sentimentDeferred.await(),
            newsDeferred.await()
        )

        // Step 3: Pre-processing (Challenge Solution: Prevent Context Bloat)
        // We simulate a "Mini-Summarizer" step here
        val compressedData = results.joinToString("\n") { raw ->
            "Source Summary: ${summarizeLocally(raw)}"
        }

        // Step 4: Final Synthesis
        aggregator.synthesize(compressedData)
    }

    private fun summarizeLocally(text: String): String {
        // In a real app, this could be a regex-based heuristic 
        // or a much smaller, cheaper local model (like Google's Gemini Nano)
        return text.take(50) + "..." 
    }
}
