
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import dev.langchain4j.service.SystemMessage
import dev.langchain4j.service.UserMessage

// 1. Data Modeling
data class TravelContext(
    val destination: String? = null,
    val month: String? = null
)

sealed class TravelWorkflowState {
    object Idle : TravelWorkflowState()
    object ExtractingContext : TravelWorkflowState()
    data class AnalyzingWeather(val destination: String) : TravelWorkflowState()
    data class GeneratingPackingList(val weather: String) : TravelWorkflowState()
    data class Completed(val fullBrief: String) : TravelWorkflowState()
    data class Error(val message: String) : TravelWorkflowState()
}

// 2. Service Definitions
interface ContextExtractor {
    @SystemMessage("Extract the destination and month from the user input. Return null if not found.")
    fun extract(userInput: String): TravelContext
}

interface WeatherAnalyst {
    @SystemMessage("Provide a brief weather summary for {{destination}} in {{month}}.")
    fun analyze(destination: String, month: String): String
}

interface PackingStrategist {
    @SystemMessage("Based on this weather: {{weather}}, generate a Markdown packing list.")
    fun generateList(weather: String): String
}

// 3. ViewModel Orchestration
class TravelViewModel(
    private val extractor: ContextExtractor,
    private val weatherAnalyst: WeatherAnalyst,
    private val strategist: PackingStrategist
) {
    fun planTrip(userInput: String): Flow<TravelWorkflowState> = flow {
        emit(TravelWorkflowState.ExtractingContext)
        
        // Step 1: Extraction
        val context = extractor.extract(userInput)
        
        // Challenge Solution: Graceful Halt if extraction fails
        if (context.destination == null || context.month == null) {
            emit(TravelWorkflowState.Error("Could not identify destination or month. Please try again."))
            return@flow
        }

        // Step 2: Weather
        emit(TravelWorkflowState.AnalyzingWeather(context.destination))
        val weather = weatherAnalyst.analyze(context.destination, context.month)

        // Step 3: Packing List
        emit(TravelWorkflowState.GeneratingPackingList(weather))
        val packingList = strategist.generateList(weather)

        val finalBrief = """
            # Travel Brief for ${context.destination} (${context.month})
            ## Weather Summary
            $weather
            ## Recommended Packing List
            $packingList
        """.trimIndent()

        emit(TravelWorkflowState.Completed(finalBrief))
    }
}
