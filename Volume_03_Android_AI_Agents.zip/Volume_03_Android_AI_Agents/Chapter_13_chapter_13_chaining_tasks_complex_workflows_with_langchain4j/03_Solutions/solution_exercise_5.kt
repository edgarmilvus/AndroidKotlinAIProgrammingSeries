
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// 1. Models
data class Email(val id: String, val content: String)
data class Summary(val text: String, val keyDates: List<String>)

// 2. Services
interface SummarizerService {
    fun summarizeChunk(emails: List<Email>): Summary
}

interface AggregatorService {
    fun reduceSummaries(summaries: List<Summary>): Summary
}

interface VerificationService {
    fun verify(finalSummary: Summary, originalEmails: List<Email>): Boolean
}

// 3. The Map-Reduce Orchestrator
class InboxManager(
    private val summarizer: SummarizerService,
    private val aggregator: AggregatorService,
    private val verifier: VerificationService
) {
    suspend fun processInbox(allEmails: List<Email>): Summary = coroutineScope {
        // PHASE 1: MAP (Chunking & Individual Summarization)
        val chunkSize = 5
        val chunks = allEmails.chunked(chunkSize)
        
        val miniSummaries = chunks.map { chunk ->
            async(Dispatchers.Default) {
                summarizer.summarizeChunk(chunk)
            }
        }.awaitAll()

        // PHASE 2: REDUCE (Aggregating mini-summaries)
        val finalSummary = aggregator.reduceSummaries(miniSummaries)

        // PHASE 3: VERIFICATION (Challenge Solution: Mitigating Information Loss)
        val isAccurate = verifier.verify(finalSummary, allEmails)
        
        if (!isAccurate) {
            // If verification fails (e.g., hallucinated date), 
            // we could trigger a retry or flag for human review.
            throw IllegalStateException("Summary failed verification: Hallucination detected.")
        }

        finalSummary
    }
}
