
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import dev.langchain4j.agent.tool.Tool
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// 1. Domain Models
data class Contact(val name: String, val email: String)
data class Meeting(val title: String, val time: String)

// 2. The Toolset
class ContactTool {
    private val mockContacts = listOf(
        Contact("Sarah Manager", "sarah@company.com"),
        Contact("Sarah Dev", "sarah.dev@tech.io")
    )
    private val mockMeetings = listOf(Meeting("Project Sync", "Tomorrow 10:00 AM"))

    @Tool("Searches for a contact by name. Returns a list if multiple found.")
    fun searchContact(name: String): List<Contact> {
        return mockContacts.filter { it.name.contains(name, ignoreCase = true) }
    }

    @Tool("Gets upcoming meetings for a specific email address.")
    fun getUpcomingMeetings(email: String): List<Meeting> {
        return mockMeetings // Mocking logic
    }
}

// 3. Agent Definition
interface ContactAssistant {
    fun chat(userMessage: String): String
}

// 4. ViewModel with Thought Process Tracking
sealed class AgentStatus {
    object Idle : AgentStatus()
    object Thinking : AgentStatus()
    data class ToolCalling(val toolName: String) : AgentStatus()
    data class Responding(val message: String) : AgentStatus()
}

class ContactViewModel(private val assistant: ContactAssistant) {
    private val _status = MutableStateFlow<AgentStatus>(AgentStatus.Idle)
    val status: StateFlow<AgentStatus> = _status

    suspend fun handleUserQuery(query: String) {
        _status.value = AgentStatus.Thinking
        
        // Note: In a real implementation, you would wrap the Assistant 
        // with a listener to intercept tool calls and update _status.
        // For this exercise, we simulate the lifecycle.
        
        try {
            // Simulated tool call interception logic
            _status.value = AgentStatus.ToolCalling("searchContact")
            val response = assistant.chat(query)
            _status.value = AgentStatus.Responding(response)
        } catch (e: Exception) {
            _status.value = AgentStatus.Idle
        }
    }
}
