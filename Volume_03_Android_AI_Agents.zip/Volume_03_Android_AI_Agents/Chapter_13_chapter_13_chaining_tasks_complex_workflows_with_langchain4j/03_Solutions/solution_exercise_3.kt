
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import dev.langchain4j.service.SystemMessage

// 1. Structured Decision Output
sealed class TriageDecision {
    data class Refund(val amount: Double, val reason: String) : TriageDecision()
    data class FAQ(val topic: String) : TriageDecision()
    data class Escalate(val priority: String, val sentiment: String) : TriageDecision()
}

// 2. Specialized Services
interface RefundChain {
    fun processRefund(amount: Double, reason: String): String
}

interface KnowledgeBaseChain {
    fun searchFAQ(topic: String): String
}

interface EscalationChain {
    fun escalateToHuman(priority: String, summary: String): String
}

// 3. The Router Agent
interface TriageRouter {
    @SystemMessage("""
        Analyze the support ticket. 
        If it's a billing error < $50, return Refund.
        If it's a 'how-to' question, return FAQ.
        Otherwise, return Escalate.
    """)
    fun route(ticketText: String): TriageDecision
}

// 4. The Decision Engine (Orchestrator)
class SupportOrchestrator(
    private val router: TriageRouter,
    private val refundChain: RefundChain,
    private val faqChain: KnowledgeBaseChain,
    private val escalationChain: EscalationChain
) {
    fun handleTicket(ticket: String): String {
        val decision = try {
            router.route(ticket)
        } catch (e: Exception) {
            // Fallback mechanism: If routing fails, escalate immediately
            TriageDecision.Escalate("High", "Routing Error: ${e.message}")
        }

        return when (decision) {
            is TriageDecision.Refund -> refundChain.processRefund(decision.amount, decision.reason)
            is TriageDecision.FAQ -> faqChain.searchFAQ(decision.topic)
            is TriageDecision.Escalate -> escalationChain.escalateToHuman(decision.priority, ticket)
        }
    }
}
