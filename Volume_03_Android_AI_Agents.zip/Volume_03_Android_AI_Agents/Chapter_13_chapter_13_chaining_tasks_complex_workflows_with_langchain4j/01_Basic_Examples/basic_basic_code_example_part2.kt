
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.langchain4j.service.AiServices
import dev.langchain4j.model.openai.OpenAiChatModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// --- 1. DATA MODELS ---

/**
 * Represents the structured data extracted from a receipt image.
 * LangChain4j uses this to map LLM output into a type-safe Kotlin object.
 */
data class ReceiptInfo(
    val merchantName: String,
    val totalAmount: Double,
    val currency: String,
    val date: String
)

// --- 2. AI SERVICE INTERFACES ---

/**
 * Task A: The Vision Agent.
 * Specializes in converting images into structured data.
 */
interface ReceiptVisionAgent {
    fun extractReceiptData(image: Bitmap): ReceiptInfo
}

/**
 * Task B: The Writing Agent.
 * Specializes in taking structured data and drafting professional text.
 */
interface EmailDraftingAgent {
    fun draftEmailToAccountant(info: ReceiptInfo): String
}

// --- 3. REPOSITORY (THE ORCHESTRATOR) ---

/**
 * The Repository manages the "Chain." 
 * It takes the output of the Vision Agent and feeds it to the Drafting Agent.
 */
class AiAgentRepository @Inject constructor(
    private val visionAgent: ReceiptVisionAgent,
    private val draftingAgent: EmailDraftingAgent
) {
    /**
     * Performs the chained workflow: Image -> ReceiptInfo -> Email Draft.
     * This is a suspending function to ensure it can be called within a Coroutine.
     */
    suspend fun processReceiptWorkflow(image: Bitmap): Result<String> = withContext(Dispatchers.Default) {
        runCatching {
            // Step 1: Execute the first link in the chain (Vision)
            val receiptData = visionAgent.extractReceiptData(image)
            
            // Step 2: Execute the second link in the chain (Text Generation)
            // We pass the structured object directly into the next agent.
            val emailDraft = draftingAgent.draftEmailToAccountant(receiptData)
            
            emailDraft
        }
    }
}

// --- 4. VIEWMODEL ---

sealed class AiUiState {
    object Idle : AiUiState()
    object Loading : AiUiState()
    data class Success(val emailDraft: String) : AiUiState()
    data class Error(val message: String) : AiUiState()
}

@HiltViewModel
class ReceiptViewModel @Inject constructor(
    private val repository: AiAgentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState

    fun onProcessReceiptClicked(image: Bitmap) {
        viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            
            // The repository handles the heavy lifting on Dispatchers.Default
            val result = repository.processReceiptWorkflow(image)
            
            result.onSuccess { draft ->
                _uiState.value = AiUiState.Success(draft)
            }.onFailure { exception ->
                _uiState.value = AiUiState.Error(exception.localizedMessage ?: "Unknown Error")
            }
        }
    }
}

// --- 5. UI LAYER (JETPACK COMPOSE) ---

@Composable
fun ReceiptWorkflowScreen(viewModel: ReceiptViewModel) {
    val uiState by viewModel.collectAsStateWithLifecycle()

    // Mock bitmap for demonstration purposes
    val mockBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (val state = uiState) {
            is AiUiState.Idle -> {
                Button(onClick = { viewModel.onProcessReceiptClicked(mockBitmap) }) {
                    Text("Process Receipt Image")
                }
            }
            is AiUiState.Loading -> {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(8.dp))
                Text("Analyzing receipt and drafting email...")
            }
            is AiUiState.Success -> {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Generated Email Draft:", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(state.emailDraft, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { viewModel.onProcessReceiptClicked(mockBitmap) }) {
                    Text("Try Again")
                }
            }
            is AiUiState.Error -> {
                Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
                Button(onClick = { viewModel.onProcessReceiptClicked(mockBitmap) }) {
                    Text("Retry")
                }
            }
        }
    }
}
