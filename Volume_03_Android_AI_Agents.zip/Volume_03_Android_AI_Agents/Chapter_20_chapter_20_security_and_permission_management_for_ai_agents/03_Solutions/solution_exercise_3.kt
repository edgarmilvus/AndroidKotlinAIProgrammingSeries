
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// --- Data Models ---

// The "Full" system model (Sensitive)
data class Contact(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val homeAddress: String, // SENSITIVE
    val email: String        // SENSITIVE
)

// The "Safe" model (Scoped)
data class SafeContact(
    val name: String,
    val phoneNumber: String
)

// --- Logic Engines ---

class DynamicScopeEngine {
    /**
     * Evaluates if the requested data matches the semantic scope of the prompt.
     */
    fun validateScope(userPrompt: String, requestedFields: List<String>): Boolean {
        val sensitiveKeywords = listOf("address", "email", "birthday", "location")
        
        // If the prompt is about "finding a number", but the tool tries to return an address
        val promptIntentIsLowSensitivity = !sensitiveKeywords.any { userPrompt.contains(it, ignoreCase = true) }
        val requestIsHighSensitivity = requestedFields.any { it in sensitiveKeywords }

        return !(promptIntentIsLowSensitivity && requestIsHighSensitivity)
    }
}

class ContactRepository {
    // Mocking ContentResolver access
    fun fetchAllContacts(): List<Contact> = listOf(
        Contact("1", "John Doe", "555-0123", "123 Maple St", "john@example.com"),
        Contact("2", "Jane Smith", "555-9876", "456 Oak Ave", "jane@example.com")
    )
}

// --- The Scoped Proxy Tool ---

class ContactSearchTool(
    private val repository: ContactRepository,
    private val scopeEngine: DynamicScopeEngine
) {
    suspend fun search(userPrompt: String, query: String): Result<List<SafeContact>> {
        val allContacts = repository.fetchAllContacts()
        
        // 1. Filter by name (the actual logic)
        val filtered = allContacts.filter { it.name.contains(query, ignoreCase = true) }
        
        // 2. Determine what fields are being requested via the prompt
        // In a real app, an LLM would pass 'requestedFields' as a parameter
        val requestedFields = mutableListOf("name", "phoneNumber")
        if (userPrompt.contains("address", ignoreCase = true)) requestedFields.add("address")
        if (userPrompt.contains("email", ignoreCase = true)) requestedFields.add("email")

        // 3. The Semantic Firewall Check
        return if (scopeEngine.validateScope(userPrompt, requestedFields)) {
            // Map to Safe DTO
            val safeList = filtered.map { SafeContact(it.name, it.phoneNumber) }
            Result.success(safeList)
        } else {
            // Block the data leakage
            Result.failure(Exception("Information not available in this scope: Privacy Violation"))
        }
    }
}
