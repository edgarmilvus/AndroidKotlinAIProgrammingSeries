
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

// --- State & Models ---

enum class AgentState { IDLE, THINKING, AWAITING_APPROVAL, EXECUTING, COMPLETED, FAILED }

data class ApprovalRequest(
    val transactionId: String,
    val amount: Double,
    val recipient: String,
    val verificationHash: String
)

sealed class ApprovalResult {
    data class Approved(val transactionId: String) : ApprovalResult()
    data class Denied(val transactionId: String) : ApprovalResult()
}

// --- ViewModel (The State Orchestrator) ---

class FinancialAgentViewModel : androidx.lifecycle.ViewModel() {
    private val _state = MutableStateFlow(AgentState.IDLE)
    val state = _state.asStateFlow()

    private val _pendingRequest = MutableStateFlow<ApprovalRequest?>(null)
    val pendingRequest = _pendingRequest.asStateFlow()

    private val _approvalResults = MutableSharedFlow<ApprovalResult>()
    val approvalResults = _approvalResults.asSharedFlow()

    fun triggerApproval(request: ApprovalRequest) {
        _pendingRequest.value = request
        _state.value = AgentState.AWAITING_APPROVAL
    }

    fun onUserAction(approved: Boolean) {
        val currentId = _pendingRequest.value?.transactionId ?: ""
        _pendingRequest.value = null
        _state.value = AgentState.IDLE // Reset state
        
        viewModelScope.launch {
            if (approved) {
                _approvalResults.emit(ApprovalResult.Approved(currentId))
            } else {
                _approvalResults.emit(ApprovalResult.Denied(currentId))
            }
        }
    }
}

// --- The Tool (The Suspended Producer) ---

class TransferMoneyTool(private val viewModel: FinancialAgentViewModel) {
    
    suspend fun execute(amount: Double, recipient: String): ToolResult {
        val txId = java.util.UUID.randomUUID().toString()
        val request = ApprovalRequest(txId, amount, recipient, "sha256_hash_here")

        // 1. Request approval from the UI
        viewModel.triggerApproval(request)

        // 2. SUSPEND the agent until the user interacts
        // We use withTimeout to handle the "User left the app" scenario
        return try {
            withTimeout(60_000L) { // 60 second timeout
                viewModel.approvalResults
                    .filter { it.transactionId == txId }
                    .first() // Suspends until an item is emitted
                    .let { result ->
                        if (result is ApprovalResult.Approved) {
                            // Simulate actual bank API call
                            delay(1000) 
                            ToolResult.Success("Transferred $$amount to $recipient")
                        } else {
                            ToolResult.Error("Transaction cancelled by user")
                        }
                    }
            }
        } catch (e: TimeoutCancellationException) {
            ToolResult.Error("Approval timed out. Transaction aborted.")
        }
    }
}

sealed class ToolResult {
    data class Success(val msg: String) : ToolResult()
    data class Error(val msg: String) : ToolResult()
}
