
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// --- Domain Models ---
sealed class ToolResult {
    data class Success(val data: String) : ToolResult()
    data class Error(val message: String) : ToolResult()
}

data class PermissionRequiredEvent(val toolId: String, val deferred: CompletableDeferred<Boolean>)

interface AgentTool<T> {
    val id: String
    val isSensitive: Boolean
    suspend fun execute(args: T): ToolResult
}

// --- Core Logic ---

@Singleton
class CapabilityManager @Inject constructor() {
    private val authorizedTools = mutableSetOf<String>()

    fun grantCapability(toolId: String) {
        authorizedTools.add(toolId)
    }

    fun hasCapability(toolId: String): Boolean = authorizedTools.contains(toolId)
}

class ToolExecutor @Inject constructor(
    private val capabilityManager: CapabilityManager
) {
    // Emits events to the UI when a sensitive tool is called without permission
    private val _permissionRequests = MutableSharedFlow<PermissionRequiredEvent>()
    val permissionRequests = _permissionRequests.asSharedFlow()

    suspend fun executeTool(tool: AgentTool<Any>, args: Any): ToolResult {
        // 1. Check if tool is sensitive and not yet authorized in this session
        if (tool.isSensitive && !capabilityManager.hasCapability(tool.id)) {
            val userApproval = CompletableDeferred<Boolean>()
            
            // 2. Trigger the UI via the flow
            _permissionRequests.emit(PermissionRequiredEvent(tool.id, userApproval))
            
            // 3. SUSPEND here until the user interacts with the Compose UI
            val approved = userApproval.await()
            
            if (!approved) {
                return ToolResult.Error("Permission Denied by User")
            }
            
            // 4. Grant capability upon approval
            capabilityManager.grantCapability(tool.id)
        }

        return tool.execute(args)
    }
}

// --- UI Layer (ViewModel & Compose) ---

class AgentViewModel(private val executor: ToolExecutor) : androidx.lifecycle.ViewModel() {
    var showDialog by mutableStateOf(false)
        private set
    var pendingToolId by mutableStateOf("")
        private set
    private var currentDeferred: CompletableDeferred<Boolean>? = null

    // Flow to observe tool execution results
    private val _result = MutableSharedFlow<ToolResult>()
    val result = _result.asSharedFlow()

    init {
        viewModelScope.launch {
            executor.permissionRequests.collect { event ->
                pendingToolId = event.toolId
                currentDeferred = event.deferred
                showDialog = true
            }
        }
    }

    fun onPermissionGranted() {
        showDialog = false
        currentDeferred?.complete(true)
    }

    fun onPermissionDenied() {
        showDialog = false
        currentDeferred?.complete(false)
    }

    fun runAgentTask(tool: AgentTool<Any>, args: Any) {
        viewModelScope.launch {
            val res = executor.executeTool(tool, args)
            _result.emit(res)
        }
    }
}

@Composable
fun PermissionRequestDialog(toolId: String, onGrant: () -> Unit, onDeny: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDeny,
        title = { Text("Permission Required") },
        text = { Text("The agent wants to use the '$toolId' tool. Allow for this session?") },
        confirmButton = { Button(onClick = onGrant) { Text("Grant") } },
        dismissButton = { TextButton(onClick = onDeny) { Text("Deny") } }
    )
}
