
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.room.*
import kotlinx.coroutines.*
import javax.inject.Inject

// --- Room Persistence ---

@Entity(tableName = "agent_audit_logs")
data class AuditEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val toolId: String,
    val rawArgumentsJson: String,
    val processedArgumentsJson: String,
    val status: String, // SUCCESS, FAILURE, DENIED
    val reasoningSnippet: String?
)

@Dao
interface AuditDao {
    @Insert
    suspend fun insertLog(entry: AuditEntry)

    @Query("SELECT * FROM agent_audit_logs ORDER BY timestamp DESC")
    fun getAllLogs(): kotlinx.coroutines.flow.Flow<List<AuditEntry>>
}

@Database(entities = [AuditEntry::class], version = 1)
abstract class AuditDatabase : RoomDatabase() {
    abstract fun auditDao(): AuditDao
}

// --- Instrumentation Layer ---

interface ToolExecutor {
    suspend fun executeTool(toolId: String, rawArgs: String, sanitizedArgs: String, reasoning: String?): ToolResult
}

sealed class ToolResult {
    object Success : ToolResult()
    data class Error(val msg: String) : ToolResult()
}

// The Decorator Pattern implementation
class AuditingToolExecutorDecorator(
    private val decorated: ToolExecutor,
    private val auditDao: AuditDao,
    private val externalScope: CoroutineScope // Application-scoped
) : ToolExecutor {

    override suspend fun executeTool(
        toolId: String, 
        rawArgs: String, 
        sanitizedArgs: String, 
        reasoning: String?
    ): ToolResult {
        val startTime = System.currentTimeMillis()
        var status = "SUCCESS"
        var result: ToolResult

        try {
            result = decorated.executeTool(toolId, rawArgs, sanitizedArgs, reasoning)
            if (result is ToolResult.Error) status = "FAILURE"
        } catch (e: Exception) {
            status = "FAILURE"
            result = ToolResult.Error(e.message ?: "Unknown Error")
        }

        // Fire-and-forget logging to ensure the agent isn't slowed down by DB IO
        externalScope.launch(Dispatchers.IO) {
            auditDao.insertLog(
                AuditEntry(
                    timestamp = startTime,
                    toolId = toolId,
                    rawArgumentsJson = rawArgs,
                    processedArgumentsJson = sanitizedArgs,
                    status = status,
                    reasoningSnippet = reasoning
                )
            )
        }

        return result
    }
}
