
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.core.content.ContextCompat
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// --- 1. DOMAIN MODELS ---

/**
 * Represents the state of the AI Agent's security context.
 */
sealed class SecurityState {
    object Idle : SecurityState()
    object Checking : SecurityState()
    data class Authorized(val toolName: String) : SecurityState()
    data class Unauthorized(val reason: String) : SecurityState()
}

/**
 * A data class representing the Tool Call requested by the AI.
 */
data class ToolCall(
    val toolName: String,
    val arguments: Map<String, String>
)

// --- 2. REPOSITORY LAYER (The Source of Truth for Permissions) ---

interface PermissionRepository {
    fun hasPermission(permission: String): Boolean
    suspend fun checkFileAccess(uri: Uri): Boolean
}

class PermissionRepositoryImpl @Inject constructor(
    private val context: Context
) : PermissionRepository {

    override fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == 
                PackageManager.PERMISSION_GRANTED
    }

    override suspend fun checkFileAccess(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        // In a real app, we would use ContentResolver to check if the URI 
        // is actually accessible via the current app process.
        // This prevents "Confused Deputy" attacks where the agent is told to 
        // access a URI it shouldn't have.
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.close()
            true
        } catch (e: Exception) {
            false
        }
    }
}

// --- 3. SECURITY INTERCEPTOR (The Gatekeeper) ---

/**
 * The SecurityInterceptor is the core of Agentic Security.
 * It sits between the LLM and the Tool Executor.
 */
class AgentSecurityInterceptor @Inject constructor(
    private val permissionRepository: PermissionRepository
) {
    /**
     * Validates if a tool call is safe to execute.
     * @return Result indicating if the call is permitted or why it failed.
     */
    suspend fun validateToolCall(call: ToolCall): SecurityState = withContext(Dispatchers.Default) {
        return@withContext when (call.toolName) {
            "analyze_document" -> {
                val uriString = call.arguments["file_uri"]
                if (uriString == null) {
                    SecurityState.Unauthorized("Missing file_uri argument")
                } else {
                    val uri = Uri.parse(uriString)
                    // Step 1: Check System Permissions (e.g., READ_EXTERNAL_STORAGE)
                    // Note: For API 34+, we use specific MediaStore permissions or Scoped Storage.
                    if (!permissionRepository.hasPermission(Manifest.permission.READ_MEDIA_IMAGES)) {
                        SecurityState.Unauthorized("System permission READ_MEDIA_IMAGES denied")
                    } else {
                        // Step 2: Check URI-specific access (The "Deep" Security Check)
                        if (permissionRepository.checkFileAccess(uri)) {
                            SecurityState.Authorized(call.toolName)
                        } else {
                            SecurityState.Unauthorized("Agent attempted to access unauthorized URI")
                        }
                    }
                }
            }
            else -> SecurityState.Unauthorized("Unknown tool: ${call.toolName}")
        }
    }
}

// --- 4. VIEWMODEL LAYER (The Orchestrator) ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val securityInterceptor: AgentSecurityInterceptor
) : ViewModel() {

    private val _uiState = MutableStateFlow<String>("Agent Ready. Waiting for command...")
    val uiState = _uiState.asStateFlow()

    private val _securityState = MutableStateFlow<SecurityState>(SecurityState.Idle)
    val securityState = _securityState.asStateFlow()

    /**
     * Simulates the AI Agent deciding to call a tool.
     */
    fun onAgentCommandReceived(command: String) {
        viewModelScope.launch {
            _uiState.value = "Agent is thinking..."
            
            // SIMULATION: In a real app, the LLM output would be parsed here.
            // We simulate the LLM deciding to call 'analyze_document'.
            val simulatedToolCall = ToolCall(
                toolName = "analyze_document",
                arguments = mapOf("file_uri" to "content://media/external/images/media/123")
            )

            _securityState.value = SecurityState.Checking
            
            // THE CRITICAL STEP: Intercepting the tool call before execution
            val validationResult = securityInterceptor.validateToolCall(simulatedToolCall)
            _securityState.value = validationResult

            when (validationResult) {
                is SecurityState.Authorized -> {
                    executeTool(simulatedToolCall)
                }
                is SecurityState.Unauthorized -> {
                    _uiState.value = "Security Violation: ${validationResult.reason}"
                }
                else -> {}
            }
        }
    }

    private suspend fun executeTool(call: ToolCall) {
        _uiState.value = "Executing ${call.toolName}..."
        // Simulate heavy AI processing/inference
        kotlinx.coroutines.delay(1500) 
        _uiState.value = "Success: Document analyzed successfully!"
    }
}

// --- 5. UI LAYER (Jetpack Compose) ---

@Composable
fun AgentSecurityScreen(viewModel: AgentViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val securityState by viewModel.securityState.collectAsState()

    // Modern way to handle permission requests in Compose
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // If granted, we can re-trigger the agent's thought process
            viewModel.onAgentCommandReceived("Analyze my photo")
        } else {
            // Handle denial
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AI Agent Security Monitor",
            style = MaterialTheme.typography.headlineMedium
        )
        
        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Agent Status:", style = MaterialTheme.typography.labelLarge)
                Text(text = uiState, style = MaterialTheme.typography.bodyLarge)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Security Status Indicator
        SecurityStatusIndicator(securityState)

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                // First, we check if we have permission. If not, ask.
                val permission = Manifest.permission.READ_MEDIA_IMAGES
                if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                    viewModel.onAgentCommandReceived("Analyze my photo")
                } else {
                    permissionLauncher.launch(permission)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Trigger Agent Task")
        }
    }
}

@Composable
fun SecurityStatusIndicator(state: SecurityState) {
    val (color, text) = when (state) {
        is SecurityState.Idle -> MaterialTheme.colorScheme.outline to "Idle"
        is SecurityState.Checking -> MaterialTheme.colorScheme.primary to "Verifying Security..."
        is SecurityState.Authorized -> MaterialTheme.colorScheme.primaryContainer to "Authorized"
        is SecurityState.Unauthorized -> MaterialTheme.colorScheme.error to "BLOCKED: ${state.reason}"
    }

    Surface(
        color = color,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(8.dp)) {
            Text(text = "Security: $text", color = if (state is SecurityState.Unauthorized) 
                MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary)
        }
    }
}
