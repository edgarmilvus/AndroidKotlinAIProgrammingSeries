
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.kt
// Description: Advanced Application
// ==========================================

// Gradle Dependencies (Kotlin DSL)
/*
dependencies {
    implementation("com.google.dagger:hilt-android:2.51")
    kapt("com.google.dagger:hilt-compiler:2.51")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    // For NPU/GPU acceleration via MediaPipe or TensorFlow Lite
    implementation("com.google.mediapipe:tasks-genai:0.10.14")
}
*/

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the severity of the action the AI agent intends to perform.
 */
enum class RiskLevel {
    LOW,      // e.g., Reading a public weather API
    MEDIUM,   // e.g., Reading contacts, drafting an email
    HIGH,     // e.g., Sending an SMS, deleting a file
    CRITICAL  // e.g., Transferring funds, wiping data
}

/**
 * Data model representing the AI's intent to use a tool.
 */
data class ToolCallRequest(
    val toolName: String,
    val arguments: Map<String, Any>,
    val originalUserPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * The outcome of a security evaluation.
 */
sealed class SecurityEvaluation {
    object Approved : SecurityEvaluation()
    data class RequiresUserConsent(val request: ToolCallRequest, val risk: RiskLevel) : SecurityEvaluation()
    data class Denied(val reason: String) : SecurityEvaluation()
}

/**
 * Hardware-aware orchestration interface for local intent verification.
 * Uses NPU/GPU to run a small-scale LLM/Classifier to check for "Prompt Injection"
 * or "Intent Mismatch" without sending data to the cloud.
 */
interface HardwareAcceleratedVerifier {
    suspend fun verifyIntent(request: ToolCallRequest): RiskLevel
}

/**
 * Repository responsible for managing and persisting security policies and 
 * permission logs for auditability.
 */
@Singleton
class SecurityPolicyRepository @Inject constructor(
    private val context: Context // In production, use EncryptedSharedPreferences
) {
    private val _policyFlow = MutableStateFlow<Map<String, RiskLevel>>(emptyMap())
    val policyFlow: StateFlow<Map<String, RiskLevel>> = _policyFlow.asStateFlow()

    init {
        // Default policies: Mapping tool names to risk levels
        _policyFlow.value = mapOf(
            "send_sms" to RiskLevel.HIGH,
            "delete_file" to RiskLevel.CRITICAL,
            "read_contacts" to RiskLevel.MEDIUM,
            "get_weather" to RiskLevel.LOW
        )
    }

    fun getRiskForTool(toolName: String): RiskLevel {
        return _policyFlow.value[toolName] ?: RiskLevel.HIGH
    }
}

/**
 * The Core Gatekeeper. This component intercepts all AI tool calls.
 */
@Singleton
class AgentSecurityGatekeeper @Inject constructor(
    private val repository: SecurityPolicyRepository,
    private val hardwareVerifier: HardwareAcceleratedVerifier
) {
    private val securityScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * Evaluates a tool call request using a multi-layered approach:
     * 1. Rule-based check (Repository)
     * 2. Semantic check (Hardware-accelerated NPU inference)
     */
    suspend fun evaluateRequest(request: ToolCallRequest): SecurityEvaluation = withContext(Dispatchers.Default) {
        val baseRisk = repository.getRiskForTool(request.toolName)

        // Layer 2: Hardware-accelerated Semantic Analysis
        // We use the NPU to check if the 'arguments' match the 'originalUserPrompt'
        // Example: Prompt: "Tell me the weather" -> Tool: "send_sms" (Mismatch!)
        val semanticRisk = hardwareVerifier.verifyIntent(request)
        
        val effectiveRisk = if (semanticRisk.ordinal > baseRisk.ordinal) semanticRisk else baseRisk

        return@withContext when (effectiveRisk) {
            RiskLevel.LOW -> SecurityEvaluation.Approved
            RiskLevel.MEDIUM -> {
                // For medium risk, we might allow it if the semantic check is perfect,
                // but for this implementation, we require consent.
                SecurityEvaluation.RequiresUserConsent(request, effectiveRisk)
            }
            RiskLevel.HIGH, RiskLevel.CRITICAL -> {
                SecurityEvaluation.RequiresUserConsent(request, effectiveRisk)
            }
        }
    }
}

/**
 * MVI-based ViewModel to manage the UI state of permission requests.
 */
@HiltViewModel
class AgentSecurityViewModel @Inject constructor(
    private val gatekeeper: AgentSecurityGatekeeper
) : ViewModel() {

    sealed class UiState {
        object Idle : UiState()
        data class PendingApproval(val request: ToolCallRequest, val risk: RiskLevel) : UiState()
        data class Error(val message: String) : UiState()
        object Success : UiState()
    }

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _actionEvents = MutableSharedFlow<String>()
    val actionEvents = _actionEvents.asSharedFlow()

    /**
     * Called when the AI Agent attempts to execute a tool.
     */
    fun onAgentToolCallAttempt(request: ToolCallRequest) {
        viewModelScope.launch {
            try {
                when (val evaluation = gatekeeper.evaluateRequest(request)) {
                    is SecurityEvaluation.Approved -> {
                        executeTool(request)
                    }
                    is SecurityEvaluation.RequiresUserConsent -> {
                        _uiState.value = UiState.PendingApproval(request, evaluation.risk)
                    }
                    is SecurityEvaluation.Denied -> {
                        _actionEvents.emit("Security Blocked: ${evaluation.reason}")
                    }
                }
            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.localizedMessage ?: "Unknown Error")
            }
        }
    }

    fun onUserApproval(request: ToolCallRequest) {
        viewModelScope.launch {
            _uiState.value = UiState.Idle
            executeTool(request)
        }
    }

    fun onUserDenial() {
        viewModelScope.launch {
            _uiState.value = UiState.Idle
            _actionEvents.emit("User denied the action.")
        }
    }

    private suspend fun executeTool(request: ToolCallRequest) {
        // In a real app, this would call the actual tool implementation
        // via a Registry pattern.
        delay(500) // Simulate execution
        _actionEvents.emit("Successfully executed ${request.toolName}")
        _uiState.value = UiState.Success
    }
}

/**
 * Implementation of hardware-aware verification.
 * In a real production environment, this would wrap a TFLite or MediaPipe model
 * running on the device's NPU (Neural Processing Unit).
 */
class NpuHardwareVerifier @Inject constructor() : HardwareAcceleratedVerifier {
    override suspend fun verifyIntent(request: ToolCallRequest): RiskLevel = withContext(Dispatchers.Default) {
        // SIMULATION: In reality, you would load a .tflite model here.
        // The model would take (request.originalUserPrompt + request.toolName) 
        // and output a probability of semantic alignment.
        
        delay(200) // Simulate NPU inference latency
        
        // Logic: If the tool is 'send_sms' but the prompt doesn't mention 'message' or 'text',
        // increase the risk level.
        val prompt = request.originalUserPrompt.lowercase()
        val isAnomaly = when (request.toolName) {
            "send_sms" -> !prompt.contains("send") && !prompt.contains("text") && !prompt.contains("message")
            "delete_file" -> !prompt.contains("remove") && !prompt.contains("delete")
            else -> false
        }

        if (isAnomaly) RiskLevel.CRITICAL else RiskLevel.LOW
    }
}

@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {
    @Provides
    @Singleton
    fun provideHardwareVerifier(): HardwareAcceleratedVerifier = NpuHardwareVerifier()
}
