
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import androidx.room.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// --- 1. DATA LAYER: THE MEMORY ENTITY ---

/**
 * Represents a single unit of memory in the Agent's history.
 * We use [role] to distinguish between 'user' and 'assistant'.
 */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

// --- 2. DATA LAYER: THE DAO ---

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessagesFlow(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(limit: Int): List<ChatMessageEntity>

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}

@Database(entities = [ChatMessageEntity::class], version = 1)
abstract class ChatDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
}

// --- 3. DOMAIN LAYER: THE REPOSITORY ---

/**
 * The Repository acts as the "Brain's Memory Manager". 
 * It decides how much history to retrieve to avoid overwhelming the LLM context window.
 */
interface MemoryRepository {
    val chatHistory: StateFlow<List<ChatMessageEntity>>
    suspend fun saveMessage(role: String, content: String)
    suspend fun getContextForInference(limit: Int): List<ChatMessageEntity>
}

@Singleton
class MemoryRepositoryImpl @Inject constructor(
    private val chatDao: ChatDao
) : MemoryRepository {

    // Expose the history as a StateFlow for the UI to observe
    override val chatHistory: StateFlow<List<ChatMessageEntity>> = 
        chatDao.getAllMessagesFlow()
            .stateIn(
                scope = kotlinx.coroutines.GlobalScope, // In production, use a dedicated Application scope
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    override suspend fun saveMessage(role: String, content: String) {
        // Always perform Disk I/O on Dispatchers.IO
        withContext(Dispatchers.IO) {
            chatDao.insertMessage(ChatMessageEntity(role = role, content = content))
        }
    }

    override suspend fun getContextForInference(limit: Int): List<ChatMessageEntity> {
        return withContext(Dispatchers.IO) {
            // Retrieve the most recent messages to form the prompt context
            chatDao.getRecentMessages(limit).reversed()
        }
    }
}

// --- 4. PRESENTATION LAYER: THE VIEWMODEL ---

/**
 * The ViewModel manages the interaction between the UI and the Agent's memory.
 * It handles the orchestration of: User Input -> Save -> LLM Call -> Save.
 */
@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: MemoryRepository
) : ViewModel() {

    // UI State representing the list of messages
    val uiState: StateFlow<List<ChatMessageEntity>> = repository.chatHistory

    // Loading state to prevent multiple concurrent inferences
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    /**
     * The core loop of an Agent interaction.
     */
    fun sendMessage(userText: String) {
        viewModelScope.launch {
            if (userText.isBlank() || _isProcessing.value) return@launch

            _isProcessing.value = true

            // Step 1: Persist User Message
            repository.saveMessage("user", userText)

            // Step 2: Prepare Context (The "Memory" part)
            // We only take the last 10 messages to keep the prompt efficient
            val context = repository.getContextForInference(limit = 10)

            // Step 3: Simulate AI Inference
            // In a real app, this would be a call to Gemini, OpenAI, or a local TFLite model
            val response = simulateAiInference(context)

            // Step 4: Persist Assistant Response
            repository.saveMessage("assistant", response)

            _isProcessing.value = false
        }
    }

    private suspend fun simulateAiInference(context: List<ChatMessageEntity>): String {
        // Simulate network/computation latency on Dispatchers.Default
        return withContext(Dispatchers.Default) {
            kotlinx.coroutines.delay(1500) 
            "I remember you said: '${context.lastOrNull()?.content}'. How can I help further?"
        }
    }
}

// --- 5. UI LAYER: JETPACK COMPOSE ---

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AgentChatScreen(viewModel: AgentViewModel) {
    val messages by viewModel.uiState.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Message List
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages) { msg ->
                ChatBubble(msg)
            }
        }

        if (isProcessing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        // Input Area
        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask your agent...") }
            )
            Button(
                onClick = {
                    viewModel.sendMessage(inputText)
                    inputText = ""
                },
                enabled = !isProcessing && inputText.isNotBlank(),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Send")
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessageEntity) {
    val isUser = message.role == "user"
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isUser) MaterialTheme.colorScheme.primaryContainer 
                             else MaterialTheme.colorScheme.secondaryContainer
        ),
        modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()
    ) {
        Text(
            text = message.content,
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodyLarge
        )
    }
}
