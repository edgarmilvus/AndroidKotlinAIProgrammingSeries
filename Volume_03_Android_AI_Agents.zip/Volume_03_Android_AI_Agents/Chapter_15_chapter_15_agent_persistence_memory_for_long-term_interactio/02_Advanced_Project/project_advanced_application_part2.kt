
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

import android.content.Context
import androidx.room.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

// --- DOMAIN MODELS ---

/**
 * Represents a single unit of memory.
 * @param id Unique identifier for the memory fragment.
 * @param content The raw text content of the memory.
 * @param embedding The high-dimensional vector representing the semantic meaning.
 * @param timestamp When this memory was recorded.
 * @param importance A weight (0.0-1.0) used for pruning low-value memories.
 */
data class MemoryFragment(
    val id: String,
    val content: String,
    val embedding: FloatArray,
    val timestamp: Long,
    val importance: Float
)

// --- DATA LAYER: PERSISTENCE ---

@Entity(tableName = "memory_metadata")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    val timestamp: Long,
    val importance: Float
)

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMetadata(metadata: MemoryEntity)

    @Query("SELECT * FROM memory_metadata ORDER BY timestamp DESC LIMIT 100")
    fun getAllMetadataFlow(): Flow<List<MemoryEntity>>

    @Query("DELETE FROM memory_metadata WHERE importance < :threshold")
    suspend fun pruneLowImportanceMemories(threshold: Float)
}

/**
 * A specialized Vector Store that simulates NPU-accelerated similarity search.
 * In a real-world production app, this would interface with an on-device 
 * vector database like ObjectBox or a custom C++ implementation via JNI.
 */
@Singleton
class OnDeviceVectorStore @Inject constructor() {
    private val vectorMap = mutableMapOf<String, FloatArray>()
    private val mutex = Mutex()

    suspend fun storeVector(id: String, vector: FloatArray) = mutex.withLock {
        vectorMap[id] = vector
    }

    suspend fun findNearestNeighbors(queryVector: FloatArray, topK: Int): List<String> = mutex.withLock {
        return vectorMap.entries
            .map { it.key to cosineSimilarity(queryVector, it.value) }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    private fun cosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in v1.indices) {
            dotProduct += v1[i] * v2[i]
            normA += v1[i] * v1[i]
            normB += v2[i] * v2[i]
        }
        return dotProduct / (sqrt(normA.toDouble()) * sqrt(normB.toDouble())).toFloat()
    }
}

// --- INFRASTRUCTURE: NPU-ACCELERATED EMBEDDINGS ---

/**
 * The EmbeddingEngine handles the transformation of text to vectors.
 * It is designed to leverage the NPU (Neural Processing Unit) via TFLite Delegates.
 */
interface EmbeddingEngine {
    suspend fun embed(text: String): FloatArray
}

class NpuEmbeddingEngine @Inject constructor(
    private val context: Context
) : EmbeddingEngine {

    // In a real implementation, this would load a .tflite model 
    // and use GpuDelegate or NNAPI delegate for NPU acceleration.
    override suspend fun embed(text: String): FloatArray = withContext(Dispatchers.Default) {
        // Simulate heavy NPU computation latency
        delay(150) 
        // Returning a dummy 384-dimension vector (standard for MiniLM models)
        FloatArray(384) { (0..100).random() / 100f }
    }
}

// --- REPOSITORY LAYER ---

@Singleton
class MemoryRepository @Inject constructor(
    private val memoryDao: MemoryDao,
    private val vectorStore: OnDeviceVectorStore,
    private val embeddingEngine: EmbeddingEngine
) {
    /**
     * The core "Remember" function.
     * Orchestrates metadata storage and vector indexing using structured concurrency.
     */
    suspend fun persistMemory(content: String, importance: Float) = supervisorScope {
        val id = java.util.UUID.randomUUID().toString()
        
        // 1. Generate embedding on NPU (Heavy)
        val embeddingDeferred = async { embeddingEngine.embed(content) }
        
        // 2. Prepare metadata
        val metadata = MemoryEntity(id, content, System.currentTimeMillis(), importance)

        // 3. Await embedding and commit both to their respective stores
        val embedding = embeddingDeferred.await()
        
        launch(Dispatchers.IO) {
            memoryDao.insertMetadata(metadata)
        }
        
        launch(Dispatchers.Default) {
            vectorStore.storeVector(id, embedding)
        }
    }

    /**
     * The core "Recall" function (RAG - Retrieval Augmented Generation).
     * Finds semantically relevant memories to augment the agent's context.
     */
    suspend fun retrieveRelevantContext(query: String, limit: Int = 3): List<String> = withContext(Dispatchers.Default) {
        val queryVector = embeddingEngine.embed(query)
        val nearestIds = vectorStore.findNearestNeighbors(queryVector, limit)
        
        // In a real app, we would fetch the actual text content from the Room DB using these IDs
        // For brevity, we return a simulated retrieval
        nearestIds.map { "Relevant memory context for ID: $it" }
    }
}

// --- PRESENTATION LAYER (MVI) ---

sealed class MemoryIntent {
    data class StoreNewMemory(val text: String, val importance: Float) : MemoryIntent()
    data class QueryMemory(val query: String) : MemoryIntent()
}

data class MemoryUiState(
    val isProcessing: Boolean = false,
    val retrievedContext: List<String> = emptyList(),
    val lastError: String? = null
)

@HiltViewModel
class AgentMemoryViewModel @Inject constructor(
    private val repository: MemoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoryUiState())
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    fun handleIntent(intent: MemoryIntent) {
        viewModelScope.launch {
            when (intent) {
                is MemoryIntent.StoreNewMemory -> storeMemory(intent.text, intent.importance)
                is MemoryIntent.QueryMemory -> queryMemory(intent.query)
            }
        }
    }

    private suspend fun storeMemory(text: String, importance: Float) {
        _uiState.update { it.copy(isProcessing = true) }
        try {
            repository.persistMemory(text, importance)
        } catch (e: Exception) {
            _uiState.update { it.copy(lastError = e.message) }
        } finally {
            _uiState.update { it.copy(isProcessing = false) }
        }
    }

    private suspend fun queryMemory(query: String) {
        _uiState.update { it.copy(isProcessing = true) }
        try {
            val context = repository.retrieveRelevantContext(query)
            _uiState.update { it.copy(retrievedContext = context) }
        } catch (e: Exception) {
            _uiState.update { it.copy(lastError = e.message) }
        } finally {
            _uiState.update { it.copy(isProcessing = false) }
        }
    }
}
