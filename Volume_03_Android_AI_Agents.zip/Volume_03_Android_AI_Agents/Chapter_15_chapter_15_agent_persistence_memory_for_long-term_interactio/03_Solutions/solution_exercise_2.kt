
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*

// Extension to initialize DataStore
val Context.dataStore by preferencesDataStore(name = "user_preferences")

data class UserPersona(
    val name: String,
    val skillLevel: String, // "Beginner", "Intermediate", "Expert"
    val tone: String        // "Professional", "Casual"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val SKILL_LEVEL = stringPreferencesKey("skill_level")
        val PREFERRED_TONE = stringPreferencesKey("preferred_tone")
    }

    // Transform raw DataStore preferences into a clean Domain Model
    val userPersonaFlow: Flow<UserPersona> = context.dataStore.data
        .map { preferences ->
            UserPersona(
                name = preferences[Keys.USER_NAME] ?: "User",
                skillLevel = preferences[Keys.SKILL_LEVEL] ?: "Beginner",
                tone = preferences[Keys.PREFERRED_TONE] ?: "Casual"
            )
        }

    suspend fun updatePersona(name: String, skill: String, tone: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.USER_NAME] = name
            prefs[Keys.SKILL_LEVEL] = skill
            prefs[Keys.PREFERRED_TONE] = tone
        }
    }
}

class PromptBuilder @Inject constructor(
    private val preferencesRepository: UserPreferencesRepository
) {
    // This function prepares the "System Message" for the LLM
    suspend fun buildSystemPrompt(): String {
        val persona = preferencesRepository.userPersonaFlow.first()
        return """
            You are a helpful AI Assistant. 
            The user's name is ${persona.name}. 
            Their technical skill level is ${persona.skillLevel}. 
            Always maintain a ${persona.tone} tone in your responses.
        """.trimIndent()
    }
}
