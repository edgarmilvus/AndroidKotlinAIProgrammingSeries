
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import net.sqlcipher.database.SupportOpenHelperFactory
import androidx.biometric.BiometricPrompt

// 1. Encrypted Room Database Setup
@Database(entities = [ChatMessage::class, MemorySnippet::class], version = 1)
abstract class SecureDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun vectorDao(): VectorDao
}

// Implementation of Database Builder (Simplified)
fun buildSecureDb(context: Context, passphrase: ByteArray): SecureDatabase {
    val factory = SupportOpenHelperFactory(passphrase)
    return Room.databaseBuilder(context, SecureDatabase::class.java, "secure_mem.db")
        .openHelperFactory(factory)
        .build()
}

// 2. Semantic Forgetting Service
class PrivacyService(
    private val vectorStore: VectorStore,
    private val vectorDao: VectorDao,
    private val embeddingModel: LocalEmbeddingModel
) {
    
    /**
     * When a user says "Forget everything about my ex-partner",
     * we don't search for the string "ex-partner", we search for the concept.
     */
    suspend fun forgetConcept(concept: String) {
        // Step A: Embed the concept to be forgotten
        val conceptEmbedding = embeddingModel.generateEmbedding(concept)

        // Step B: Find all memories semantically similar to this concept
        // We use a high threshold to ensure we only delete related items
        val allSnippets = vectorDao.getAllSnippets()
        val idsToDelete = allSnippets.filter { snippet ->
            val similarity = calculateCosineSimilarity(conceptEmbedding, snippet.embedding)
            similarity > 0.75f 
        }.map { it.id }

        // Step C: Execute bulk deletion
        if (idsToDelete.isNotEmpty()) {
            vectorDao.deleteByIds(idsToDelete)
        }
    }
}

// 3. Biometric Guard (Pseudo-code for UI layer)
fun authenticateUser(activity: FragmentActivity, onAuthenticated: () -> Unit) {
    val executor = ContextCompat.getMainExecutor(activity)
    val biometricPrompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onAuthenticated()
        }
    })

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock AI Memory")
        .setSubtitle("Authenticate to access sensitive personal data")
        .setNegativeButtonText("Cancel")
        .build()

    biometricPrompt.authenticate(promptInfo)
}
