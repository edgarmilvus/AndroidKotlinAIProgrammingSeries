
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import kotlin.math.sqrt

// 1. Entity for Vector Storage
@Entity(tableName = "semantic_memory")
data class MemorySnippet(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val embedding: FloatArray // Stored as a BLOB or converted to String
)

// 2. The Vector Store logic
class VectorStore(private val memoryDao: MemoryDao) {

    // Core Math: Cosine Similarity
    // Formula: (A · B) / (||A|| * ||B||)
    private fun cosineSimilarity(vectorA: FloatArray, vectorB: FloatArray): Float {
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vectorA.indices) {
            dotProduct += vectorA[i] * vectorB[i]
            normA += vectorA[i] * vectorA[i]
            normB += vectorB[i] * vectorB[i]
        }
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }

    suspend fun findRelevantContext(queryEmbedding: FloatArray, topK: Int = 3): List<String> {
        // 1. Fetch all snippets from DB
        val allSnippets = memoryDao.getAllSnippets()

        // 2. Calculate similarity in a background thread
        return withContext(Dispatchers.Default) {
            allSnippets
                .map { snippet ->
                    val similarity = cosineSimilarity(queryEmbedding, snippet.embedding)
                    Pair(snippet.content, similarity)
                }
                .filter { it.second > 0.7f } // Threshold to ensure relevance
                .sortedByDescending { it.second }
                .take(topK)
                .map { it.first }
        }
    }
}

// 3. The RAG Pipeline Orchestrator
class RAGService(
    private val embeddingModel: LocalEmbeddingModel, // Interface for TFLite
    private val vectorStore: VectorStore,
    private val llmClient: LLMClient
) {
    suspend fun askQuestion(question: String): String {
        // Step A: Convert question to vector
        val queryVector = embeddingModel.generateEmbedding(question)

        // Step B: Retrieve semantic context
        val contextSnippets = vectorStore.findRelevantContext(queryVector)
        val contextString = contextSnippets.joinToString("\n")

        // Step C: Augment the prompt
        val augmentedPrompt = """
            Use the following context to answer the question.
            Context: $contextString
            Question: $question
        """.trimIndent()

        // Step D: Generate response
        return llmClient.generate(augmentedPrompt)
    }
}
