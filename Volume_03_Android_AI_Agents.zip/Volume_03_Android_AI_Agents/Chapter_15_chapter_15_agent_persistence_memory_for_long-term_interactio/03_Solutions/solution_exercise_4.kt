
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

class MemoryManager(
    private val chatRepository: ChatRepository,
    private val summaryRepository: SummaryRepository,
    private val llmClient: LLMClient
) {
    private val TOKEN_THRESHOLD = 4000
    private val CHAR_TO_TOKEN_RATIO = 4 // Rough estimation

    suspend fun processNewMessage(newMessage: ChatMessage) {
        chatRepository.saveMessage(newMessage)
        
        val history = chatRepository.getFullHistory("session_1").first()
        val currentTokenCount = history.sumOf { it.content.length } / CHAR_TO_TOKEN_RATIO

        if (currentTokenCount > TOKEN_THRESHOLD) {
            triggerSummarization()
        }
    }

    private suspend fun triggerSummarization() {
        // 1. Identify the "Old" part of the conversation (the first 50%)
        val allMessages = chatRepository.getFullHistory("session_1").first()
        val splitIndex = allMessages.size / 2
        val messagesToSummarize = allMessages.subList(0, splitIndex)
        
        val conversationText = messagesToSummarize.joinToString("\n") { "${it.role}: ${it.content}" }

        // 2. Call LLM to compress information
        val summaryPrompt = """
            Summarize the following conversation into a concise list of key facts, 
            decisions, and user preferences. Focus on information that is 
            important for long-term memory.
            
            Conversation:
            $conversationText
        """.trimIndent()

        val summary = llmClient.generate(summaryPrompt)

        // 3. Persist the summary
        summaryRepository.saveSummary(MemorySummary(content = summary, timestamp = System.currentTimeMillis()))

        // 4. (Optional) Prune the old messages to free up context window
        // In a real app, you might archive them to a "Cold Storage" table
    }
}
