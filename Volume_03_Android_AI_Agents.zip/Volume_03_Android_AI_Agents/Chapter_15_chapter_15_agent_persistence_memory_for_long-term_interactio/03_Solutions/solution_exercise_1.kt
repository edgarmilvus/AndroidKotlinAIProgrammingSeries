
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import androidx.room.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

// 1. Entity Definition
@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val role: String, // "system", "user", "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

// 2. DAO with Sliding Window Query
@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Query("SELECT * FROM chat_messages WHERE conversationId = :convId ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentMessages(convId: String, limit: Int): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE conversationId = :convId ORDER BY timestamp ASC")
    fun getAllMessages(convId: String): Flow<List<ChatMessage>>
}

// 3. Repository handling the "Sliding Window" logic
@Singleton
class ChatRepository @Inject constructor(private val chatDao: ChatDao) {
    
    // For the UI: Show the full history
    fun getFullHistory(conversationId: String): Flow<List<ChatMessage>> = 
        chatDao.getAllMessages(conversationId)

    // For the LLM: Get only the last N messages, reversed to chronological order
    suspend fun getContextWindow(conversationId: String, limit: Int): List<ChatMessage> {
        // We take the first emission from the Flow (the latest N messages)
        // Because the DAO returns them DESC (newest first), we must reverse them
        return chatDao.getRecentMessages(conversationId, limit).first().reversed()
    }

    suspend fun saveMessage(message: ChatMessage) = chatDao.insertMessage(message)
}

// 4. ViewModel managing UI State
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository
) : ViewModel() {

    private val _conversationId = MutableStateFlow("default_session")
    
    // Expose conversation history to Compose via StateFlow
    val uiState: StateFlow<List<ChatMessage>> = _conversationId
        .flatMapLatest { id -> repository.getFullHistory(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sendMessage(text: String) {
        viewModelScope.launch {
            val userMsg = ChatMessage(conversationId = _conversationId.value, role = "user", content = text)
            repository.saveMessage(userMsg)
            // In a real app, trigger LLM call here...
        }
    }
}
