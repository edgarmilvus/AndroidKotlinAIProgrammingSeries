
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

class IntentResolver @Inject constructor(
    private val context: Context
) {
    /**
     * Resolves a SystemAction into an Android Intent and executes it.
     * We use the context to start the activity.
     */
    fun resolveAndExecute(action: SystemAction) {
        val intent = when (action) {
            is SystemAction.OpenUrl -> {
                Log.d("IntentResolver", "Opening URL: ${action.url}")
                Intent(Intent.ACTION_VIEW, Uri.parse(action.url))
            }
            is SystemAction.SendMessage -> {
                Log.d("IntentResolver", "Sending message to ${action.recipient}")
                // Implicit Intent to send a text message
                Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:${action.recipient}")
                    putExtra("sms_body", action.message)
                }
            }
            is SystemAction.OpenCamera -> {
                Log.d("IntentResolver", "Launching Camera")
                Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            }
            is SystemAction.Unknown -> {
                Log.e("IntentResolver", "AI generated an unknown action")
                return
            }
        }

        try {
            // Ensure there is an app available to handle the intent to avoid crashes
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                Log.e("IntentResolver", "No app found to handle this intent")
            }
        } catch (e: Exception) {
            Log.e("IntentResolver", "Failed to execute intent", e)
        }
    }
}
