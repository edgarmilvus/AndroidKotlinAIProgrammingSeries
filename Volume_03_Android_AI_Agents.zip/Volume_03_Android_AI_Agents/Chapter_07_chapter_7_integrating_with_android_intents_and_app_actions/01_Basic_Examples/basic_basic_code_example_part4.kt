
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AIOrchestrator @Inject constructor() {
    private val jsonParser = Json { ignoreUnknownKeys = true }

    /**
     * Simulates an LLM call. 
     * In production, this would be a network call to a Vertex AI or OpenAI endpoint.
     */
    suspend fun processUserRequest(prompt: String): SystemAction = withContext(Dispatchers.Default) {
        // SIMULATION: Imagine the LLM is given a system prompt like:
        // "You are an Android Agent. Respond ONLY in JSON. 
        // Options: {'OpenUrl': {'url': '...'}, 'SendMessage': {'recipient': '...', 'message': '...'}, 'OpenCamera': {}}"
        
        delay(1000) // Simulate network latency

        val simulatedLlmResponse = when {
            prompt.contains("google", ignoreCase = true) -> 
                """{"type": "OpenUrl", "url": "https://www.google.com"}"""
            prompt.contains("message", ignoreCase = true) || prompt.contains("text", ignoreCase = true) -> 
                """{"type": "SendMessage", "recipient": "123456789", "message": "Hello from AI Agent!"}"""
            prompt.contains("photo", ignoreCase = true) || prompt.contains("camera", ignoreCase = true) -> 
                """{"type": "OpenCamera"}"""
            else -> """{"type": "Unknown"}"""
        }

        return@withContext try {
            // This is where we map the raw JSON string to our sealed class
            // In a real implementation, you'd use a polymorphic serializer
            parseJsonToAction(simulatedLlmResponse)
        } catch (e: Exception) {
            SystemAction.Unknown
        }
    }

    private fun parseJsonToAction(json: String): SystemAction {
        // Simplified manual parsing for the example to avoid complex polymorphic setup
        return when {
            json.contains("OpenUrl") -> SystemAction.OpenUrl("https://www.google.com")
            json.contains("SendMessage") -> SystemAction.SendMessage("123456789", "Hello!")
            json.contains("OpenCamera") -> SystemAction.OpenCamera()
            else -> SystemAction.Unknown
        }
    }
}
