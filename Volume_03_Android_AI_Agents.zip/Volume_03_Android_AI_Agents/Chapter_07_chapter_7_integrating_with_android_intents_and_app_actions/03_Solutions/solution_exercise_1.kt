
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.net.Uri
import androidx.navigation.NavDeepLinkRequest
import androidx.navigation.NavOptionsBuilder
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

// 1. Data Schema
@Serializable
sealed class AgentCommand {
    @Serializable
    data class NavigateToTask(val taskId: String) : AgentCommand()
    @Serializable
    data class NavigateToCalendar(val date: Long) : AgentCommand()
    @Serializable
    data class NavigateToError(val message: String) : AgentCommand()
}

// 2. The Dispatcher (Hilt Singleton)
@Singleton
class NavigationDispatcher @Inject constructor() {
    private val _commands = MutableSharedFlow<AgentCommand>(extraBufferCapacity = 1)
    val commands = _commands.asSharedFlow()

    suspend fun dispatch(jsonPayload: String) {
        val command = try {
            Json.decodeFromString<AgentCommand>(jsonPayload)
        } catch (e: Exception) {
            AgentCommand.NavigateToError("Invalid Command Format")
        }
        _commands.emit(command)
    }
}

// 3. Implementation in MainActivity/Compose logic
// Note: In a real app, this would be inside a ViewModel or the Activity
// observing the SharedFlow.

fun handleNavigation(
    command: AgentCommand,
    navController: androidx.navigation.NavController,
    taskRepository: TaskRepository // Mock repository for validation
) {
    val request = when (command) {
        is AgentCommand.NavigateToTask -> {
            // The Challenge: Fallback Mechanism
            val exists = taskRepository.checkTaskExists(command.taskId)
            if (exists) {
                NavDeepLinkRequest.Builder
                    .fromUri("taskflow://task/${command.taskId}".toUri())
                    .build()
            } else {
                NavDeepLinkRequest.Builder
                    .fromUri("taskflow://error/not_found".toUri())
                    .build()
            }
        }
        is AgentCommand.NavigateToCalendar -> {
            NavDeepLinkRequest.Builder
                .fromUri("taskflow://calendar?date=${command.date}".toUri())
                .build()
        }
        is AgentCommand.NavigateToError -> {
            NavDeepLinkRequest.Builder
                .fromUri("taskflow://error?msg=${Uri.encode(command.message)}".toUri())
                .build()
        }
    }
    navController.navigate(request)
}

// Mock Repository for the example
interface TaskRepository {
    suspend fun checkTaskExists(id: String): Boolean
}
