
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.Shortcut المستخدم
import android.graphics.drawable.Icon
import androidx.core.content.pm.ShortcutManagerCompat
import javax.inject.Inject

// 1. The Shortcut Model
data class SmartScene(val id: String, val name: String, val iconRes: Int, val isHighEnergy: Boolean)

class ShortcutManagerSystem @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // 2. Dynamic Shortcut Creation
    fun updateDynamicShortcuts(scenes: List<SmartScene>) {
        val shortcutInfos = scenes.map { scene ->
            val intent = Intent("com.taskflow.ACTION_SCENE").apply {
                putExtra("EXTRA_SCENE_ID", scene.id)
                // Ensure the intent targets our own receiver/activity
                setPackage(context.packageName) 
            }

            ShortcutInfo.Builder(context, scene.id)
                .setShortLabel(scene.name)
                .setIntent(intent)
                .setIcon(Icon.createWithResource(context, scene.iconRes))
                .build()
        }
        ShortcutManagerCompat.pushDynamicShortcuts(context, shortcutInfos)
    }

    // 3. AI Awareness Layer & Contextual Pruning
    fun getAvailableActionsForAI(currentMode: String): List<String> {
        val allScenes = listOf(
            SmartScene("movie_night", "Movie Night", android.R.drawable.ic_menu_slideshow, false),
            SmartScene("party_mode", "Party Mode", android.R.drawable.ic_menu_compass, true),
            SmartScene("sleep_mode", "Sleep Mode", android.R.drawable.ic_lock_idle_lock, false)
        )

        // The Challenge: Contextual Pruning
        return allScenes.filter { scene ->
            if (currentMode == "SLEEP" && scene.isHighEnergy) {
                false // Prune "Party Mode" if user is sleeping
            } else {
                true
            }
        }.map { it.name }
    }
}
