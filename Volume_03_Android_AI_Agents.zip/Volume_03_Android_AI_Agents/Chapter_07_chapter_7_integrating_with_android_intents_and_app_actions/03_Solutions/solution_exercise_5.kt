
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicInteger

sealed class InterceptorResult {
    object Allow : InterceptorResult()
    data class Deny(val reason: String) : InterceptorResult()
    data class RequireManualApproval(val intent: Intent) : InterceptorResult()
}

interface IntentInterceptor {
    suspend fun intercept(intent: Intent): InterceptorResult
}

// 1. Component Whitelist Interceptor
class ComponentWhitelistInterceptor : IntentInterceptor {
    private val allowedPackages = setOf("com.taskflow", "com.google.android.apps.maps")

    override suspend fun intercept(intent: Intent): InterceptorResult {
        val targetPackage = intent.component?.packageName ?: intent.action // Simplified check
        return if (allowedPackages.any { targetPackage?.contains(it) == true }) {
            InterceptorResult.Allow
        } else {
            InterceptorResult.Deny("Target package not whitelisted")
        }
    }
}

// 2. Rate Limit Interceptor
class RateLimitInterceptor : IntentInterceptor {
    private val requestCount = AtomicInteger(0)
    private var lastResetTime = System.currentTimeMillis()

    override suspend fun intercept(intent: Intent): InterceptorResult {
        val now = System.currentTimeMillis()
        if (now - lastResetTime > 1000) { // Reset every second
            requestCount.set(0)
            lastResetTime = now
        }

        return if (requestCount.incrementAndGet() > 5) { // Max 5 intents per second
            InterceptorResult.Deny("Rate limit exceeded")
        } else {
            InterceptorResult.Allow
        }
    }
}

// 3. The Pipeline Orchestrator
class IntentSecurityPipeline(
    private val interceptors: List<IntentInterceptor>
) {
    suspend fun validateIntent(intent: Intent): InterceptorResult = withContext(Dispatchers.Default) {
        // The Challenge: Latency-Aware Security
        val result = withTimeoutOrNull(200L) {
            var currentResult: InterceptorResult = InterceptorResult.Allow
            
            for (interceptor in interceptors) {
                val interceptResult = interceptor.intercept(intent)
                if (interceptResult != InterceptorResult.Allow) {
                    currentResult = interceptResult
                    break
                }
            }
            currentResult
        }

        // If timeout occurs, default to manual approval for safety
        result ?: InterceptorResult.RequireManualApproval(intent)
    }
}
