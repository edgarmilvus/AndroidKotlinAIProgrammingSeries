
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

interface ExternalIntentFactory {
    fun createMapIntent(lat: Double?, lng: Double?): Intent?
    fun createCalendarIntent(title: String, startTime: Long): Intent
    fun createEmailIntent(recipient: String, subject: String): Intent
}

class ExternalIntentFactoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ExternalIntentFactory {

    override fun createMapIntent(lat: Double?, lng: Double?): Intent? {
        // The Challenge: Intent Enrichment
        return if (lat != null && lng != null) {
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng"))
        } else {
            // Fallback: If coordinates are missing, use a Search Intent
            Intent(Intent.ACTION_SEARCH).apply {
                data = Uri.parse("geo:0,0?q=destination") 
            }
        }
    }

    override fun createCalendarIntent(title: String, startTime: Long): Intent {
        return Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startTime)
        }
    }

    override fun createEmailIntent(recipient: String, subject: String): Intent {
        return Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
            putExtra(Intent.EXTRA_SUBJECT, subject)
        }
    }
}

class AgentOrchestrator @Inject constructor(
    private val factory: ExternalIntentFactory,
    @ApplicationContext private val context: Context
) {
    fun executeExternalAction(intent: Intent): Result<Unit> {
        // 2. Safety Check: Capability Check
        val packageManager = context.packageManager
        if (intent.resolveActivity(packageManager) != null) {
            context.startActivity(intent)
            return Result.success(Unit)
        } else {
            // 3. Error Handling
            return Result.failure(Exception("No suitable app found to handle this action."))
        }
    }
}
