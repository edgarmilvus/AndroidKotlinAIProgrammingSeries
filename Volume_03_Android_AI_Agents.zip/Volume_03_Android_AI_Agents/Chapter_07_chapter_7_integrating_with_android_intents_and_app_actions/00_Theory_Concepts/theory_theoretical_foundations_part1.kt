
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

import kotlinx.serialization.*
import kotlinx.serialization.json.*

/**
 * Represents the structured output of the LLM's reasoning process.
 * Instead of raw text, the LLM is prompted to return this JSON schema.
 */
@Serializable
data class AgentAction(
    val actionType: ActionType,
    val targetPackage: String? = null, // For Explicit Intents
    val parameters: Map<String, String>,
    val confidenceScore: Float
)

@Serializable
enum class ActionType {
    SEND_MESSAGE,
    CREATE_CALENDAR_EVENT,
    NAVIGATE_TO_LOCATION,
    SEARCH_WEB
}

/**
 * A production-ready mapper that converts LLM output into a real Android Intent.
 */
class IntentSynthesizer {
    fun synthesize(jsonOutput: String): Intent {
        val action = Json.decodeFromString<AgentAction>(jsonOutput)
        
        // Validation: High-confidence threshold check
        if (action.confidenceScore < 0.85f) {
            throw LowConfidenceException("Agent is unsure about this action.")
        }

        return when (action.actionType) {
            ActionType.SEND_MESSAGE -> {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra("jid", action.parameters["recipient_id"])
                    putExtra("body", action.parameters["message_body"])
                }
            }
            ActionType.NAVIGATE_TO_LOCATION -> {
                // Mapping semantic parameters to URI-based intents
                val uri = Uri.parse("geo:${action.parameters["lat"]},${action.parameters["lng']}")
                Intent(Intent.ACTION_VIEW, uri)
            }
            // Additional mappings...
            else -> throw UnsupportedOperationException("Action not implemented")
        }
    }
}

class LowConfidenceException(message: String) : Exception(message)
