
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

// Note: Context Receivers are an evolving Kotlin feature. 
// This demonstrates the architectural intent.

interface AIContext {
    val userPreferences: UserPreferences
    val currentTask: Task
}

interface PermissionContext {
    fun hasPermission(permission: String): Boolean
}

/**
 * This function can ONLY be called if an AIContext and a PermissionContext 
 * are available in the calling scope. 
 * This prevents the Agent from attempting unauthorized actions.
 */
context(AIContext, PermissionContext)
suspend fun executeAgenticIntent(intent: Intent) {
    val requiredPermission = when(intent.action) {
        Intent.ACTION_SEND -> android.Manifest.permission.SEND_SMS
        else -> null
    }

    if (requiredPermission != null && !hasPermission(requiredPermission)) {
        // Handle permission denial gracefully
        return
    }

    // Proceed with execution...
    println("Executing task ${currentTask.id} with preference ${userPreferences.theme}")
}
