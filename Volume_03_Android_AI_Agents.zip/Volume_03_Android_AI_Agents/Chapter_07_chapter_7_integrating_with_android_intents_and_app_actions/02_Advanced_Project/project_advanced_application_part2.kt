
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.intent

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Qualifier

// --- Domain Models ---

/**
 * Represents the high-level intent parsed from natural language.
 */
sealed class AgentIntentRequest {
    data class SendMessage(val recipient: String, val content: String, val packageOverride: String? = null) : AgentIntentRequest()
    data class OpenApp(val appName: String) : AgentIntentRequest()
    data class WebSearch(val query: String) : AgentIntentRequest()
    object Unknown : AgentIntentRequest()
}

/**
 * Represents the outcome of an intent execution attempt.
 */
sealed class IntentExecutionResult {
    object Success : IntentExecutionResult()
    data class Failure(val error: String) : IntentExecutionResult()
    data class RequiresConfirmation(val intent: Intent) : IntentExecutionResult()
}

/**
 * Custom Dispatcher to ensure AI inference runs on high-performance hardware (NPU/GPU).
 */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class NpuDispatcher

// --- Hardware-Aware Orchestration ---

/**
 * A specialized Repository that handles the translation from AI reasoning to Android System calls.
 */
interface IntentOrchestratorRepository {
    suspend fun execute(request: AgentIntentRequest): IntentExecutionResult
}

class IntentOrchestratorRepositoryImpl @Inject constructor(
    private val context: Context,
    @NpuDispatcher private val aiDispatcher: CoroutineDispatcher
) : IntentOrchestratorRepository {

    override suspend fun execute(request: AgentIntentRequest): IntentExecutionResult = withContext(aiDispatcher) {
        try {
            val intent = when (request) {
                is AgentIntentRequest.SendMessage -> buildMessageIntent(request)
                is AgentIntentRequest.OpenApp -> buildAppIntent(request)
                is AgentIntentRequest.WebSearch -> buildWebIntent(request)
                is AgentIntentRequest.Unknown -> return@withContext IntentExecutionResult.Failure("Could not parse intent")
            }

            // Safety Layer: Check if the intent is "High Risk" (e.g., sending messages to non-contacts)
            if (isHighRisk(request)) {
                return@withContext IntentExecutionResult.RequiresConfirmation(intent)
            }

            // Execution
            context.startActivity(intent)
            IntentExecutionResult.Success
        } catch (e: Exception) {
            IntentExecutionResult.Failure(e.localizedMessage ?: "Unknown Error")
        }
    }

    private fun buildMessageIntent(req: AgentIntentRequest.SendMessage): Intent {
        // Logic to find messaging apps or use a generic SEND intent
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, req.content)
            // In a real agent, we would use PackageManager to find the specific package for 'req.recipient'
            // For this example, we assume a generic intent or a specific package override
            req.packageOverride?.let { `package` = it }
        }
    }

    private fun buildAppIntent(req: AgentIntentRequest.OpenApp): Intent {
        // Simplified: In production, use a semantic lookup table or LLM-based package resolution
        val launchIntent = context.packageManager.getLaunchIntentForPackage(req.appName) 
            ?: Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        return launchIntent
    }

    private fun buildWebIntent(req: AgentIntentRequest.WebSearch): Intent {
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(req.query)}")
        return Intent(Intent.ACTION_VIEW, uri)
    }

    private fun isHighRisk(request: AgentIntentRequest): Boolean {
        // Logic to determine if the AI is performing an action that requires user eyes-on
        // e.g., Sending a message to a person not in the contact list
        return request is AgentIntentRequest.SendMessage && request.recipient.contains("unknown")
    }
}

// --- The Intelligence Engine ---

/**
 * The Engine responsible for the "Thinking" phase.
 * It uses the NPU-optimized dispatcher to run local LLM inference.
 */
class IntelligenceEngine @Inject constructor(
    @NpuDispatcher private val aiDispatcher: CoroutineDispatcher
) {
    /**
     * Simulates the process of an LLM parsing a string into a structured AgentIntentRequest.
     */
    suspend fun parseNaturalLanguage(input: String): AgentIntentRequest = withContext(aiDispatcher) {
        // In a real implementation, this would call a local model via MediaPipe or TensorFlow Lite
        // Here we simulate the semantic mapping logic
        delay(800) // Simulate NPU inference latency
        
        when {
            input.contains("send", ignoreCase = true) && input.contains("message", ignoreCase = true) -> {
                // Regex/LLM would extract these
                AgentIntentRequest.SendMessage("Mom", "I'm running 5 minutes late!")
            }
            input.contains("open", ignoreCase = true) -> {
                AgentIntentRequest.OpenApp("com.android.settings")
            }
            input.contains("search", ignoreCase = true) -> {
                AgentIntentRequest.WebSearch("How does NPU acceleration work?")
            }
            else -> AgentIntentRequest.Unknown
        }
    }
}

// --- ViewModel & UI State ---

data class AgentUiState(
    val isProcessing: Boolean = false,
    val lastCommand: String = "",
    val statusMessage: String = "",
    val pendingIntent: Intent? = null
)

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val intelligenceEngine: IntelligenceEngine,
    private val repository: IntentOrchestratorRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgentUiState())
    val uiState: StateFlow<AgentUiState> = _uiState.asStateFlow()

    /**
     * The primary entry point for user interaction.
     * Uses Structured Concurrency to ensure that if the ViewModel is cleared,
     * the AI inference and intent execution are cancelled.
     */
    fun processUserCommand(command: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true, lastCommand = command, statusMessage = "Thinking...")

            // Step 1: Parse (Reasoning Phase)
            val request = intelligenceEngine.parseNaturalLanguage(command)

            if (request is AgentIntentRequest.Unknown) {
                _uiState.value = _uiState.value.copy(isProcessing = false, statusMessage = "I didn't understand that.")
                return@launch
            }

            // Step 2: Execute (Action Phase)
            val result = repository.execute(request)

            // Step 3: Handle Result (State Transition)
            handleResult(result)
        }
    }

    private fun handleResult(result: IntentExecutionResult) {
        when (result) {
            is IntentExecutionResult.Success -> {
                _uiState.value = _uiState.value.copy(isProcessing = false, statusMessage = "Action completed successfully.")
            }
            is IntentExecutionResult.Failure -> {
                _uiState.value = _uiState.value.copy(isProcessing = false, statusMessage = "Error: ${result.error}")
            }
            is IntentExecutionResult.RequiresConfirmation -> {
                _uiState.value = _uiState.value.copy(
                    isProcessing = false,
                    statusMessage = "Confirm this action?",
                    pendingIntent = result.intent
                )
            }
        }
    }

    fun confirmIntent() {
        val intent = _uiState.value.pendingIntent
        if (intent != null) {
            // In a real app, we'd re-call the repository with a 'confirmed' flag
            // For brevity, we execute the intent directly here
            // Note: In production, use the Repository to maintain the single source of truth
            _uiState.value.pendingIntent?.let { 
                // Real-world: This would be handled by a dedicated confirmation flow
                _uiState.value = _uiState.value.copy(pendingIntent = null, statusMessage = "Confirmed!")
            }
        }
    }
}
