
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.ContentResolver
import android.provider.CalendarContract
import dagger.hilt.android.qualifiers.IoDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject

class CalendarQueryTool @Inject constructor(
    private val contentResolver: ContentResolver,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : Tool {
    override val name = "get_calendar_events"
    override val description = "Retrieves calendar events within a specific time range."
    override val inputSchema = """
        {
            "type": "object",
            "properties": {
                "start_time": { "type": "string", "description": "ISO 8601 format" },
                "end_time": { "type": "string", "description": "ISO 8601 format" }
            },
            "required": ["start_time", "end_time"]
        }
    """.trimIndent()

    override suspend fun execute(arguments: Map<String, Any>): ToolResult = withContext(ioDispatcher) {
        try {
            val startTimeStr = arguments["start_time"] as? String 
                ?: return@withContext ToolResult.Error("Missing start_time")
            val endTimeStr = arguments["end_time"] as? String 
                ?: return@withContext ToolResult.Error("Missing end_time")

            // 1. Parse ISO 8601 to Unix Millis
            val startMillis = ZonedDateTime.parse(startTimeStr, DateTimeFormatter.ISO_DATE_TIME)
                .toInstant().toEpochMilli()
            val endMillis = ZonedDateTime.parse(endTimeStr, DateTimeFormatter.ISO_DATE_TIME)
                .toInstant().toEpochMilli()

            // 2. Query ContentResolver
            val projection = arrayOf(
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DTSTART
            )
            
            val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} <= ?"
            val selectionArgs = arrayOf(startMillis.toString(), endMillis.toString())

            val events = mutableListOf<String>()
            
            contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${CalendarContract.Events.DTSTART} ASC"
            )?.use { cursor ->
                val titleIndex = cursor.getColumnIndex(CalendarContract.Events.TITLE)
                val startIdx = cursor.getColumnIndex(CalendarContract.Events.DTSTART)

                while (cursor.moveToNext()) {
                    val title = cursor.getString(titleIndex)
                    val startTime = cursor.getLong(startIdx)
                    val formattedTime = ZonedDateTime.ofInstant(
                        java.time.Instant.ofEpochMilli(startTime), 
                        java.time.ZoneId.systemDefault()
                    ).format(DateTimeFormatter.ofPattern("HH:mm"))
                    
                    events.add("'$title' at $formattedTime")
                }
            }

            // 3. Distill output for LLM
            if (events.isEmpty()) {
                ToolResult.Success("No events found in this time range.")
            } else {
                ToolResult.Success("Found ${events.size} events: ${events.joinToString(", ")}.")
            }

        } catch (e: Exception) {
            ToolResult.Error("Failed to query calendar: ${e.localizedMessage}")
        }
    }
}
