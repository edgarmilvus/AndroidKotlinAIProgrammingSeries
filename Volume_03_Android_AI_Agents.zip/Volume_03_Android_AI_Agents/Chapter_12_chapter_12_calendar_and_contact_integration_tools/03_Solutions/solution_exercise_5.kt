
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import androidx.compose.runtime.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

// 1. State and Context Definitions
data class UserContext(val visibleText: String, val activeApp: String)

sealed class AgentState {
    object Idle : AgentState()
    object Analyzing : AgentState()
    data class Clarifying(val message: String) : AgentState()
    data class Proposing(val eventTitle: String, val time: String) : AgentState()
    data class SuggestingAlternative(val message: String) : AgentState()
}

// 2. The Orchestrator
class AgentOrchestrator(
    private val contactTool: ContactLookupTool,
    private val calendarTool: CalendarQueryTool,
    private val viewModel: AgentViewModel
) {
    suspend fun onScreenContentChanged(context: UserContext) {
        viewModel.updateState(AgentState.Analyzing)

        // SIMULATION: In a real app, this text is sent to an LLM
        // LLM identifies intent: "schedule_meeting", person: "Dave", time: "next Tuesday 10am"
        val detectedPerson = "Dave" 
        val detectedTime = "2023-10-24T10:00:00Z" 

        // Step A: Contact Lookup
        val contactResult = contactTool.execute(mapOf("query" to detectedPerson))
        
        if (contactResult is ToolResult.Success) {
            // Check for ambiguity (Simulated: if result contains multiple names)
            if (contactResult.output.contains("Found: Dave Jenkins, Dave Connor")) {
                viewModel.updateState(AgentState.Clarifying("Which Dave did you mean?"))
                return
            }

            // Step B: Calendar Check
            val calendarResult = calendarTool.execute(mapOf(
                "start_time" to detectedTime,
                "end_time" to "2023-10-24T11:00:00Z"
            ))

            if (calendarResult is ToolResult.Success) {
                // If the calendar tool says "No events found", we propose
                if (calendarResult.output.contains("No events found")) {
                    viewModel.updateState(AgentState.Proposing("Coffee with $detectedPerson", "Tuesday 10am"))
                } else {
                    viewModel.updateState(AgentState.SuggestingAlternative(calendarResult.output))
                }
            }
        } else {
            viewModel.updateState(AgentState.Clarifying("I couldn't find that person."))
        }
    }
}

// 3. The ViewModel and UI (Jetpack Compose)
class AgentViewModel : androidx.lifecycle.ViewModel() {
    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    val state = _state.asStateFlow()

    fun updateState(newState: AgentState) { _state.value = newState }
}

@Composable
fun SuggestionOverlay(state: AgentState, onAccept: () -> Unit, onDismiss: () -> Unit) {
    when (state) {
        is AgentState.Proposing -> {
            androidx.compose.material3.Card(
                modifier = androidx.compose.ui.Modifier.padding(16.dp)
            ) {
                androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.padding(16.dp)) {
                    androidx.compose.material3.Text("Schedule ${state.eventTitle}?")
                    androidx.compose.material3.Text("Time: ${state.time}")
                    androidx.compose.material3.Button(onClick = onAccept) { androidx.compose.material3.Text("Accept") }
                    androidx.compose.material3.TextButton(onClick = onDismiss) { androidx.compose.material3.Text("Dismiss") }
                }
            }
        }
        is AgentState.Clarifying -> {
            androidx.compose.material3.Snackbar(action = { /* ... */ }) {
                androidx.compose.material3.Text(state.message)
            }
        }
        else -> {}
    }
}
