
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.room.*
import androidx.work.*
import android.content.Context
import kotlinx.coroutines.flow.Flow

// 1. The Room Entity with FTS4 for Full-Text Search
@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val phoneNumber: String,
    val email: String,
    val notes: String,
    val jobTitle: String
)

@Fts4(contentEntity = ContactEntity::class)
@Entity(tableName = "contacts_fts")
data class ContactFtsEntity(
    val name: String,
    val notes: String,
    val jobTitle: String
)

@Dao
interface ContactDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(contacts: List<ContactEntity>)

    // High-speed FTS search
    @Query("""
        SELECT c.* FROM contacts c 
        JOIN contacts_fts f ON c.id = f.rowid 
        WHERE contacts_fts MATCH :query
    """)
    suspend fun searchContacts(query: String): List<ContactEntity>

    @Query("SELECT * FROM contacts")
    fun getAllContacts(): Flow<List<ContactEntity>>
}

@Database(entities = [ContactEntity::class, ContactFtsEntity::class], version = 1)
abstract class ContactDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
}

// 2. The Synchronization Engine (WorkManager)
class ContactSyncWorker(
    context: Context,
    params: WorkerParameters,
    private val contactDao: ContactDao,
    private val contentResolver: android.content.ContentResolver
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        // In a real app, you'd query ContactsContract and map to ContactEntity
        // For this exercise, we simulate the sync logic
        val contactsToSync = listOf(
            ContactEntity(1, "Dave Rust", "555-0101", "dave@rust.com", "Met at tech conference, knows Rust", "Engineer"),
            ContactEntity(2, "Sarah Jenkins", "555-0202", "sarah@j.com", "Plumber", "Contractor")
        )
        
        contactDao.insertAll(contactsToSync)
        return Result.success()
    }
}

// 3. The Optimized Tool
class FastContactTool @Inject constructor(
    private val contactDao: ContactDao
) : Tool {
    override val name = "fast_contact_search"
    override val description = "Extremely fast search across names, notes, and job titles."
    override val inputSchema = "{ \"type\": \"object\", \"properties\": { \"query\": { \"type\": \"string\" } } }"

    override suspend fun execute(arguments: Map<String, Any>): ToolResult {
        val query = arguments["query"] as? String ?: return ToolResult.Error("Missing query")
        
        // FTS search is significantly faster than ContentResolver IPC
        val results = contactDao.searchContacts(query)
        
        return if (results.isEmpty()) {
            ToolResult.Success("No matching contacts found.")
        } else {
            val summary = results.joinToString("; ") { 
                "${it.name} (${it.jobTitle}) - ${it.notes}" 
            }
            ToolResult.Success(summary)
        }
    }
}
