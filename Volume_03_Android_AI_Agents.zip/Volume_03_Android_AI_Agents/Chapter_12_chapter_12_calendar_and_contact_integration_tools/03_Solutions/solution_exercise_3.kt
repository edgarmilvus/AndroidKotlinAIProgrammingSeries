
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.ContentResolver
import android.provider.CalendarContract
import dagger.hilt.android.qualifiers.IoDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject

class SmartSchedulerTool @Inject constructor(
    private val contentResolver: ContentResolver,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : Tool {
    override val name = "schedule_meeting"
    override val description = "Schedules a meeting. Automatically checks for conflicts."
    override val inputSchema = """
        {
            "type": "object",
            "properties": {
                "title": { "type": "string" },
                "start_time": { "type": "string" },
                "end_time": { "type": "string" }
            },
            "required": ["title", "start_time", "end_time"]
        }
    """.trimIndent()

    override suspend fun execute(arguments: Map<String, Any>): ToolResult = withContext(ioDispatcher) {
        try {
            val title = arguments["title"] as String
            val startStr = arguments["start_time"] as String
            val endStr = arguments["end_time"] as String

            val startMillis = ZonedDateTime.parse(startStr, DateTimeFormatter.ISO_DATE_TIME).toInstant().toEpochMilli()
            val endMillis = ZonedDateTime.parse(endStr, DateTimeFormatter.ISO_DATE_TIME).toInstant().toEpochMilli()

            // 1. THE CHECK PHASE: Look for overlaps
            val conflictSelection = "${CalendarContract.Events.DTSTART} < ? AND ${CalendarContract.Events.DTEND} > ?"
            val conflictArgs = arrayOf(endMillis.toString(), startMillis.toString())
            
            var conflictingEventName: String? = null

            contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                arrayOf(CalendarContract.Events.TITLE),
                conflictSelection,
                conflictArgs,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    conflictingEventName = cursor.getString(0)
                }
            }

            // 2. THE REASONING LOGIC
            if (conflictingEventName != null) {
                // We return Success because the tool performed its job correctly.
                // The "Conflict" is the payload that allows the LLM to re-plan.
                return@withContext ToolResult.Success(
                    "Conflict found: You already have '$conflictingEventName' at this time. Suggest an alternative time to the user."
                )
            }

            // 3. THE ACT PHASE: Insert the event
            val values = android.content.ContentValues().apply {
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, endMillis)
                put(CalendarContract.Events.CALENDAR_ID, 1) // Default calendar
                put(CalendarContract.Events.DESCRIPTION, "Scheduled by AI Assistant")
            }

            val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            if (uri != null) {
                ToolResult.Success("Meeting '$title' scheduled successfully.")
            } else {
                ToolResult.Error("Failed to insert event into calendar.")
            }

        } catch (e: Exception) {
            ToolResult.Error("Scheduling failed: ${e.localizedMessage}")
        }
    }
}
