
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.TimeZone
import javax.inject.Inject

// --- 1. Domain Models ---

/**
 * Represents a structured event within our Agent's domain.
 * This is what the LLM will eventually "populate" via function calling.
 */
data class AgentCalendarEvent(
    val title: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val description: String? = null
)

sealed class AgentState {
    object Idle : AgentState()
    object Thinking : AgentState()
    data class ToolExecuting(val toolName: String) : AgentState()
    data class Success(val message: String) : AgentState()
    data class Error(val error: String) : AgentState()
}

// --- 2. The Repository (The "Muscle") ---

/**
 * The Repository handles the low-level Android ContentResolver interactions.
 * It abstracts the complexity of the CalendarContract from the AI logic.
 */
class CalendarRepository @Inject constructor(
    private val context: Context
) {
    /**
     * Inserts a new event into the system calendar.
     * Uses Dispatchers.IO to ensure the Main thread is never blocked during disk I/O.
     */
    suspend fun insertEvent(event: AgentCalendarEvent): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, event.startTimeMillis)
                put(CalendarContract.Events.DTEND, event.endTimeMillis)
                put(CalendarContract.Events.TITLE, event.title)
                put(CalendarContract.Events.DESCRIPTION, event.description)
                put(CalendarContract.Events.CALENDAR_ID, 1) // Default calendar
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }

            val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            
            if (uri != null) {
                Result.success(uri.hashCode().toLong()) // Returning a dummy ID for demonstration
            } else {
                Result.failure(Exception("Failed to insert event: URI is null"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// --- 3. The ViewModel (The "Brain/Orchestrator") ---

/**
 * The ViewModel manages the Agent's state and orchestrates the Tool Calling loop.
 * It acts as the bridge between the UI and the Repository.
 */
@HiltViewModel
class AgentViewModel @Inject constructor(
    private val calendarRepository: CalendarRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState = _uiState.asStateFlow()

    /**
     * This function simulates the arrival of a "Tool Call" from an LLM.
     * In a real app, this would be triggered by a parsing engine that
     * converts LLM JSON output into Kotlin objects.
     */
    fun onAgentCommandReceived(commandJson: String) {
        viewModelScope.launch {
            _uiState.value = AgentState.Thinking
            
            // SIMULATION: In a real scenario, we would use a library like 
            // kotlinx.serialization to parse the LLM's JSON.
            // For this example, we assume the LLM successfully identified the intent.
            val mockEvent = AgentCalendarEvent(
                title = "Lunch with Sarah",
                startTimeMillis = System.currentTimeMillis() + 3600000, // +1 hour
                endTimeMillis = System.currentTimeMillis() + 7200000,  // +2 hours
                description = "Discussing the new AI Agent project"
            )

            executeCalendarTool(mockEvent)
        }
    }

    private suspend fun executeCalendarTool(event: AgentCalendarEvent) {
        _uiState.value = AgentState.ToolExecuting("add_calendar_event")

        // Perform the actual system operation
        val result = calendarRepository.insertEvent(event)

        // Transition state based on the result
        result.fold(
            onSuccess = {
                _uiState.value = AgentState.Success("Successfully scheduled: ${event.title}")
            },
            onFailure = { error ->
                _uiState.value = AgentState.Error(error.message ?: "Unknown Error")
            }
        )
    }
}

// --- 4. The UI Layer (Jetpack Compose) ---

/**
 * A simple UI to demonstrate the Agent's lifecycle.
 */
@Composable
fun AgentToolScreen(viewModel: AgentViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // UI Layout
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "AI Agent Calendar Tool", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(24.dp))

        when (val currentState = state) {
            is AgentState.Idle -> {
                Button(onClick = { viewModel.onAgentCommandReceived("{...}") }) {
                    Text("Simulate LLM Tool Call")
                }
            }
            is AgentState.Thinking -> {
                CircularProgressIndicator()
                Text("Agent is thinking...")
            }
            is AgentState.ToolExecuting -> {
                CircularProgressIndicator(color = Color.Magenta)
                Text("Executing Tool: ${currentState.toolName}")
            }
            is AgentState.Success -> {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Green)
                Text(currentState.message, color = Color.Green)
                Button(onClick = { /* Reset logic */ }) { Text("Reset") }
            }
            is AgentState.Error -> {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                Text("Error: ${currentState.error}", color = Color.Red)
            }
        }
    }
}
