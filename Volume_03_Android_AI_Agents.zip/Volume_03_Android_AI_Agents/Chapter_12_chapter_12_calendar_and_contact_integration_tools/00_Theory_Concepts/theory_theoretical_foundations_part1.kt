
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.kt
// Description: Theoretical Foundations
// ==========================================

// Gradle Dependencies for the Agentic Ecosystem
/*
dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    implementation("com.google.dagger:hilt-android:2.48")
    // AICore/Gemini Nano integration libraries (Internal/Preview)
    implementation("com.google.android.aicore:gemini-nano-sdk:1.0.0-alpha")
}
*/

/**
 * Represents the structured schema that is injected into the LLM.
 * This is what the "Reasoning Engine" sees.
 */
@Serializable
data class CreateEventSchema(
    val title: String,
    val startTimeIso: String,
    val durationMinutes: Int,
    val attendees: List<String> = emptyList()
)

/**
 * The Tool Definition interface.
 * Just as a Fragment has a lifecycle, a Tool has an execution context.
 */
interface AgentTool<T> {
    val name: String
    val description: String
    val schema: KClass<*>
    
    suspend fun execute(input: T): ToolResult
}

sealed class ToolResult {
    data class Success(val observation: String) : ToolResult()
    data class Failure(val error: String) : ToolResult()
}

/**
 * A production-ready implementation of a Calendar Tool.
 * 
 * We use 'context(CalendarRepository)' to demonstrate how the tool 
 * gains access to the system without explicit parameter passing.
 * This is the 'Context Receiver' pattern.
 */
class CreateCalendarEventTool(
    private val repository: CalendarRepository // Injected via Hilt
) : AgentTool<CreateEventSchema> {

    override val name = "create_calendar_event"
    override val description = "Creates a new event in the user's primary calendar."
    override val schema = CreateEventSchema::class

    // The 'context' keyword allows this function to be called only 
    // when a CalendarRepository is available in the scope.
    override suspend fun execute(input: CreateEventSchema): ToolResult = 
        withContext(Dispatchers.IO) {
            try {
                // Mapping the LLM's parsed schema to the Android ContentProvider model
                val eventUri = repository.insertEvent(
                    title = input.title,
                    start = input.startTimeIso,
                    duration = input.durationMinutes,
                    participants = input.attendees
                )
                
                ToolResult.Success("Event successfully created with ID: $eventUri")
            } catch (e: Exception) {
                // We return the error as an 'Observation' so the LLM can 
                // attempt to fix its own mistake (Self-Correction).
                ToolResult.Failure("Failed to create event: ${e.localizedMessage}")
            }
        }
}
