
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

// 1. The Tool Suite
class MorningBriefingTools @Inject constructor(
    private val weatherApi: WeatherApi,
    private val calendarRepo: CalendarRepository,
    private val newsApi: NewsApi
) {
    suspend fun getWeather() = weatherApi.fetch() // Suspending network call
    suspend fun getCalendar() = calendarRepo.getEvents(todayStart, todayEnd)
    suspend fun getNews() = newsApi.fetchLatest()
}

// 2. High-Performance ViewModel
@HiltViewModel
class BatchAgentViewModel @Inject constructor(
    private val tools: MorningBriefingTools,
    private val llmSdk: GoogleAiSdk
) : ViewModel() {

    fun performDailyBriefing(userPrompt: String) {
        viewModelScope.launch {
            // Step 1: LLM identifies all required tools
            val response = llmSdk.generateContent(userPrompt)
            val toolCalls = response.functionCalls // Assume SDK returns List<FunctionCall>

            if (toolCalls.isEmpty()) return@launch

            // Step 2: Parallel Dispatch using Coroutines
            val results = coroutineScope {
                toolCalls.map { call ->
                    async {
                        // Step 3: Partial Failure Handling via runCatching
                        runCatching {
                            when (call.name) {
                                "get_weather" -> tools.getWeather().toString()
                                "get_calendar" -> tools.getCalendar().toString()
                                "get_news" -> tools.getNews().toString()
                                else -> "Error: Unknown tool"
                            }
                        }.getOrElse { e ->
                            "Error: ${call.name} failed due to ${e.message}"
                        }
                    }
                }.awaitAll() // Wait for all to complete in parallel
            }

            // Step 4: Batch Response Processing
            // We map the results back to a single structured prompt for the LLM
            val batchContext = toolCalls.zip(results).joinToString("\n") { (call, res) ->
                "Tool: ${call.name}, Result: $res"
            }

            val finalBriefing = llmSdk.generateContent("Based on these results: $batchContext, provide a summary.")
            updateUi(finalBriefing.text)
        }
    }
}
