
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

// 1. Media Repository (Mocked)
class MediaRepository @Inject constructor() {
    data class MediaItem(val id: String, val title: String, val artist: String)

    private val library = listOf(
        MediaItem("id_1", "Lo-fi Study Beats", "Chill Master"),
        MediaItem("id_2", "Never Gonna Give You Up", "Rick Astley"),
        MediaItem("id_3", "Midnight Jazz", "Smooth Operator")
    )

    fun searchMedia(query: String): List<MediaItem> {
        return library.filter { 
            it.title.contains(query, ignoreCase = true) || 
            it.artist.contains(query, ignoreCase = true) 
        }
    }

    fun playMedia(mediaId: String): String {
        val item = library.find { it.id == mediaId }
        return if (item != null) "Now playing: ${item.title}" else "Error: Media not found"
    }
}

// 2. ViewModel with Contextual Memory
@HiltViewModel
class MediaViewModel @Inject constructor(
    private val mediaRepo: MediaRepository,
    private val llmSdk: GoogleAiSdk
) : ViewModel() {

    // This acts as the "Working Memory" for the agent
    private val chatHistory = mutableListOf<ChatMessage>()

    fun handleUserRequest(prompt: String) {
        viewModelScope.launch {
            chatHistory.add(ChatMessage(role = "user", content = prompt))
            
            // The System Prompt enforces the Grounding rule
            val systemInstructions = """
                You are a music controller. 
                RULE: You MUST NOT call 'play_media' unless you have a specific 'mediaId'.
                If the user is vague, call 'search_media' first.
                Once you have search results, ask the user to pick one or identify which one they want.
            """.trimIndent()

            var response = llmSdk.generateWithHistory(systemInstructions, chatHistory)

            // Handle the Tool Loop
            if (response.functionCall != null) {
                val call = response.functionCall!!
                val result = when (call.name) {
                    "search_media" -> {
                        val query = call.args["query"] as String
                        val items = mediaRepo.searchMedia(query)
                        // We return a string representation for the LLM to "see" the IDs
                        items.joinToString { "[ID: ${it.id}, Title: ${it.title}, Artist: ${it.artist}]" }
                    }
                    "play_media" -> {
                        val id = call.args["mediaId"] as String
                        mediaRepo.playMedia(id)
                    }
                    else -> "Unknown tool"
                }

                // Add tool result to history so the LLM "remembers" the IDs
                chatHistory.add(ChatMessage(role = "assistant", content = response.text))
                chatHistory.add(ChatMessage(role = "tool", content = result))

                // Final pass to synthesize the answer
                response = llmSdk.generateWithHistory(systemInstructions, chatHistory)
            }

            chatHistory.add(ChatMessage(role = "assistant", content = response.text))
            updateUi(response.text)
        }
    }
    
    private fun updateUi(msg: String) { /* ... */ }
}
