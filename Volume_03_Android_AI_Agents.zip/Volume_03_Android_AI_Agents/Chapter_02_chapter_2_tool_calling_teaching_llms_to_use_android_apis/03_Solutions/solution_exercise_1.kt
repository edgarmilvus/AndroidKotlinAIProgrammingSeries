
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

// 1. Data Model for Tool Output
data class ContactResult(val name: String, val phone: String?, val email: String?)

// 2. Repository with Hilt Injection
class ContactRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun searchContact(query: String): List<ContactResult> {
        val contacts = mutableListOf<ContactResult>()
        val resolver = context.contentResolver

        // Querying Phone Numbers
        val phoneCursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            null
        )

        phoneCursor?.use { cursor ->
            while (cursor.moveToNext()) {
                val name = cursor.getString(0)
                val number = cursor.getString(1)
                contacts.add(ContactResult(name, number, null))
            }
        }

        // Querying Emails (Simplified for brevity)
        val emailCursor = resolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Email.DISPLAY_NAME, ContactsContract.CommonDataKinds.Email.ADDRESS),
            "${ContactsContract.CommonDataKinds.Email.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            null
        )

        emailCursor?.use { cursor ->
            while (cursor.moveToNext()) {
                val name = cursor.getString(0)
                val email = cursor.getString(1)
                // Avoid duplicates if name matches phone entry
                if (contacts.none { it.name == name }) {
                    contacts.add(ContactResult(name, null, email))
                }
            }
        }
        return contacts
    }
}

// 3. ViewModel managing the Tool Loop and State
@HiltViewModel
class ContactChatViewModel @Inject constructor(
    private val contactRepository: ContactRepository,
    private val llmSdk: GoogleAiSdk // Mocked SDK
) : ViewModel() {

    sealed class AgentState {
        object Idle : AgentState()
        object Thinking : AgentState()
        data class CallingTool(val toolName: String) : AgentState()
        data class Responding(val message: String) : AgentState()
        data class Error(val message: String) : AgentState()
    }

    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState = _uiState.asStateFlow()

    fun sendMessage(userPrompt: String) {
        viewModelScope.launch {
            _uiState.value = AgentState.Thinking
            
            // Step 1: Send prompt to LLM
            val response = llmSdk.generateContent(userPrompt)

            // Step 2: Check if LLM wants to call a tool
            if (response.functionCall != null) {
                val call = response.functionCall!!
                if (call.name == "search_contact") {
                    _uiState.value = AgentState.CallingTool("search_contact")
                    
                    // Step 3: Execute the actual Android API call
                    val query = call.args["query"] as String
                    val results = contactRepository.searchContact(query)
                    
                    // Step 4: Feed results back to LLM
                    val toolResponse = "Results: ${results.joinToString { "${it.name}: ${it.phone ?: it.email}" }}"
                    val finalResponse = llmSdk.generateContent(toolResponse)
                    
                    _uiState.value = AgentState.Responding(finalResponse.text)
                }
            } else {
                _uiState.value = AgentState.Responding(response.text)
            }
        }
    }
}
