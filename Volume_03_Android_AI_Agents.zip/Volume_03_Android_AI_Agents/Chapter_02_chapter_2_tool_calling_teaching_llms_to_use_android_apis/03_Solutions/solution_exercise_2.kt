
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

// 1. Repository for System Settings
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun setDarkMode(enabled: Boolean) {
        uiModeManager.setNightMode(if (enabled) Configuration.MODE_NIGHT_YES else Configuration.MODE_NIGHT_NO)
    }

    fun setBrightness(level: Int) {
        // Normalize 0-100 to 0-255 if the LLM sends percentage
        val normalizedLevel = if (level <= 100) (level * 2.55).toInt() else level.coerceIn(0, 255)
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, normalizedLevel)
    }

    fun toggleDND(enabled: Boolean) {
        if (notificationManager.isNotificationPolicyAccessGranted) {
            val filter = if (enabled) NotificationManager.INTERRUPTION_FILTER_NONE 
                         else NotificationManager.INTERRUPTION_FILTER_ALL
            notificationManager.setInterruptionFilter(filter)
        } else {
            throw SecurityException("DND permission not granted")
        }
    }
}

// 2. ViewModel with HITL Logic
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    // Represents a pending action awaiting user confirmation
    private val _pendingAction = MutableStateFlow<PendingAction?>(null)
    val pendingAction = _pendingAction.asStateFlow()

    data class PendingAction(val name: String, val execute: () -> Unit)

    fun handleToolCall(toolName: String, args: Map<String, Any>) {
        viewModelScope.launch {
            when (toolName) {
                "set_dark_mode" -> {
                    val enabled = args["enabled"] as Boolean
                    // Safety Guardrail: Instead of executing, we queue for confirmation
                    _pendingAction.value = PendingAction("Enable Dark Mode") {
                        settingsRepository.setDarkMode(enabled)
                    }
                }
                "set_screen_brightness" -> {
                    val level = args["level"] as Int
                    _pendingAction.value = PendingAction("Set brightness to $level%") {
                        settingsRepository.setBrightness(level)
                    }
                }
                "toggle_do_not_disturb" -> {
                    val enabled = args["enabled"] as Boolean
                    _pendingAction.value = PendingAction("Turn on Do Not Disturb") {
                        settingsRepository.toggleDND(enabled)
                    }
                }
            }
        }
    }

    fun confirmAction() {
        _pendingAction.value?.execute?.invoke()
        _pendingAction.value = null
    }

    fun cancelAction() {
        _pendingAction.value = null
    }
}

// 3. UI Component (Jetpack Compose)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val pendingAction by viewModel.pendingAction.collectAsState()

    Column {
        Text("AI Settings Agent")
        
        // Confirmation Dialog (The HITL Pattern)
        pendingAction?.let { action ->
            AlertDialog(
                onDismissRequest = { viewModel.cancelAction() },
                title = { Text("Confirm AI Action") },
                text = { Text("The AI wants to: ${action.name}. Allow?") },
                confirmButton = {
                    Button(onClick = { viewModel.confirmAction() }) { Text("Allow") }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.cancelAction() }) { Text("Deny") }
                }
            )
        }
    }
}
