
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

// 1. Calendar Repository
class CalendarRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun getEvents(start: Long, end: Long): List<CalendarEvent> {
        val events = mutableListOf<CalendarEvent>()
        val projection = arrayOf(
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND
        )
        
        val selection = "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTEND} <= ?"
        val selectionArgs = arrayOf(start.toString(), end.toString())

        context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                events.add(CalendarEvent(
                    title = cursor.getString(0),
                    start = cursor.getLong(1),
                    end = cursor.getLong(2)
                ))
            }
        }
        return events
    }

    fun createEvent(title: String, start: Long, end: Long) {
        val values = ContentValues().apply {
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, start)
            put(CalendarContract.Events.DTEND, end)
            put(CalendarContract.Events.CALENDAR_ID, 1) // Default calendar
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
    }
}

data class CalendarEvent(val title: String, val start: Long, val end: Long)

// 2. ReAct Agent ViewModel
@HiltViewModel
class CalendarAgentViewModel @Inject constructor(
    private val calendarRepo: CalendarRepository,
    private val llmSdk: GoogleAiSdk
) : ViewModel() {

    // The "System Prompt" provides Temporal Grounding
    private val systemPrompt = """
        You are a scheduling assistant. 
        Current Time: ${System.currentTimeMillis()}
        If the user asks for a time, use the current time to calculate the exact Long timestamp.
        Follow the ReAct pattern: 
        1. Use get_calendar_events to check availability.
        2. Analyze the results.
        3. Use create_calendar_event to book if clear.
    """.trimIndent()

    fun processUserRequest(userPrompt: String) {
        viewModelScope.launch {
            var currentContext = listOf(ChatMessage(role = "user", content = userPrompt))
            var iterations = 0
            val maxIterations = 5

            while (iterations < maxIterations) {
                iterations++
                
                // 1. LLM Reasoning Step
                val response = llmSdk.generateWithHistory(systemPrompt, currentContext)
                
                if (response.functionCall == null) {
                    // Final Answer reached
                    updateUi(response.text)
                    break
                }

                // 2. Tool Execution Step
                val call = response.functionCall!!
                val toolResult = when (call.name) {
                    "get_calendar_events" -> {
                        val start = call.args["start"] as Long
                        val end = call.args["end"] as Long
                        calendarRepo.getEvents(start, end).toString()
                    }
                    "create_calendar_event" -> {
                        calendarRepo.createEvent(
                            call.args["title"] as String,
                            call.args["start"] as Long,
                            call.args["end"] as Long
                        )
                        "Success: Event created."
                    }
                    else -> "Unknown tool"
                }

                // 3. Observation Step (Feeding result back into history)
                currentContext = currentContext + listOf(
                    ChatMessage(role = "assistant", content = response.text),
                    ChatMessage(role = "tool", content = toolResult)
                )
                
                if (iterations == maxIterations) {
                    updateUi("I'm sorry, I'm having trouble completing that multi-step task.")
                }
            }
        }
    }
    
    private fun updateUi(msg: String) { /* Update StateFlow */ }
}
