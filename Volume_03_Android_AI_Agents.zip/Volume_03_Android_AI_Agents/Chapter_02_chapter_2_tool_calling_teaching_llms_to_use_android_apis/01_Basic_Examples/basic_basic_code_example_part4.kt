
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * The ViewModel manages the state machine of the AI Agent.
 * It handles the loop: User -> AI -> Tool -> AI -> User.
 */
@HiltViewModel
class AgentViewModel @Inject constructor(
    private val toolExecutor: ToolExecutor
) : ViewModel() {

    // State for the UI to observe
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    fun sendMessage(text: String) {
        viewModelScope.launch {
            // 1. Update UI with user message
            appendMessage(ChatMessage.User(text))
            _isThinking.value = true

            try {
                // 2. The Tool Calling Loop
                processAiResponse(text)
            } finally {
                _isThinking.value = false
            }
        }
    }

    private suspend fun processAiResponse(userInput: String) {
        // Switch to Default dispatcher for AI processing to avoid blocking Main Thread
        withContext(Dispatchers.Default) {
            // SIMULATION: In a real app, you would call the Gemini/OpenAI API here.
            // We simulate the LLM returning a 'Tool Call' request.
            val aiResponse = simulateLlmCall(userInput)

            if (aiResponse is AiResponse.ToolCall) {
                // LOGIC: The LLM wants to use a tool.
                appendMessage(ChatMessage.Ai("I'll check that for you..."))

                // Execute the tool on the Android system
                val result = toolExecutor.executeTool(
                    aiResponse.toolName, 
                    aiResponse.arguments
                )

                // Feed the result back to the LLM to get the final natural language answer
                val finalResponse = simulateLlmFinalSynthesis(result)
                appendMessage(ChatMessage.Ai(finalResponse))
            } else if (aiResponse is AiResponse.Text) {
                // The LLM answered directly without needing a tool.
                appendMessage(ChatMessage.Ai(aiResponse.text))
            }
        }
    }

    private suspend fun appendMessage(message: ChatMessage) {
        withContext(Dispatchers.Main) {
            _chatHistory.value = _chatHistory.value + message
        }
    }

    // --- Simulation Helpers (Replacing actual API calls for this example) ---

    private fun simulateLlmCall(input: String): AiResponse {
        return when {
            input.contains("flashlight", ignoreCase = true) -> 
                AiResponse.ToolCall("toggle_flashlight", mapOf("enabled" to true))
            input.contains("battery", ignoreCase = true) -> 
                AiResponse.ToolCall("get_battery_level", emptyMap())
            else -> AiResponse.Text("I'm not sure how to help with that, but I can control your flashlight or check battery!")
        }
    }

    private fun simulateLlmFinalSynthesis(toolResult: String): String {
        return "Done! $toolResult"
    }
}

// Data models for the AI interaction
sealed class ChatMessage {
    data class User(val text: String) : ChatMessage()
    data class Ai(val text: String) : ChatMessage()
}

sealed class AiResponse {
    data class Text(val text: String) : AiResponse()
    data class ToolCall(val toolName: String, val arguments: Map<String, Any>) : AiResponse()
}
