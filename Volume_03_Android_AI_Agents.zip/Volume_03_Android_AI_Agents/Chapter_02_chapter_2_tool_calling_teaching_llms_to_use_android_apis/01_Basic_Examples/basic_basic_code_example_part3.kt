
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The ToolExecutor is responsible for the actual side-effects on the Android system.
 * It acts as the bridge between the LLM's intent and the Android OS.
 */
@Singleton
class ToolExecutor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    /**
     * Executes a tool based on the name and arguments provided by the LLM.
     * @return A string representation of the result to be fed back to the LLM.
     */
    suspend fun executeTool(toolName: String, arguments: Map<String, Any>): String {
        return when (toolName) {
            "toggle_flashlight" -> {
                val enabled = arguments["enabled"] as? Boolean ?: false
                handleFlashlight(enabled)
            }
            "get_battery_level" -> {
                handleBatteryLevel()
            }
            else -> "Error: Tool $toolName not found."
        }
    }

    private fun handleFlashlight(enabled: Boolean): String {
        return try {
            // Get the first available camera ID (usually the back camera with flash)
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, enabled)
            "Success: Flashlight has been turned ${if (enabled) "on" else "off"}."
        } catch (e: Exception) {
            "Error: Could not toggle flashlight. ${e.localizedMessage}"
        }
    }

    private fun handleBatteryLevel(): String {
        val batteryStatus: Intent? = context.registerReceiver(
            IntentFilter(Intent.ACTION_BATTERY_CHANGED), 
            null
        )
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = (level.toFloat() / scale.toFloat() * 100).toInt()
        
        return "The current battery level is $batteryPct%."
    }
}
