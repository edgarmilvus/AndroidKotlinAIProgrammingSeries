
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.example.aiagent.orchestration

import android.content.Context
import android.graphics.Bitmap
import androidx.annotation.OptIn
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

// --- DOMAIN MODELS ---

/**
 * Represents the structured output from an LLM indicating a tool should be called.
 */
@Serializable
data class ToolCall(
    val toolName: String,
    val arguments: Map<String, String>
)

/**
 * Represents the result of a tool execution, which is fed back into the LLM.
 */
data class ToolResult(
    val output: String,
    val success: Boolean,
    val error: String? = null
)

/**
 * Sealed interface representing the various states of the Agentic Orchestrator.
 */
sealed interface AgentState {
    object Idle : AgentState
    data class Thinking(val thought: String) : AgentState
    data class ExecutingTool(val toolName: String, val args: Map<String, String>) : AgentState
    data class Success(val finalResponse: String) : AgentState
    data class Error(val message: String) : AgentState
}

// --- TOOL DEFINITIONS ---

/**
 * Base interface for all Android-integrated tools.
 * Implementations must be thread-safe and handle their own hardware orchestration.
 */
interface AndroidTool {
    val name: String
    suspend fun execute(args: Map<String, String>): ToolResult
}

/**
 * A tool that interacts with the Android MediaStore.
 * Optimized for Dispatchers.IO as it performs heavy Disk I/O.
 */
class MediaTool @Inject constructor(
    private val context: Context
) : AndroidTool {
    override val name: String = "media_tool"

    override suspend fun execute(args: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        try {
            val fileName = args["file_name"] ?: throw IllegalArgumentException("Missing file_name")
            // Simulate MediaStore lookup
            delay(500) 
            ToolResult(output = "Found file: /storage/emulated/0/Pictures/$fileName", success = true)
        } catch (e: Exception) {
            ToolResult(output = "", success = false, error = e.message)
        }
    }
}

/**
 * A tool that performs heavy image processing using NPU/GPU acceleration.
 * Uses a custom dispatcher to ensure it doesn't starve the UI or standard IO threads.
 */
class VisionTool @Inject constructor() : AndroidTool {
    override val name: String = "vision_tool"

    // In a real app, this would be a dispatcher tied to a specialized thread pool
    // or an NPU-aware executor via NNAPI.
    private val npuDispatcher = Dispatchers.Default 

    override suspend fun execute(args: Map<String, String>): ToolResult = withContext(npuDispatcher) {
        try {
            val inputPath = args["path"] ?: throw IllegalArgumentException("Missing path")
            val effect = args["effect"] ?: "grayscale"
            
            // Simulate NPU-intensive computation (e.g., running a TFLite model)
            delay(1500) 
            
            ToolResult(output = "Processed $inputPath with $effect effect successfully.", success = true)
        } catch (e: Exception) {
            ToolResult(output = "", success = false, error = e.message)
        }
    }
}

// --- ORCHESTRATION LAYER ---

/**
 * The Registry maps LLM string identifiers to concrete Tool implementations.
 */
class ToolRegistry @Inject constructor(
    private val tools: Set<@JvmSuppressWildcards AndroidTool>
) {
    private val toolMap = tools.associateBy { it.name }

    fun getTool(name: String): AndroidTool? = toolMap[name]
}

/**
 * The AgentOrchestrator manages the "Reasoning Loop".
 * It is responsible for the lifecycle of a task, from initial intent to final observation.
 */
@Singleton
class AgentOrchestrator @Inject constructor(
    private val toolRegistry: ToolRegistry,
    // In a real app, this would be your LLM client (e.g., Gemini SDK or OpenAI)
    private val llmClient: MockLLMClient 
) {
    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    val state: StateFlow<AgentState> = _state.asStateFlow()

    /**
     * The core execution loop. Uses Structured Concurrency to ensure that
     * if the user cancels the task, all tool executions are immediately halted.
     */
    suspend fun runTask(userIntent: String) = coroutineScope {
        _state.value = AgentState.Thinking("Analyzing intent: $userIntent")

        try {
            var conversationHistory = listOf("User: $userIntent")
            var isTaskComplete = false
            var finalAnswer = ""

            // The Agentic Loop
            while (!isTaskComplete) {
                // 1. Ask the LLM what to do next based on history
                val response = llmClient.generateResponse(conversationHistory)

                if (response.toolCalls.isNotEmpty()) {
                    // 2. If the LLM wants to call tools, execute them
                    for (call in response.toolCalls) {
                        _state.value = AgentState.ExecutingTool(call.toolName, call.arguments)
                        
                        val tool = toolRegistry.getTool(call.toolName)
                        val result = if (tool != null) {
                            tool.execute(call.arguments)
                        } else {
                            ToolResult(output = "Error: Tool ${call.toolName} not found", success = false)
                        }

                        // 3. Append the tool result back to history for the next reasoning step
                        conversationHistory += "Tool Result (${call.toolName}): ${result.output}"
                        
                        if (!result.success) {
                            // Handle tool failure: The agent can decide to retry or give up
                            conversationHistory += "System: Tool failed with error: ${result.error}"
                        }
                    }
                } else {
                    // 4. If no more tool calls, the LLM has provided the final answer
                    finalAnswer = response.finalText
                    isTaskComplete = true
                }

                // Safety break to prevent infinite loops in reasoning
                if (conversationHistory.size > 20) {
                    throw IllegalStateException("Agent reasoning loop exceeded maximum steps.")
                }
            }

            _state.value = AgentState.Success(finalAnswer)

        } catch (e: CancellationException) {
            _state.value = AgentState.Error("Task cancelled by user.")
            throw e // Re-throw to respect coroutine cancellation
        } catch (e: Exception) {
            _state.value = AgentState.Error("Agent Error: ${e.localizedMessage}")
        }
    }
}

/**
 * Mock LLM client to demonstrate the flow.
 */
class MockLLMClient @Inject constructor() {
    suspend fun generateResponse(history: List<String>): LLMResponse {
        delay(1000) // Simulate network latency
        
        return when {
            // Step 1: User wants to find a file
            history.size == 1 -> LLMResponse(
                toolCalls = listOf(ToolCall("media_tool", mapOf("file_name" to "cat.jpg"))),
                finalText = ""
            )
            // Step 2: Agent sees file found, now wants to process it
            history.size == 3 -> LLMResponse(
                toolCalls = listOf(ToolCall("vision_tool", mapOf("path" to "/storage/emulated/0/Pictures/cat.jpg", "effect" to "sepia"))),
                finalText = ""
            )
            // Step 3: Agent sees processing done, provides final answer
            else -> LLMResponse(
                toolCalls = emptyList(),
                finalText = "I've found your cat photo and applied a beautiful sepia filter to it!"
            )
        }
    }
}

data class LLMResponse(
    val toolCalls: List<ToolCall> = emptyList(),
    val finalText: String = ""
)

// --- VIEWMODEL LAYER ---

@HiltViewModel
class AgentViewModel @Inject constructor(
    private val orchestrator: AgentOrchestrator
) : ViewModel() {

    val uiState: StateFlow<AgentState> = orchestrator.state

    fun onUserIntentEntered(intent: String) {
        viewModelScope.launch {
            orchestrator.runTask(intent)
        }
    }
}
