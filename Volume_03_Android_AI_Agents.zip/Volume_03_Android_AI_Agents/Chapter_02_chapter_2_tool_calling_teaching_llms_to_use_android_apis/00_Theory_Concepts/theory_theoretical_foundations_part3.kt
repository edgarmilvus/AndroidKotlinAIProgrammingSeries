
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

// Conceptual representation of a Tool Definition
data class ToolDefinition(
    val name: String,
    val description: String,
    val parameters: Map<String, ParameterInfo>
)

data class ParameterInfo(
    val type: String, // "string", "number", "boolean"
    val description: String,
    val required: Boolean
)

// Example: A tool to send a WhatsApp message
val sendWhatsAppTool = ToolDefinition(
    name = "send_whatsapp_message",
    description = "Sends a text message to a specific contact via WhatsApp",
    parameters = mapOf(
        "contactName" to ParameterInfo("string", "The full name of the contact", true),
        "message" to ParameterInfo("string", "The content of the message to send", true),
        "urgent" to ParameterInfo("boolean", "Whether to mark the message as urgent", false)
    )
)
