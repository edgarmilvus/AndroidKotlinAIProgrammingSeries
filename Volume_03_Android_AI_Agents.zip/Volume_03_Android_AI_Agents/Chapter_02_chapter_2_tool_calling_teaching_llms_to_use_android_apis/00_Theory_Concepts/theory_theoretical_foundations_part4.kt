
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.kt
// Description: Theoretical Foundations
// ==========================================

class ToolExecutor @Inject constructor(
    private val reminderRepository: ReminderRepository,
    private val contactRepository: ContactRepository
) {
    suspend fun execute(call: ToolCall): ToolResult {
        return try {
            when (call.name) {
                "schedule_reminder" -> {
                    val args = ToolParser.parseReminderRequest(call.args)
                    reminderRepository.insert(args.toEntity())
                    ToolResult.Success("Reminder scheduled for ${args.time}")
                }
                "find_contact" -> {
                    val contact = contactRepository.findByName(call.args["name"])
                    ToolResult.Success(contact?.toString() ?: "Contact not found")
                }
                else -> ToolResult.Error("Unknown tool: ${call.name}")
            }
        } catch (e: Exception) {
            ToolResult.Error("Execution failed: ${e.localizedMessage}")
        }
    }
}
