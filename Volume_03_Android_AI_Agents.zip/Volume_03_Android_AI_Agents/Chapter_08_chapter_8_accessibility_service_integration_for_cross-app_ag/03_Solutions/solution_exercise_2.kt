
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle

class FormAutomator @Inject constructor() {

    private val submitKeywords = listOf("submit", "send", "save", "continue", "confirm")

    fun automateForm(service: AccessibilityService, dataMap: Map<String, String>) {
        val rootNode = service.rootInActiveWindow ?: return

        // 1. Populate Fields
        dataMap.forEach { (label, value) ->
            val targetNode = findNodeBySemanticMatch(rootNode, label)
            targetNode?.let { node ->
                fillField(node, value)
            }
        }

        // 2. Submit Form
        val submitButton = findNodeBySemanticMatch(rootNode, submitKeywords)
        submitButton?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeBySemanticMatch(root: AccessibilityNodeInfo, query: Any): AccessibilityNodeInfo? {
        return if (query is String) {
            findNodeRecursive(root, listOf(query))
        } else if (query is List<*>) {
            findNodeRecursive(root, query.filterIsInstance<String>())
        } else null
    }

    private fun findNodeRecursive(node: AccessibilityNodeInfo, keywords: List<String>): AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val description = node.contentDescription?.toString() ?: ""
        
        // Fuzzy matching logic
        if (keywords.any { k -> 
            text.contains(k, ignoreCase = true) || description.contains(k, ignoreCase = true) 
        }) {
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeRecursive(child, keywords)
            if (found != null) return found
        }
        return null
    }

    private fun fillField(node: AccessibilityNodeInfo, value: String) {
        // 4. Focus Management: Ensure node is focused before input
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        
        // 2. Input Injection
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) {
            // Fallback for apps that resist SET_TEXT: try to click then use a keyboard helper (omitted for brevity)
        }
    }
}
