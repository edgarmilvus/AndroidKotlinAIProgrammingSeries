
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo

class AdaptiveNavigationEngine @Inject constructor() {

    private val synonymMap = mapOf(
        "SUBMIT" to listOf("Submit", "Confirm", "Send", "Done", "Apply"),
        "CANCEL" to listOf("Cancel", "Back", "Dismiss", "Stop")
    )

    suspend fun executeAndVerify(
        service: AccessibilityService,
        actionLabel: String,
        expectedState: (AccessibilityNodeInfo?) -> Boolean
    ): Boolean {
        // 1. Obstacle Detection
        if (detectPopUp(service)) {
            if (!handlePopUp(service)) return false
        }

        // 2. Dynamic Alias Matching
        val synonyms = synonymMap[actionLabel.uppercase()] ?: listOf(actionLabel)
        val node = findNodeBySynonyms(service.rootInActiveWindow, synonyms)

        if (node != null) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            
            // 3. Action-Verification Loop
            var attempts = 0
            while (attempts < 3) {
                kotlinx.coroutines.delay(1000)
                if (expectedState(service.rootInActiveWindow)) return true
                attempts++
            }
        }
        
        logFailure(service, actionLabel)
        return false
    }

    private fun detectPopUp(service: AccessibilityService): Boolean {
        val root = service.rootInActiveWindow ?: return false
        // Look for common modal patterns (e.g., AlertDialog)
        val isModal = root.className?.contains("AlertDialog") == true || 
                      root.className?.contains("PopupWindow") == true
        
        // Or look for a "Close" button that is high in the hierarchy
        val hasCloseButton = findNodeBySynonyms(root, listOf("Close", "X", "Dismiss")) != null
        
        return isModal || hasCloseButton
    }

    private suspend fun handlePopUp(service: AccessibilityService): Boolean {
        val closeButton = findNodeBySynonyms(service.rootInActiveWindow, listOf("Close", "X", "Dismiss"))
        return if (closeButton != null) {
            closeButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            kotlinx.coroutines.delay(500)
            true
        } else false
    }

    private fun findNodeBySynonyms(root: AccessibilityNodeInfo?, synonyms: List<String>): AccessibilityNodeInfo? {
        if (root == null) return null
        val text = root.text?.toString() ?: ""
        if (synonyms.any { text.contains(it, ignoreCase = true) }) return root
        
        for (i in 0 until root.childCount) {
            val found = findNodeBySynonyms(root.getChild(i), synonyms)
            if (found != null) return found
        }
        return null
    }

    private fun logFailure(service: AccessibilityService, action: String) {
        val snapshot = service.rootInActiveWindow // In reality, map to SemanticElements
        println("Navigation Failure: Could not verify $action. Snapshot captured.")
    }
}
