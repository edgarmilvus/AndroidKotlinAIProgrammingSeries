
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect
import javax.inject.Inject
import javax.inject.Singleton

// 1. Stable data class to avoid AccessibilityNodeInfo pooling issues
data class SemanticElement(
    val text: String?,
    val contentDescription: String?,
    val className: String?,
    val bounds: Rect,
    val isClickable: Boolean,
    val resourceId: String?
)

@Singleton
class ScreenParser @Inject constructor() {

    fun parseScreen(rootNode: AccessibilityNodeInfo?): List<SemanticElement> {
        val elements = mutableListOf<SemanticElement>()
        if (rootNode == null) return elements

        // Start recursive traversal
        traverseNode(rootNode, elements)
        return elements
    }

    private fun traverseNode(node: AccessibilityNodeInfo, elements: MutableList<SemanticElement>) {
        // 2. Noise Filtering: Only keep nodes that provide semantic value or interaction
        val isInteractable = node.isClickable || node.isFocusable || node.isCheckable
        val hasText = !node.text.isNullOrEmpty() || !node.contentDescription.isNullOrEmpty()

        if (node.isImportantForAccessibility && (isInteractable || hasText)) {
            // 3. Metadata Extraction: Map to POJO immediately
            elements.add(
                SemanticElement(
                    text = node.text?.toString(),
                    contentDescription = node.contentDescription?.toString(),
                    className = node.className?.toString(),
                    bounds = Rect(), // Initialize empty rect
                    isClickable = node.isClickable,
                    resourceId = node.viewIdResourceName
                ).apply {
                    // Capture bounds in a separate call to ensure accuracy
                    node.getBoundsInScreen(this.bounds)
                }
            )
        }

        // 4. Recursive Traversal
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                traverseNode(child, elements)
                // Note: In older Android versions, child.recycle() was mandatory here
            }
        }
    }
}

// Simple Compose Overlay for real-time debugging
@Composable
fun SemanticDebugOverlay(elementCount: Int) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Surface(
            color = Color.Black.copy(alpha = 0.7f),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "Semantic Elements: $elementCount",
                color = Color.White,
                modifier = Modifier.padding(8.dp),
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
