
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.security.MessageDigest

class SmartUIObserver @Inject constructor(
    private val screenParser: ScreenParser
) {
    private val eventFlow = MutableSharedFlow<AccessibilityEvent>(extraBufferCapacity = 64)
    private var lastSemanticHash: String? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    init {
        setupObservationPipeline()
    }

    fun onEvent(event: AccessibilityEvent) {
        eventFlow.tryEmit(event)
    }

    private fun setupObservationPipeline() {
        serviceScope.launch {
            eventFlow
                .filter { it.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || 
                           it.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED }
                .debounce(300) // 3. Debounce to wait for UI to settle
                .collect { event ->
                    if (hasSemanticChanged(event)) {
                        triggerFullScan()
                    }
                }
        }
    }

    private suspend fun hasSemanticChanged(event: AccessibilityEvent): Boolean {
        return withContext(Dispatchers.Main) {
            val root = (event as? AccessibilityService)?.rootInActiveWindow // Simplified for example
            // In real implementation, pass the service reference
            val currentText = root?.let { extractAllText(it) } ?: ""
            val currentHash = generateHash(currentText)
            
            if (currentHash != lastSemanticHash) {
                lastSemanticHash = currentHash
                true
            } else {
                false
            }
        }
    }

    private fun extractAllText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        // Recursive text extraction (simplified)
        fun traverse(node: AccessibilityNodeInfo) {
            sb.append(node.text ?: "")
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { traverse(it) }
            }
        }
        traverse(root)
        return sb.toString()
    }

    private fun generateHash(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun triggerFullScan() {
        // Offload heavy LLM/Parsing logic to background
        println("Semantic change detected. Triggering AI analysis...")
    }
}
