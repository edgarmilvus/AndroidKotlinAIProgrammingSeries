
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.content.Intent
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import javax.inject.Inject
import javax.inject.Singleton

sealed class AgentState {
    object Idle : AgentState()
    data class Extracting(val appPackage: String) : AgentState()
    data class Navigating(val targetPackage: String, val payload: String) : AgentState()
    data class Inputting(val targetPackage: String) : AgentState()
    data class Error(val message: String) : AgentState()
}

@Singleton
class DataBridgeManager @Inject constructor(
    private val screenParser: ScreenParser
) {
    private var currentState: AgentState = AgentState.Idle
    private var extractedData: String? = null
    private val trackingRegex = Regex("\\d{12}") // Example: 12-digit tracking number

    fun handleEvent(service: AccessibilityService, event: android.view.accessibility.AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return

        when (currentState) {
            is AgentState.Extracting -> {
                if (packageName == "com.google.android.gm") {
                    extractTrackingNumber(service)
                }
            }
            is AgentState.Navigating -> {
                if (packageName == (currentState as AgentState.Navigating).targetPackage) {
                    currentState = AgentState.Inputting(packageName)
                }
            }
            is AgentState.Inputting -> {
                if (packageName == (currentState as AgentState.Inputting).targetPackage) {
                    attemptInput(service)
                }
            }
            else -> {}
        }
    }

    private fun extractTrackingNumber(service: AccessibilityService) {
        val root = service.rootInActiveWindow ?: return
        val elements = screenParser.parseScreen(root)
        
        val match = elements.firstOrNull { it.text?.contains(trackingRegex) == true }
        if (match != null) {
            extractedData = trackingRegex.find(match.text!!)?.value
            currentState = AgentState.Navigating("com.fedex.package", extractedData!!)
            launchCarrierApp(service)
        }
    }

    private fun launchCarrierApp(service: AccessibilityService) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage("com.fedex.package")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        service.startActivity(intent)
    }

    private fun attemptInput(service: AccessibilityService) {
        CoroutineScope(Dispatchers.Main).launch {
            var retries = 0
            var success = false
            
            while (retries < 3 && !success) {
                val root = service.rootInActiveWindow
                val inputField = findInputNode(root)
                if (inputField != null) {
                    inputField.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, 
                        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, extractedData) })
                    success = true
                } else {
                    retries++
                    delay(2000) // Wait for loading screen
                }
            }
            if (!success) currentState = AgentState.Error("Could not find input field")
            else currentState = AgentState.Idle
        }
    }

    private fun findInputNode(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        // Simplified search for an EditText
        return root?.findAccessibilityNodeInfosByViewId("com.fedex.package:id/tracking_input")?.firstOrNull()
    }
}
