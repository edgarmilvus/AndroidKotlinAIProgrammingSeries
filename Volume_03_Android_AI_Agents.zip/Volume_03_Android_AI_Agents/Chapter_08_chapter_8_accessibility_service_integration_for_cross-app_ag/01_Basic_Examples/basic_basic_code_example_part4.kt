
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.kt
// Description: Basic Code Example
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class AgentAccessibilityService : AccessibilityService() {

    @Inject
    lateinit var repository: UIHierarchyRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We only care about window content changes or focus changes
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            
            // Capture the root node of the current window
            val rootNode = rootInActiveWindow ?: return
            
            // Process the tree on a background thread to prevent ANR
            serviceScope.launch {
                val semanticSnapshot = captureSemanticTree(rootNode)
                repository.updateHierarchy(semanticSnapshot)
                // Important: AccessibilityNodeInfo is a heavy resource; 
                // the system handles much of the recycling, but we must 
                // be careful not to hold long-term references.
            }
        }
    }

    private fun captureSemanticTree(root: AccessibilityNodeInfo): List<SemanticNode> {
        val nodeList = mutableListOf<SemanticNode>()
        traverse(root, 0, nodeList)
        return nodeList
    }

    private fun traverse(node: AccessibilityNodeInfo, depth: Int, list: MutableList<SemanticNode>) {
        // Convert the heavy NodeInfo into our lightweight DTO
        val bounds = node.boundsInScreen
        val semanticNode = SemanticNode(
            id = node.viewIdResourceName,
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            className = node.className?.toString() ?: "Unknown",
            isClickable = node.isClickable,
            bounds = Rect(bounds.left, bounds.top, bounds.right, bounds.bottom),
            depth = depth
        )
        list.add(semanticNode)

        // Recursively traverse children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverse(child, depth + 1, list)
            // In a production environment, you must ensure child nodes 
            // are handled correctly to avoid memory leaks.
        }
    }

    override fun onInterrupt() {
        serviceScope.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
