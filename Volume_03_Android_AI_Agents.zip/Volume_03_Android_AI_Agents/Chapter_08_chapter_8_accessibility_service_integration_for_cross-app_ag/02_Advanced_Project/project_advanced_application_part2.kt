
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.accessibility

import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.OptIn
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.toImmutableList
import javax.inject.Inject
import javax.inject.Qualifier
import javax.inject.Singleton

// --- DOMAIN MODELS ---

/**
 * A lightweight, flattened representation of a UI node.
 * This is what we actually send to the LLM to save tokens.
 */
data class SemanticNode(
    val id: String,
    val text: String?,
    val description: String?,
    val role: String, // e.g., "Button", "EditText"
    val bounds: Rect,
    val isClickable: Boolean,
    val depth: Int
)

data class Rect(val left: Int, val top: Int, val right: Int, val bottom: Int)

/**
 * Represents the current cognitive state of the AI Agent.
 */
sealed interface AgentState {
    object Idle : AgentState
    data class Thinking(val goal: String, val lastObservation: String) : AgentState
    data class Acting(val action: String, val targetNodeId: String?) : AgentState
    data class Error(val message: String) : AgentState
}

sealed interface AgentIntent {
    data class ExecuteGoal(val goal: String) : AgentIntent
    object StopAgent : AgentIntent
}

// --- DISPATCHERS ---

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class AIDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class HardwareDispatcher

// --- REPOSITORY & LOGIC ---

/**
 * The Repository manages the orchestration between the Accessibility Service,
 * the Semantic Compressor, and the AI Inference Engine.
 */
interface AgentRepository {
    val state: StateFlow<AgentState>
    suspend fun processScreenAndAct(goal: String)
    suspend fun stop()
}

@Singleton
class AgentRepositoryImpl @Inject constructor(
    private val compressor: SemanticNodeCompressor,
    private val inferenceEngine: HardwareAcceleratedInferenceEngine,
    @AIDispatcher private val aiDispatcher: CoroutineDispatcher,
    @HardwareDispatcher private val hardwareDispatcher: CoroutineDispatcher
) : AgentRepository {

    private val _state = MutableStateFlow<AgentState>(AgentState.Idle)
    override val state: StateFlow<AgentState> = _state.asStateFlow()

    private var agentJob: Job? = null

    override suspend fun processScreenAndAct(goal: String) {
        // Structured Concurrency: Ensure previous tasks are cancelled
        agentJob?.cancelAndJoin()
        
        agentJob = CoroutineScope(aiDispatcher + SupervisorJob()).launch {
            try {
                _state.value = AgentState.Thinking(goal, "Analyzing screen...")

                // 1. Capture and Compress (Heavy CPU/Memory task)
                val semanticMap = withContext(aiDispatcher) {
                    compressor.compressCurrentScreen()
                }

                // 2. Inference (NPU/GPU intensive task)
                _state.value = AgentState.Thinking(goal, "Reasoning via NPU...")
                val decision = withContext(hardwareDispatcher) {
                    inferenceEngine.inferNextAction(semanticMap, goal)
                }

                // 3. Execute Action
                if (decision != null) {
                    _state.value = AgentState.Acting(decision.actionType, decision.targetId)
                    // In a real app, this would call back to the AccessibilityService
                    performAction(decision)
                }

                _state.value = AgentState.Idle
            } catch (e: CancellationException) {
                _state.value = AgentState.Idle
            } catch (e: Exception) {
                _state.value = AgentState.Error(e.message ?: "Unknown Error")
            }
        }
    }

    private suspend fun performAction(decision: AgentDecision) {
        // Implementation of actual AccessibilityNodeInfo.performAction()
        delay(500) // Simulate hardware latency
    }

    override suspend fun stop() {
        agentJob?.cancel()
        _state.value = AgentState.Idle
    }
}

data class AgentDecision(val actionType: String, val targetId: String?)

/**
 * The "Eyes": Responsible for traversing the massive Accessibility tree
 * and distilling it into a tiny, semantic JSON-like structure.
 */
class SemanticNodeCompressor @Inject constructor(
    @AIDispatcher private val aiDispatcher: CoroutineDispatcher
) {
    /**
     * Recursively traverses the Accessibility Tree.
     * Uses a depth-limited search to prevent token explosion.
     */
    suspend fun compressCurrentScreen(rootNode: AccessibilityNodeInfo? = null): List<SemanticNode> = 
        withContext(aiDispatcher) {
            val nodes = mutableListOf<SemanticNode>()
            // In a real implementation, the rootNode is provided by the AccessibilityService
            // We use a placeholder here for the logic demonstration
            traverse(rootNode, nodes, 0)
            nodes
        }

    private fun traverse(node: AccessibilityNodeInfo?, accumulator: MutableList<SemanticNode>, depth: Int) {
        if (node == null || depth > 10) return // Depth limit to prevent recursion hell

        // HEURISTIC: Only include nodes that are actually interactable or contain text
        val isRelevant = node.isClickable || node.isFocusable || !node.text.isNullOrEmpty() || !node.contentDescription.isNullOrEmpty()

        if (isRelevant) {
            accumulator.add(
                SemanticNode(
                    id = node.viewIdResourceName ?: "unknown_${node.hashCode()}",
                    text = node.text?.toString(),
                    description = node.contentDescription?.toString(),
                    role = node.className ?: "View",
                    bounds = Rect(node.boundsInScreen.left, node.boundsInScreen.top, node.boundsInScreen.right, node.boundsInScreen.bottom),
                    isClickable = node.isClickable,
                    depth = depth
                )
            )
        }

        // Recurse through children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            traverse(child, accumulator, depth + 1)
            // CRITICAL: AccessibilityNodeInfo must be recycled to prevent massive memory leaks
            child?.recycle() 
        }
    }
}

/**
 * The "NPU Orchestrator": Manages the handoff to hardware-accelerated inference.
 */
interface HardwareAcceleratedInferenceEngine {
    suspend fun inferNextAction(nodes: List<SemanticNode>, goal: String): AgentDecision?
}

class NpuInferenceEngineImpl @Inject constructor(
    @HardwareDispatcher private val hardwareDispatcher: CoroutineDispatcher
) : HardwareAcceleratedInferenceEngine {
    override suspend fun inferNextAction(nodes: List<SemanticNode>, goal: String): AgentDecision? = 
        withContext(hardwareDispatcher) {
            // Here, we would interface with NNAPI or TFLite Delegate
            // simulate heavy NPU computation
            delay(800) 
            // Mocked decision logic
            if (nodes.isNotEmpty()) AgentDecision("CLICK", nodes.first().id) else null
        }
}

// --- VIEWMODEL (MVI PATTERN) ---

@HiltViewModel
class AgentOrchestratorViewModel @Inject constructor(
    private val repository: AgentRepository
) : ViewModel() {

    val state: StateFlow<AgentState> = repository.state

    fun onIntent(intent: AgentIntent) {
        viewModelScope.launch {
            when (intent) {
                is AgentIntent.ExecuteGoal -> repository.processScreenAndAct(intent.goal)
                is AgentIntent.StopAgent -> repository.stop()
            }
        }
    }
}

// --- DI MODULE ---

@Module
@InstallIn(SingletonComponent::class)
object AgentModule {

    @Provides
    @Singleton
    @AIDispatcher
    fun provideAiDispatcher(): CoroutineDispatcher = Dispatchers.Default

    @Provides
    @Singleton
    @HardwareDispatcher
    fun provideHardwareDispatcher(): CoroutineDispatcher = Dispatchers.Default // In production, a custom thread pool for NPU/GPU

    @Provides
    @Singleton
    fun provideRepository(
        compressor: SemanticNodeCompressor,
        inferenceEngine: HardwareAcceleratedInferenceEngine,
        @AIDispatcher ai: CoroutineDispatcher,
        @HardwareDispatcher hw: CoroutineDispatcher
    ): AgentRepository = AgentRepositoryImpl(compressor, inferenceEngine, ai, hw)

    @Provides
    @Singleton
    fun provideInferenceEngine(@HardwareDispatcher hw: CoroutineDispatcher): HardwareAcceleratedInferenceEngine = 
        NpuInferenceEngineImpl(hw)
}
