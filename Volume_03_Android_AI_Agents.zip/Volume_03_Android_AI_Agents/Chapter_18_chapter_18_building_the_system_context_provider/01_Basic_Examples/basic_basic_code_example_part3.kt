
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.kt
// Description: Basic Code Example
// ==========================================

// --- DEPENDENCIES (build.gradle.kts) ---
// implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
// implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
// implementation("com.google.dagger:hilt-android:2.50")
// kapt("com.google.dagger:hilt-compiler:2.50")

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

// 1. DATA MODEL
data class SystemContext(
    val batteryLevel: Int,
    val isCharging: Boolean,
    val connectionType: ConnectionType,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ConnectionType { WIFI, CELLULAR, NONE, UNKNOWN }

// 2. ABSTRACTION (The Interface)
interface SystemContextProvider {
    fun observeContext(): Flow<SystemContext>
}

// 3. IMPLEMENTATION (The Sensory Logic)
class AndroidSystemContextProvider @Inject constructor(
    private val context: Context
) : SystemContextProvider {

    override fun observeContext(): Flow<SystemContext> = flow {
        while (true) {
            emit(captureCurrentContext())
            // Poll every 5 seconds for this basic example.
            // In production, use callbackFlow for event-driven updates.
            delay(5000) 
        }
    }.flowOn(Dispatchers.Default) // Ensure heavy system calls don't block Main

    private fun captureCurrentContext(): SystemContext {
        val batteryStatus: Intent? = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        
        val level = batteryStatus?.let {
            val l = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val s = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (l != -1 && s != -1) (l * 100 / s.toFloat()).toInt() else 0
        } ?: 0

        val charging = batteryStatus?.let {
            val s = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL
        } ?: false

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val type = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> ConnectionType.WIFI
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> ConnectionType.CELLULAR
            else -> ConnectionType.NONE
        }

        return SystemContext(level, charging, type)
    }
}

// 4. DI MODULE
@Module
@InstallIn(SingletonComponent::class)
object ContextModule {
    @Provides
    @Singleton
    fun provideContextProvider(@ApplicationContext context: Context): SystemContextProvider {
        return AndroidSystemContextProvider(context)
    }
}

// 5. REPOSITORY (The Single Source of Truth)
@Singleton
class ContextRepository @Inject constructor(
    private val provider: SystemContextProvider
) {
    // Expose a hot Flow that multiple parts of the app can subscribe to
    val contextFlow: StateFlow<SystemContext?> = provider.observeContext()
        .stateIn(
            scope = kotlinx.coroutines.GlobalScope, // In real apps, use a custom ApplicationScope
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
}

// 6. VIEWMODEL (The Agent's Brain Interface)
@HiltViewModel
class AgentViewModel @Inject constructor(
    private val repository: ContextRepository
) : ViewModel() {

    // UI-ready state
    val uiState: StateFlow<SystemContext?> = repository.contextFlow

    fun getPromptContext(): String {
        val current = uiState.value ?: return "No context available."
        return """
            Current Device State:
            - Battery: ${current.batteryLevel}% (${if (current.isCharging) "Charging" else "Discharging"})
            - Network: ${current.connectionType}
            - Time: ${current.timestamp}
        """.trimIndent()
    }
}

// 7. UI (Jetpack Compose)
@Composable
fun ContextDashboardScreen(viewModel: AgentViewModel) {
    // collectAsStateWithLifecycle is the modern, lifecycle-aware way to collect flows in Compose
    val context by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "AI Agent Sensory Input", style = MaterialTheme.typography.headlineMedium)
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (context == null) {
                    CircularProgressIndicator()
                } else {
                    context?.let {
                        Text("🔋 Battery: ${it.batteryLevel}%")
                        Text("🔌 Charging: ${it.isCharging}")
                        Text("🌐 Network: ${it.connectionType}")
                        Text("🕒 Last Update: ${it.timestamp}")
                    }
                }
            }
        }

        Button(
            onClick = { /* In a real app, this triggers the LLM call */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Generate Agent Prompt")
        }
        
        // Debug view to see the "Prompt" the agent would see
        Text(
            text = "Prompt Preview:\n${viewModel.getPromptContext()}",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
