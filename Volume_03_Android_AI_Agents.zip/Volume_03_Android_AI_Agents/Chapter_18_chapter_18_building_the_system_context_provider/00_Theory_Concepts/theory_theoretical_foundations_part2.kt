
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.kt
// Description: Theoretical Foundations
// ==========================================

// Using the modern context receiver pattern
// This function can only be called when a SystemContextState is available in the scope.

context(SystemContextState)
fun performSmartAction(action: AgentAction) {
    if (isLowPowerMode && action.isHeavyTask) {
        // Automatically defer or downgrade the task if the context says so
        println("Deferring ${action.name} due to low power mode.")
        return
    }
    
    println("Executing ${action.name} in app: $activeApp")
    // The logic can directly access 'activeApp' and 'uiHierarchySummary'
    // without them being explicitly passed as arguments.
}

// Usage Example
suspend fun runAgentLoop(provider: SystemContextProvider) {
    provider.contextStream.collect { currentState ->
        // We "provide" the context to the scope of the block
        with(currentState) {
            performSmartAction(AgentAction.SUMMARIZE_SCREEN)
        }
    }
}
