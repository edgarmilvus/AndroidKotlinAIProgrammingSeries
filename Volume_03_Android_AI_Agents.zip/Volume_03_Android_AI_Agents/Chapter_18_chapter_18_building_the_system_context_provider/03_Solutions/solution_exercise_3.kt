
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import dagger.hilt.android.EntryPoint
import dagger.hilt.android.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

data class ScreenElement(
    val className: String,
    val text: String?,
    val isClickable: Boolean,
    val bounds: Rect
)

data class ScreenSnapshot(val elements: List<ScreenElement>)

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AccessibilityServiceEntryPoint {
    fun getScreenFlow(): MutableSharedFlow<ScreenSnapshot>
}

class ScreenContextProvider : AccessibilityService() {

    private val _screenFlow = MutableSharedFlow<ScreenSnapshot>(replay = 1)
    val screenFlow = _screenFlow.asSharedFlow()

    override fun onServiceConnected() {
        super.onServiceConnected()
        // In a real Hilt setup, we use EntryPointAccessors because 
        // AccessibilityService is instantiated by the OS, not Hilt.
        // For this exercise, we assume the flow is managed via an EntryPoint.
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rootNode = rootInActiveWindow ?: return
        val elements = mutableListOf<ScreenElement>()
        
        traverseTree(rootNode, elements)
        
        _screenFlow.tryEmit(ScreenSnapshot(elements))
        
        // CRITICAL: The system recycles nodes. We must not hold references.
        rootNode.recycle()
    }

    private fun traverseTree(node: AccessibilityNodeInfo, elements: MutableList<ScreenElement>) {
        // Semantic Pruning: Only collect nodes that are interactive or have text
        val hasText = !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
        val isInteractive = node.isClickable || node.isFocusable

        if (hasText || isInteractive) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            
            elements.add(
                ScreenElement(
                    className = node.className.toString(),
                    text = node.text?.toString() ?: node.contentDescription?.toString(),
                    isClickable = node.isClickable,
                    bounds = bounds
                )
            )
        }

        // Recursive traversal
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseTree(child, elements)
            child.recycle() // Recycle child immediately after processing
        }
    }

    override fun onInterrupt() {}
}
