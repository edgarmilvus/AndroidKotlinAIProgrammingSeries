
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

data class ScoredElement(
    val element: ScreenElement,
    val importanceScore: Int
)

class SemanticPruner(private val maxTokenChars: Int = 1000) {

    fun prune(rawElements: List<ScreenElement>): String {
        // 1. Calculate Importance Scores
        val scoredElements = rawElements.map { element ->
            var score = 0
            if (element.isClickable) score += 50
            if (!element.text.isNullOrBlank()) score += 30
            // Heuristic: Elements with text are usually more important than icons
            scoredElements.add(ScoredElement(element, score))
        }

        // 2. Sort by Importance (Descending)
        val sortedElements = scoredElements.sortedByDescending { it.importanceScore }

        // 3. Select Top N elements that fit within character budget
        val selectedElements = mutableListOf<ScoredElement>()
        var currentLength = 0

        for (scored in sortedElements) {
            val elementString = formatElement(scored.element)
            if (currentLength + elementString.length <= maxTokenChars) {
                selectedElements.add(scored)
                currentLength += elementString.length
            } else {
                break // Budget exhausted
            }
        }

        // 4. Convert to final Markdown format
        return selectedElements.joinToString("\n") { formatElement(it.element) }
    }

    private fun formatElement(el: ScreenElement): String {
        val textPart = if (!el.text.isNullOrBlank()) "\"${el.text}\"" else ""
        val typePart = el.className.split(".").last() // e.g., "Button"
        val interaction = if (el.isClickable) "[Clickable]" else ""
        return "- [$typePart: $textPart $interaction | Bounds: ${el.bounds}]"
    }
}
