
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.await
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

// 1. Data Models
data class LocationSnapshot(
    val latitude: Double,
    val longitude: Double,
    val description: String
)

data class EnvironmentalSnapshot(
    val currentTime: String, // ISO-8601
    val timeZone: String,
    val location: LocationSnapshot?
)

// 2. Interface
interface ContextProvider<T> {
    suspend fun provideContext(): T
}

// 3. Implementation
@Singleton
class EnvironmentContextProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val fusedLocationClient: FusedLocationProviderClient
) : ContextProvider<EnvironmentalSnapshot> {

    @SuppressLint("MissingPermission") // In production, check permissions before calling
    override suspend fun provideContext(): EnvironmentalSnapshot {
        val now = Clock.System.now()
        val tz = TimeZone.currentSystemDefault()
        val isoTimestamp = now.toString() // ISO-8601 by default in kotlinx-datetime

        // Fetch last known location asynchronously using Coroutines + Play Services Tasks
        val location = try {
            val lastLoc = fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                null
            ).await()
            
            lastLoc?.let {
                LocationSnapshot(
                    latitude = it.latitude,
                    longitude = it.longitude,
                    description = "Lat: ${it.latitude}, Lon: ${it.longitude}" // Simplified for exercise
                )
            }
        } catch (e: Exception) {
            null // Fallback if location fails
        }

        return EnvironmentalSnapshot(
            currentTime = isoTimestamp,
            timeZone = tz.id,
            location = location
        )
    }
}
