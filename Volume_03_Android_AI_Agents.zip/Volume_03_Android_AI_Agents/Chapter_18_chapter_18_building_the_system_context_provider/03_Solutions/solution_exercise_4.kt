
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.time.Duration.Companion.milliseconds

data class SystemSnapshot(
    val environment: EnvironmentalSnapshot,
    val health: SystemHealthSnapshot,
    val screen: ScreenSnapshot,
    val capturedAt: Instant
)

@Singleton
class ContextAggregator @Inject constructor(
    private val envProvider: EnvironmentContextProvider,
    private val healthProvider: SystemHealthContextProvider,
    private val screenProvider: ScreenContextProvider // From Exercise 3
) {
    // Use a SupervisorJob so one failing provider doesn't kill the whole aggregator
    private val aggregatorScope = CoroutineScope(
        Dispatchers.Default + SupervisorJob() + CoroutineName("ContextAggregator")
    )

    val systemSnapshot: StateFlow<SystemSnapshot?> = combine(
        // Convert the one-shot provider to a flow
        flow { emit(envProvider.provideContext()) },
        healthProvider.observeHealth(),
        screenProvider.screenFlow
    ) { env, health, screen ->
        SystemSnapshot(
            environment = env,
            health = health,
            screen = screen,
            capturedAt = Instant.now()
        )
    }
    .sample(500.milliseconds) // Prevent overwhelming the LLM with rapid UI updates
    .catch { e -> 
        // Log error and emit null or a partial snapshot in a real app
        emit(null) 
    }
    .stateIn(
        scope = aggregatorScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )
}
