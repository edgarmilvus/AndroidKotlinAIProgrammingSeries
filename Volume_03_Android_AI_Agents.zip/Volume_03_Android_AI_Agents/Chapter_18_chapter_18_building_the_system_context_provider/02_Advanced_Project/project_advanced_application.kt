
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.kt
// Description: Advanced Application
// ==========================================

// Gradle Dependencies (Kotlin DSL)
/*
dependencies {
    implementation("com.google.dagger:hilt-android:2.51")
    kapt("com.google.dagger:hilt-compiler:2.51")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.camera:camera-core:1.3.1")
    implementation("org.tensorflow:tensorflow-lite-gpu:2.14.0") // For NPU/GPU acceleration
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")
}
*/

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Represents the unified semantic state of the Android device.
 * This is the "Single Source of Truth" for the AI Agent.
 */
data class SystemContext(
    val timestamp: Long = System.currentTimeMillis(),
    val screenSemantics: List<String> = emptyList(),
    val userActivity: ActivityState = ActivityState.STATIONARY,
    val deviceEnvironment: EnvironmentContext = EnvironmentContext(),
    val confidenceScore: Float = 1.0f
)

enum class ActivityState { STATIONARY, WALKING, DRIVING, RUNNING }

data class EnvironmentContext(
    val ambientLightLux: Float = 0f,
    val isCharging: Boolean = false
)

/**
 * Interface for individual context providers.
 * Each provider is responsible for one modality (Visual, Motion, System).
 */
interface ContextSource {
    val contextFlow: StateFlow<Boolean> // Indicates if the source is active/healthy
    fun observe(): Flow<Unit> // Trigger for updates
}

/**
 * Hardware-aware Vision Provider.
 * Uses NPU/GPU via TFLite to convert screen semantics into text.
 */
class VisualContextSource @Inject constructor(
    private val context: Context,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ContextSource {
    private val _isHealthy = MutableStateFlow(true)
    override val contextFlow = _isHealthy.asStateFlow()

    // In a real implementation, this would interface with MediaProjection 
    // and a TFLite model running on the NPU.
    override fun observe(): Flow<Unit> = flow {
        while (true) {
            emit(Unit)
            delay(500) // 2Hz sampling for visual semantics
        }
    }.flowOn(ioDispatcher)

    suspend fun getScreenSemantics(): List<String> = withContext(ioDispatcher) {
        // Simulate NPU-accelerated OCR/Object Detection
        // In production: TFLite Delegate (NPU/GPU) processing
        delay(100) 
        listOf("Button: 'Submit'", "Text: 'Total: $50.00'", "TextField: 'Search'")
    }
}

/**
 * Motion-aware Sensor Provider.
 * Translates raw accelerometer data into semantic ActivityStates.
 */
class MotionContextSource @Inject constructor(
    private val sensorManager: SensorManager,
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default
) : ContextSource, SensorEventListener {
    
    private val _activityState = MutableStateFlow(ActivityState.STATIONARY)
    override val contextFlow = MutableStateFlow(true)

    override fun observe(): Flow<Unit> = flow {
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this@MotionContextSource, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        while (true) {
            emit(Unit)
            delay(1000)
        }
    }.flowOn(defaultDispatcher)

    fun getActivity(): ActivityState = _activityState.value

    override fun onSensorChanged(event: SensorEvent?) {
        // Logic to determine ActivityState from raw accelerometer/gyroscope
        // This would typically use a lightweight on-device ML model
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

/**
 * The Orchestrator: The core engine that fuses multimodal data.
 * Implements the Repository pattern to provide a clean API to the ViewModel.
 */
@Singleton
class ContextRepository @Inject constructor(
    private val visualSource: VisualContextSource,
    private val motionSource: MotionContextSource,
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    /**
     * Fuses multiple flows into a single, high-level SystemContext.
     * Uses 'combine' to ensure that any change in any source triggers a re-evaluation.
     */
    val systemContext: StateFlow<SystemContext> = combine(
        visualSource.observe(),
        motionSource.observe()
    ) { _, _ ->
        // We use a supervisorScope to ensure that a failure in one provider 
        // (e.g., Camera permission denied) doesn't kill the entire orchestration.
        supervisorScope {
            val semantics = async(ioDispatcher) { visualSource.getScreenSemantics() }
            val activity = async(defaultDispatcher) { motionSource.getActivity() }

            SystemContext(
                screenSemantics = semantics.await(),
                userActivity = activity.await(),
                confidenceScore = calculateConfidence(visualSource, motionSource)
            )
        }
    }.stateIn(
        scope = CoroutineScope(defaultDispatcher + SupervisorJob()),
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SystemContext()
    )

    private fun calculateConfidence(v: ContextSource, m: ContextSource): Float {
        // Heuristic to determine how much the Agent should trust the current context
        return if (v.contextFlow.value && m.contextFlow.value) 1.0f else 0.5f
    }
}

/**
 * ViewModel following MVI/MVVM principles.
 * Exposes the context to the UI or the Agent's decision-making loop.
 */
@HiltViewModel
class AgentContextViewModel @Inject constructor(
    private val repository: ContextRepository
) : ViewModel() {

    // The UI or the Agent observes this state
    val uiState: StateFlow<SystemContext> = repository.systemContext
        .onEach { /* Log context for debugging/telemetry */ }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SystemContext()
        )

    fun getContextForPrompt(): String {
        val current = uiState.value
        return """
            Current Context:
            - Activity: ${current.userActivity}
            - Screen Elements: ${current.screenSemantics.joinToString(", ")}
            - Confidence: ${current.confidenceScore}
        """.trimIndent()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object ContextModule {
    @Provides
    @Singleton
    fun provideSensorManager(@ApplicationContext context: Context): SensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    @Provides
    @Singleton
    fun provideDefaultDispatcher(): CoroutineDispatcher = Dispatchers.Default

    @Provides
    @Singleton
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO
}
