
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.kt
// Description: Theoretical Foundations
// ==========================================

/**
 * Represents a capability the AI Agent can invoke.
 * Just like CameraX abstracts the camera hardware, 
 * this abstracts a system capability.
 */
interface AgentTool<T> {
    val name: String
    val description: String // This is sent to the LLM so it knows when to use the tool
    val parameters: ToolParameters // JSON schema of required arguments

    suspend fun execute(args: Map<String, Any>): T
}

// Example implementation for Calendar access
class CalendarTool @Inject constructor(
    private val calendarRepository: CalendarRepository
) : AgentTool<List<Event>> {
    override val name = "get_calendar_events"
    override val description = "Retrieves upcoming calendar events for a specific date range."
    override val parameters = ToolParameters(
        "startDate" to ParameterType.STRING,
        "endDate" to ParameterType.STRING
    )

    override suspend fun execute(args: Map<String, Any>): List<Event> {
        val start = args["startDate"] as String
        val end = args["endDate"] as String
        return calendarRepository.getEvents(start, end)
    }
}
