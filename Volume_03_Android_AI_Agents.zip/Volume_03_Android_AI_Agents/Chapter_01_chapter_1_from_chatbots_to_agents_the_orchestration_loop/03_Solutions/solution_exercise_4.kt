
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.kt
// Description: Solution for Exercise 4
// ==========================================

import androidx.lifecycle.*
import kotlinx.coroutines.flow.*
import java.util.UUID

sealed interface TransactionState {
    object Idle : TransactionState
    data class PendingConfirmation(val transactionId: String, val amount: Double, val recipient: String) : TransactionState
    object Executing : TransactionState
    data class Completed(val message: String) : TransactionState
}

@HiltViewModel
class FinancialAgentViewModel(
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _state = MutableStateFlow<TransactionState>(TransactionState.Idle)
    val state: StateFlow<TransactionState> = _state

    // Secure buffer for pending calls
    private var pendingCall: PendingToolCall? = null

    data class PendingToolCall(val id: String, val amount: Double, val recipient: String)

    fun onLlmRequestTool(toolName: String, args: Map<String, Any>) {
        if (toolName == "transfer_funds") {
            val amount = args["amount"] as Double
            val recipient = args["recipient"] as String
            val txId = UUID.randomUUID().toString()
            
            pendingCall = PendingToolCall(txId, amount, recipient)
            // Save to SavedStateHandle to survive process death
            savedStateHandle["pending_tx"] = txId 
            
            _state.value = TransactionState.PendingConfirmation(txId, amount, recipient)
        }
    }

    fun confirmTransaction() {
        val call = pendingCall ?: return
        _state.value = TransactionState.Executing
        
        // Actual execution logic
        val result = executeSecureTransfer(call.amount, call.recipient)
        
        pendingCall = null
        savedStateHandle.remove<String>("pending_tx")
        _state.value = TransactionState.Completed(result)
    }

    private fun executeSecureTransfer(amount: Double, recipient: String): String {
        return "Successfully transferred $$amount to $recipient"
    }
}
