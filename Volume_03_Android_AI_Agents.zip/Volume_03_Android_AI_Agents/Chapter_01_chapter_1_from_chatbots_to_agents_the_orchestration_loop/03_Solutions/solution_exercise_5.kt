
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.kt
// Description: Solution for Exercise 5
// ==========================================

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap

class ContextManager(private val tokenLimit: Int = 4000) {
    private val history = mutableListOf<Message>()

    fun addMessage(msg: Message) {
        history.add(msg)
        if (calculateTokens() > tokenLimit) {
            summarizeOldMessages()
        }
    }

    private fun summarizeOldMessages() {
        // Meta-loop: Use LLM to condense the first 50% of history
        val toSummarize = history.take(history.size / 2)
        val summary = "Summary of previous turns: [Condensed data...]" 
        
        // Remove old, add summary as a system message
        repeat(toSummarize.size) { history.removeAt(0) }
        history.add(0, Message(role = "system", content = summary))
    }

    private fun calculateTokens(): Int = history.sumOf { it.content.length / 4 } // Rough estimate
    fun getContext() = history.toList()
}

class ToolCache {
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val TTL = 10_000L // 10 seconds

    data class CacheEntry(val result: String, val timestamp: Long)

    fun get(key: String): String? {
        val entry = cache[key] ?: return null
        if (System.currentTimeMillis() - entry.timestamp > TTL) {
            cache.remove(key)
            return null
        }
        return entry.result
    }

    fun put(key: String, value: String) {
        cache[key] = CacheEntry(value, System.currentTimeMillis())
    }
}

class HighPerfAgent(
    private val contextManager: ContextManager,
    private val toolCache: ToolCache
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Asynchronous Observation: Tools can "push" updates
    val asyncObservations = MutableSharedFlow<String>()

    fun startObservationLoop() {
        scope.launch {
            asyncObservations.collect { observation ->
                // Trigger the orchestration loop automatically when a decision is detected
                if (observation.contains("DECISION")) {
                    runOrchestrationLoop("A decision was reached: $observation")
                }
            }
        }
    }

    private suspend fun runOrchestrationLoop(prompt: String) {
        withContext(Dispatchers.Default) {
            // Implementation of the loop using contextManager.getContext() 
            // and checking toolCache before executing tools.
        }
    }
}

data class Message(val role: String, val content: String)
