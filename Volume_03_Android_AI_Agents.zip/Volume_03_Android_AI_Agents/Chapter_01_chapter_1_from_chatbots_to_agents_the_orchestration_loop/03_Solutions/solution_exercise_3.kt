
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.kt
// Description: Solution for Exercise 3
// ==========================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class Flight(val flightId: String, val price: Int)
data class Hotel(val hotelId: String, val name: String)

class TravelAgentViewModel @Inject constructor(
    private val llmClient: MockLlmClient,
    private val toolRegistry: TravelToolRegistry
) : ViewModel() {

    // Working Memory to track IDs across loop turns
    private val sessionMemory = mutableMapOf<String, String>()

    fun handleTravelRequest(request: String) {
        viewModelScope.launch {
            var currentPrompt = request
            var iterations = 0
            
            while (iterations < 10) {
                val response = llmClient.generateResponse(currentPrompt, toolRegistry.getDefinitions())
                
                if (response.toolCalls == null) {
                    // Final answer reached
                    break 
                }

                // Parallel Tool Execution
                val observations = response.toolCalls!!.map { call ->
                    async(Dispatchers.IO) {
                        val result = toolRegistry.execute(call.name, call.args)
                        // Store result in memory if it's an ID
                        if (result.contains("id:")) {
                            val id = result.substringAfter("id:").trim()
                            sessionMemory[call.name] = id
                        }
                        result
                    }
                }.awaitAll()

                currentPrompt = "Observations: ${observations.joinToString("\n")}. Please proceed."
                iterations++
            }
        }
    }
}

class TravelToolRegistry {
    fun execute(name: String, args: Map<String, Any>): String {
        return when (name) {
            "search_flights" -> {
                val price = args["max_price"] as Int
                if (price < 500) "No flights found under $price. Try increasing budget." 
                else "Flight found! id:FL123, Price: $600"
            }
            "search_hotels" -> "Hotel found! id:HT456, Name: Shinjuku Prince"
            "add_to_itinerary" -> {
                val fId = args["flightId"] ?: return "Error: Missing flightId"
                val hId = args["hotelId"] ?: return "Error: Missing hotelId"
                "Success: Itinerary created with Flight $fId and Hotel $hId."
            }
            else -> "Unknown tool"
        }
    }
    fun getDefinitions() = listOf(/* ... Tool definitions ... */)
}
