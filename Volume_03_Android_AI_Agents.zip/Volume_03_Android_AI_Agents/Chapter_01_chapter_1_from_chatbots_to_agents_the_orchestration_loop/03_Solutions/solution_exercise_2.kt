
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.kt
// Description: Solution for Exercise 2
// ==========================================

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

// --- Screen State Management ---
data class ProductScreenState(
    val productId: String = "",
    val productName: String = "",
    val price: Double = 0.0,
    val specs: Map<String, String> = emptyMap(),
    val topReviews: List<String> = emptyList()
)

@Singleton
class ScreenStateProvider @Inject constructor() {
    private val _currentState = MutableStateFlow(ProductScreenState())
    val currentState: StateFlow<ProductScreenState> = _currentState

    fun updateState(state: ProductScreenState) {
        _currentState.value = state
    }
}

// --- Context-Aware ViewModel ---
@HiltViewModel
class ProductAssistantViewModel @Inject constructor(
    private val screenStateProvider: ScreenStateProvider,
    private val llmClient: MockLlmClient
) : ViewModel() {

    private val _chatResponse = MutableStateFlow("")
    val chatResponse: StateFlow<String> = _chatResponse

    fun askQuestion(question: String) {
        viewModelScope.launch {
            // 1. Semantic Mapping: Convert raw state to a concise string
            val state = screenStateProvider.currentState.value
            val contextBlock = """
                [CONTEXT: User is viewing '${state.productName}' (ID: ${state.productId}). 
                Price: $${state.price}. Specs: ${state.specs.entries.joinToString { "${it.key}: ${it.value}" }}. 
                Recent Reviews: ${state.topReviews.joinToString("; ")}]
            """.trimIndent()

            // 2. Context Injection: Prefix the prompt
            val fullPrompt = "$contextBlock\nUser Question: $question"
            
            val response = llmClient.generateResponse(fullPrompt, emptyList())
            _chatResponse.value = response.text ?: "I'm not sure about that."
        }
    }
}

// --- Compose Integration ---
@Composable
fun ProductDetailScreen(
    product: ProductScreenState,
    viewModel: ProductAssistantViewModel,
    stateProvider: ScreenStateProvider
) {
    // Update the provider whenever the product changes
    LaunchedEffect(product) {
        stateProvider.updateState(product)
    }

    // ... UI implementation ...
}
