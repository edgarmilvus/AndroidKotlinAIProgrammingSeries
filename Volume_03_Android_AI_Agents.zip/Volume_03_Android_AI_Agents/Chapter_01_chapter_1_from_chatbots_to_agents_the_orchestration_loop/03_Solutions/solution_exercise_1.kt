
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.kt
// Description: Solution for Exercise 1
// ==========================================

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.Environment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// --- Domain Models ---
data class Tool(val name: String, val description: String, val parameters: String)

sealed interface AgentState {
    object Idle : AgentState
    object Thinking : AgentState
    data class CallingTool(val toolName: String) : AgentState
    data class Observing(val result: String) : AgentState
    data class Responding(val text: String) : AgentState
}

// --- Tool Registry ---
class ToolRegistry @Inject constructor(private val context: Context) {
    private val tools = mapOf<String, () -> String>(
        "get_battery_level" to {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val status = if (bm.isCharging) "Charging" else "Discharging"
            "Battery level is $level% and status is $status."
        },
        "get_storage_info" to {
            val stats = Environment.getDataDirectory().usableSpace
            val total = Environment.getDataDirectory().totalSpace
            "Available storage: ${stats / 1024 / 1024} MB / Total: ${total / 1024 / 1024} MB."
        },
        "get_network_type" to {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetwork
            if (activeNetwork == null) "Offline" else "Connected to Network"
        }
    )

    fun execute(toolName: String): String {
        return tools[toolName]?.invoke() ?: "Error: Tool $toolName not found."
    }

    fun getDefinitions(): List<Tool> = listOf(
        Tool("get_battery_level", "Returns the current battery percentage as an integer (0-100) and charging status.", "{}"),
        Tool("get_storage_info", "Returns available and total internal storage in MB.", "{}"),
        Tool("get_network_type", "Returns the current network connectivity status (Wi-Fi, 5G, or Offline).", "{}")
    )
}

// --- ViewModel Orchestrator ---
@HiltViewModel
class SystemAgentViewModel @Inject constructor(
    private val toolRegistry: ToolRegistry,
    private val llmClient: MockLlmClient // Assume a wrapper for Gemini/OpenAI
) : ViewModel() {

    private val _uiState = MutableStateFlow<AgentState>(AgentState.Idle)
    val uiState: StateFlow<AgentState> = _uiState

    fun processPrompt(userPrompt: String) {
        viewModelScope.launch {
            var currentPrompt = userPrompt
            var iterations = 0
            val maxIterations = 5
            var isFinalResponse = false

            while (!isFinalResponse && iterations < maxIterations) {
                _uiState.value = AgentState.Thinking
                
                // Step A: Send prompt + tool definitions
                val response = llmClient.generateResponse(
                    prompt = currentPrompt, 
                    tools = toolRegistry.getDefinitions()
                )

                if (response.toolCall != null) {
                    // Step B & C: Intercept and Execute
                    val toolName = response.toolCall!!
                    _uiState.value = AgentState.CallingTool(toolName)
                    
                    val observation = toolRegistry.execute(toolName)
                    _uiState.value = AgentState.Observing(observation)

                    // Step D: Feed observation back to LLM
                    currentPrompt = "Observation: $observation. Now answer the user's original request."
                    iterations++
                } else {
                    // Step E: Final Synthesis
                    _uiState.value = AgentState.Responding(response.text ?: "")
                    isFinalResponse = true
                }
            }
        }
    }
}

// Mock LLM Client for demonstration
data class LlmResponse(val text: String? = null, val toolCall: String? = null)
class MockLlmClient {
    fun generateResponse(prompt: String, tools: List<Tool>): LlmResponse {
        return if (prompt.contains("battery")) LlmResponse(toolCall = "get_battery_level")
        else LlmResponse(text = "Your system is healthy!")
    }
}
