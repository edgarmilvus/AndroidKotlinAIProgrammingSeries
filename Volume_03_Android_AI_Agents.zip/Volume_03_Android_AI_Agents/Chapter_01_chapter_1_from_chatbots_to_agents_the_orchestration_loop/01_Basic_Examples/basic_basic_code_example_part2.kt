
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.kt
// Description: Basic Code Example
// ==========================================

package com.example.aiagent.orchestration

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

// =============================================================================
// 1. DOMAIN MODELS
// =============================================================================

/**
 * Represents the different types of outputs the LLM can generate.
 * We use a sealed interface to ensure type-safety during the orchestration loop.
 */
sealed interface AgentStep {
    data class Thought(val content: String) : AgentStep
    data class Action(val toolName: String, val input: String) : AgentStep
    data class Observation(val result: String) : AgentStep
    data class FinalResponse(val message: String) : AgentStep
}

/**
 * A simple log entry to display the loop's progress in the UI.
 */
data class AgentLog(val step: AgentStep, val timestamp: Long = System.currentTimeMillis())

// =============================================================================
// 2. TOOL DEFINITIONS (The "Hands")
// =============================================================================

/**
 * Tool interface that all agent capabilities must implement.
 */
interface AgentTool {
    val name: String
    val description: String
    suspend fun execute(input: String): String
}

@Singleton
class HomeAutomationTool @Inject constructor() : AgentTool {
    override val name = "home_automation"
    override val description = "Can check temperature (input: 'get_temp') or toggle AC (input: 'ac_on' or 'ac_off')"

    override suspend fun execute(input: String): String {
        // Simulate hardware latency
        kotlinx.coroutines.delay(500) 
        return when (input) {
            "get_temp" -> "The current living room temperature is 28°C."
            "ac_on" -> "AC has been turned ON successfully."
            "ac_off" -> "AC has been turned OFF successfully."
            else -> "Error: Unknown command for home_automation tool."
        }
    }
}

// =============================================================================
// 3. THE ORCHESTRATOR (The "Brain")
// =============================================================================

class AgentOrchestrator @Inject constructor(
    private val tools: List<AgentTool>
) {
    /**
     * This is the core Orchestration Loop.
     * It manages the cycle of Thought -> Action -> Observation.
     */
    suspend fun runLoop(
        userInput: String,
        onStepGenerated: (AgentStep) -> Unit
    ): String {
        var currentContext = "User request: $userInput\n"
        var isTaskComplete = false
        var iterations = 0
        val maxIterations = 5 // Safety break to prevent infinite loops

        while (!isTaskComplete && iterations < maxIterations) {
            iterations++

            // STEP 1: THOUGHT & ACTION
            // In a real app, this is where you call the LLM (Gemini, GPT-4, etc.)
            // We simulate the LLM's decision-making process here.
            val llmDecision = simulateLLMCall(currentContext)
            onStepGenerated(llmDecision)

            when (llmDecision) {
                is AgentStep.FinalResponse -> {
                    isTaskComplete = true
                    return llmDecision.message
                }
                is AgentStep.Action -> {
                    // STEP 2: EXECUTE ACTION (The "Act" part of ReAct)
                    val tool = tools.find { it.name == llmDecision.toolName }
                    val observation = if (tool != null) {
                        tool.execute(llmDecision.input)
                    } else {
                        "Error: Tool ${llmDecision.toolName} not found."
                    }

                    // STEP 3: OBSERVATION
                    val obsStep = AgentStep.Observation(observation)
                    onStepGenerated(obsStep)
                    
                    // Append the observation to the context so the LLM can "see" it in the next iteration
                    currentContext += "\nThought: ${llmDecision}\nObservation: $observation"
                }
                is AgentStep.Thought -> {
                    currentContext += "\nThought: ${llmDecision.content}"
                }
                else -> {}
            }
        }
        return "I'm sorry, I couldn't complete the task within the allowed steps."
    }

    /**
     * MOCK LLM LOGIC
     * This replaces the actual API call to an LLM for demonstration purposes.
     * It mimics the reasoning process of an agent.
     */
    private fun simulateLLMCall(context: String): AgentStep {
        return when {
            context.contains("too hot") && !context.contains("28°C") -> 
                AgentStep.Thought("The user says it's too hot. I should check the current temperature first.")
            
            context.contains("too hot") && context.contains("28°C") && !context.contains("AC has been turned ON") -> 
                AgentStep.Action("home_automation", "ac_on")
            
            context.contains("AC has been turned ON") -> 
                AgentStep.FinalResponse("I've checked the temperature (it was 28°C) and turned on the AC for you.")
            
            // Default fallback to check temp if the user is vague
            !context.contains("28°C") -> 
                AgentStep.Action("home_automation", "get_temp")
            
            else -> AgentStep.FinalResponse("I'm not sure how to help with that.")
        }
    }
}

// =============================================================================
// 4. VIEWMODEL (The Android Glue)
// =============================================================================

class AgentViewModel @Inject constructor(
    private val orchestrator: AgentOrchestrator
) : ViewModel() {

    private val _logs = MutableStateFlow<List<AgentLog>>(emptyList())
    val logs: StateFlow<List<AgentLog>> = _logs.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun sendRequest(text: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            _logs.value = emptyList() // Clear previous session

            // Use Dispatchers.Default for AI orchestration to avoid blocking the Main thread
            val finalResult = withContext(Dispatchers.Default) {
                orchestrator.runLoop(text) { step ->
                    // Move UI updates back to the Main thread
                    viewModelScope.launch(Dispatchers.Main) {
                        _logs.value = _logs.value + AgentLog(step)
                    }
                }
            }

            _logs.value = _logs.value + AgentLog(AgentStep.FinalResponse(finalResult))
            _isProcessing.value = false
        }
    }
}

// =============================================================================
// 5. UI LAYER (Jetpack Compose)
// =============================================================================

@Composable
fun AgentScreen(viewModel: AgentViewModel) {
    var inputText by remember { mutableStateOf("") }
    val logs by viewModel.logs.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "AI Agent Orchestrator", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(logs) { log ->
                AgentLogItem(log)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("e.g., It's too hot in here") },
                enabled = !isProcessing
            )
            Button(
                onClick = { 
                    viewModel.sendRequest(inputText)
                    inputText = "" 
                },
                enabled = !isProcessing && inputText.isNotBlank(),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(if (isProcessing) "Thinking..." else "Send")
            }
        }
    }
}

@Composable
fun AgentLogItem(log: AgentLog) {
    val (color, label) = when (log.step) {
        is AgentStep.Thought -> androidx.compose.ui.graphics.Color.Gray to "THOUGHT"
        is AgentStep.Action -> androidx.compose.ui.graphics.Color.Blue to "ACTION"
        is AgentStep.Observation -> androidx.compose.ui.graphics.Color(0xFF388E3C) to "OBSERVATION"
        is AgentStep.FinalResponse -> androidx.compose.ui.graphics.Color.Magenta to "FINAL"
    }

    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = color)
            Text(
                text = when (val s = log.step) {
                    is AgentStep.Thought -> s.content
                    is AgentStep.Action -> "Calling ${s.toolName} with ${s.input}"
                    is AgentStep.Observation -> s.result
                    is AgentStep.FinalResponse -> s.message
                },
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// =============================================================================
// 6. ACTIVITY & DI SETUP
// =============================================================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Manual DI for the sake of a single-file example
        // In a real app, use @HiltAndroidApp and @AndroidEntryPoint
        val tool = HomeAutomationTool()
        val orchestrator = AgentOrchestrator(listOf(tool))
        val viewModel = AgentViewModel(orchestrator)

        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AgentScreen(viewModel)
                }
            }
        }
    }
}
