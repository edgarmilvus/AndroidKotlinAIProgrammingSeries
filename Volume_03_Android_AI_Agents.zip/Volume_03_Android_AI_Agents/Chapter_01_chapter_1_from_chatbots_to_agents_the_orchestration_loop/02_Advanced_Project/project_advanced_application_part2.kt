
/*
#
# These sources are part of the "Android Kotlin & AI Masterclass Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/AndroidKotlinAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.kt
// Description: Advanced Application
// ==========================================

package com.ai.agent.orchestration

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.AndroidInjection
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.Inject
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject as HiltInject
import javax.inject.Singleton

/**
 * Represents the current state of the Agent's orchestration loop.
 */
data class AgentUiState(
    val userQuery: String = "",
    val agentThoughts: List<String> = emptyList(),
    val isProcessing: Boolean = false,
    val finalResponse: String? = null,
    val error: String? = null
)

/**
 * Sealed class for LLM responses to distinguish between a final answer 
 * and a request to call a system tool.
 */
sealed class AgentAction {
    data class ToolCall(val functionName: String, val parameters: Map<String, Any>) : AgentAction()
    data class FinalResponse(val text: String) : AgentAction()
}

/**
 * Interface for a Tool that the Agent can execute.
 */
interface AgentTool {
    val name: String
    val description: String
    suspend fun execute(params: Map<String, Any>): String
}

/**
 * Real-world Tool implementation: Battery Monitor.
 * Demonstrates hardware-aware data retrieval.
 */
class BatteryTool @HiltInject constructor(
    @ApplicationContext private val context: Context
) : AgentTool {
    override val name = "get_battery_status"
    override val description = "Returns the current battery percentage and charging status."

    override suspend fun execute(params: Map<String, Any>): String = withContext(Dispatchers.IO) {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = if (bm.isCharging) "Charging" else "Discharging"
        "Battery level is $level% and status is $status."
    }
}

/**
 * The ToolRegistry manages the mapping between LLM function names and Kotlin code.
 */
@Singleton
class ToolRegistry @HiltInject constructor(
    private val batteryTool: BatteryTool
    // Other tools like WifiTool, ScreenAwarenessTool would be injected here
) {
    private val tools = mapOf(batteryTool.name to batteryTool)

    suspend fun callTool(name: String, params: Map<String, Any>): String {
        val tool = tools[name] ?: return "Error: Tool $name not found."
        return tool.execute(params)
    }

    fun getToolDefinitions(): List<AgentTool> = tools.values.toList()
}

/**
 * The AgentOrchestrator is the heart of the "Orchestration Loop".
 * It handles the iterative process of Reason -> Act -> Observe.
 */
@Singleton
class AgentOrchestrator @HiltInject constructor(
    private val toolRegistry: ToolRegistry,
    // In a real app, this would be an AICore or Gemini client
    private val aiClient: GenerativeModelClient 
) {
    suspend fun runLoop(
        initialQuery: String,
        onThought: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.Default) {
        var currentContext = "User Goal: $initialQuery\n"
        var loopCount = 0
        val maxLoops = 5 // Prevent infinite loops

        try {
            while (loopCount < maxLoops) {
                loopCount++
                
                // 1. REASONING PHASE
                // We prompt the LLM to either provide a tool call or a final answer.
                onThought("Thinking... (Iteration $loopCount)")
                val response = aiClient.generateAction(currentContext, toolRegistry.getToolDefinitions())

                when (response) {
                    is AgentAction.FinalResponse -> {
                        return@withContext Result.success(response.text)
                    }
                    is AgentAction.ToolCall -> {
                        // 2. ACTING PHASE
                        onThought("Executing tool: ${response.functionName}")
                        
                        // Execute the tool on the appropriate dispatcher (IO)
                        val observation = toolRegistry.callTool(response.functionName, response.parameters)
                        
                        // 3. OBSERVATION PHASE
                        // Append the tool result back into the context for the next iteration.
                        currentContext += "\nAction: ${response.functionName}\nObservation: $observation\n"
                        onThought("Observation received: $observation")
                    }
                }
            }
            Result.failure(Exception("Max orchestration loops reached without final answer."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * ViewModel implementing MVI to bridge the Orchestrator with the UI.
 */
@HiltViewModel
class AgentViewModel @HiltInject constructor(
    private val orchestrator: AgentOrchestrator
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgentUiState())
    val uiState: StateFlow<AgentUiState> = _uiState.asStateFlow()

    fun handleIntent(query: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(
                userQuery = query, 
                isProcessing = true, 
                agentThoughts = emptyList(), 
                finalResponse = null, 
                error = null 
            ) }

            // Structured Concurrency: The loop runs in the background
            val result = orchestrator.runLoop(query) { thought ->
                _uiState.update { it.copy(agentThoughts = it.agentThoughts + thought) }
            }

            result.onSuccess { response ->
                _uiState.update { it.copy(finalResponse = response, isProcessing = false) }
            }.onFailure { error ->
                _uiState.update { it.copy(error = error.message, isProcessing = false) }
            }
        }
    }
}

// Mock Client for demonstration purposes
class GenerativeModelClient @HiltInject constructor() {
    suspend fun generateAction(context: String, tools: List<AgentTool>): AgentAction {
        delay(1000) // Simulate NPU latency
        return if (context.contains("Battery")) {
            AgentAction.ToolCall("get_battery_status", emptyMap())
        } else {
            AgentAction.FinalResponse("I've analyzed your request and everything looks good!")
        }
    }
}
